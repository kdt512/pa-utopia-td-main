"use strict";
var e = require("util"), t = require("stream"), a = require("path"), n = require("http"), i = require("https"), s = require("url"), o = require("fs"), r = require("assert"), c = require("zlib"), l = require("events");
function p(e) {
    return e && "object" == typeof e && "default" in e ? e : {
    default:
        e
    }
}
var u = p(e), d = p(t), h = p(a), m = p(n), f = p(i), _ = p(s), E = p(o), g = p(r), b = p(c), x = p(l), T = "undefined" != typeof globalThis ? globalThis : "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {}, v = {};
exports.exec3xAdapter = void 0, Object.defineProperty(v, "__esModule", {
    value: !0
});
var A = u.default, y = d.default, w = h.default, S = m.default, N = f.default, C = _.default, I = E.default, k = g.default, R = b.default, O = x.default;
function D(e) {
    return e && "object" == typeof e && "default" in e ? e : {
    default:
        e
    }
}
var L = D(A), M = D(y), P = D(w), B = D(S), U = D(N), F = D(C), H = D(I), j = D(k), z = D(R), G = D(O);
function q(e, t) {
    return function () {
        return e.apply(t, arguments)
    }
}
const {
    toString: Y
} = Object.prototype, {
    getPrototypeOf: V
} = Object, Q = (W = Object.create(null), e => {
    const t = Y.call(e);
    return W[t] || (W[t] = t.slice(8, -1).toLowerCase())
});
var W;
const K = e => (e = e.toLowerCase(), t => Q(t) === e), Z = e => t => typeof t === e, {
    isArray: X
} = Array, $ = Z("undefined"), J = K("ArrayBuffer"), ee = Z("string"), te = Z("function"), ae = Z("number"), ne = e => null !== e && "object" == typeof e, ie = e => {
    if ("object" !== Q(e))
        return !1;
    const t = V(e);
    return !(null !== t && t !== Object.prototype && null !== Object.getPrototypeOf(t) || Symbol.toStringTag in e || Symbol.iterator in e)
}, se = K("Date"), oe = K("File"), re = K("Blob"), ce = K("FileList"), le = K("URLSearchParams");
function pe(e, t, {
    allOwnKeys: a = !1
} = {}) {
    if (null == e)
        return;
    let n,
    i;
    if ("object" != typeof e && (e = [e]), X(e))
        for (n = 0, i = e.length; n < i; n++)
            t.call(null, e[n], n, e);
    else {
        const i = a ? Object.getOwnPropertyNames(e) : Object.keys(e),
        s = i.length;
        let o;
        for (n = 0; n < s; n++)
            o = i[n], t.call(null, e[o], o, e)
    }
}
const ue = (de = "undefined" != typeof Uint8Array && V(Uint8Array), e => de && e instanceof de);
var de;
const he = K("HTMLFormElement"), me = (({
        hasOwnProperty: e
    }) => (t, a) => e.call(t, a))(Object.prototype), fe = K("RegExp"), _e = (e, t) => {
    const a = Object.getOwnPropertyDescriptors(e),
    n = {};
    pe(a, ((a, i) => {
            !1 !== t(a, i, e) && (n[i] = a)
        })),
    Object.defineProperties(e, n)
};
var Ee = {
    isArray: X,
    isArrayBuffer: J,
    isBuffer: function (e) {
        return null !== e && !$(e) && null !== e.constructor && !$(e.constructor) && te(e.constructor.isBuffer) && e.constructor.isBuffer(e)
    },
    isFormData: e => {
        const t = "[object FormData]";
        return e && ("function" == typeof FormData && e instanceof FormData || Y.call(e) === t || te(e.toString) && e.toString() === t)
    },
    isArrayBufferView: function (e) {
        let t;
        return t = "undefined" != typeof ArrayBuffer && ArrayBuffer.isView ? ArrayBuffer.isView(e) : e && e.buffer && J(e.buffer),
        t
    },
    isString: ee,
    isNumber: ae,
    isBoolean: e => !0 === e || !1 === e,
    isObject: ne,
    isPlainObject: ie,
    isUndefined: $,
    isDate: se,
    isFile: oe,
    isBlob: re,
    isRegExp: fe,
    isFunction: te,
    isStream: e => ne(e) && te(e.pipe),
    isURLSearchParams: le,
    isTypedArray: ue,
    isFileList: ce,
    forEach: pe,
    merge: function e() {
        const t = {},
        a = (a, n) => {
            ie(t[n]) && ie(a) ? t[n] = e(t[n], a) : ie(a) ? t[n] = e({}, a) : X(a) ? t[n] = a.slice() : t[n] = a
        };
        for (let e = 0, t = arguments.length; e < t; e++)
            arguments[e] && pe(arguments[e], a);
        return t
    },
    extend: (e, t, a, {
        allOwnKeys: n
    } = {}) => (pe(t, ((t, n) => {
                a && te(t) ? e[n] = q(t, a) : e[n] = t
            }), {
            allOwnKeys: n
        }), e),
    trim: e => e.trim ? e.trim() : e.replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, ""),
    stripBOM: e => (65279 === e.charCodeAt(0) && (e = e.slice(1)), e),
    inherits: (e, t, a, n) => {
        e.prototype = Object.create(t.prototype, n),
        e.prototype.constructor = e,
        Object.defineProperty(e, "super", {
            value: t.prototype
        }),
        a && Object.assign(e.prototype, a)
    },
    toFlatObject: (e, t, a, n) => {
        let i,
        s,
        o;
        const r = {};
        if (t = t || {}, null == e)
            return t;
        do {
            for (i = Object.getOwnPropertyNames(e), s = i.length; s-- > 0; )
                o = i[s], n && !n(o, e, t) || r[o] || (t[o] = e[o], r[o] = !0);
            e = !1 !== a && V(e)
        } while (e && (!a || a(e, t)) && e !== Object.prototype);
        return t
    },
    kindOf: Q,
    kindOfTest: K,
    endsWith: (e, t, a) => {
        e = String(e),
        (void 0 === a || a > e.length) && (a = e.length),
        a -= t.length;
        const n = e.indexOf(t, a);
        return -1 !== n && n === a
    },
    toArray: e => {
        if (!e)
            return null;
        if (X(e))
            return e;
        let t = e.length;
        if (!ae(t))
            return null;
        const a = new Array(t);
        for (; t-- > 0; )
            a[t] = e[t];
        return a
    },
    forEachEntry: (e, t) => {
        const a = (e && e[Symbol.iterator]).call(e);
        let n;
        for (; (n = a.next()) && !n.done; ) {
            const a = n.value;
            t.call(e, a[0], a[1])
        }
    },
    matchAll: (e, t) => {
        let a;
        const n = [];
        for (; null !== (a = e.exec(t)); )
            n.push(a);
        return n
    },
    isHTMLForm: he,
    hasOwnProperty: me,
    hasOwnProp: me,
    reduceDescriptors: _e,
    freezeMethods: e => {
        _e(e, ((t, a) => {
                const n = e[a];
                te(n) && (t.enumerable = !1, "writable" in t ? t.writable = !1 : t.set || (t.set = () => {
                            throw Error("Can not read-only method '" + a + "'")
                        }))
            }))
    },
    toObjectSet: (e, t) => {
        const a = {},
        n = e => {
            e.forEach((e => {
                    a[e] = !0
                }))
        };
        return X(e) ? n(e) : n(String(e).split(t)),
        a
    },
    toCamelCase: e => e.toLowerCase().replace(/[_-\s]([a-z\d])(\w*)/g, (function (e, t, a) {
            return t.toUpperCase() + a
        })),
    noop: () => {},
    toFiniteNumber: (e, t) => (e = +e, Number.isFinite(e) ? e : t)
};
function ge(e, t, a, n, i) {
    Error.call(this),
    Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = (new Error).stack,
    this.message = e,
    this.name = "AxiosError",
    t && (this.code = t),
    a && (this.config = a),
    n && (this.request = n),
    i && (this.response = i)
}
Ee.inherits(ge, Error, {
    toJSON: function () {
        return {
            message: this.message,
            name: this.name,
            description: this.description,
            number: this.number,
            fileName: this.fileName,
            lineNumber: this.lineNumber,
            columnNumber: this.columnNumber,
            stack: this.stack,
            config: this.config,
            code: this.code,
            status: this.response && this.response.status ? this.response.status : null
        }
    }
});
const be = ge.prototype, xe = {};
["ERR_BAD_OPTION_VALUE", "ERR_BAD_OPTION", "ECONNABORTED", "ETIMEDOUT", "ERR_NETWORK", "ERR_FR_TOO_MANY_REDIRECTS", "ERR_DEPRECATED", "ERR_BAD_RESPONSE", "ERR_BAD_REQUEST", "ERR_CANCELED", "ERR_NOT_SUPPORT", "ERR_INVALID_URL"].forEach((e => {
        xe[e] = {
            value: e
        }
    })), Object.defineProperties(ge, xe), Object.defineProperty(be, "isAxiosError", {
    value: !0
}), ge.from = (e, t, a, n, i, s) => {
    const o = Object.create(be);
    return Ee.toFlatObject(e, o, (function (e) {
            return e !== Error.prototype
        }), (e => "isAxiosError" !== e)),
    ge.call(o, e.message, t, a, n, i),
    o.cause = e,
    o.name = e.name,
    s && Object.assign(o, s),
    o
};
var Te = M.default.Stream, ve = Ae;
function Ae() {
    this.source = null,
    this.dataSize = 0,
    this.maxDataSize = 1048576,
    this.pauseStream = !0,
    this._maxDataSizeExceeded = !1,
    this._released = !1,
    this._bufferedEvents = []
}
L.default.inherits(Ae, Te), Ae.create = function (e, t) {
    var a = new this;
    for (var n in t = t || {})
        a[n] = t[n];
    a.source = e;
    var i = e.emit;
    return e.emit = function () {
        return a._handleEmit(arguments),
        i.apply(e, arguments)
    },
    e.on("error", (function () {})),
    a.pauseStream && e.pause(),
    a
}, Object.defineProperty(Ae.prototype, "readable", {
    configurable: !0,
    enumerable: !0,
    get: function () {
        return this.source.readable
    }
}), Ae.prototype.setEncoding = function () {
    return this.source.setEncoding.apply(this.source, arguments)
}, Ae.prototype.resume = function () {
    this._released || this.release(),
    this.source.resume()
}, Ae.prototype.pause = function () {
    this.source.pause()
}, Ae.prototype.release = function () {
    this._released = !0,
    this._bufferedEvents.forEach(function (e) {
        this.emit.apply(this, e)
    }
        .bind(this)),
    this._bufferedEvents = []
}, Ae.prototype.pipe = function () {
    var e = Te.prototype.pipe.apply(this, arguments);
    return this.resume(),
    e
}, Ae.prototype._handleEmit = function (e) {
    this._released ? this.emit.apply(this, e) : ("data" === e[0] && (this.dataSize += e[1].length, this._checkIfMaxDataSizeExceeded()), this._bufferedEvents.push(e))
}, Ae.prototype._checkIfMaxDataSizeExceeded = function () {
    if (!(this._maxDataSizeExceeded || this.dataSize <= this.maxDataSize)) {
        this._maxDataSizeExceeded = !0;
        var e = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
        this.emit("error", new Error(e))
    }
};
var ye = L.default, we = M.default.Stream, Se = ve, Ne = Ce;
function Ce() {
    this.writable = !1,
    this.readable = !0,
    this.dataSize = 0,
    this.maxDataSize = 2097152,
    this.pauseStreams = !0,
    this._released = !1,
    this._streams = [],
    this._currentStream = null,
    this._insideLoop = !1,
    this._pendingNext = !1
}
ye.inherits(Ce, we), Ce.create = function (e) {
    var t = new this;
    for (var a in e = e || {})
        t[a] = e[a];
    return t
}, Ce.isStreamLike = function (e) {
    return "function" != typeof e && "string" != typeof e && "boolean" != typeof e && "number" != typeof e && !Buffer.isBuffer(e)
}, Ce.prototype.append = function (e) {
    if (Ce.isStreamLike(e)) {
        if (!(e instanceof Se)) {
            var t = Se.create(e, {
                maxDataSize: 1 / 0,
                pauseStream: this.pauseStreams
            });
            e.on("data", this._checkDataSize.bind(this)),
            e = t
        }
        this._handleErrors(e),
        this.pauseStreams && e.pause()
    }
    return this._streams.push(e),
    this
}, Ce.prototype.pipe = function (e, t) {
    return we.prototype.pipe.call(this, e, t),
    this.resume(),
    e
}, Ce.prototype._getNext = function () {
    if (this._currentStream = null, this._insideLoop)
        this._pendingNext = !0;
    else {
        this._insideLoop = !0;
        try {
            do {
                this._pendingNext = !1,
                this._realGetNext()
            } while (this._pendingNext)
        } finally {
            this._insideLoop = !1
        }
    }
}, Ce.prototype._realGetNext = function () {
    var e = this._streams.shift();
    void 0 !== e ? "function" == typeof e ? e(function (e) {
        Ce.isStreamLike(e) && (e.on("data", this._checkDataSize.bind(this)), this._handleErrors(e)),
        this._pipeNext(e)
    }
        .bind(this)) : this._pipeNext(e) : this.end()
}, Ce.prototype._pipeNext = function (e) {
    if (this._currentStream = e, Ce.isStreamLike(e))
        return e.on("end", this._getNext.bind(this)), void e.pipe(this, {
            end: !1
        });
    var t = e;
    this.write(t),
    this._getNext()
}, Ce.prototype._handleErrors = function (e) {
    var t = this;
    e.on("error", (function (e) {
            t._emitError(e)
        }))
}, Ce.prototype.write = function (e) {
    this.emit("data", e)
}, Ce.prototype.pause = function () {
    this.pauseStreams && (this.pauseStreams && this._currentStream && "function" == typeof this._currentStream.pause && this._currentStream.pause(), this.emit("pause"))
}, Ce.prototype.resume = function () {
    this._released || (this._released = !0, this.writable = !0, this._getNext()),
    this.pauseStreams && this._currentStream && "function" == typeof this._currentStream.resume && this._currentStream.resume(),
    this.emit("resume")
}, Ce.prototype.end = function () {
    this._reset(),
    this.emit("end")
}, Ce.prototype.destroy = function () {
    this._reset(),
    this.emit("close")
}, Ce.prototype._reset = function () {
    this.writable = !1,
    this._streams = [],
    this._currentStream = null
}, Ce.prototype._checkDataSize = function () {
    if (this._updateDataSize(), !(this.dataSize <= this.maxDataSize)) {
        var e = "DelayedStream#maxDataSize of " + this.maxDataSize + " bytes exceeded.";
        this._emitError(new Error(e))
    }
}, Ce.prototype._updateDataSize = function () {
    this.dataSize = 0;
    var e = this;
    this._streams.forEach((function (t) {
            t.dataSize && (e.dataSize += t.dataSize)
        })),
    this._currentStream && this._currentStream.dataSize && (this.dataSize += this._currentStream.dataSize)
}, Ce.prototype._emitError = function (e) {
    this._reset(),
    this.emit("error", e)
};
var Ie = {}, ke = {
    exports: {}
};
ke.exports = {
    "application/1d-interleaved-parityfec": {
        source: "iana"
    },
    "application/3gpdash-qoe-report+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/3gpp-ims+xml": {
        source: "iana",
        compressible: !0
    },
    "application/3gpphal+json": {
        source: "iana",
        compressible: !0
    },
    "application/3gpphalforms+json": {
        source: "iana",
        compressible: !0
    },
    "application/a2l": {
        source: "iana"
    },
    "application/ace+cbor": {
        source: "iana"
    },
    "application/activemessage": {
        source: "iana"
    },
    "application/activity+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-costmap+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-costmapfilter+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-directory+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-endpointcost+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-endpointcostparams+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-endpointprop+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-endpointpropparams+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-error+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-networkmap+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-networkmapfilter+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-updatestreamcontrol+json": {
        source: "iana",
        compressible: !0
    },
    "application/alto-updatestreamparams+json": {
        source: "iana",
        compressible: !0
    },
    "application/aml": {
        source: "iana"
    },
    "application/andrew-inset": {
        source: "iana",
        extensions: ["ez"]
    },
    "application/applefile": {
        source: "iana"
    },
    "application/applixware": {
        source: "apache",
        extensions: ["aw"]
    },
    "application/at+jwt": {
        source: "iana"
    },
    "application/atf": {
        source: "iana"
    },
    "application/atfx": {
        source: "iana"
    },
    "application/atom+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["atom"]
    },
    "application/atomcat+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["atomcat"]
    },
    "application/atomdeleted+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["atomdeleted"]
    },
    "application/atomicmail": {
        source: "iana"
    },
    "application/atomsvc+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["atomsvc"]
    },
    "application/atsc-dwd+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["dwd"]
    },
    "application/atsc-dynamic-event-message": {
        source: "iana"
    },
    "application/atsc-held+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["held"]
    },
    "application/atsc-rdt+json": {
        source: "iana",
        compressible: !0
    },
    "application/atsc-rsat+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["rsat"]
    },
    "application/atxml": {
        source: "iana"
    },
    "application/auth-policy+xml": {
        source: "iana",
        compressible: !0
    },
    "application/bacnet-xdd+zip": {
        source: "iana",
        compressible: !1
    },
    "application/batch-smtp": {
        source: "iana"
    },
    "application/bdoc": {
        compressible: !1,
        extensions: ["bdoc"]
    },
    "application/beep+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/calendar+json": {
        source: "iana",
        compressible: !0
    },
    "application/calendar+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xcs"]
    },
    "application/call-completion": {
        source: "iana"
    },
    "application/cals-1840": {
        source: "iana"
    },
    "application/captive+json": {
        source: "iana",
        compressible: !0
    },
    "application/cbor": {
        source: "iana"
    },
    "application/cbor-seq": {
        source: "iana"
    },
    "application/cccex": {
        source: "iana"
    },
    "application/ccmp+xml": {
        source: "iana",
        compressible: !0
    },
    "application/ccxml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["ccxml"]
    },
    "application/cdfx+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["cdfx"]
    },
    "application/cdmi-capability": {
        source: "iana",
        extensions: ["cdmia"]
    },
    "application/cdmi-container": {
        source: "iana",
        extensions: ["cdmic"]
    },
    "application/cdmi-domain": {
        source: "iana",
        extensions: ["cdmid"]
    },
    "application/cdmi-object": {
        source: "iana",
        extensions: ["cdmio"]
    },
    "application/cdmi-queue": {
        source: "iana",
        extensions: ["cdmiq"]
    },
    "application/cdni": {
        source: "iana"
    },
    "application/cea": {
        source: "iana"
    },
    "application/cea-2018+xml": {
        source: "iana",
        compressible: !0
    },
    "application/cellml+xml": {
        source: "iana",
        compressible: !0
    },
    "application/cfw": {
        source: "iana"
    },
    "application/city+json": {
        source: "iana",
        compressible: !0
    },
    "application/clr": {
        source: "iana"
    },
    "application/clue+xml": {
        source: "iana",
        compressible: !0
    },
    "application/clue_info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/cms": {
        source: "iana"
    },
    "application/cnrp+xml": {
        source: "iana",
        compressible: !0
    },
    "application/coap-group+json": {
        source: "iana",
        compressible: !0
    },
    "application/coap-payload": {
        source: "iana"
    },
    "application/commonground": {
        source: "iana"
    },
    "application/conference-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/cose": {
        source: "iana"
    },
    "application/cose-key": {
        source: "iana"
    },
    "application/cose-key-set": {
        source: "iana"
    },
    "application/cpl+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["cpl"]
    },
    "application/csrattrs": {
        source: "iana"
    },
    "application/csta+xml": {
        source: "iana",
        compressible: !0
    },
    "application/cstadata+xml": {
        source: "iana",
        compressible: !0
    },
    "application/csvm+json": {
        source: "iana",
        compressible: !0
    },
    "application/cu-seeme": {
        source: "apache",
        extensions: ["cu"]
    },
    "application/cwt": {
        source: "iana"
    },
    "application/cybercash": {
        source: "iana"
    },
    "application/dart": {
        compressible: !0
    },
    "application/dash+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mpd"]
    },
    "application/dash-patch+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mpp"]
    },
    "application/dashdelta": {
        source: "iana"
    },
    "application/davmount+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["davmount"]
    },
    "application/dca-rft": {
        source: "iana"
    },
    "application/dcd": {
        source: "iana"
    },
    "application/dec-dx": {
        source: "iana"
    },
    "application/dialog-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/dicom": {
        source: "iana"
    },
    "application/dicom+json": {
        source: "iana",
        compressible: !0
    },
    "application/dicom+xml": {
        source: "iana",
        compressible: !0
    },
    "application/dii": {
        source: "iana"
    },
    "application/dit": {
        source: "iana"
    },
    "application/dns": {
        source: "iana"
    },
    "application/dns+json": {
        source: "iana",
        compressible: !0
    },
    "application/dns-message": {
        source: "iana"
    },
    "application/docbook+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["dbk"]
    },
    "application/dots+cbor": {
        source: "iana"
    },
    "application/dskpp+xml": {
        source: "iana",
        compressible: !0
    },
    "application/dssc+der": {
        source: "iana",
        extensions: ["dssc"]
    },
    "application/dssc+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xdssc"]
    },
    "application/dvcs": {
        source: "iana"
    },
    "application/ecmascript": {
        source: "iana",
        compressible: !0,
        extensions: ["es", "ecma"]
    },
    "application/edi-consent": {
        source: "iana"
    },
    "application/edi-x12": {
        source: "iana",
        compressible: !1
    },
    "application/edifact": {
        source: "iana",
        compressible: !1
    },
    "application/efi": {
        source: "iana"
    },
    "application/elm+json": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/elm+xml": {
        source: "iana",
        compressible: !0
    },
    "application/emergencycalldata.cap+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/emergencycalldata.comment+xml": {
        source: "iana",
        compressible: !0
    },
    "application/emergencycalldata.control+xml": {
        source: "iana",
        compressible: !0
    },
    "application/emergencycalldata.deviceinfo+xml": {
        source: "iana",
        compressible: !0
    },
    "application/emergencycalldata.ecall.msd": {
        source: "iana"
    },
    "application/emergencycalldata.providerinfo+xml": {
        source: "iana",
        compressible: !0
    },
    "application/emergencycalldata.serviceinfo+xml": {
        source: "iana",
        compressible: !0
    },
    "application/emergencycalldata.subscriberinfo+xml": {
        source: "iana",
        compressible: !0
    },
    "application/emergencycalldata.veds+xml": {
        source: "iana",
        compressible: !0
    },
    "application/emma+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["emma"]
    },
    "application/emotionml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["emotionml"]
    },
    "application/encaprtp": {
        source: "iana"
    },
    "application/epp+xml": {
        source: "iana",
        compressible: !0
    },
    "application/epub+zip": {
        source: "iana",
        compressible: !1,
        extensions: ["epub"]
    },
    "application/eshop": {
        source: "iana"
    },
    "application/exi": {
        source: "iana",
        extensions: ["exi"]
    },
    "application/expect-ct-report+json": {
        source: "iana",
        compressible: !0
    },
    "application/express": {
        source: "iana",
        extensions: ["exp"]
    },
    "application/fastinfoset": {
        source: "iana"
    },
    "application/fastsoap": {
        source: "iana"
    },
    "application/fdt+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["fdt"]
    },
    "application/fhir+json": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/fhir+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/fido.trusted-apps+json": {
        compressible: !0
    },
    "application/fits": {
        source: "iana"
    },
    "application/flexfec": {
        source: "iana"
    },
    "application/font-sfnt": {
        source: "iana"
    },
    "application/font-tdpfr": {
        source: "iana",
        extensions: ["pfr"]
    },
    "application/font-woff": {
        source: "iana",
        compressible: !1
    },
    "application/framework-attributes+xml": {
        source: "iana",
        compressible: !0
    },
    "application/geo+json": {
        source: "iana",
        compressible: !0,
        extensions: ["geojson"]
    },
    "application/geo+json-seq": {
        source: "iana"
    },
    "application/geopackage+sqlite3": {
        source: "iana"
    },
    "application/geoxacml+xml": {
        source: "iana",
        compressible: !0
    },
    "application/gltf-buffer": {
        source: "iana"
    },
    "application/gml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["gml"]
    },
    "application/gpx+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["gpx"]
    },
    "application/gxf": {
        source: "apache",
        extensions: ["gxf"]
    },
    "application/gzip": {
        source: "iana",
        compressible: !1,
        extensions: ["gz"]
    },
    "application/h224": {
        source: "iana"
    },
    "application/held+xml": {
        source: "iana",
        compressible: !0
    },
    "application/hjson": {
        extensions: ["hjson"]
    },
    "application/http": {
        source: "iana"
    },
    "application/hyperstudio": {
        source: "iana",
        extensions: ["stk"]
    },
    "application/ibe-key-request+xml": {
        source: "iana",
        compressible: !0
    },
    "application/ibe-pkg-reply+xml": {
        source: "iana",
        compressible: !0
    },
    "application/ibe-pp-data": {
        source: "iana"
    },
    "application/iges": {
        source: "iana"
    },
    "application/im-iscomposing+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/index": {
        source: "iana"
    },
    "application/index.cmd": {
        source: "iana"
    },
    "application/index.obj": {
        source: "iana"
    },
    "application/index.response": {
        source: "iana"
    },
    "application/index.vnd": {
        source: "iana"
    },
    "application/inkml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["ink", "inkml"]
    },
    "application/iotp": {
        source: "iana"
    },
    "application/ipfix": {
        source: "iana",
        extensions: ["ipfix"]
    },
    "application/ipp": {
        source: "iana"
    },
    "application/isup": {
        source: "iana"
    },
    "application/its+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["its"]
    },
    "application/java-archive": {
        source: "apache",
        compressible: !1,
        extensions: ["jar", "war", "ear"]
    },
    "application/java-serialized-object": {
        source: "apache",
        compressible: !1,
        extensions: ["ser"]
    },
    "application/java-vm": {
        source: "apache",
        compressible: !1,
        extensions: ["class"]
    },
    "application/javascript": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0,
        extensions: ["js", "mjs"]
    },
    "application/jf2feed+json": {
        source: "iana",
        compressible: !0
    },
    "application/jose": {
        source: "iana"
    },
    "application/jose+json": {
        source: "iana",
        compressible: !0
    },
    "application/jrd+json": {
        source: "iana",
        compressible: !0
    },
    "application/jscalendar+json": {
        source: "iana",
        compressible: !0
    },
    "application/json": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0,
        extensions: ["json", "map"]
    },
    "application/json-patch+json": {
        source: "iana",
        compressible: !0
    },
    "application/json-seq": {
        source: "iana"
    },
    "application/json5": {
        extensions: ["json5"]
    },
    "application/jsonml+json": {
        source: "apache",
        compressible: !0,
        extensions: ["jsonml"]
    },
    "application/jwk+json": {
        source: "iana",
        compressible: !0
    },
    "application/jwk-set+json": {
        source: "iana",
        compressible: !0
    },
    "application/jwt": {
        source: "iana"
    },
    "application/kpml-request+xml": {
        source: "iana",
        compressible: !0
    },
    "application/kpml-response+xml": {
        source: "iana",
        compressible: !0
    },
    "application/ld+json": {
        source: "iana",
        compressible: !0,
        extensions: ["jsonld"]
    },
    "application/lgr+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["lgr"]
    },
    "application/link-format": {
        source: "iana"
    },
    "application/load-control+xml": {
        source: "iana",
        compressible: !0
    },
    "application/lost+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["lostxml"]
    },
    "application/lostsync+xml": {
        source: "iana",
        compressible: !0
    },
    "application/lpf+zip": {
        source: "iana",
        compressible: !1
    },
    "application/lxf": {
        source: "iana"
    },
    "application/mac-binhex40": {
        source: "iana",
        extensions: ["hqx"]
    },
    "application/mac-compactpro": {
        source: "apache",
        extensions: ["cpt"]
    },
    "application/macwriteii": {
        source: "iana"
    },
    "application/mads+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mads"]
    },
    "application/manifest+json": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0,
        extensions: ["webmanifest"]
    },
    "application/marc": {
        source: "iana",
        extensions: ["mrc"]
    },
    "application/marcxml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mrcx"]
    },
    "application/mathematica": {
        source: "iana",
        extensions: ["ma", "nb", "mb"]
    },
    "application/mathml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mathml"]
    },
    "application/mathml-content+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mathml-presentation+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-associated-procedure-description+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-deregister+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-envelope+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-msk+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-msk-response+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-protection-description+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-reception-report+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-register+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-register-response+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-schedule+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbms-user-service-description+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mbox": {
        source: "iana",
        extensions: ["mbox"]
    },
    "application/media-policy-dataset+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mpf"]
    },
    "application/media_control+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mediaservercontrol+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mscml"]
    },
    "application/merge-patch+json": {
        source: "iana",
        compressible: !0
    },
    "application/metalink+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["metalink"]
    },
    "application/metalink4+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["meta4"]
    },
    "application/mets+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mets"]
    },
    "application/mf4": {
        source: "iana"
    },
    "application/mikey": {
        source: "iana"
    },
    "application/mipc": {
        source: "iana"
    },
    "application/missing-blocks+cbor-seq": {
        source: "iana"
    },
    "application/mmt-aei+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["maei"]
    },
    "application/mmt-usd+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["musd"]
    },
    "application/mods+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mods"]
    },
    "application/moss-keys": {
        source: "iana"
    },
    "application/moss-signature": {
        source: "iana"
    },
    "application/mosskey-data": {
        source: "iana"
    },
    "application/mosskey-request": {
        source: "iana"
    },
    "application/mp21": {
        source: "iana",
        extensions: ["m21", "mp21"]
    },
    "application/mp4": {
        source: "iana",
        extensions: ["mp4s", "m4p"]
    },
    "application/mpeg4-generic": {
        source: "iana"
    },
    "application/mpeg4-iod": {
        source: "iana"
    },
    "application/mpeg4-iod-xmt": {
        source: "iana"
    },
    "application/mrb-consumer+xml": {
        source: "iana",
        compressible: !0
    },
    "application/mrb-publish+xml": {
        source: "iana",
        compressible: !0
    },
    "application/msc-ivr+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/msc-mixer+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/msword": {
        source: "iana",
        compressible: !1,
        extensions: ["doc", "dot"]
    },
    "application/mud+json": {
        source: "iana",
        compressible: !0
    },
    "application/multipart-core": {
        source: "iana"
    },
    "application/mxf": {
        source: "iana",
        extensions: ["mxf"]
    },
    "application/n-quads": {
        source: "iana",
        extensions: ["nq"]
    },
    "application/n-triples": {
        source: "iana",
        extensions: ["nt"]
    },
    "application/nasdata": {
        source: "iana"
    },
    "application/news-checkgroups": {
        source: "iana",
        charset: "US-ASCII"
    },
    "application/news-groupinfo": {
        source: "iana",
        charset: "US-ASCII"
    },
    "application/news-transmission": {
        source: "iana"
    },
    "application/nlsml+xml": {
        source: "iana",
        compressible: !0
    },
    "application/node": {
        source: "iana",
        extensions: ["cjs"]
    },
    "application/nss": {
        source: "iana"
    },
    "application/oauth-authz-req+jwt": {
        source: "iana"
    },
    "application/oblivious-dns-message": {
        source: "iana"
    },
    "application/ocsp-request": {
        source: "iana"
    },
    "application/ocsp-response": {
        source: "iana"
    },
    "application/octet-stream": {
        source: "iana",
        compressible: !1,
        extensions: ["bin", "dms", "lrf", "mar", "so", "dist", "distz", "pkg", "bpk", "dump", "elc", "deploy", "exe", "dll", "deb", "dmg", "iso", "img", "msi", "msp", "msm", "buffer"]
    },
    "application/oda": {
        source: "iana",
        extensions: ["oda"]
    },
    "application/odm+xml": {
        source: "iana",
        compressible: !0
    },
    "application/odx": {
        source: "iana"
    },
    "application/oebps-package+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["opf"]
    },
    "application/ogg": {
        source: "iana",
        compressible: !1,
        extensions: ["ogx"]
    },
    "application/omdoc+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["omdoc"]
    },
    "application/onenote": {
        source: "apache",
        extensions: ["onetoc", "onetoc2", "onetmp", "onepkg"]
    },
    "application/opc-nodeset+xml": {
        source: "iana",
        compressible: !0
    },
    "application/oscore": {
        source: "iana"
    },
    "application/oxps": {
        source: "iana",
        extensions: ["oxps"]
    },
    "application/p21": {
        source: "iana"
    },
    "application/p21+zip": {
        source: "iana",
        compressible: !1
    },
    "application/p2p-overlay+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["relo"]
    },
    "application/parityfec": {
        source: "iana"
    },
    "application/passport": {
        source: "iana"
    },
    "application/patch-ops-error+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xer"]
    },
    "application/pdf": {
        source: "iana",
        compressible: !1,
        extensions: ["pdf"]
    },
    "application/pdx": {
        source: "iana"
    },
    "application/pem-certificate-chain": {
        source: "iana"
    },
    "application/pgp-encrypted": {
        source: "iana",
        compressible: !1,
        extensions: ["pgp"]
    },
    "application/pgp-keys": {
        source: "iana",
        extensions: ["asc"]
    },
    "application/pgp-signature": {
        source: "iana",
        extensions: ["asc", "sig"]
    },
    "application/pics-rules": {
        source: "apache",
        extensions: ["prf"]
    },
    "application/pidf+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/pidf-diff+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/pkcs10": {
        source: "iana",
        extensions: ["p10"]
    },
    "application/pkcs12": {
        source: "iana"
    },
    "application/pkcs7-mime": {
        source: "iana",
        extensions: ["p7m", "p7c"]
    },
    "application/pkcs7-signature": {
        source: "iana",
        extensions: ["p7s"]
    },
    "application/pkcs8": {
        source: "iana",
        extensions: ["p8"]
    },
    "application/pkcs8-encrypted": {
        source: "iana"
    },
    "application/pkix-attr-cert": {
        source: "iana",
        extensions: ["ac"]
    },
    "application/pkix-cert": {
        source: "iana",
        extensions: ["cer"]
    },
    "application/pkix-crl": {
        source: "iana",
        extensions: ["crl"]
    },
    "application/pkix-pkipath": {
        source: "iana",
        extensions: ["pkipath"]
    },
    "application/pkixcmp": {
        source: "iana",
        extensions: ["pki"]
    },
    "application/pls+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["pls"]
    },
    "application/poc-settings+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/postscript": {
        source: "iana",
        compressible: !0,
        extensions: ["ai", "eps", "ps"]
    },
    "application/ppsp-tracker+json": {
        source: "iana",
        compressible: !0
    },
    "application/problem+json": {
        source: "iana",
        compressible: !0
    },
    "application/problem+xml": {
        source: "iana",
        compressible: !0
    },
    "application/provenance+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["provx"]
    },
    "application/prs.alvestrand.titrax-sheet": {
        source: "iana"
    },
    "application/prs.cww": {
        source: "iana",
        extensions: ["cww"]
    },
    "application/prs.cyn": {
        source: "iana",
        charset: "7-BIT"
    },
    "application/prs.hpub+zip": {
        source: "iana",
        compressible: !1
    },
    "application/prs.nprend": {
        source: "iana"
    },
    "application/prs.plucker": {
        source: "iana"
    },
    "application/prs.rdf-xml-crypt": {
        source: "iana"
    },
    "application/prs.xsf+xml": {
        source: "iana",
        compressible: !0
    },
    "application/pskc+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["pskcxml"]
    },
    "application/pvd+json": {
        source: "iana",
        compressible: !0
    },
    "application/qsig": {
        source: "iana"
    },
    "application/raml+yaml": {
        compressible: !0,
        extensions: ["raml"]
    },
    "application/raptorfec": {
        source: "iana"
    },
    "application/rdap+json": {
        source: "iana",
        compressible: !0
    },
    "application/rdf+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["rdf", "owl"]
    },
    "application/reginfo+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["rif"]
    },
    "application/relax-ng-compact-syntax": {
        source: "iana",
        extensions: ["rnc"]
    },
    "application/remote-printing": {
        source: "iana"
    },
    "application/reputon+json": {
        source: "iana",
        compressible: !0
    },
    "application/resource-lists+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["rl"]
    },
    "application/resource-lists-diff+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["rld"]
    },
    "application/rfc+xml": {
        source: "iana",
        compressible: !0
    },
    "application/riscos": {
        source: "iana"
    },
    "application/rlmi+xml": {
        source: "iana",
        compressible: !0
    },
    "application/rls-services+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["rs"]
    },
    "application/route-apd+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["rapd"]
    },
    "application/route-s-tsid+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["sls"]
    },
    "application/route-usd+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["rusd"]
    },
    "application/rpki-ghostbusters": {
        source: "iana",
        extensions: ["gbr"]
    },
    "application/rpki-manifest": {
        source: "iana",
        extensions: ["mft"]
    },
    "application/rpki-publication": {
        source: "iana"
    },
    "application/rpki-roa": {
        source: "iana",
        extensions: ["roa"]
    },
    "application/rpki-updown": {
        source: "iana"
    },
    "application/rsd+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["rsd"]
    },
    "application/rss+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["rss"]
    },
    "application/rtf": {
        source: "iana",
        compressible: !0,
        extensions: ["rtf"]
    },
    "application/rtploopback": {
        source: "iana"
    },
    "application/rtx": {
        source: "iana"
    },
    "application/samlassertion+xml": {
        source: "iana",
        compressible: !0
    },
    "application/samlmetadata+xml": {
        source: "iana",
        compressible: !0
    },
    "application/sarif+json": {
        source: "iana",
        compressible: !0
    },
    "application/sarif-external-properties+json": {
        source: "iana",
        compressible: !0
    },
    "application/sbe": {
        source: "iana"
    },
    "application/sbml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["sbml"]
    },
    "application/scaip+xml": {
        source: "iana",
        compressible: !0
    },
    "application/scim+json": {
        source: "iana",
        compressible: !0
    },
    "application/scvp-cv-request": {
        source: "iana",
        extensions: ["scq"]
    },
    "application/scvp-cv-response": {
        source: "iana",
        extensions: ["scs"]
    },
    "application/scvp-vp-request": {
        source: "iana",
        extensions: ["spq"]
    },
    "application/scvp-vp-response": {
        source: "iana",
        extensions: ["spp"]
    },
    "application/sdp": {
        source: "iana",
        extensions: ["sdp"]
    },
    "application/secevent+jwt": {
        source: "iana"
    },
    "application/senml+cbor": {
        source: "iana"
    },
    "application/senml+json": {
        source: "iana",
        compressible: !0
    },
    "application/senml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["senmlx"]
    },
    "application/senml-etch+cbor": {
        source: "iana"
    },
    "application/senml-etch+json": {
        source: "iana",
        compressible: !0
    },
    "application/senml-exi": {
        source: "iana"
    },
    "application/sensml+cbor": {
        source: "iana"
    },
    "application/sensml+json": {
        source: "iana",
        compressible: !0
    },
    "application/sensml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["sensmlx"]
    },
    "application/sensml-exi": {
        source: "iana"
    },
    "application/sep+xml": {
        source: "iana",
        compressible: !0
    },
    "application/sep-exi": {
        source: "iana"
    },
    "application/session-info": {
        source: "iana"
    },
    "application/set-payment": {
        source: "iana"
    },
    "application/set-payment-initiation": {
        source: "iana",
        extensions: ["setpay"]
    },
    "application/set-registration": {
        source: "iana"
    },
    "application/set-registration-initiation": {
        source: "iana",
        extensions: ["setreg"]
    },
    "application/sgml": {
        source: "iana"
    },
    "application/sgml-open-catalog": {
        source: "iana"
    },
    "application/shf+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["shf"]
    },
    "application/sieve": {
        source: "iana",
        extensions: ["siv", "sieve"]
    },
    "application/simple-filter+xml": {
        source: "iana",
        compressible: !0
    },
    "application/simple-message-summary": {
        source: "iana"
    },
    "application/simplesymbolcontainer": {
        source: "iana"
    },
    "application/sipc": {
        source: "iana"
    },
    "application/slate": {
        source: "iana"
    },
    "application/smil": {
        source: "iana"
    },
    "application/smil+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["smi", "smil"]
    },
    "application/smpte336m": {
        source: "iana"
    },
    "application/soap+fastinfoset": {
        source: "iana"
    },
    "application/soap+xml": {
        source: "iana",
        compressible: !0
    },
    "application/sparql-query": {
        source: "iana",
        extensions: ["rq"]
    },
    "application/sparql-results+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["srx"]
    },
    "application/spdx+json": {
        source: "iana",
        compressible: !0
    },
    "application/spirits-event+xml": {
        source: "iana",
        compressible: !0
    },
    "application/sql": {
        source: "iana"
    },
    "application/srgs": {
        source: "iana",
        extensions: ["gram"]
    },
    "application/srgs+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["grxml"]
    },
    "application/sru+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["sru"]
    },
    "application/ssdl+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["ssdl"]
    },
    "application/ssml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["ssml"]
    },
    "application/stix+json": {
        source: "iana",
        compressible: !0
    },
    "application/swid+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["swidtag"]
    },
    "application/tamp-apex-update": {
        source: "iana"
    },
    "application/tamp-apex-update-confirm": {
        source: "iana"
    },
    "application/tamp-community-update": {
        source: "iana"
    },
    "application/tamp-community-update-confirm": {
        source: "iana"
    },
    "application/tamp-error": {
        source: "iana"
    },
    "application/tamp-sequence-adjust": {
        source: "iana"
    },
    "application/tamp-sequence-adjust-confirm": {
        source: "iana"
    },
    "application/tamp-status-query": {
        source: "iana"
    },
    "application/tamp-status-response": {
        source: "iana"
    },
    "application/tamp-update": {
        source: "iana"
    },
    "application/tamp-update-confirm": {
        source: "iana"
    },
    "application/tar": {
        compressible: !0
    },
    "application/taxii+json": {
        source: "iana",
        compressible: !0
    },
    "application/td+json": {
        source: "iana",
        compressible: !0
    },
    "application/tei+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["tei", "teicorpus"]
    },
    "application/tetra_isi": {
        source: "iana"
    },
    "application/thraud+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["tfi"]
    },
    "application/timestamp-query": {
        source: "iana"
    },
    "application/timestamp-reply": {
        source: "iana"
    },
    "application/timestamped-data": {
        source: "iana",
        extensions: ["tsd"]
    },
    "application/tlsrpt+gzip": {
        source: "iana"
    },
    "application/tlsrpt+json": {
        source: "iana",
        compressible: !0
    },
    "application/tnauthlist": {
        source: "iana"
    },
    "application/token-introspection+jwt": {
        source: "iana"
    },
    "application/toml": {
        compressible: !0,
        extensions: ["toml"]
    },
    "application/trickle-ice-sdpfrag": {
        source: "iana"
    },
    "application/trig": {
        source: "iana",
        extensions: ["trig"]
    },
    "application/ttml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["ttml"]
    },
    "application/tve-trigger": {
        source: "iana"
    },
    "application/tzif": {
        source: "iana"
    },
    "application/tzif-leap": {
        source: "iana"
    },
    "application/ubjson": {
        compressible: !1,
        extensions: ["ubj"]
    },
    "application/ulpfec": {
        source: "iana"
    },
    "application/urc-grpsheet+xml": {
        source: "iana",
        compressible: !0
    },
    "application/urc-ressheet+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["rsheet"]
    },
    "application/urc-targetdesc+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["td"]
    },
    "application/urc-uisocketdesc+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vcard+json": {
        source: "iana",
        compressible: !0
    },
    "application/vcard+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vemmi": {
        source: "iana"
    },
    "application/vividence.scriptfile": {
        source: "apache"
    },
    "application/vnd.1000minds.decision-model+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["1km"]
    },
    "application/vnd.3gpp-prose+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp-prose-pc3ch+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp-v2x-local-service-information": {
        source: "iana"
    },
    "application/vnd.3gpp.5gnas": {
        source: "iana"
    },
    "application/vnd.3gpp.access-transfer-events+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.bsf+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.gmop+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.gtpc": {
        source: "iana"
    },
    "application/vnd.3gpp.interworking-data": {
        source: "iana"
    },
    "application/vnd.3gpp.lpp": {
        source: "iana"
    },
    "application/vnd.3gpp.mc-signalling-ear": {
        source: "iana"
    },
    "application/vnd.3gpp.mcdata-affiliation-command+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcdata-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcdata-payload": {
        source: "iana"
    },
    "application/vnd.3gpp.mcdata-service-config+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcdata-signalling": {
        source: "iana"
    },
    "application/vnd.3gpp.mcdata-ue-config+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcdata-user-profile+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-affiliation-command+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-floor-request+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-location-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-mbms-usage-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-service-config+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-signed+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-ue-config+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-ue-init-config+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcptt-user-profile+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcvideo-affiliation-command+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcvideo-affiliation-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcvideo-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcvideo-location-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcvideo-mbms-usage-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcvideo-service-config+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcvideo-transmission-request+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcvideo-ue-config+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mcvideo-user-profile+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.mid-call+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.ngap": {
        source: "iana"
    },
    "application/vnd.3gpp.pfcp": {
        source: "iana"
    },
    "application/vnd.3gpp.pic-bw-large": {
        source: "iana",
        extensions: ["plb"]
    },
    "application/vnd.3gpp.pic-bw-small": {
        source: "iana",
        extensions: ["psb"]
    },
    "application/vnd.3gpp.pic-bw-var": {
        source: "iana",
        extensions: ["pvb"]
    },
    "application/vnd.3gpp.s1ap": {
        source: "iana"
    },
    "application/vnd.3gpp.sms": {
        source: "iana"
    },
    "application/vnd.3gpp.sms+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.srvcc-ext+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.srvcc-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.state-and-event-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp.ussd+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp2.bcmcsinfo+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.3gpp2.sms": {
        source: "iana"
    },
    "application/vnd.3gpp2.tcap": {
        source: "iana",
        extensions: ["tcap"]
    },
    "application/vnd.3lightssoftware.imagescal": {
        source: "iana"
    },
    "application/vnd.3m.post-it-notes": {
        source: "iana",
        extensions: ["pwn"]
    },
    "application/vnd.accpac.simply.aso": {
        source: "iana",
        extensions: ["aso"]
    },
    "application/vnd.accpac.simply.imp": {
        source: "iana",
        extensions: ["imp"]
    },
    "application/vnd.acucobol": {
        source: "iana",
        extensions: ["acu"]
    },
    "application/vnd.acucorp": {
        source: "iana",
        extensions: ["atc", "acutc"]
    },
    "application/vnd.adobe.air-application-installer-package+zip": {
        source: "apache",
        compressible: !1,
        extensions: ["air"]
    },
    "application/vnd.adobe.flash.movie": {
        source: "iana"
    },
    "application/vnd.adobe.formscentral.fcdt": {
        source: "iana",
        extensions: ["fcdt"]
    },
    "application/vnd.adobe.fxp": {
        source: "iana",
        extensions: ["fxp", "fxpl"]
    },
    "application/vnd.adobe.partial-upload": {
        source: "iana"
    },
    "application/vnd.adobe.xdp+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xdp"]
    },
    "application/vnd.adobe.xfdf": {
        source: "iana",
        extensions: ["xfdf"]
    },
    "application/vnd.aether.imp": {
        source: "iana"
    },
    "application/vnd.afpc.afplinedata": {
        source: "iana"
    },
    "application/vnd.afpc.afplinedata-pagedef": {
        source: "iana"
    },
    "application/vnd.afpc.cmoca-cmresource": {
        source: "iana"
    },
    "application/vnd.afpc.foca-charset": {
        source: "iana"
    },
    "application/vnd.afpc.foca-codedfont": {
        source: "iana"
    },
    "application/vnd.afpc.foca-codepage": {
        source: "iana"
    },
    "application/vnd.afpc.modca": {
        source: "iana"
    },
    "application/vnd.afpc.modca-cmtable": {
        source: "iana"
    },
    "application/vnd.afpc.modca-formdef": {
        source: "iana"
    },
    "application/vnd.afpc.modca-mediummap": {
        source: "iana"
    },
    "application/vnd.afpc.modca-objectcontainer": {
        source: "iana"
    },
    "application/vnd.afpc.modca-overlay": {
        source: "iana"
    },
    "application/vnd.afpc.modca-pagesegment": {
        source: "iana"
    },
    "application/vnd.age": {
        source: "iana",
        extensions: ["age"]
    },
    "application/vnd.ah-barcode": {
        source: "iana"
    },
    "application/vnd.ahead.space": {
        source: "iana",
        extensions: ["ahead"]
    },
    "application/vnd.airzip.filesecure.azf": {
        source: "iana",
        extensions: ["azf"]
    },
    "application/vnd.airzip.filesecure.azs": {
        source: "iana",
        extensions: ["azs"]
    },
    "application/vnd.amadeus+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.amazon.ebook": {
        source: "apache",
        extensions: ["azw"]
    },
    "application/vnd.amazon.mobi8-ebook": {
        source: "iana"
    },
    "application/vnd.americandynamics.acc": {
        source: "iana",
        extensions: ["acc"]
    },
    "application/vnd.amiga.ami": {
        source: "iana",
        extensions: ["ami"]
    },
    "application/vnd.amundsen.maze+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.android.ota": {
        source: "iana"
    },
    "application/vnd.android.package-archive": {
        source: "apache",
        compressible: !1,
        extensions: ["apk"]
    },
    "application/vnd.anki": {
        source: "iana"
    },
    "application/vnd.anser-web-certificate-issue-initiation": {
        source: "iana",
        extensions: ["cii"]
    },
    "application/vnd.anser-web-funds-transfer-initiation": {
        source: "apache",
        extensions: ["fti"]
    },
    "application/vnd.antix.game-component": {
        source: "iana",
        extensions: ["atx"]
    },
    "application/vnd.apache.arrow.file": {
        source: "iana"
    },
    "application/vnd.apache.arrow.stream": {
        source: "iana"
    },
    "application/vnd.apache.thrift.binary": {
        source: "iana"
    },
    "application/vnd.apache.thrift.compact": {
        source: "iana"
    },
    "application/vnd.apache.thrift.json": {
        source: "iana"
    },
    "application/vnd.api+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.aplextor.warrp+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.apothekende.reservation+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.apple.installer+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mpkg"]
    },
    "application/vnd.apple.keynote": {
        source: "iana",
        extensions: ["key"]
    },
    "application/vnd.apple.mpegurl": {
        source: "iana",
        extensions: ["m3u8"]
    },
    "application/vnd.apple.numbers": {
        source: "iana",
        extensions: ["numbers"]
    },
    "application/vnd.apple.pages": {
        source: "iana",
        extensions: ["pages"]
    },
    "application/vnd.apple.pkpass": {
        compressible: !1,
        extensions: ["pkpass"]
    },
    "application/vnd.arastra.swi": {
        source: "iana"
    },
    "application/vnd.aristanetworks.swi": {
        source: "iana",
        extensions: ["swi"]
    },
    "application/vnd.artisan+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.artsquare": {
        source: "iana"
    },
    "application/vnd.astraea-software.iota": {
        source: "iana",
        extensions: ["iota"]
    },
    "application/vnd.audiograph": {
        source: "iana",
        extensions: ["aep"]
    },
    "application/vnd.autopackage": {
        source: "iana"
    },
    "application/vnd.avalon+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.avistar+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.balsamiq.bmml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["bmml"]
    },
    "application/vnd.balsamiq.bmpr": {
        source: "iana"
    },
    "application/vnd.banana-accounting": {
        source: "iana"
    },
    "application/vnd.bbf.usp.error": {
        source: "iana"
    },
    "application/vnd.bbf.usp.msg": {
        source: "iana"
    },
    "application/vnd.bbf.usp.msg+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.bekitzur-stech+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.bint.med-content": {
        source: "iana"
    },
    "application/vnd.biopax.rdf+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.blink-idb-value-wrapper": {
        source: "iana"
    },
    "application/vnd.blueice.multipass": {
        source: "iana",
        extensions: ["mpm"]
    },
    "application/vnd.bluetooth.ep.oob": {
        source: "iana"
    },
    "application/vnd.bluetooth.le.oob": {
        source: "iana"
    },
    "application/vnd.bmi": {
        source: "iana",
        extensions: ["bmi"]
    },
    "application/vnd.bpf": {
        source: "iana"
    },
    "application/vnd.bpf3": {
        source: "iana"
    },
    "application/vnd.businessobjects": {
        source: "iana",
        extensions: ["rep"]
    },
    "application/vnd.byu.uapi+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.cab-jscript": {
        source: "iana"
    },
    "application/vnd.canon-cpdl": {
        source: "iana"
    },
    "application/vnd.canon-lips": {
        source: "iana"
    },
    "application/vnd.capasystems-pg+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.cendio.thinlinc.clientconf": {
        source: "iana"
    },
    "application/vnd.century-systems.tcp_stream": {
        source: "iana"
    },
    "application/vnd.chemdraw+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["cdxml"]
    },
    "application/vnd.chess-pgn": {
        source: "iana"
    },
    "application/vnd.chipnuts.karaoke-mmd": {
        source: "iana",
        extensions: ["mmd"]
    },
    "application/vnd.ciedi": {
        source: "iana"
    },
    "application/vnd.cinderella": {
        source: "iana",
        extensions: ["cdy"]
    },
    "application/vnd.cirpack.isdn-ext": {
        source: "iana"
    },
    "application/vnd.citationstyles.style+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["csl"]
    },
    "application/vnd.claymore": {
        source: "iana",
        extensions: ["cla"]
    },
    "application/vnd.cloanto.rp9": {
        source: "iana",
        extensions: ["rp9"]
    },
    "application/vnd.clonk.c4group": {
        source: "iana",
        extensions: ["c4g", "c4d", "c4f", "c4p", "c4u"]
    },
    "application/vnd.cluetrust.cartomobile-config": {
        source: "iana",
        extensions: ["c11amc"]
    },
    "application/vnd.cluetrust.cartomobile-config-pkg": {
        source: "iana",
        extensions: ["c11amz"]
    },
    "application/vnd.coffeescript": {
        source: "iana"
    },
    "application/vnd.collabio.xodocuments.document": {
        source: "iana"
    },
    "application/vnd.collabio.xodocuments.document-template": {
        source: "iana"
    },
    "application/vnd.collabio.xodocuments.presentation": {
        source: "iana"
    },
    "application/vnd.collabio.xodocuments.presentation-template": {
        source: "iana"
    },
    "application/vnd.collabio.xodocuments.spreadsheet": {
        source: "iana"
    },
    "application/vnd.collabio.xodocuments.spreadsheet-template": {
        source: "iana"
    },
    "application/vnd.collection+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.collection.doc+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.collection.next+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.comicbook+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.comicbook-rar": {
        source: "iana"
    },
    "application/vnd.commerce-battelle": {
        source: "iana"
    },
    "application/vnd.commonspace": {
        source: "iana",
        extensions: ["csp"]
    },
    "application/vnd.contact.cmsg": {
        source: "iana",
        extensions: ["cdbcmsg"]
    },
    "application/vnd.coreos.ignition+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.cosmocaller": {
        source: "iana",
        extensions: ["cmc"]
    },
    "application/vnd.crick.clicker": {
        source: "iana",
        extensions: ["clkx"]
    },
    "application/vnd.crick.clicker.keyboard": {
        source: "iana",
        extensions: ["clkk"]
    },
    "application/vnd.crick.clicker.palette": {
        source: "iana",
        extensions: ["clkp"]
    },
    "application/vnd.crick.clicker.template": {
        source: "iana",
        extensions: ["clkt"]
    },
    "application/vnd.crick.clicker.wordbank": {
        source: "iana",
        extensions: ["clkw"]
    },
    "application/vnd.criticaltools.wbs+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["wbs"]
    },
    "application/vnd.cryptii.pipe+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.crypto-shade-file": {
        source: "iana"
    },
    "application/vnd.cryptomator.encrypted": {
        source: "iana"
    },
    "application/vnd.cryptomator.vault": {
        source: "iana"
    },
    "application/vnd.ctc-posml": {
        source: "iana",
        extensions: ["pml"]
    },
    "application/vnd.ctct.ws+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.cups-pdf": {
        source: "iana"
    },
    "application/vnd.cups-postscript": {
        source: "iana"
    },
    "application/vnd.cups-ppd": {
        source: "iana",
        extensions: ["ppd"]
    },
    "application/vnd.cups-raster": {
        source: "iana"
    },
    "application/vnd.cups-raw": {
        source: "iana"
    },
    "application/vnd.curl": {
        source: "iana"
    },
    "application/vnd.curl.car": {
        source: "apache",
        extensions: ["car"]
    },
    "application/vnd.curl.pcurl": {
        source: "apache",
        extensions: ["pcurl"]
    },
    "application/vnd.cyan.dean.root+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.cybank": {
        source: "iana"
    },
    "application/vnd.cyclonedx+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.cyclonedx+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.d2l.coursepackage1p0+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.d3m-dataset": {
        source: "iana"
    },
    "application/vnd.d3m-problem": {
        source: "iana"
    },
    "application/vnd.dart": {
        source: "iana",
        compressible: !0,
        extensions: ["dart"]
    },
    "application/vnd.data-vision.rdz": {
        source: "iana",
        extensions: ["rdz"]
    },
    "application/vnd.datapackage+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dataresource+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dbf": {
        source: "iana",
        extensions: ["dbf"]
    },
    "application/vnd.debian.binary-package": {
        source: "iana"
    },
    "application/vnd.dece.data": {
        source: "iana",
        extensions: ["uvf", "uvvf", "uvd", "uvvd"]
    },
    "application/vnd.dece.ttml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["uvt", "uvvt"]
    },
    "application/vnd.dece.unspecified": {
        source: "iana",
        extensions: ["uvx", "uvvx"]
    },
    "application/vnd.dece.zip": {
        source: "iana",
        extensions: ["uvz", "uvvz"]
    },
    "application/vnd.denovo.fcselayout-link": {
        source: "iana",
        extensions: ["fe_launch"]
    },
    "application/vnd.desmume.movie": {
        source: "iana"
    },
    "application/vnd.dir-bi.plate-dl-nosuffix": {
        source: "iana"
    },
    "application/vnd.dm.delegation+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dna": {
        source: "iana",
        extensions: ["dna"]
    },
    "application/vnd.document+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dolby.mlp": {
        source: "apache",
        extensions: ["mlp"]
    },
    "application/vnd.dolby.mobile.1": {
        source: "iana"
    },
    "application/vnd.dolby.mobile.2": {
        source: "iana"
    },
    "application/vnd.doremir.scorecloud-binary-document": {
        source: "iana"
    },
    "application/vnd.dpgraph": {
        source: "iana",
        extensions: ["dpg"]
    },
    "application/vnd.dreamfactory": {
        source: "iana",
        extensions: ["dfac"]
    },
    "application/vnd.drive+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ds-keypoint": {
        source: "apache",
        extensions: ["kpxx"]
    },
    "application/vnd.dtg.local": {
        source: "iana"
    },
    "application/vnd.dtg.local.flash": {
        source: "iana"
    },
    "application/vnd.dtg.local.html": {
        source: "iana"
    },
    "application/vnd.dvb.ait": {
        source: "iana",
        extensions: ["ait"]
    },
    "application/vnd.dvb.dvbisl+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dvb.dvbj": {
        source: "iana"
    },
    "application/vnd.dvb.esgcontainer": {
        source: "iana"
    },
    "application/vnd.dvb.ipdcdftnotifaccess": {
        source: "iana"
    },
    "application/vnd.dvb.ipdcesgaccess": {
        source: "iana"
    },
    "application/vnd.dvb.ipdcesgaccess2": {
        source: "iana"
    },
    "application/vnd.dvb.ipdcesgpdd": {
        source: "iana"
    },
    "application/vnd.dvb.ipdcroaming": {
        source: "iana"
    },
    "application/vnd.dvb.iptv.alfec-base": {
        source: "iana"
    },
    "application/vnd.dvb.iptv.alfec-enhancement": {
        source: "iana"
    },
    "application/vnd.dvb.notif-aggregate-root+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dvb.notif-container+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dvb.notif-generic+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dvb.notif-ia-msglist+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dvb.notif-ia-registration-request+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dvb.notif-ia-registration-response+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dvb.notif-init+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.dvb.pfr": {
        source: "iana"
    },
    "application/vnd.dvb.service": {
        source: "iana",
        extensions: ["svc"]
    },
    "application/vnd.dxr": {
        source: "iana"
    },
    "application/vnd.dynageo": {
        source: "iana",
        extensions: ["geo"]
    },
    "application/vnd.dzr": {
        source: "iana"
    },
    "application/vnd.easykaraoke.cdgdownload": {
        source: "iana"
    },
    "application/vnd.ecdis-update": {
        source: "iana"
    },
    "application/vnd.ecip.rlp": {
        source: "iana"
    },
    "application/vnd.eclipse.ditto+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ecowin.chart": {
        source: "iana",
        extensions: ["mag"]
    },
    "application/vnd.ecowin.filerequest": {
        source: "iana"
    },
    "application/vnd.ecowin.fileupdate": {
        source: "iana"
    },
    "application/vnd.ecowin.series": {
        source: "iana"
    },
    "application/vnd.ecowin.seriesrequest": {
        source: "iana"
    },
    "application/vnd.ecowin.seriesupdate": {
        source: "iana"
    },
    "application/vnd.efi.img": {
        source: "iana"
    },
    "application/vnd.efi.iso": {
        source: "iana"
    },
    "application/vnd.emclient.accessrequest+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.enliven": {
        source: "iana",
        extensions: ["nml"]
    },
    "application/vnd.enphase.envoy": {
        source: "iana"
    },
    "application/vnd.eprints.data+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.epson.esf": {
        source: "iana",
        extensions: ["esf"]
    },
    "application/vnd.epson.msf": {
        source: "iana",
        extensions: ["msf"]
    },
    "application/vnd.epson.quickanime": {
        source: "iana",
        extensions: ["qam"]
    },
    "application/vnd.epson.salt": {
        source: "iana",
        extensions: ["slt"]
    },
    "application/vnd.epson.ssf": {
        source: "iana",
        extensions: ["ssf"]
    },
    "application/vnd.ericsson.quickcall": {
        source: "iana"
    },
    "application/vnd.espass-espass+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.eszigno3+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["es3", "et3"]
    },
    "application/vnd.etsi.aoc+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.asic-e+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.etsi.asic-s+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.etsi.cug+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.iptvcommand+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.iptvdiscovery+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.iptvprofile+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.iptvsad-bc+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.iptvsad-cod+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.iptvsad-npvr+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.iptvservice+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.iptvsync+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.iptvueprofile+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.mcid+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.mheg5": {
        source: "iana"
    },
    "application/vnd.etsi.overload-control-policy-dataset+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.pstn+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.sci+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.simservs+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.timestamp-token": {
        source: "iana"
    },
    "application/vnd.etsi.tsl+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.etsi.tsl.der": {
        source: "iana"
    },
    "application/vnd.eu.kasparian.car+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.eudora.data": {
        source: "iana"
    },
    "application/vnd.evolv.ecig.profile": {
        source: "iana"
    },
    "application/vnd.evolv.ecig.settings": {
        source: "iana"
    },
    "application/vnd.evolv.ecig.theme": {
        source: "iana"
    },
    "application/vnd.exstream-empower+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.exstream-package": {
        source: "iana"
    },
    "application/vnd.ezpix-album": {
        source: "iana",
        extensions: ["ez2"]
    },
    "application/vnd.ezpix-package": {
        source: "iana",
        extensions: ["ez3"]
    },
    "application/vnd.f-secure.mobile": {
        source: "iana"
    },
    "application/vnd.familysearch.gedcom+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.fastcopy-disk-image": {
        source: "iana"
    },
    "application/vnd.fdf": {
        source: "iana",
        extensions: ["fdf"]
    },
    "application/vnd.fdsn.mseed": {
        source: "iana",
        extensions: ["mseed"]
    },
    "application/vnd.fdsn.seed": {
        source: "iana",
        extensions: ["seed", "dataless"]
    },
    "application/vnd.ffsns": {
        source: "iana"
    },
    "application/vnd.ficlab.flb+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.filmit.zfc": {
        source: "iana"
    },
    "application/vnd.fints": {
        source: "iana"
    },
    "application/vnd.firemonkeys.cloudcell": {
        source: "iana"
    },
    "application/vnd.flographit": {
        source: "iana",
        extensions: ["gph"]
    },
    "application/vnd.fluxtime.clip": {
        source: "iana",
        extensions: ["ftc"]
    },
    "application/vnd.font-fontforge-sfd": {
        source: "iana"
    },
    "application/vnd.framemaker": {
        source: "iana",
        extensions: ["fm", "frame", "maker", "book"]
    },
    "application/vnd.frogans.fnc": {
        source: "iana",
        extensions: ["fnc"]
    },
    "application/vnd.frogans.ltf": {
        source: "iana",
        extensions: ["ltf"]
    },
    "application/vnd.fsc.weblaunch": {
        source: "iana",
        extensions: ["fsc"]
    },
    "application/vnd.fujifilm.fb.docuworks": {
        source: "iana"
    },
    "application/vnd.fujifilm.fb.docuworks.binder": {
        source: "iana"
    },
    "application/vnd.fujifilm.fb.docuworks.container": {
        source: "iana"
    },
    "application/vnd.fujifilm.fb.jfi+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.fujitsu.oasys": {
        source: "iana",
        extensions: ["oas"]
    },
    "application/vnd.fujitsu.oasys2": {
        source: "iana",
        extensions: ["oa2"]
    },
    "application/vnd.fujitsu.oasys3": {
        source: "iana",
        extensions: ["oa3"]
    },
    "application/vnd.fujitsu.oasysgp": {
        source: "iana",
        extensions: ["fg5"]
    },
    "application/vnd.fujitsu.oasysprs": {
        source: "iana",
        extensions: ["bh2"]
    },
    "application/vnd.fujixerox.art-ex": {
        source: "iana"
    },
    "application/vnd.fujixerox.art4": {
        source: "iana"
    },
    "application/vnd.fujixerox.ddd": {
        source: "iana",
        extensions: ["ddd"]
    },
    "application/vnd.fujixerox.docuworks": {
        source: "iana",
        extensions: ["xdw"]
    },
    "application/vnd.fujixerox.docuworks.binder": {
        source: "iana",
        extensions: ["xbd"]
    },
    "application/vnd.fujixerox.docuworks.container": {
        source: "iana"
    },
    "application/vnd.fujixerox.hbpl": {
        source: "iana"
    },
    "application/vnd.fut-misnet": {
        source: "iana"
    },
    "application/vnd.futoin+cbor": {
        source: "iana"
    },
    "application/vnd.futoin+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.fuzzysheet": {
        source: "iana",
        extensions: ["fzs"]
    },
    "application/vnd.genomatix.tuxedo": {
        source: "iana",
        extensions: ["txd"]
    },
    "application/vnd.gentics.grd+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.geo+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.geocube+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.geogebra.file": {
        source: "iana",
        extensions: ["ggb"]
    },
    "application/vnd.geogebra.slides": {
        source: "iana"
    },
    "application/vnd.geogebra.tool": {
        source: "iana",
        extensions: ["ggt"]
    },
    "application/vnd.geometry-explorer": {
        source: "iana",
        extensions: ["gex", "gre"]
    },
    "application/vnd.geonext": {
        source: "iana",
        extensions: ["gxt"]
    },
    "application/vnd.geoplan": {
        source: "iana",
        extensions: ["g2w"]
    },
    "application/vnd.geospace": {
        source: "iana",
        extensions: ["g3w"]
    },
    "application/vnd.gerber": {
        source: "iana"
    },
    "application/vnd.globalplatform.card-content-mgt": {
        source: "iana"
    },
    "application/vnd.globalplatform.card-content-mgt-response": {
        source: "iana"
    },
    "application/vnd.gmx": {
        source: "iana",
        extensions: ["gmx"]
    },
    "application/vnd.google-apps.document": {
        compressible: !1,
        extensions: ["gdoc"]
    },
    "application/vnd.google-apps.presentation": {
        compressible: !1,
        extensions: ["gslides"]
    },
    "application/vnd.google-apps.spreadsheet": {
        compressible: !1,
        extensions: ["gsheet"]
    },
    "application/vnd.google-earth.kml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["kml"]
    },
    "application/vnd.google-earth.kmz": {
        source: "iana",
        compressible: !1,
        extensions: ["kmz"]
    },
    "application/vnd.gov.sk.e-form+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.gov.sk.e-form+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.gov.sk.xmldatacontainer+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.grafeq": {
        source: "iana",
        extensions: ["gqf", "gqs"]
    },
    "application/vnd.gridmp": {
        source: "iana"
    },
    "application/vnd.groove-account": {
        source: "iana",
        extensions: ["gac"]
    },
    "application/vnd.groove-help": {
        source: "iana",
        extensions: ["ghf"]
    },
    "application/vnd.groove-identity-message": {
        source: "iana",
        extensions: ["gim"]
    },
    "application/vnd.groove-injector": {
        source: "iana",
        extensions: ["grv"]
    },
    "application/vnd.groove-tool-message": {
        source: "iana",
        extensions: ["gtm"]
    },
    "application/vnd.groove-tool-template": {
        source: "iana",
        extensions: ["tpl"]
    },
    "application/vnd.groove-vcard": {
        source: "iana",
        extensions: ["vcg"]
    },
    "application/vnd.hal+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.hal+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["hal"]
    },
    "application/vnd.handheld-entertainment+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["zmm"]
    },
    "application/vnd.hbci": {
        source: "iana",
        extensions: ["hbci"]
    },
    "application/vnd.hc+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.hcl-bireports": {
        source: "iana"
    },
    "application/vnd.hdt": {
        source: "iana"
    },
    "application/vnd.heroku+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.hhe.lesson-player": {
        source: "iana",
        extensions: ["les"]
    },
    "application/vnd.hl7cda+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/vnd.hl7v2+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/vnd.hp-hpgl": {
        source: "iana",
        extensions: ["hpgl"]
    },
    "application/vnd.hp-hpid": {
        source: "iana",
        extensions: ["hpid"]
    },
    "application/vnd.hp-hps": {
        source: "iana",
        extensions: ["hps"]
    },
    "application/vnd.hp-jlyt": {
        source: "iana",
        extensions: ["jlt"]
    },
    "application/vnd.hp-pcl": {
        source: "iana",
        extensions: ["pcl"]
    },
    "application/vnd.hp-pclxl": {
        source: "iana",
        extensions: ["pclxl"]
    },
    "application/vnd.httphone": {
        source: "iana"
    },
    "application/vnd.hydrostatix.sof-data": {
        source: "iana",
        extensions: ["sfd-hdstx"]
    },
    "application/vnd.hyper+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.hyper-item+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.hyperdrive+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.hzn-3d-crossword": {
        source: "iana"
    },
    "application/vnd.ibm.afplinedata": {
        source: "iana"
    },
    "application/vnd.ibm.electronic-media": {
        source: "iana"
    },
    "application/vnd.ibm.minipay": {
        source: "iana",
        extensions: ["mpy"]
    },
    "application/vnd.ibm.modcap": {
        source: "iana",
        extensions: ["afp", "listafp", "list3820"]
    },
    "application/vnd.ibm.rights-management": {
        source: "iana",
        extensions: ["irm"]
    },
    "application/vnd.ibm.secure-container": {
        source: "iana",
        extensions: ["sc"]
    },
    "application/vnd.iccprofile": {
        source: "iana",
        extensions: ["icc", "icm"]
    },
    "application/vnd.ieee.1905": {
        source: "iana"
    },
    "application/vnd.igloader": {
        source: "iana",
        extensions: ["igl"]
    },
    "application/vnd.imagemeter.folder+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.imagemeter.image+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.immervision-ivp": {
        source: "iana",
        extensions: ["ivp"]
    },
    "application/vnd.immervision-ivu": {
        source: "iana",
        extensions: ["ivu"]
    },
    "application/vnd.ims.imsccv1p1": {
        source: "iana"
    },
    "application/vnd.ims.imsccv1p2": {
        source: "iana"
    },
    "application/vnd.ims.imsccv1p3": {
        source: "iana"
    },
    "application/vnd.ims.lis.v2.result+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ims.lti.v2.toolconsumerprofile+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ims.lti.v2.toolproxy+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ims.lti.v2.toolproxy.id+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ims.lti.v2.toolsettings+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ims.lti.v2.toolsettings.simple+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.informedcontrol.rms+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.informix-visionary": {
        source: "iana"
    },
    "application/vnd.infotech.project": {
        source: "iana"
    },
    "application/vnd.infotech.project+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.innopath.wamp.notification": {
        source: "iana"
    },
    "application/vnd.insors.igm": {
        source: "iana",
        extensions: ["igm"]
    },
    "application/vnd.intercon.formnet": {
        source: "iana",
        extensions: ["xpw", "xpx"]
    },
    "application/vnd.intergeo": {
        source: "iana",
        extensions: ["i2g"]
    },
    "application/vnd.intertrust.digibox": {
        source: "iana"
    },
    "application/vnd.intertrust.nncp": {
        source: "iana"
    },
    "application/vnd.intu.qbo": {
        source: "iana",
        extensions: ["qbo"]
    },
    "application/vnd.intu.qfx": {
        source: "iana",
        extensions: ["qfx"]
    },
    "application/vnd.iptc.g2.catalogitem+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.iptc.g2.conceptitem+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.iptc.g2.knowledgeitem+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.iptc.g2.newsitem+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.iptc.g2.newsmessage+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.iptc.g2.packageitem+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.iptc.g2.planningitem+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ipunplugged.rcprofile": {
        source: "iana",
        extensions: ["rcprofile"]
    },
    "application/vnd.irepository.package+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["irp"]
    },
    "application/vnd.is-xpr": {
        source: "iana",
        extensions: ["xpr"]
    },
    "application/vnd.isac.fcs": {
        source: "iana",
        extensions: ["fcs"]
    },
    "application/vnd.iso11783-10+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.jam": {
        source: "iana",
        extensions: ["jam"]
    },
    "application/vnd.japannet-directory-service": {
        source: "iana"
    },
    "application/vnd.japannet-jpnstore-wakeup": {
        source: "iana"
    },
    "application/vnd.japannet-payment-wakeup": {
        source: "iana"
    },
    "application/vnd.japannet-registration": {
        source: "iana"
    },
    "application/vnd.japannet-registration-wakeup": {
        source: "iana"
    },
    "application/vnd.japannet-setstore-wakeup": {
        source: "iana"
    },
    "application/vnd.japannet-verification": {
        source: "iana"
    },
    "application/vnd.japannet-verification-wakeup": {
        source: "iana"
    },
    "application/vnd.jcp.javame.midlet-rms": {
        source: "iana",
        extensions: ["rms"]
    },
    "application/vnd.jisp": {
        source: "iana",
        extensions: ["jisp"]
    },
    "application/vnd.joost.joda-archive": {
        source: "iana",
        extensions: ["joda"]
    },
    "application/vnd.jsk.isdn-ngn": {
        source: "iana"
    },
    "application/vnd.kahootz": {
        source: "iana",
        extensions: ["ktz", "ktr"]
    },
    "application/vnd.kde.karbon": {
        source: "iana",
        extensions: ["karbon"]
    },
    "application/vnd.kde.kchart": {
        source: "iana",
        extensions: ["chrt"]
    },
    "application/vnd.kde.kformula": {
        source: "iana",
        extensions: ["kfo"]
    },
    "application/vnd.kde.kivio": {
        source: "iana",
        extensions: ["flw"]
    },
    "application/vnd.kde.kontour": {
        source: "iana",
        extensions: ["kon"]
    },
    "application/vnd.kde.kpresenter": {
        source: "iana",
        extensions: ["kpr", "kpt"]
    },
    "application/vnd.kde.kspread": {
        source: "iana",
        extensions: ["ksp"]
    },
    "application/vnd.kde.kword": {
        source: "iana",
        extensions: ["kwd", "kwt"]
    },
    "application/vnd.kenameaapp": {
        source: "iana",
        extensions: ["htke"]
    },
    "application/vnd.kidspiration": {
        source: "iana",
        extensions: ["kia"]
    },
    "application/vnd.kinar": {
        source: "iana",
        extensions: ["kne", "knp"]
    },
    "application/vnd.koan": {
        source: "iana",
        extensions: ["skp", "skd", "skt", "skm"]
    },
    "application/vnd.kodak-descriptor": {
        source: "iana",
        extensions: ["sse"]
    },
    "application/vnd.las": {
        source: "iana"
    },
    "application/vnd.las.las+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.las.las+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["lasxml"]
    },
    "application/vnd.laszip": {
        source: "iana"
    },
    "application/vnd.leap+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.liberty-request+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.llamagraphics.life-balance.desktop": {
        source: "iana",
        extensions: ["lbd"]
    },
    "application/vnd.llamagraphics.life-balance.exchange+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["lbe"]
    },
    "application/vnd.logipipe.circuit+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.loom": {
        source: "iana"
    },
    "application/vnd.lotus-1-2-3": {
        source: "iana",
        extensions: ["123"]
    },
    "application/vnd.lotus-approach": {
        source: "iana",
        extensions: ["apr"]
    },
    "application/vnd.lotus-freelance": {
        source: "iana",
        extensions: ["pre"]
    },
    "application/vnd.lotus-notes": {
        source: "iana",
        extensions: ["nsf"]
    },
    "application/vnd.lotus-organizer": {
        source: "iana",
        extensions: ["org"]
    },
    "application/vnd.lotus-screencam": {
        source: "iana",
        extensions: ["scm"]
    },
    "application/vnd.lotus-wordpro": {
        source: "iana",
        extensions: ["lwp"]
    },
    "application/vnd.macports.portpkg": {
        source: "iana",
        extensions: ["portpkg"]
    },
    "application/vnd.mapbox-vector-tile": {
        source: "iana",
        extensions: ["mvt"]
    },
    "application/vnd.marlin.drm.actiontoken+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.marlin.drm.conftoken+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.marlin.drm.license+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.marlin.drm.mdcf": {
        source: "iana"
    },
    "application/vnd.mason+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.maxar.archive.3tz+zip": {
        source: "iana",
        compressible: !1
    },
    "application/vnd.maxmind.maxmind-db": {
        source: "iana"
    },
    "application/vnd.mcd": {
        source: "iana",
        extensions: ["mcd"]
    },
    "application/vnd.medcalcdata": {
        source: "iana",
        extensions: ["mc1"]
    },
    "application/vnd.mediastation.cdkey": {
        source: "iana",
        extensions: ["cdkey"]
    },
    "application/vnd.meridian-slingshot": {
        source: "iana"
    },
    "application/vnd.mfer": {
        source: "iana",
        extensions: ["mwf"]
    },
    "application/vnd.mfmp": {
        source: "iana",
        extensions: ["mfm"]
    },
    "application/vnd.micro+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.micrografx.flo": {
        source: "iana",
        extensions: ["flo"]
    },
    "application/vnd.micrografx.igx": {
        source: "iana",
        extensions: ["igx"]
    },
    "application/vnd.microsoft.portable-executable": {
        source: "iana"
    },
    "application/vnd.microsoft.windows.thumbnail-cache": {
        source: "iana"
    },
    "application/vnd.miele+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.mif": {
        source: "iana",
        extensions: ["mif"]
    },
    "application/vnd.minisoft-hp3000-save": {
        source: "iana"
    },
    "application/vnd.mitsubishi.misty-guard.trustweb": {
        source: "iana"
    },
    "application/vnd.mobius.daf": {
        source: "iana",
        extensions: ["daf"]
    },
    "application/vnd.mobius.dis": {
        source: "iana",
        extensions: ["dis"]
    },
    "application/vnd.mobius.mbk": {
        source: "iana",
        extensions: ["mbk"]
    },
    "application/vnd.mobius.mqy": {
        source: "iana",
        extensions: ["mqy"]
    },
    "application/vnd.mobius.msl": {
        source: "iana",
        extensions: ["msl"]
    },
    "application/vnd.mobius.plc": {
        source: "iana",
        extensions: ["plc"]
    },
    "application/vnd.mobius.txf": {
        source: "iana",
        extensions: ["txf"]
    },
    "application/vnd.mophun.application": {
        source: "iana",
        extensions: ["mpn"]
    },
    "application/vnd.mophun.certificate": {
        source: "iana",
        extensions: ["mpc"]
    },
    "application/vnd.motorola.flexsuite": {
        source: "iana"
    },
    "application/vnd.motorola.flexsuite.adsi": {
        source: "iana"
    },
    "application/vnd.motorola.flexsuite.fis": {
        source: "iana"
    },
    "application/vnd.motorola.flexsuite.gotap": {
        source: "iana"
    },
    "application/vnd.motorola.flexsuite.kmr": {
        source: "iana"
    },
    "application/vnd.motorola.flexsuite.ttc": {
        source: "iana"
    },
    "application/vnd.motorola.flexsuite.wem": {
        source: "iana"
    },
    "application/vnd.motorola.iprm": {
        source: "iana"
    },
    "application/vnd.mozilla.xul+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xul"]
    },
    "application/vnd.ms-3mfdocument": {
        source: "iana"
    },
    "application/vnd.ms-artgalry": {
        source: "iana",
        extensions: ["cil"]
    },
    "application/vnd.ms-asf": {
        source: "iana"
    },
    "application/vnd.ms-cab-compressed": {
        source: "iana",
        extensions: ["cab"]
    },
    "application/vnd.ms-color.iccprofile": {
        source: "apache"
    },
    "application/vnd.ms-excel": {
        source: "iana",
        compressible: !1,
        extensions: ["xls", "xlm", "xla", "xlc", "xlt", "xlw"]
    },
    "application/vnd.ms-excel.addin.macroenabled.12": {
        source: "iana",
        extensions: ["xlam"]
    },
    "application/vnd.ms-excel.sheet.binary.macroenabled.12": {
        source: "iana",
        extensions: ["xlsb"]
    },
    "application/vnd.ms-excel.sheet.macroenabled.12": {
        source: "iana",
        extensions: ["xlsm"]
    },
    "application/vnd.ms-excel.template.macroenabled.12": {
        source: "iana",
        extensions: ["xltm"]
    },
    "application/vnd.ms-fontobject": {
        source: "iana",
        compressible: !0,
        extensions: ["eot"]
    },
    "application/vnd.ms-htmlhelp": {
        source: "iana",
        extensions: ["chm"]
    },
    "application/vnd.ms-ims": {
        source: "iana",
        extensions: ["ims"]
    },
    "application/vnd.ms-lrm": {
        source: "iana",
        extensions: ["lrm"]
    },
    "application/vnd.ms-office.activex+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ms-officetheme": {
        source: "iana",
        extensions: ["thmx"]
    },
    "application/vnd.ms-opentype": {
        source: "apache",
        compressible: !0
    },
    "application/vnd.ms-outlook": {
        compressible: !1,
        extensions: ["msg"]
    },
    "application/vnd.ms-package.obfuscated-opentype": {
        source: "apache"
    },
    "application/vnd.ms-pki.seccat": {
        source: "apache",
        extensions: ["cat"]
    },
    "application/vnd.ms-pki.stl": {
        source: "apache",
        extensions: ["stl"]
    },
    "application/vnd.ms-playready.initiator+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ms-powerpoint": {
        source: "iana",
        compressible: !1,
        extensions: ["ppt", "pps", "pot"]
    },
    "application/vnd.ms-powerpoint.addin.macroenabled.12": {
        source: "iana",
        extensions: ["ppam"]
    },
    "application/vnd.ms-powerpoint.presentation.macroenabled.12": {
        source: "iana",
        extensions: ["pptm"]
    },
    "application/vnd.ms-powerpoint.slide.macroenabled.12": {
        source: "iana",
        extensions: ["sldm"]
    },
    "application/vnd.ms-powerpoint.slideshow.macroenabled.12": {
        source: "iana",
        extensions: ["ppsm"]
    },
    "application/vnd.ms-powerpoint.template.macroenabled.12": {
        source: "iana",
        extensions: ["potm"]
    },
    "application/vnd.ms-printdevicecapabilities+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ms-printing.printticket+xml": {
        source: "apache",
        compressible: !0
    },
    "application/vnd.ms-printschematicket+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ms-project": {
        source: "iana",
        extensions: ["mpp", "mpt"]
    },
    "application/vnd.ms-tnef": {
        source: "iana"
    },
    "application/vnd.ms-windows.devicepairing": {
        source: "iana"
    },
    "application/vnd.ms-windows.nwprinting.oob": {
        source: "iana"
    },
    "application/vnd.ms-windows.printerpairing": {
        source: "iana"
    },
    "application/vnd.ms-windows.wsd.oob": {
        source: "iana"
    },
    "application/vnd.ms-wmdrm.lic-chlg-req": {
        source: "iana"
    },
    "application/vnd.ms-wmdrm.lic-resp": {
        source: "iana"
    },
    "application/vnd.ms-wmdrm.meter-chlg-req": {
        source: "iana"
    },
    "application/vnd.ms-wmdrm.meter-resp": {
        source: "iana"
    },
    "application/vnd.ms-word.document.macroenabled.12": {
        source: "iana",
        extensions: ["docm"]
    },
    "application/vnd.ms-word.template.macroenabled.12": {
        source: "iana",
        extensions: ["dotm"]
    },
    "application/vnd.ms-works": {
        source: "iana",
        extensions: ["wps", "wks", "wcm", "wdb"]
    },
    "application/vnd.ms-wpl": {
        source: "iana",
        extensions: ["wpl"]
    },
    "application/vnd.ms-xpsdocument": {
        source: "iana",
        compressible: !1,
        extensions: ["xps"]
    },
    "application/vnd.msa-disk-image": {
        source: "iana"
    },
    "application/vnd.mseq": {
        source: "iana",
        extensions: ["mseq"]
    },
    "application/vnd.msign": {
        source: "iana"
    },
    "application/vnd.multiad.creator": {
        source: "iana"
    },
    "application/vnd.multiad.creator.cif": {
        source: "iana"
    },
    "application/vnd.music-niff": {
        source: "iana"
    },
    "application/vnd.musician": {
        source: "iana",
        extensions: ["mus"]
    },
    "application/vnd.muvee.style": {
        source: "iana",
        extensions: ["msty"]
    },
    "application/vnd.mynfc": {
        source: "iana",
        extensions: ["taglet"]
    },
    "application/vnd.nacamar.ybrid+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.ncd.control": {
        source: "iana"
    },
    "application/vnd.ncd.reference": {
        source: "iana"
    },
    "application/vnd.nearst.inv+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.nebumind.line": {
        source: "iana"
    },
    "application/vnd.nervana": {
        source: "iana"
    },
    "application/vnd.netfpx": {
        source: "iana"
    },
    "application/vnd.neurolanguage.nlu": {
        source: "iana",
        extensions: ["nlu"]
    },
    "application/vnd.nimn": {
        source: "iana"
    },
    "application/vnd.nintendo.nitro.rom": {
        source: "iana"
    },
    "application/vnd.nintendo.snes.rom": {
        source: "iana"
    },
    "application/vnd.nitf": {
        source: "iana",
        extensions: ["ntf", "nitf"]
    },
    "application/vnd.noblenet-directory": {
        source: "iana",
        extensions: ["nnd"]
    },
    "application/vnd.noblenet-sealer": {
        source: "iana",
        extensions: ["nns"]
    },
    "application/vnd.noblenet-web": {
        source: "iana",
        extensions: ["nnw"]
    },
    "application/vnd.nokia.catalogs": {
        source: "iana"
    },
    "application/vnd.nokia.conml+wbxml": {
        source: "iana"
    },
    "application/vnd.nokia.conml+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.nokia.iptv.config+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.nokia.isds-radio-presets": {
        source: "iana"
    },
    "application/vnd.nokia.landmark+wbxml": {
        source: "iana"
    },
    "application/vnd.nokia.landmark+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.nokia.landmarkcollection+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.nokia.n-gage.ac+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["ac"]
    },
    "application/vnd.nokia.n-gage.data": {
        source: "iana",
        extensions: ["ngdat"]
    },
    "application/vnd.nokia.n-gage.symbian.install": {
        source: "iana",
        extensions: ["n-gage"]
    },
    "application/vnd.nokia.ncd": {
        source: "iana"
    },
    "application/vnd.nokia.pcd+wbxml": {
        source: "iana"
    },
    "application/vnd.nokia.pcd+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.nokia.radio-preset": {
        source: "iana",
        extensions: ["rpst"]
    },
    "application/vnd.nokia.radio-presets": {
        source: "iana",
        extensions: ["rpss"]
    },
    "application/vnd.novadigm.edm": {
        source: "iana",
        extensions: ["edm"]
    },
    "application/vnd.novadigm.edx": {
        source: "iana",
        extensions: ["edx"]
    },
    "application/vnd.novadigm.ext": {
        source: "iana",
        extensions: ["ext"]
    },
    "application/vnd.ntt-local.content-share": {
        source: "iana"
    },
    "application/vnd.ntt-local.file-transfer": {
        source: "iana"
    },
    "application/vnd.ntt-local.ogw_remote-access": {
        source: "iana"
    },
    "application/vnd.ntt-local.sip-ta_remote": {
        source: "iana"
    },
    "application/vnd.ntt-local.sip-ta_tcp_stream": {
        source: "iana"
    },
    "application/vnd.oasis.opendocument.chart": {
        source: "iana",
        extensions: ["odc"]
    },
    "application/vnd.oasis.opendocument.chart-template": {
        source: "iana",
        extensions: ["otc"]
    },
    "application/vnd.oasis.opendocument.database": {
        source: "iana",
        extensions: ["odb"]
    },
    "application/vnd.oasis.opendocument.formula": {
        source: "iana",
        extensions: ["odf"]
    },
    "application/vnd.oasis.opendocument.formula-template": {
        source: "iana",
        extensions: ["odft"]
    },
    "application/vnd.oasis.opendocument.graphics": {
        source: "iana",
        compressible: !1,
        extensions: ["odg"]
    },
    "application/vnd.oasis.opendocument.graphics-template": {
        source: "iana",
        extensions: ["otg"]
    },
    "application/vnd.oasis.opendocument.image": {
        source: "iana",
        extensions: ["odi"]
    },
    "application/vnd.oasis.opendocument.image-template": {
        source: "iana",
        extensions: ["oti"]
    },
    "application/vnd.oasis.opendocument.presentation": {
        source: "iana",
        compressible: !1,
        extensions: ["odp"]
    },
    "application/vnd.oasis.opendocument.presentation-template": {
        source: "iana",
        extensions: ["otp"]
    },
    "application/vnd.oasis.opendocument.spreadsheet": {
        source: "iana",
        compressible: !1,
        extensions: ["ods"]
    },
    "application/vnd.oasis.opendocument.spreadsheet-template": {
        source: "iana",
        extensions: ["ots"]
    },
    "application/vnd.oasis.opendocument.text": {
        source: "iana",
        compressible: !1,
        extensions: ["odt"]
    },
    "application/vnd.oasis.opendocument.text-master": {
        source: "iana",
        extensions: ["odm"]
    },
    "application/vnd.oasis.opendocument.text-template": {
        source: "iana",
        extensions: ["ott"]
    },
    "application/vnd.oasis.opendocument.text-web": {
        source: "iana",
        extensions: ["oth"]
    },
    "application/vnd.obn": {
        source: "iana"
    },
    "application/vnd.ocf+cbor": {
        source: "iana"
    },
    "application/vnd.oci.image.manifest.v1+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oftn.l10n+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oipf.contentaccessdownload+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oipf.contentaccessstreaming+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oipf.cspg-hexbinary": {
        source: "iana"
    },
    "application/vnd.oipf.dae.svg+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oipf.dae.xhtml+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oipf.mippvcontrolmessage+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oipf.pae.gem": {
        source: "iana"
    },
    "application/vnd.oipf.spdiscovery+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oipf.spdlist+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oipf.ueprofile+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oipf.userprofile+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.olpc-sugar": {
        source: "iana",
        extensions: ["xo"]
    },
    "application/vnd.oma-scws-config": {
        source: "iana"
    },
    "application/vnd.oma-scws-http-request": {
        source: "iana"
    },
    "application/vnd.oma-scws-http-response": {
        source: "iana"
    },
    "application/vnd.oma.bcast.associated-procedure-parameter+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.bcast.drm-trigger+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.bcast.imd+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.bcast.ltkm": {
        source: "iana"
    },
    "application/vnd.oma.bcast.notification+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.bcast.provisioningtrigger": {
        source: "iana"
    },
    "application/vnd.oma.bcast.sgboot": {
        source: "iana"
    },
    "application/vnd.oma.bcast.sgdd+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.bcast.sgdu": {
        source: "iana"
    },
    "application/vnd.oma.bcast.simple-symbol-container": {
        source: "iana"
    },
    "application/vnd.oma.bcast.smartcard-trigger+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.bcast.sprov+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.bcast.stkm": {
        source: "iana"
    },
    "application/vnd.oma.cab-address-book+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.cab-feature-handler+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.cab-pcc+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.cab-subs-invite+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.cab-user-prefs+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.dcd": {
        source: "iana"
    },
    "application/vnd.oma.dcdc": {
        source: "iana"
    },
    "application/vnd.oma.dd2+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["dd2"]
    },
    "application/vnd.oma.drm.risd+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.group-usage-list+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.lwm2m+cbor": {
        source: "iana"
    },
    "application/vnd.oma.lwm2m+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.lwm2m+tlv": {
        source: "iana"
    },
    "application/vnd.oma.pal+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.poc.detailed-progress-report+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.poc.final-report+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.poc.groups+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.poc.invocation-descriptor+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.poc.optimized-progress-report+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.push": {
        source: "iana"
    },
    "application/vnd.oma.scidm.messages+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oma.xcap-directory+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.omads-email+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/vnd.omads-file+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/vnd.omads-folder+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/vnd.omaloc-supl-init": {
        source: "iana"
    },
    "application/vnd.onepager": {
        source: "iana"
    },
    "application/vnd.onepagertamp": {
        source: "iana"
    },
    "application/vnd.onepagertamx": {
        source: "iana"
    },
    "application/vnd.onepagertat": {
        source: "iana"
    },
    "application/vnd.onepagertatp": {
        source: "iana"
    },
    "application/vnd.onepagertatx": {
        source: "iana"
    },
    "application/vnd.openblox.game+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["obgx"]
    },
    "application/vnd.openblox.game-binary": {
        source: "iana"
    },
    "application/vnd.openeye.oeb": {
        source: "iana"
    },
    "application/vnd.openofficeorg.extension": {
        source: "apache",
        extensions: ["oxt"]
    },
    "application/vnd.openstreetmap.data+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["osm"]
    },
    "application/vnd.opentimestamps.ots": {
        source: "iana"
    },
    "application/vnd.openxmlformats-officedocument.custom-properties+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.customxmlproperties+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.drawing+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.drawingml.chart+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.drawingml.chartshapes+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.drawingml.diagramcolors+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.drawingml.diagramdata+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.drawingml.diagramlayout+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.drawingml.diagramstyle+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.extended-properties+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.commentauthors+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.comments+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.handoutmaster+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.notesmaster+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.notesslide+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": {
        source: "iana",
        compressible: !1,
        extensions: ["pptx"]
    },
    "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.presprops+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.slide": {
        source: "iana",
        extensions: ["sldx"]
    },
    "application/vnd.openxmlformats-officedocument.presentationml.slide+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.slidelayout+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.slidemaster+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.slideshow": {
        source: "iana",
        extensions: ["ppsx"]
    },
    "application/vnd.openxmlformats-officedocument.presentationml.slideshow.main+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.slideupdateinfo+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.tablestyles+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.tags+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.template": {
        source: "iana",
        extensions: ["potx"]
    },
    "application/vnd.openxmlformats-officedocument.presentationml.template.main+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.presentationml.viewprops+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.calcchain+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.chartsheet+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.connections+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.dialogsheet+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.externallink+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotcachedefinition+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.pivotcacherecords+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.pivottable+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.querytable+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionheaders+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.revisionlog+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sharedstrings+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": {
        source: "iana",
        compressible: !1,
        extensions: ["xlsx"]
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheetmetadata+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.tablesinglecells+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.template": {
        source: "iana",
        extensions: ["xltx"]
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.template.main+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.usernames+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.volatiledependencies+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.theme+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.themeoverride+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.vmldrawing": {
        source: "iana"
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.comments+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": {
        source: "iana",
        compressible: !1,
        extensions: ["docx"]
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document.glossary+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.endnotes+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.fonttable+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.footer+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.footnotes+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.settings+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.template": {
        source: "iana",
        extensions: ["dotx"]
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.template.main+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-officedocument.wordprocessingml.websettings+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-package.core-properties+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-package.digital-signature-xmlsignature+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.openxmlformats-package.relationships+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oracle.resource+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.orange.indata": {
        source: "iana"
    },
    "application/vnd.osa.netdeploy": {
        source: "iana"
    },
    "application/vnd.osgeo.mapguide.package": {
        source: "iana",
        extensions: ["mgp"]
    },
    "application/vnd.osgi.bundle": {
        source: "iana"
    },
    "application/vnd.osgi.dp": {
        source: "iana",
        extensions: ["dp"]
    },
    "application/vnd.osgi.subsystem": {
        source: "iana",
        extensions: ["esa"]
    },
    "application/vnd.otps.ct-kip+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.oxli.countgraph": {
        source: "iana"
    },
    "application/vnd.pagerduty+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.palm": {
        source: "iana",
        extensions: ["pdb", "pqa", "oprc"]
    },
    "application/vnd.panoply": {
        source: "iana"
    },
    "application/vnd.paos.xml": {
        source: "iana"
    },
    "application/vnd.patentdive": {
        source: "iana"
    },
    "application/vnd.patientecommsdoc": {
        source: "iana"
    },
    "application/vnd.pawaafile": {
        source: "iana",
        extensions: ["paw"]
    },
    "application/vnd.pcos": {
        source: "iana"
    },
    "application/vnd.pg.format": {
        source: "iana",
        extensions: ["str"]
    },
    "application/vnd.pg.osasli": {
        source: "iana",
        extensions: ["ei6"]
    },
    "application/vnd.piaccess.application-licence": {
        source: "iana"
    },
    "application/vnd.picsel": {
        source: "iana",
        extensions: ["efif"]
    },
    "application/vnd.pmi.widget": {
        source: "iana",
        extensions: ["wg"]
    },
    "application/vnd.poc.group-advertisement+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.pocketlearn": {
        source: "iana",
        extensions: ["plf"]
    },
    "application/vnd.powerbuilder6": {
        source: "iana",
        extensions: ["pbd"]
    },
    "application/vnd.powerbuilder6-s": {
        source: "iana"
    },
    "application/vnd.powerbuilder7": {
        source: "iana"
    },
    "application/vnd.powerbuilder7-s": {
        source: "iana"
    },
    "application/vnd.powerbuilder75": {
        source: "iana"
    },
    "application/vnd.powerbuilder75-s": {
        source: "iana"
    },
    "application/vnd.preminet": {
        source: "iana"
    },
    "application/vnd.previewsystems.box": {
        source: "iana",
        extensions: ["box"]
    },
    "application/vnd.proteus.magazine": {
        source: "iana",
        extensions: ["mgz"]
    },
    "application/vnd.psfs": {
        source: "iana"
    },
    "application/vnd.publishare-delta-tree": {
        source: "iana",
        extensions: ["qps"]
    },
    "application/vnd.pvi.ptid1": {
        source: "iana",
        extensions: ["ptid"]
    },
    "application/vnd.pwg-multiplexed": {
        source: "iana"
    },
    "application/vnd.pwg-xhtml-print+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.qualcomm.brew-app-res": {
        source: "iana"
    },
    "application/vnd.quarantainenet": {
        source: "iana"
    },
    "application/vnd.quark.quarkxpress": {
        source: "iana",
        extensions: ["qxd", "qxt", "qwd", "qwt", "qxl", "qxb"]
    },
    "application/vnd.quobject-quoxdocument": {
        source: "iana"
    },
    "application/vnd.radisys.moml+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-audit+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-audit-conf+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-audit-conn+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-audit-dialog+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-audit-stream+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-conf+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-dialog+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-dialog-base+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-dialog-fax-detect+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-dialog-fax-sendrecv+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-dialog-group+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-dialog-speech+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.radisys.msml-dialog-transform+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.rainstor.data": {
        source: "iana"
    },
    "application/vnd.rapid": {
        source: "iana"
    },
    "application/vnd.rar": {
        source: "iana",
        extensions: ["rar"]
    },
    "application/vnd.realvnc.bed": {
        source: "iana",
        extensions: ["bed"]
    },
    "application/vnd.recordare.musicxml": {
        source: "iana",
        extensions: ["mxl"]
    },
    "application/vnd.recordare.musicxml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["musicxml"]
    },
    "application/vnd.renlearn.rlprint": {
        source: "iana"
    },
    "application/vnd.resilient.logic": {
        source: "iana"
    },
    "application/vnd.restful+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.rig.cryptonote": {
        source: "iana",
        extensions: ["cryptonote"]
    },
    "application/vnd.rim.cod": {
        source: "apache",
        extensions: ["cod"]
    },
    "application/vnd.rn-realmedia": {
        source: "apache",
        extensions: ["rm"]
    },
    "application/vnd.rn-realmedia-vbr": {
        source: "apache",
        extensions: ["rmvb"]
    },
    "application/vnd.route66.link66+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["link66"]
    },
    "application/vnd.rs-274x": {
        source: "iana"
    },
    "application/vnd.ruckus.download": {
        source: "iana"
    },
    "application/vnd.s3sms": {
        source: "iana"
    },
    "application/vnd.sailingtracker.track": {
        source: "iana",
        extensions: ["st"]
    },
    "application/vnd.sar": {
        source: "iana"
    },
    "application/vnd.sbm.cid": {
        source: "iana"
    },
    "application/vnd.sbm.mid2": {
        source: "iana"
    },
    "application/vnd.scribus": {
        source: "iana"
    },
    "application/vnd.sealed.3df": {
        source: "iana"
    },
    "application/vnd.sealed.csf": {
        source: "iana"
    },
    "application/vnd.sealed.doc": {
        source: "iana"
    },
    "application/vnd.sealed.eml": {
        source: "iana"
    },
    "application/vnd.sealed.mht": {
        source: "iana"
    },
    "application/vnd.sealed.net": {
        source: "iana"
    },
    "application/vnd.sealed.ppt": {
        source: "iana"
    },
    "application/vnd.sealed.tiff": {
        source: "iana"
    },
    "application/vnd.sealed.xls": {
        source: "iana"
    },
    "application/vnd.sealedmedia.softseal.html": {
        source: "iana"
    },
    "application/vnd.sealedmedia.softseal.pdf": {
        source: "iana"
    },
    "application/vnd.seemail": {
        source: "iana",
        extensions: ["see"]
    },
    "application/vnd.seis+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.sema": {
        source: "iana",
        extensions: ["sema"]
    },
    "application/vnd.semd": {
        source: "iana",
        extensions: ["semd"]
    },
    "application/vnd.semf": {
        source: "iana",
        extensions: ["semf"]
    },
    "application/vnd.shade-save-file": {
        source: "iana"
    },
    "application/vnd.shana.informed.formdata": {
        source: "iana",
        extensions: ["ifm"]
    },
    "application/vnd.shana.informed.formtemplate": {
        source: "iana",
        extensions: ["itp"]
    },
    "application/vnd.shana.informed.interchange": {
        source: "iana",
        extensions: ["iif"]
    },
    "application/vnd.shana.informed.package": {
        source: "iana",
        extensions: ["ipk"]
    },
    "application/vnd.shootproof+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.shopkick+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.shp": {
        source: "iana"
    },
    "application/vnd.shx": {
        source: "iana"
    },
    "application/vnd.sigrok.session": {
        source: "iana"
    },
    "application/vnd.simtech-mindmapper": {
        source: "iana",
        extensions: ["twd", "twds"]
    },
    "application/vnd.siren+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.smaf": {
        source: "iana",
        extensions: ["mmf"]
    },
    "application/vnd.smart.notebook": {
        source: "iana"
    },
    "application/vnd.smart.teacher": {
        source: "iana",
        extensions: ["teacher"]
    },
    "application/vnd.snesdev-page-table": {
        source: "iana"
    },
    "application/vnd.software602.filler.form+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["fo"]
    },
    "application/vnd.software602.filler.form-xml-zip": {
        source: "iana"
    },
    "application/vnd.solent.sdkm+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["sdkm", "sdkd"]
    },
    "application/vnd.spotfire.dxp": {
        source: "iana",
        extensions: ["dxp"]
    },
    "application/vnd.spotfire.sfs": {
        source: "iana",
        extensions: ["sfs"]
    },
    "application/vnd.sqlite3": {
        source: "iana"
    },
    "application/vnd.sss-cod": {
        source: "iana"
    },
    "application/vnd.sss-dtf": {
        source: "iana"
    },
    "application/vnd.sss-ntf": {
        source: "iana"
    },
    "application/vnd.stardivision.calc": {
        source: "apache",
        extensions: ["sdc"]
    },
    "application/vnd.stardivision.draw": {
        source: "apache",
        extensions: ["sda"]
    },
    "application/vnd.stardivision.impress": {
        source: "apache",
        extensions: ["sdd"]
    },
    "application/vnd.stardivision.math": {
        source: "apache",
        extensions: ["smf"]
    },
    "application/vnd.stardivision.writer": {
        source: "apache",
        extensions: ["sdw", "vor"]
    },
    "application/vnd.stardivision.writer-global": {
        source: "apache",
        extensions: ["sgl"]
    },
    "application/vnd.stepmania.package": {
        source: "iana",
        extensions: ["smzip"]
    },
    "application/vnd.stepmania.stepchart": {
        source: "iana",
        extensions: ["sm"]
    },
    "application/vnd.street-stream": {
        source: "iana"
    },
    "application/vnd.sun.wadl+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["wadl"]
    },
    "application/vnd.sun.xml.calc": {
        source: "apache",
        extensions: ["sxc"]
    },
    "application/vnd.sun.xml.calc.template": {
        source: "apache",
        extensions: ["stc"]
    },
    "application/vnd.sun.xml.draw": {
        source: "apache",
        extensions: ["sxd"]
    },
    "application/vnd.sun.xml.draw.template": {
        source: "apache",
        extensions: ["std"]
    },
    "application/vnd.sun.xml.impress": {
        source: "apache",
        extensions: ["sxi"]
    },
    "application/vnd.sun.xml.impress.template": {
        source: "apache",
        extensions: ["sti"]
    },
    "application/vnd.sun.xml.math": {
        source: "apache",
        extensions: ["sxm"]
    },
    "application/vnd.sun.xml.writer": {
        source: "apache",
        extensions: ["sxw"]
    },
    "application/vnd.sun.xml.writer.global": {
        source: "apache",
        extensions: ["sxg"]
    },
    "application/vnd.sun.xml.writer.template": {
        source: "apache",
        extensions: ["stw"]
    },
    "application/vnd.sus-calendar": {
        source: "iana",
        extensions: ["sus", "susp"]
    },
    "application/vnd.svd": {
        source: "iana",
        extensions: ["svd"]
    },
    "application/vnd.swiftview-ics": {
        source: "iana"
    },
    "application/vnd.sycle+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.syft+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.symbian.install": {
        source: "apache",
        extensions: ["sis", "sisx"]
    },
    "application/vnd.syncml+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0,
        extensions: ["xsm"]
    },
    "application/vnd.syncml.dm+wbxml": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["bdm"]
    },
    "application/vnd.syncml.dm+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0,
        extensions: ["xdm"]
    },
    "application/vnd.syncml.dm.notification": {
        source: "iana"
    },
    "application/vnd.syncml.dmddf+wbxml": {
        source: "iana"
    },
    "application/vnd.syncml.dmddf+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0,
        extensions: ["ddf"]
    },
    "application/vnd.syncml.dmtnds+wbxml": {
        source: "iana"
    },
    "application/vnd.syncml.dmtnds+xml": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0
    },
    "application/vnd.syncml.ds.notification": {
        source: "iana"
    },
    "application/vnd.tableschema+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.tao.intent-module-archive": {
        source: "iana",
        extensions: ["tao"]
    },
    "application/vnd.tcpdump.pcap": {
        source: "iana",
        extensions: ["pcap", "cap", "dmp"]
    },
    "application/vnd.think-cell.ppttc+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.tmd.mediaflex.api+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.tml": {
        source: "iana"
    },
    "application/vnd.tmobile-livetv": {
        source: "iana",
        extensions: ["tmo"]
    },
    "application/vnd.tri.onesource": {
        source: "iana"
    },
    "application/vnd.trid.tpt": {
        source: "iana",
        extensions: ["tpt"]
    },
    "application/vnd.triscape.mxs": {
        source: "iana",
        extensions: ["mxs"]
    },
    "application/vnd.trueapp": {
        source: "iana",
        extensions: ["tra"]
    },
    "application/vnd.truedoc": {
        source: "iana"
    },
    "application/vnd.ubisoft.webplayer": {
        source: "iana"
    },
    "application/vnd.ufdl": {
        source: "iana",
        extensions: ["ufd", "ufdl"]
    },
    "application/vnd.uiq.theme": {
        source: "iana",
        extensions: ["utz"]
    },
    "application/vnd.umajin": {
        source: "iana",
        extensions: ["umj"]
    },
    "application/vnd.unity": {
        source: "iana",
        extensions: ["unityweb"]
    },
    "application/vnd.uoml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["uoml"]
    },
    "application/vnd.uplanet.alert": {
        source: "iana"
    },
    "application/vnd.uplanet.alert-wbxml": {
        source: "iana"
    },
    "application/vnd.uplanet.bearer-choice": {
        source: "iana"
    },
    "application/vnd.uplanet.bearer-choice-wbxml": {
        source: "iana"
    },
    "application/vnd.uplanet.cacheop": {
        source: "iana"
    },
    "application/vnd.uplanet.cacheop-wbxml": {
        source: "iana"
    },
    "application/vnd.uplanet.channel": {
        source: "iana"
    },
    "application/vnd.uplanet.channel-wbxml": {
        source: "iana"
    },
    "application/vnd.uplanet.list": {
        source: "iana"
    },
    "application/vnd.uplanet.list-wbxml": {
        source: "iana"
    },
    "application/vnd.uplanet.listcmd": {
        source: "iana"
    },
    "application/vnd.uplanet.listcmd-wbxml": {
        source: "iana"
    },
    "application/vnd.uplanet.signal": {
        source: "iana"
    },
    "application/vnd.uri-map": {
        source: "iana"
    },
    "application/vnd.valve.source.material": {
        source: "iana"
    },
    "application/vnd.vcx": {
        source: "iana",
        extensions: ["vcx"]
    },
    "application/vnd.vd-study": {
        source: "iana"
    },
    "application/vnd.vectorworks": {
        source: "iana"
    },
    "application/vnd.vel+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.verimatrix.vcas": {
        source: "iana"
    },
    "application/vnd.veritone.aion+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.veryant.thin": {
        source: "iana"
    },
    "application/vnd.ves.encrypted": {
        source: "iana"
    },
    "application/vnd.vidsoft.vidconference": {
        source: "iana"
    },
    "application/vnd.visio": {
        source: "iana",
        extensions: ["vsd", "vst", "vss", "vsw"]
    },
    "application/vnd.visionary": {
        source: "iana",
        extensions: ["vis"]
    },
    "application/vnd.vividence.scriptfile": {
        source: "iana"
    },
    "application/vnd.vsf": {
        source: "iana",
        extensions: ["vsf"]
    },
    "application/vnd.wap.sic": {
        source: "iana"
    },
    "application/vnd.wap.slc": {
        source: "iana"
    },
    "application/vnd.wap.wbxml": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["wbxml"]
    },
    "application/vnd.wap.wmlc": {
        source: "iana",
        extensions: ["wmlc"]
    },
    "application/vnd.wap.wmlscriptc": {
        source: "iana",
        extensions: ["wmlsc"]
    },
    "application/vnd.webturbo": {
        source: "iana",
        extensions: ["wtb"]
    },
    "application/vnd.wfa.dpp": {
        source: "iana"
    },
    "application/vnd.wfa.p2p": {
        source: "iana"
    },
    "application/vnd.wfa.wsc": {
        source: "iana"
    },
    "application/vnd.windows.devicepairing": {
        source: "iana"
    },
    "application/vnd.wmc": {
        source: "iana"
    },
    "application/vnd.wmf.bootstrap": {
        source: "iana"
    },
    "application/vnd.wolfram.mathematica": {
        source: "iana"
    },
    "application/vnd.wolfram.mathematica.package": {
        source: "iana"
    },
    "application/vnd.wolfram.player": {
        source: "iana",
        extensions: ["nbp"]
    },
    "application/vnd.wordperfect": {
        source: "iana",
        extensions: ["wpd"]
    },
    "application/vnd.wqd": {
        source: "iana",
        extensions: ["wqd"]
    },
    "application/vnd.wrq-hp3000-labelled": {
        source: "iana"
    },
    "application/vnd.wt.stf": {
        source: "iana",
        extensions: ["stf"]
    },
    "application/vnd.wv.csp+wbxml": {
        source: "iana"
    },
    "application/vnd.wv.csp+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.wv.ssp+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.xacml+json": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.xara": {
        source: "iana",
        extensions: ["xar"]
    },
    "application/vnd.xfdl": {
        source: "iana",
        extensions: ["xfdl"]
    },
    "application/vnd.xfdl.webform": {
        source: "iana"
    },
    "application/vnd.xmi+xml": {
        source: "iana",
        compressible: !0
    },
    "application/vnd.xmpie.cpkg": {
        source: "iana"
    },
    "application/vnd.xmpie.dpkg": {
        source: "iana"
    },
    "application/vnd.xmpie.plan": {
        source: "iana"
    },
    "application/vnd.xmpie.ppkg": {
        source: "iana"
    },
    "application/vnd.xmpie.xlim": {
        source: "iana"
    },
    "application/vnd.yamaha.hv-dic": {
        source: "iana",
        extensions: ["hvd"]
    },
    "application/vnd.yamaha.hv-script": {
        source: "iana",
        extensions: ["hvs"]
    },
    "application/vnd.yamaha.hv-voice": {
        source: "iana",
        extensions: ["hvp"]
    },
    "application/vnd.yamaha.openscoreformat": {
        source: "iana",
        extensions: ["osf"]
    },
    "application/vnd.yamaha.openscoreformat.osfpvg+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["osfpvg"]
    },
    "application/vnd.yamaha.remote-setup": {
        source: "iana"
    },
    "application/vnd.yamaha.smaf-audio": {
        source: "iana",
        extensions: ["saf"]
    },
    "application/vnd.yamaha.smaf-phrase": {
        source: "iana",
        extensions: ["spf"]
    },
    "application/vnd.yamaha.through-ngn": {
        source: "iana"
    },
    "application/vnd.yamaha.tunnel-udpencap": {
        source: "iana"
    },
    "application/vnd.yaoweme": {
        source: "iana"
    },
    "application/vnd.yellowriver-custom-menu": {
        source: "iana",
        extensions: ["cmp"]
    },
    "application/vnd.youtube.yt": {
        source: "iana"
    },
    "application/vnd.zul": {
        source: "iana",
        extensions: ["zir", "zirz"]
    },
    "application/vnd.zzazz.deck+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["zaz"]
    },
    "application/voicexml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["vxml"]
    },
    "application/voucher-cms+json": {
        source: "iana",
        compressible: !0
    },
    "application/vq-rtcpxr": {
        source: "iana"
    },
    "application/wasm": {
        source: "iana",
        compressible: !0,
        extensions: ["wasm"]
    },
    "application/watcherinfo+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["wif"]
    },
    "application/webpush-options+json": {
        source: "iana",
        compressible: !0
    },
    "application/whoispp-query": {
        source: "iana"
    },
    "application/whoispp-response": {
        source: "iana"
    },
    "application/widget": {
        source: "iana",
        extensions: ["wgt"]
    },
    "application/winhlp": {
        source: "apache",
        extensions: ["hlp"]
    },
    "application/wita": {
        source: "iana"
    },
    "application/wordperfect5.1": {
        source: "iana"
    },
    "application/wsdl+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["wsdl"]
    },
    "application/wspolicy+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["wspolicy"]
    },
    "application/x-7z-compressed": {
        source: "apache",
        compressible: !1,
        extensions: ["7z"]
    },
    "application/x-abiword": {
        source: "apache",
        extensions: ["abw"]
    },
    "application/x-ace-compressed": {
        source: "apache",
        extensions: ["ace"]
    },
    "application/x-amf": {
        source: "apache"
    },
    "application/x-apple-diskimage": {
        source: "apache",
        extensions: ["dmg"]
    },
    "application/x-arj": {
        compressible: !1,
        extensions: ["arj"]
    },
    "application/x-authorware-bin": {
        source: "apache",
        extensions: ["aab", "x32", "u32", "vox"]
    },
    "application/x-authorware-map": {
        source: "apache",
        extensions: ["aam"]
    },
    "application/x-authorware-seg": {
        source: "apache",
        extensions: ["aas"]
    },
    "application/x-bcpio": {
        source: "apache",
        extensions: ["bcpio"]
    },
    "application/x-bdoc": {
        compressible: !1,
        extensions: ["bdoc"]
    },
    "application/x-bittorrent": {
        source: "apache",
        extensions: ["torrent"]
    },
    "application/x-blorb": {
        source: "apache",
        extensions: ["blb", "blorb"]
    },
    "application/x-bzip": {
        source: "apache",
        compressible: !1,
        extensions: ["bz"]
    },
    "application/x-bzip2": {
        source: "apache",
        compressible: !1,
        extensions: ["bz2", "boz"]
    },
    "application/x-cbr": {
        source: "apache",
        extensions: ["cbr", "cba", "cbt", "cbz", "cb7"]
    },
    "application/x-cdlink": {
        source: "apache",
        extensions: ["vcd"]
    },
    "application/x-cfs-compressed": {
        source: "apache",
        extensions: ["cfs"]
    },
    "application/x-chat": {
        source: "apache",
        extensions: ["chat"]
    },
    "application/x-chess-pgn": {
        source: "apache",
        extensions: ["pgn"]
    },
    "application/x-chrome-extension": {
        extensions: ["crx"]
    },
    "application/x-cocoa": {
        source: "nginx",
        extensions: ["cco"]
    },
    "application/x-compress": {
        source: "apache"
    },
    "application/x-conference": {
        source: "apache",
        extensions: ["nsc"]
    },
    "application/x-cpio": {
        source: "apache",
        extensions: ["cpio"]
    },
    "application/x-csh": {
        source: "apache",
        extensions: ["csh"]
    },
    "application/x-deb": {
        compressible: !1
    },
    "application/x-debian-package": {
        source: "apache",
        extensions: ["deb", "udeb"]
    },
    "application/x-dgc-compressed": {
        source: "apache",
        extensions: ["dgc"]
    },
    "application/x-director": {
        source: "apache",
        extensions: ["dir", "dcr", "dxr", "cst", "cct", "cxt", "w3d", "fgd", "swa"]
    },
    "application/x-doom": {
        source: "apache",
        extensions: ["wad"]
    },
    "application/x-dtbncx+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["ncx"]
    },
    "application/x-dtbook+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["dtb"]
    },
    "application/x-dtbresource+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["res"]
    },
    "application/x-dvi": {
        source: "apache",
        compressible: !1,
        extensions: ["dvi"]
    },
    "application/x-envoy": {
        source: "apache",
        extensions: ["evy"]
    },
    "application/x-eva": {
        source: "apache",
        extensions: ["eva"]
    },
    "application/x-font-bdf": {
        source: "apache",
        extensions: ["bdf"]
    },
    "application/x-font-dos": {
        source: "apache"
    },
    "application/x-font-framemaker": {
        source: "apache"
    },
    "application/x-font-ghostscript": {
        source: "apache",
        extensions: ["gsf"]
    },
    "application/x-font-libgrx": {
        source: "apache"
    },
    "application/x-font-linux-psf": {
        source: "apache",
        extensions: ["psf"]
    },
    "application/x-font-pcf": {
        source: "apache",
        extensions: ["pcf"]
    },
    "application/x-font-snf": {
        source: "apache",
        extensions: ["snf"]
    },
    "application/x-font-speedo": {
        source: "apache"
    },
    "application/x-font-sunos-news": {
        source: "apache"
    },
    "application/x-font-type1": {
        source: "apache",
        extensions: ["pfa", "pfb", "pfm", "afm"]
    },
    "application/x-font-vfont": {
        source: "apache"
    },
    "application/x-freearc": {
        source: "apache",
        extensions: ["arc"]
    },
    "application/x-futuresplash": {
        source: "apache",
        extensions: ["spl"]
    },
    "application/x-gca-compressed": {
        source: "apache",
        extensions: ["gca"]
    },
    "application/x-glulx": {
        source: "apache",
        extensions: ["ulx"]
    },
    "application/x-gnumeric": {
        source: "apache",
        extensions: ["gnumeric"]
    },
    "application/x-gramps-xml": {
        source: "apache",
        extensions: ["gramps"]
    },
    "application/x-gtar": {
        source: "apache",
        extensions: ["gtar"]
    },
    "application/x-gzip": {
        source: "apache"
    },
    "application/x-hdf": {
        source: "apache",
        extensions: ["hdf"]
    },
    "application/x-httpd-php": {
        compressible: !0,
        extensions: ["php"]
    },
    "application/x-install-instructions": {
        source: "apache",
        extensions: ["install"]
    },
    "application/x-iso9660-image": {
        source: "apache",
        extensions: ["iso"]
    },
    "application/x-iwork-keynote-sffkey": {
        extensions: ["key"]
    },
    "application/x-iwork-numbers-sffnumbers": {
        extensions: ["numbers"]
    },
    "application/x-iwork-pages-sffpages": {
        extensions: ["pages"]
    },
    "application/x-java-archive-diff": {
        source: "nginx",
        extensions: ["jardiff"]
    },
    "application/x-java-jnlp-file": {
        source: "apache",
        compressible: !1,
        extensions: ["jnlp"]
    },
    "application/x-javascript": {
        compressible: !0
    },
    "application/x-keepass2": {
        extensions: ["kdbx"]
    },
    "application/x-latex": {
        source: "apache",
        compressible: !1,
        extensions: ["latex"]
    },
    "application/x-lua-bytecode": {
        extensions: ["luac"]
    },
    "application/x-lzh-compressed": {
        source: "apache",
        extensions: ["lzh", "lha"]
    },
    "application/x-makeself": {
        source: "nginx",
        extensions: ["run"]
    },
    "application/x-mie": {
        source: "apache",
        extensions: ["mie"]
    },
    "application/x-mobipocket-ebook": {
        source: "apache",
        extensions: ["prc", "mobi"]
    },
    "application/x-mpegurl": {
        compressible: !1
    },
    "application/x-ms-application": {
        source: "apache",
        extensions: ["application"]
    },
    "application/x-ms-shortcut": {
        source: "apache",
        extensions: ["lnk"]
    },
    "application/x-ms-wmd": {
        source: "apache",
        extensions: ["wmd"]
    },
    "application/x-ms-wmz": {
        source: "apache",
        extensions: ["wmz"]
    },
    "application/x-ms-xbap": {
        source: "apache",
        extensions: ["xbap"]
    },
    "application/x-msaccess": {
        source: "apache",
        extensions: ["mdb"]
    },
    "application/x-msbinder": {
        source: "apache",
        extensions: ["obd"]
    },
    "application/x-mscardfile": {
        source: "apache",
        extensions: ["crd"]
    },
    "application/x-msclip": {
        source: "apache",
        extensions: ["clp"]
    },
    "application/x-msdos-program": {
        extensions: ["exe"]
    },
    "application/x-msdownload": {
        source: "apache",
        extensions: ["exe", "dll", "com", "bat", "msi"]
    },
    "application/x-msmediaview": {
        source: "apache",
        extensions: ["mvb", "m13", "m14"]
    },
    "application/x-msmetafile": {
        source: "apache",
        extensions: ["wmf", "wmz", "emf", "emz"]
    },
    "application/x-msmoney": {
        source: "apache",
        extensions: ["mny"]
    },
    "application/x-mspublisher": {
        source: "apache",
        extensions: ["pub"]
    },
    "application/x-msschedule": {
        source: "apache",
        extensions: ["scd"]
    },
    "application/x-msterminal": {
        source: "apache",
        extensions: ["trm"]
    },
    "application/x-mswrite": {
        source: "apache",
        extensions: ["wri"]
    },
    "application/x-netcdf": {
        source: "apache",
        extensions: ["nc", "cdf"]
    },
    "application/x-ns-proxy-autoconfig": {
        compressible: !0,
        extensions: ["pac"]
    },
    "application/x-nzb": {
        source: "apache",
        extensions: ["nzb"]
    },
    "application/x-perl": {
        source: "nginx",
        extensions: ["pl", "pm"]
    },
    "application/x-pilot": {
        source: "nginx",
        extensions: ["prc", "pdb"]
    },
    "application/x-pkcs12": {
        source: "apache",
        compressible: !1,
        extensions: ["p12", "pfx"]
    },
    "application/x-pkcs7-certificates": {
        source: "apache",
        extensions: ["p7b", "spc"]
    },
    "application/x-pkcs7-certreqresp": {
        source: "apache",
        extensions: ["p7r"]
    },
    "application/x-pki-message": {
        source: "iana"
    },
    "application/x-rar-compressed": {
        source: "apache",
        compressible: !1,
        extensions: ["rar"]
    },
    "application/x-redhat-package-manager": {
        source: "nginx",
        extensions: ["rpm"]
    },
    "application/x-research-info-systems": {
        source: "apache",
        extensions: ["ris"]
    },
    "application/x-sea": {
        source: "nginx",
        extensions: ["sea"]
    },
    "application/x-sh": {
        source: "apache",
        compressible: !0,
        extensions: ["sh"]
    },
    "application/x-shar": {
        source: "apache",
        extensions: ["shar"]
    },
    "application/x-shockwave-flash": {
        source: "apache",
        compressible: !1,
        extensions: ["swf"]
    },
    "application/x-silverlight-app": {
        source: "apache",
        extensions: ["xap"]
    },
    "application/x-sql": {
        source: "apache",
        extensions: ["sql"]
    },
    "application/x-stuffit": {
        source: "apache",
        compressible: !1,
        extensions: ["sit"]
    },
    "application/x-stuffitx": {
        source: "apache",
        extensions: ["sitx"]
    },
    "application/x-subrip": {
        source: "apache",
        extensions: ["srt"]
    },
    "application/x-sv4cpio": {
        source: "apache",
        extensions: ["sv4cpio"]
    },
    "application/x-sv4crc": {
        source: "apache",
        extensions: ["sv4crc"]
    },
    "application/x-t3vm-image": {
        source: "apache",
        extensions: ["t3"]
    },
    "application/x-tads": {
        source: "apache",
        extensions: ["gam"]
    },
    "application/x-tar": {
        source: "apache",
        compressible: !0,
        extensions: ["tar"]
    },
    "application/x-tcl": {
        source: "apache",
        extensions: ["tcl", "tk"]
    },
    "application/x-tex": {
        source: "apache",
        extensions: ["tex"]
    },
    "application/x-tex-tfm": {
        source: "apache",
        extensions: ["tfm"]
    },
    "application/x-texinfo": {
        source: "apache",
        extensions: ["texinfo", "texi"]
    },
    "application/x-tgif": {
        source: "apache",
        extensions: ["obj"]
    },
    "application/x-ustar": {
        source: "apache",
        extensions: ["ustar"]
    },
    "application/x-virtualbox-hdd": {
        compressible: !0,
        extensions: ["hdd"]
    },
    "application/x-virtualbox-ova": {
        compressible: !0,
        extensions: ["ova"]
    },
    "application/x-virtualbox-ovf": {
        compressible: !0,
        extensions: ["ovf"]
    },
    "application/x-virtualbox-vbox": {
        compressible: !0,
        extensions: ["vbox"]
    },
    "application/x-virtualbox-vbox-extpack": {
        compressible: !1,
        extensions: ["vbox-extpack"]
    },
    "application/x-virtualbox-vdi": {
        compressible: !0,
        extensions: ["vdi"]
    },
    "application/x-virtualbox-vhd": {
        compressible: !0,
        extensions: ["vhd"]
    },
    "application/x-virtualbox-vmdk": {
        compressible: !0,
        extensions: ["vmdk"]
    },
    "application/x-wais-source": {
        source: "apache",
        extensions: ["src"]
    },
    "application/x-web-app-manifest+json": {
        compressible: !0,
        extensions: ["webapp"]
    },
    "application/x-www-form-urlencoded": {
        source: "iana",
        compressible: !0
    },
    "application/x-x509-ca-cert": {
        source: "iana",
        extensions: ["der", "crt", "pem"]
    },
    "application/x-x509-ca-ra-cert": {
        source: "iana"
    },
    "application/x-x509-next-ca-cert": {
        source: "iana"
    },
    "application/x-xfig": {
        source: "apache",
        extensions: ["fig"]
    },
    "application/x-xliff+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["xlf"]
    },
    "application/x-xpinstall": {
        source: "apache",
        compressible: !1,
        extensions: ["xpi"]
    },
    "application/x-xz": {
        source: "apache",
        extensions: ["xz"]
    },
    "application/x-zmachine": {
        source: "apache",
        extensions: ["z1", "z2", "z3", "z4", "z5", "z6", "z7", "z8"]
    },
    "application/x400-bp": {
        source: "iana"
    },
    "application/xacml+xml": {
        source: "iana",
        compressible: !0
    },
    "application/xaml+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["xaml"]
    },
    "application/xcap-att+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xav"]
    },
    "application/xcap-caps+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xca"]
    },
    "application/xcap-diff+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xdf"]
    },
    "application/xcap-el+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xel"]
    },
    "application/xcap-error+xml": {
        source: "iana",
        compressible: !0
    },
    "application/xcap-ns+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xns"]
    },
    "application/xcon-conference-info+xml": {
        source: "iana",
        compressible: !0
    },
    "application/xcon-conference-info-diff+xml": {
        source: "iana",
        compressible: !0
    },
    "application/xenc+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xenc"]
    },
    "application/xhtml+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xhtml", "xht"]
    },
    "application/xhtml-voice+xml": {
        source: "apache",
        compressible: !0
    },
    "application/xliff+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xlf"]
    },
    "application/xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xml", "xsl", "xsd", "rng"]
    },
    "application/xml-dtd": {
        source: "iana",
        compressible: !0,
        extensions: ["dtd"]
    },
    "application/xml-external-parsed-entity": {
        source: "iana"
    },
    "application/xml-patch+xml": {
        source: "iana",
        compressible: !0
    },
    "application/xmpp+xml": {
        source: "iana",
        compressible: !0
    },
    "application/xop+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xop"]
    },
    "application/xproc+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["xpl"]
    },
    "application/xslt+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xsl", "xslt"]
    },
    "application/xspf+xml": {
        source: "apache",
        compressible: !0,
        extensions: ["xspf"]
    },
    "application/xv+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["mxml", "xhvml", "xvml", "xvm"]
    },
    "application/yang": {
        source: "iana",
        extensions: ["yang"]
    },
    "application/yang-data+json": {
        source: "iana",
        compressible: !0
    },
    "application/yang-data+xml": {
        source: "iana",
        compressible: !0
    },
    "application/yang-patch+json": {
        source: "iana",
        compressible: !0
    },
    "application/yang-patch+xml": {
        source: "iana",
        compressible: !0
    },
    "application/yin+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["yin"]
    },
    "application/zip": {
        source: "iana",
        compressible: !1,
        extensions: ["zip"]
    },
    "application/zlib": {
        source: "iana"
    },
    "application/zstd": {
        source: "iana"
    },
    "audio/1d-interleaved-parityfec": {
        source: "iana"
    },
    "audio/32kadpcm": {
        source: "iana"
    },
    "audio/3gpp": {
        source: "iana",
        compressible: !1,
        extensions: ["3gpp"]
    },
    "audio/3gpp2": {
        source: "iana"
    },
    "audio/aac": {
        source: "iana"
    },
    "audio/ac3": {
        source: "iana"
    },
    "audio/adpcm": {
        source: "apache",
        extensions: ["adp"]
    },
    "audio/amr": {
        source: "iana",
        extensions: ["amr"]
    },
    "audio/amr-wb": {
        source: "iana"
    },
    "audio/amr-wb+": {
        source: "iana"
    },
    "audio/aptx": {
        source: "iana"
    },
    "audio/asc": {
        source: "iana"
    },
    "audio/atrac-advanced-lossless": {
        source: "iana"
    },
    "audio/atrac-x": {
        source: "iana"
    },
    "audio/atrac3": {
        source: "iana"
    },
    "audio/basic": {
        source: "iana",
        compressible: !1,
        extensions: ["au", "snd"]
    },
    "audio/bv16": {
        source: "iana"
    },
    "audio/bv32": {
        source: "iana"
    },
    "audio/clearmode": {
        source: "iana"
    },
    "audio/cn": {
        source: "iana"
    },
    "audio/dat12": {
        source: "iana"
    },
    "audio/dls": {
        source: "iana"
    },
    "audio/dsr-es201108": {
        source: "iana"
    },
    "audio/dsr-es202050": {
        source: "iana"
    },
    "audio/dsr-es202211": {
        source: "iana"
    },
    "audio/dsr-es202212": {
        source: "iana"
    },
    "audio/dv": {
        source: "iana"
    },
    "audio/dvi4": {
        source: "iana"
    },
    "audio/eac3": {
        source: "iana"
    },
    "audio/encaprtp": {
        source: "iana"
    },
    "audio/evrc": {
        source: "iana"
    },
    "audio/evrc-qcp": {
        source: "iana"
    },
    "audio/evrc0": {
        source: "iana"
    },
    "audio/evrc1": {
        source: "iana"
    },
    "audio/evrcb": {
        source: "iana"
    },
    "audio/evrcb0": {
        source: "iana"
    },
    "audio/evrcb1": {
        source: "iana"
    },
    "audio/evrcnw": {
        source: "iana"
    },
    "audio/evrcnw0": {
        source: "iana"
    },
    "audio/evrcnw1": {
        source: "iana"
    },
    "audio/evrcwb": {
        source: "iana"
    },
    "audio/evrcwb0": {
        source: "iana"
    },
    "audio/evrcwb1": {
        source: "iana"
    },
    "audio/evs": {
        source: "iana"
    },
    "audio/flexfec": {
        source: "iana"
    },
    "audio/fwdred": {
        source: "iana"
    },
    "audio/g711-0": {
        source: "iana"
    },
    "audio/g719": {
        source: "iana"
    },
    "audio/g722": {
        source: "iana"
    },
    "audio/g7221": {
        source: "iana"
    },
    "audio/g723": {
        source: "iana"
    },
    "audio/g726-16": {
        source: "iana"
    },
    "audio/g726-24": {
        source: "iana"
    },
    "audio/g726-32": {
        source: "iana"
    },
    "audio/g726-40": {
        source: "iana"
    },
    "audio/g728": {
        source: "iana"
    },
    "audio/g729": {
        source: "iana"
    },
    "audio/g7291": {
        source: "iana"
    },
    "audio/g729d": {
        source: "iana"
    },
    "audio/g729e": {
        source: "iana"
    },
    "audio/gsm": {
        source: "iana"
    },
    "audio/gsm-efr": {
        source: "iana"
    },
    "audio/gsm-hr-08": {
        source: "iana"
    },
    "audio/ilbc": {
        source: "iana"
    },
    "audio/ip-mr_v2.5": {
        source: "iana"
    },
    "audio/isac": {
        source: "apache"
    },
    "audio/l16": {
        source: "iana"
    },
    "audio/l20": {
        source: "iana"
    },
    "audio/l24": {
        source: "iana",
        compressible: !1
    },
    "audio/l8": {
        source: "iana"
    },
    "audio/lpc": {
        source: "iana"
    },
    "audio/melp": {
        source: "iana"
    },
    "audio/melp1200": {
        source: "iana"
    },
    "audio/melp2400": {
        source: "iana"
    },
    "audio/melp600": {
        source: "iana"
    },
    "audio/mhas": {
        source: "iana"
    },
    "audio/midi": {
        source: "apache",
        extensions: ["mid", "midi", "kar", "rmi"]
    },
    "audio/mobile-xmf": {
        source: "iana",
        extensions: ["mxmf"]
    },
    "audio/mp3": {
        compressible: !1,
        extensions: ["mp3"]
    },
    "audio/mp4": {
        source: "iana",
        compressible: !1,
        extensions: ["m4a", "mp4a"]
    },
    "audio/mp4a-latm": {
        source: "iana"
    },
    "audio/mpa": {
        source: "iana"
    },
    "audio/mpa-robust": {
        source: "iana"
    },
    "audio/mpeg": {
        source: "iana",
        compressible: !1,
        extensions: ["mpga", "mp2", "mp2a", "mp3", "m2a", "m3a"]
    },
    "audio/mpeg4-generic": {
        source: "iana"
    },
    "audio/musepack": {
        source: "apache"
    },
    "audio/ogg": {
        source: "iana",
        compressible: !1,
        extensions: ["oga", "ogg", "spx", "opus"]
    },
    "audio/opus": {
        source: "iana"
    },
    "audio/parityfec": {
        source: "iana"
    },
    "audio/pcma": {
        source: "iana"
    },
    "audio/pcma-wb": {
        source: "iana"
    },
    "audio/pcmu": {
        source: "iana"
    },
    "audio/pcmu-wb": {
        source: "iana"
    },
    "audio/prs.sid": {
        source: "iana"
    },
    "audio/qcelp": {
        source: "iana"
    },
    "audio/raptorfec": {
        source: "iana"
    },
    "audio/red": {
        source: "iana"
    },
    "audio/rtp-enc-aescm128": {
        source: "iana"
    },
    "audio/rtp-midi": {
        source: "iana"
    },
    "audio/rtploopback": {
        source: "iana"
    },
    "audio/rtx": {
        source: "iana"
    },
    "audio/s3m": {
        source: "apache",
        extensions: ["s3m"]
    },
    "audio/scip": {
        source: "iana"
    },
    "audio/silk": {
        source: "apache",
        extensions: ["sil"]
    },
    "audio/smv": {
        source: "iana"
    },
    "audio/smv-qcp": {
        source: "iana"
    },
    "audio/smv0": {
        source: "iana"
    },
    "audio/sofa": {
        source: "iana"
    },
    "audio/sp-midi": {
        source: "iana"
    },
    "audio/speex": {
        source: "iana"
    },
    "audio/t140c": {
        source: "iana"
    },
    "audio/t38": {
        source: "iana"
    },
    "audio/telephone-event": {
        source: "iana"
    },
    "audio/tetra_acelp": {
        source: "iana"
    },
    "audio/tetra_acelp_bb": {
        source: "iana"
    },
    "audio/tone": {
        source: "iana"
    },
    "audio/tsvcis": {
        source: "iana"
    },
    "audio/uemclip": {
        source: "iana"
    },
    "audio/ulpfec": {
        source: "iana"
    },
    "audio/usac": {
        source: "iana"
    },
    "audio/vdvi": {
        source: "iana"
    },
    "audio/vmr-wb": {
        source: "iana"
    },
    "audio/vnd.3gpp.iufp": {
        source: "iana"
    },
    "audio/vnd.4sb": {
        source: "iana"
    },
    "audio/vnd.audiokoz": {
        source: "iana"
    },
    "audio/vnd.celp": {
        source: "iana"
    },
    "audio/vnd.cisco.nse": {
        source: "iana"
    },
    "audio/vnd.cmles.radio-events": {
        source: "iana"
    },
    "audio/vnd.cns.anp1": {
        source: "iana"
    },
    "audio/vnd.cns.inf1": {
        source: "iana"
    },
    "audio/vnd.dece.audio": {
        source: "iana",
        extensions: ["uva", "uvva"]
    },
    "audio/vnd.digital-winds": {
        source: "iana",
        extensions: ["eol"]
    },
    "audio/vnd.dlna.adts": {
        source: "iana"
    },
    "audio/vnd.dolby.heaac.1": {
        source: "iana"
    },
    "audio/vnd.dolby.heaac.2": {
        source: "iana"
    },
    "audio/vnd.dolby.mlp": {
        source: "iana"
    },
    "audio/vnd.dolby.mps": {
        source: "iana"
    },
    "audio/vnd.dolby.pl2": {
        source: "iana"
    },
    "audio/vnd.dolby.pl2x": {
        source: "iana"
    },
    "audio/vnd.dolby.pl2z": {
        source: "iana"
    },
    "audio/vnd.dolby.pulse.1": {
        source: "iana"
    },
    "audio/vnd.dra": {
        source: "iana",
        extensions: ["dra"]
    },
    "audio/vnd.dts": {
        source: "iana",
        extensions: ["dts"]
    },
    "audio/vnd.dts.hd": {
        source: "iana",
        extensions: ["dtshd"]
    },
    "audio/vnd.dts.uhd": {
        source: "iana"
    },
    "audio/vnd.dvb.file": {
        source: "iana"
    },
    "audio/vnd.everad.plj": {
        source: "iana"
    },
    "audio/vnd.hns.audio": {
        source: "iana"
    },
    "audio/vnd.lucent.voice": {
        source: "iana",
        extensions: ["lvp"]
    },
    "audio/vnd.ms-playready.media.pya": {
        source: "iana",
        extensions: ["pya"]
    },
    "audio/vnd.nokia.mobile-xmf": {
        source: "iana"
    },
    "audio/vnd.nortel.vbk": {
        source: "iana"
    },
    "audio/vnd.nuera.ecelp4800": {
        source: "iana",
        extensions: ["ecelp4800"]
    },
    "audio/vnd.nuera.ecelp7470": {
        source: "iana",
        extensions: ["ecelp7470"]
    },
    "audio/vnd.nuera.ecelp9600": {
        source: "iana",
        extensions: ["ecelp9600"]
    },
    "audio/vnd.octel.sbc": {
        source: "iana"
    },
    "audio/vnd.presonus.multitrack": {
        source: "iana"
    },
    "audio/vnd.qcelp": {
        source: "iana"
    },
    "audio/vnd.rhetorex.32kadpcm": {
        source: "iana"
    },
    "audio/vnd.rip": {
        source: "iana",
        extensions: ["rip"]
    },
    "audio/vnd.rn-realaudio": {
        compressible: !1
    },
    "audio/vnd.sealedmedia.softseal.mpeg": {
        source: "iana"
    },
    "audio/vnd.vmx.cvsd": {
        source: "iana"
    },
    "audio/vnd.wave": {
        compressible: !1
    },
    "audio/vorbis": {
        source: "iana",
        compressible: !1
    },
    "audio/vorbis-config": {
        source: "iana"
    },
    "audio/wav": {
        compressible: !1,
        extensions: ["wav"]
    },
    "audio/wave": {
        compressible: !1,
        extensions: ["wav"]
    },
    "audio/webm": {
        source: "apache",
        compressible: !1,
        extensions: ["weba"]
    },
    "audio/x-aac": {
        source: "apache",
        compressible: !1,
        extensions: ["aac"]
    },
    "audio/x-aiff": {
        source: "apache",
        extensions: ["aif", "aiff", "aifc"]
    },
    "audio/x-caf": {
        source: "apache",
        compressible: !1,
        extensions: ["caf"]
    },
    "audio/x-flac": {
        source: "apache",
        extensions: ["flac"]
    },
    "audio/x-m4a": {
        source: "nginx",
        extensions: ["m4a"]
    },
    "audio/x-matroska": {
        source: "apache",
        extensions: ["mka"]
    },
    "audio/x-mpegurl": {
        source: "apache",
        extensions: ["m3u"]
    },
    "audio/x-ms-wax": {
        source: "apache",
        extensions: ["wax"]
    },
    "audio/x-ms-wma": {
        source: "apache",
        extensions: ["wma"]
    },
    "audio/x-pn-realaudio": {
        source: "apache",
        extensions: ["ram", "ra"]
    },
    "audio/x-pn-realaudio-plugin": {
        source: "apache",
        extensions: ["rmp"]
    },
    "audio/x-realaudio": {
        source: "nginx",
        extensions: ["ra"]
    },
    "audio/x-tta": {
        source: "apache"
    },
    "audio/x-wav": {
        source: "apache",
        extensions: ["wav"]
    },
    "audio/xm": {
        source: "apache",
        extensions: ["xm"]
    },
    "chemical/x-cdx": {
        source: "apache",
        extensions: ["cdx"]
    },
    "chemical/x-cif": {
        source: "apache",
        extensions: ["cif"]
    },
    "chemical/x-cmdf": {
        source: "apache",
        extensions: ["cmdf"]
    },
    "chemical/x-cml": {
        source: "apache",
        extensions: ["cml"]
    },
    "chemical/x-csml": {
        source: "apache",
        extensions: ["csml"]
    },
    "chemical/x-pdb": {
        source: "apache"
    },
    "chemical/x-xyz": {
        source: "apache",
        extensions: ["xyz"]
    },
    "font/collection": {
        source: "iana",
        extensions: ["ttc"]
    },
    "font/otf": {
        source: "iana",
        compressible: !0,
        extensions: ["otf"]
    },
    "font/sfnt": {
        source: "iana"
    },
    "font/ttf": {
        source: "iana",
        compressible: !0,
        extensions: ["ttf"]
    },
    "font/woff": {
        source: "iana",
        extensions: ["woff"]
    },
    "font/woff2": {
        source: "iana",
        extensions: ["woff2"]
    },
    "image/aces": {
        source: "iana",
        extensions: ["exr"]
    },
    "image/apng": {
        compressible: !1,
        extensions: ["apng"]
    },
    "image/avci": {
        source: "iana",
        extensions: ["avci"]
    },
    "image/avcs": {
        source: "iana",
        extensions: ["avcs"]
    },
    "image/avif": {
        source: "iana",
        compressible: !1,
        extensions: ["avif"]
    },
    "image/bmp": {
        source: "iana",
        compressible: !0,
        extensions: ["bmp"]
    },
    "image/cgm": {
        source: "iana",
        extensions: ["cgm"]
    },
    "image/dicom-rle": {
        source: "iana",
        extensions: ["drle"]
    },
    "image/emf": {
        source: "iana",
        extensions: ["emf"]
    },
    "image/fits": {
        source: "iana",
        extensions: ["fits"]
    },
    "image/g3fax": {
        source: "iana",
        extensions: ["g3"]
    },
    "image/gif": {
        source: "iana",
        compressible: !1,
        extensions: ["gif"]
    },
    "image/heic": {
        source: "iana",
        extensions: ["heic"]
    },
    "image/heic-sequence": {
        source: "iana",
        extensions: ["heics"]
    },
    "image/heif": {
        source: "iana",
        extensions: ["heif"]
    },
    "image/heif-sequence": {
        source: "iana",
        extensions: ["heifs"]
    },
    "image/hej2k": {
        source: "iana",
        extensions: ["hej2"]
    },
    "image/hsj2": {
        source: "iana",
        extensions: ["hsj2"]
    },
    "image/ief": {
        source: "iana",
        extensions: ["ief"]
    },
    "image/jls": {
        source: "iana",
        extensions: ["jls"]
    },
    "image/jp2": {
        source: "iana",
        compressible: !1,
        extensions: ["jp2", "jpg2"]
    },
    "image/jpeg": {
        source: "iana",
        compressible: !1,
        extensions: ["jpeg", "jpg", "jpe"]
    },
    "image/jph": {
        source: "iana",
        extensions: ["jph"]
    },
    "image/jphc": {
        source: "iana",
        extensions: ["jhc"]
    },
    "image/jpm": {
        source: "iana",
        compressible: !1,
        extensions: ["jpm"]
    },
    "image/jpx": {
        source: "iana",
        compressible: !1,
        extensions: ["jpx", "jpf"]
    },
    "image/jxr": {
        source: "iana",
        extensions: ["jxr"]
    },
    "image/jxra": {
        source: "iana",
        extensions: ["jxra"]
    },
    "image/jxrs": {
        source: "iana",
        extensions: ["jxrs"]
    },
    "image/jxs": {
        source: "iana",
        extensions: ["jxs"]
    },
    "image/jxsc": {
        source: "iana",
        extensions: ["jxsc"]
    },
    "image/jxsi": {
        source: "iana",
        extensions: ["jxsi"]
    },
    "image/jxss": {
        source: "iana",
        extensions: ["jxss"]
    },
    "image/ktx": {
        source: "iana",
        extensions: ["ktx"]
    },
    "image/ktx2": {
        source: "iana",
        extensions: ["ktx2"]
    },
    "image/naplps": {
        source: "iana"
    },
    "image/pjpeg": {
        compressible: !1
    },
    "image/png": {
        source: "iana",
        compressible: !1,
        extensions: ["png"]
    },
    "image/prs.btif": {
        source: "iana",
        extensions: ["btif"]
    },
    "image/prs.pti": {
        source: "iana",
        extensions: ["pti"]
    },
    "image/pwg-raster": {
        source: "iana"
    },
    "image/sgi": {
        source: "apache",
        extensions: ["sgi"]
    },
    "image/svg+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["svg", "svgz"]
    },
    "image/t38": {
        source: "iana",
        extensions: ["t38"]
    },
    "image/tiff": {
        source: "iana",
        compressible: !1,
        extensions: ["tif", "tiff"]
    },
    "image/tiff-fx": {
        source: "iana",
        extensions: ["tfx"]
    },
    "image/vnd.adobe.photoshop": {
        source: "iana",
        compressible: !0,
        extensions: ["psd"]
    },
    "image/vnd.airzip.accelerator.azv": {
        source: "iana",
        extensions: ["azv"]
    },
    "image/vnd.cns.inf2": {
        source: "iana"
    },
    "image/vnd.dece.graphic": {
        source: "iana",
        extensions: ["uvi", "uvvi", "uvg", "uvvg"]
    },
    "image/vnd.djvu": {
        source: "iana",
        extensions: ["djvu", "djv"]
    },
    "image/vnd.dvb.subtitle": {
        source: "iana",
        extensions: ["sub"]
    },
    "image/vnd.dwg": {
        source: "iana",
        extensions: ["dwg"]
    },
    "image/vnd.dxf": {
        source: "iana",
        extensions: ["dxf"]
    },
    "image/vnd.fastbidsheet": {
        source: "iana",
        extensions: ["fbs"]
    },
    "image/vnd.fpx": {
        source: "iana",
        extensions: ["fpx"]
    },
    "image/vnd.fst": {
        source: "iana",
        extensions: ["fst"]
    },
    "image/vnd.fujixerox.edmics-mmr": {
        source: "iana",
        extensions: ["mmr"]
    },
    "image/vnd.fujixerox.edmics-rlc": {
        source: "iana",
        extensions: ["rlc"]
    },
    "image/vnd.globalgraphics.pgb": {
        source: "iana"
    },
    "image/vnd.microsoft.icon": {
        source: "iana",
        compressible: !0,
        extensions: ["ico"]
    },
    "image/vnd.mix": {
        source: "iana"
    },
    "image/vnd.mozilla.apng": {
        source: "iana"
    },
    "image/vnd.ms-dds": {
        compressible: !0,
        extensions: ["dds"]
    },
    "image/vnd.ms-modi": {
        source: "iana",
        extensions: ["mdi"]
    },
    "image/vnd.ms-photo": {
        source: "apache",
        extensions: ["wdp"]
    },
    "image/vnd.net-fpx": {
        source: "iana",
        extensions: ["npx"]
    },
    "image/vnd.pco.b16": {
        source: "iana",
        extensions: ["b16"]
    },
    "image/vnd.radiance": {
        source: "iana"
    },
    "image/vnd.sealed.png": {
        source: "iana"
    },
    "image/vnd.sealedmedia.softseal.gif": {
        source: "iana"
    },
    "image/vnd.sealedmedia.softseal.jpg": {
        source: "iana"
    },
    "image/vnd.svf": {
        source: "iana"
    },
    "image/vnd.tencent.tap": {
        source: "iana",
        extensions: ["tap"]
    },
    "image/vnd.valve.source.texture": {
        source: "iana",
        extensions: ["vtf"]
    },
    "image/vnd.wap.wbmp": {
        source: "iana",
        extensions: ["wbmp"]
    },
    "image/vnd.xiff": {
        source: "iana",
        extensions: ["xif"]
    },
    "image/vnd.zbrush.pcx": {
        source: "iana",
        extensions: ["pcx"]
    },
    "image/webp": {
        source: "apache",
        extensions: ["webp"]
    },
    "image/wmf": {
        source: "iana",
        extensions: ["wmf"]
    },
    "image/x-3ds": {
        source: "apache",
        extensions: ["3ds"]
    },
    "image/x-cmu-raster": {
        source: "apache",
        extensions: ["ras"]
    },
    "image/x-cmx": {
        source: "apache",
        extensions: ["cmx"]
    },
    "image/x-freehand": {
        source: "apache",
        extensions: ["fh", "fhc", "fh4", "fh5", "fh7"]
    },
    "image/x-icon": {
        source: "apache",
        compressible: !0,
        extensions: ["ico"]
    },
    "image/x-jng": {
        source: "nginx",
        extensions: ["jng"]
    },
    "image/x-mrsid-image": {
        source: "apache",
        extensions: ["sid"]
    },
    "image/x-ms-bmp": {
        source: "nginx",
        compressible: !0,
        extensions: ["bmp"]
    },
    "image/x-pcx": {
        source: "apache",
        extensions: ["pcx"]
    },
    "image/x-pict": {
        source: "apache",
        extensions: ["pic", "pct"]
    },
    "image/x-portable-anymap": {
        source: "apache",
        extensions: ["pnm"]
    },
    "image/x-portable-bitmap": {
        source: "apache",
        extensions: ["pbm"]
    },
    "image/x-portable-graymap": {
        source: "apache",
        extensions: ["pgm"]
    },
    "image/x-portable-pixmap": {
        source: "apache",
        extensions: ["ppm"]
    },
    "image/x-rgb": {
        source: "apache",
        extensions: ["rgb"]
    },
    "image/x-tga": {
        source: "apache",
        extensions: ["tga"]
    },
    "image/x-xbitmap": {
        source: "apache",
        extensions: ["xbm"]
    },
    "image/x-xcf": {
        compressible: !1
    },
    "image/x-xpixmap": {
        source: "apache",
        extensions: ["xpm"]
    },
    "image/x-xwindowdump": {
        source: "apache",
        extensions: ["xwd"]
    },
    "message/cpim": {
        source: "iana"
    },
    "message/delivery-status": {
        source: "iana"
    },
    "message/disposition-notification": {
        source: "iana",
        extensions: ["disposition-notification"]
    },
    "message/external-body": {
        source: "iana"
    },
    "message/feedback-report": {
        source: "iana"
    },
    "message/global": {
        source: "iana",
        extensions: ["u8msg"]
    },
    "message/global-delivery-status": {
        source: "iana",
        extensions: ["u8dsn"]
    },
    "message/global-disposition-notification": {
        source: "iana",
        extensions: ["u8mdn"]
    },
    "message/global-headers": {
        source: "iana",
        extensions: ["u8hdr"]
    },
    "message/http": {
        source: "iana",
        compressible: !1
    },
    "message/imdn+xml": {
        source: "iana",
        compressible: !0
    },
    "message/news": {
        source: "iana"
    },
    "message/partial": {
        source: "iana",
        compressible: !1
    },
    "message/rfc822": {
        source: "iana",
        compressible: !0,
        extensions: ["eml", "mime"]
    },
    "message/s-http": {
        source: "iana"
    },
    "message/sip": {
        source: "iana"
    },
    "message/sipfrag": {
        source: "iana"
    },
    "message/tracking-status": {
        source: "iana"
    },
    "message/vnd.si.simp": {
        source: "iana"
    },
    "message/vnd.wfa.wsc": {
        source: "iana",
        extensions: ["wsc"]
    },
    "model/3mf": {
        source: "iana",
        extensions: ["3mf"]
    },
    "model/e57": {
        source: "iana"
    },
    "model/gltf+json": {
        source: "iana",
        compressible: !0,
        extensions: ["gltf"]
    },
    "model/gltf-binary": {
        source: "iana",
        compressible: !0,
        extensions: ["glb"]
    },
    "model/iges": {
        source: "iana",
        compressible: !1,
        extensions: ["igs", "iges"]
    },
    "model/mesh": {
        source: "iana",
        compressible: !1,
        extensions: ["msh", "mesh", "silo"]
    },
    "model/mtl": {
        source: "iana",
        extensions: ["mtl"]
    },
    "model/obj": {
        source: "iana",
        extensions: ["obj"]
    },
    "model/step": {
        source: "iana"
    },
    "model/step+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["stpx"]
    },
    "model/step+zip": {
        source: "iana",
        compressible: !1,
        extensions: ["stpz"]
    },
    "model/step-xml+zip": {
        source: "iana",
        compressible: !1,
        extensions: ["stpxz"]
    },
    "model/stl": {
        source: "iana",
        extensions: ["stl"]
    },
    "model/vnd.collada+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["dae"]
    },
    "model/vnd.dwf": {
        source: "iana",
        extensions: ["dwf"]
    },
    "model/vnd.flatland.3dml": {
        source: "iana"
    },
    "model/vnd.gdl": {
        source: "iana",
        extensions: ["gdl"]
    },
    "model/vnd.gs-gdl": {
        source: "apache"
    },
    "model/vnd.gs.gdl": {
        source: "iana"
    },
    "model/vnd.gtw": {
        source: "iana",
        extensions: ["gtw"]
    },
    "model/vnd.moml+xml": {
        source: "iana",
        compressible: !0
    },
    "model/vnd.mts": {
        source: "iana",
        extensions: ["mts"]
    },
    "model/vnd.opengex": {
        source: "iana",
        extensions: ["ogex"]
    },
    "model/vnd.parasolid.transmit.binary": {
        source: "iana",
        extensions: ["x_b"]
    },
    "model/vnd.parasolid.transmit.text": {
        source: "iana",
        extensions: ["x_t"]
    },
    "model/vnd.pytha.pyox": {
        source: "iana"
    },
    "model/vnd.rosette.annotated-data-model": {
        source: "iana"
    },
    "model/vnd.sap.vds": {
        source: "iana",
        extensions: ["vds"]
    },
    "model/vnd.usdz+zip": {
        source: "iana",
        compressible: !1,
        extensions: ["usdz"]
    },
    "model/vnd.valve.source.compiled-map": {
        source: "iana",
        extensions: ["bsp"]
    },
    "model/vnd.vtu": {
        source: "iana",
        extensions: ["vtu"]
    },
    "model/vrml": {
        source: "iana",
        compressible: !1,
        extensions: ["wrl", "vrml"]
    },
    "model/x3d+binary": {
        source: "apache",
        compressible: !1,
        extensions: ["x3db", "x3dbz"]
    },
    "model/x3d+fastinfoset": {
        source: "iana",
        extensions: ["x3db"]
    },
    "model/x3d+vrml": {
        source: "apache",
        compressible: !1,
        extensions: ["x3dv", "x3dvz"]
    },
    "model/x3d+xml": {
        source: "iana",
        compressible: !0,
        extensions: ["x3d", "x3dz"]
    },
    "model/x3d-vrml": {
        source: "iana",
        extensions: ["x3dv"]
    },
    "multipart/alternative": {
        source: "iana",
        compressible: !1
    },
    "multipart/appledouble": {
        source: "iana"
    },
    "multipart/byteranges": {
        source: "iana"
    },
    "multipart/digest": {
        source: "iana"
    },
    "multipart/encrypted": {
        source: "iana",
        compressible: !1
    },
    "multipart/form-data": {
        source: "iana",
        compressible: !1
    },
    "multipart/header-set": {
        source: "iana"
    },
    "multipart/mixed": {
        source: "iana"
    },
    "multipart/multilingual": {
        source: "iana"
    },
    "multipart/parallel": {
        source: "iana"
    },
    "multipart/related": {
        source: "iana",
        compressible: !1
    },
    "multipart/report": {
        source: "iana"
    },
    "multipart/signed": {
        source: "iana",
        compressible: !1
    },
    "multipart/vnd.bint.med-plus": {
        source: "iana"
    },
    "multipart/voice-message": {
        source: "iana"
    },
    "multipart/x-mixed-replace": {
        source: "iana"
    },
    "text/1d-interleaved-parityfec": {
        source: "iana"
    },
    "text/cache-manifest": {
        source: "iana",
        compressible: !0,
        extensions: ["appcache", "manifest"]
    },
    "text/calendar": {
        source: "iana",
        extensions: ["ics", "ifb"]
    },
    "text/calender": {
        compressible: !0
    },
    "text/cmd": {
        compressible: !0
    },
    "text/coffeescript": {
        extensions: ["coffee", "litcoffee"]
    },
    "text/cql": {
        source: "iana"
    },
    "text/cql-expression": {
        source: "iana"
    },
    "text/cql-identifier": {
        source: "iana"
    },
    "text/css": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0,
        extensions: ["css"]
    },
    "text/csv": {
        source: "iana",
        compressible: !0,
        extensions: ["csv"]
    },
    "text/csv-schema": {
        source: "iana"
    },
    "text/directory": {
        source: "iana"
    },
    "text/dns": {
        source: "iana"
    },
    "text/ecmascript": {
        source: "iana"
    },
    "text/encaprtp": {
        source: "iana"
    },
    "text/enriched": {
        source: "iana"
    },
    "text/fhirpath": {
        source: "iana"
    },
    "text/flexfec": {
        source: "iana"
    },
    "text/fwdred": {
        source: "iana"
    },
    "text/gff3": {
        source: "iana"
    },
    "text/grammar-ref-list": {
        source: "iana"
    },
    "text/html": {
        source: "iana",
        compressible: !0,
        extensions: ["html", "htm", "shtml"]
    },
    "text/jade": {
        extensions: ["jade"]
    },
    "text/javascript": {
        source: "iana",
        compressible: !0
    },
    "text/jcr-cnd": {
        source: "iana"
    },
    "text/jsx": {
        compressible: !0,
        extensions: ["jsx"]
    },
    "text/less": {
        compressible: !0,
        extensions: ["less"]
    },
    "text/markdown": {
        source: "iana",
        compressible: !0,
        extensions: ["markdown", "md"]
    },
    "text/mathml": {
        source: "nginx",
        extensions: ["mml"]
    },
    "text/mdx": {
        compressible: !0,
        extensions: ["mdx"]
    },
    "text/mizar": {
        source: "iana"
    },
    "text/n3": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0,
        extensions: ["n3"]
    },
    "text/parameters": {
        source: "iana",
        charset: "UTF-8"
    },
    "text/parityfec": {
        source: "iana"
    },
    "text/plain": {
        source: "iana",
        compressible: !0,
        extensions: ["txt", "text", "conf", "def", "list", "log", "in", "ini"]
    },
    "text/provenance-notation": {
        source: "iana",
        charset: "UTF-8"
    },
    "text/prs.fallenstein.rst": {
        source: "iana"
    },
    "text/prs.lines.tag": {
        source: "iana",
        extensions: ["dsc"]
    },
    "text/prs.prop.logic": {
        source: "iana"
    },
    "text/raptorfec": {
        source: "iana"
    },
    "text/red": {
        source: "iana"
    },
    "text/rfc822-headers": {
        source: "iana"
    },
    "text/richtext": {
        source: "iana",
        compressible: !0,
        extensions: ["rtx"]
    },
    "text/rtf": {
        source: "iana",
        compressible: !0,
        extensions: ["rtf"]
    },
    "text/rtp-enc-aescm128": {
        source: "iana"
    },
    "text/rtploopback": {
        source: "iana"
    },
    "text/rtx": {
        source: "iana"
    },
    "text/sgml": {
        source: "iana",
        extensions: ["sgml", "sgm"]
    },
    "text/shaclc": {
        source: "iana"
    },
    "text/shex": {
        source: "iana",
        extensions: ["shex"]
    },
    "text/slim": {
        extensions: ["slim", "slm"]
    },
    "text/spdx": {
        source: "iana",
        extensions: ["spdx"]
    },
    "text/strings": {
        source: "iana"
    },
    "text/stylus": {
        extensions: ["stylus", "styl"]
    },
    "text/t140": {
        source: "iana"
    },
    "text/tab-separated-values": {
        source: "iana",
        compressible: !0,
        extensions: ["tsv"]
    },
    "text/troff": {
        source: "iana",
        extensions: ["t", "tr", "roff", "man", "me", "ms"]
    },
    "text/turtle": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["ttl"]
    },
    "text/ulpfec": {
        source: "iana"
    },
    "text/uri-list": {
        source: "iana",
        compressible: !0,
        extensions: ["uri", "uris", "urls"]
    },
    "text/vcard": {
        source: "iana",
        compressible: !0,
        extensions: ["vcard"]
    },
    "text/vnd.a": {
        source: "iana"
    },
    "text/vnd.abc": {
        source: "iana"
    },
    "text/vnd.ascii-art": {
        source: "iana"
    },
    "text/vnd.curl": {
        source: "iana",
        extensions: ["curl"]
    },
    "text/vnd.curl.dcurl": {
        source: "apache",
        extensions: ["dcurl"]
    },
    "text/vnd.curl.mcurl": {
        source: "apache",
        extensions: ["mcurl"]
    },
    "text/vnd.curl.scurl": {
        source: "apache",
        extensions: ["scurl"]
    },
    "text/vnd.debian.copyright": {
        source: "iana",
        charset: "UTF-8"
    },
    "text/vnd.dmclientscript": {
        source: "iana"
    },
    "text/vnd.dvb.subtitle": {
        source: "iana",
        extensions: ["sub"]
    },
    "text/vnd.esmertec.theme-descriptor": {
        source: "iana",
        charset: "UTF-8"
    },
    "text/vnd.familysearch.gedcom": {
        source: "iana",
        extensions: ["ged"]
    },
    "text/vnd.ficlab.flt": {
        source: "iana"
    },
    "text/vnd.fly": {
        source: "iana",
        extensions: ["fly"]
    },
    "text/vnd.fmi.flexstor": {
        source: "iana",
        extensions: ["flx"]
    },
    "text/vnd.gml": {
        source: "iana"
    },
    "text/vnd.graphviz": {
        source: "iana",
        extensions: ["gv"]
    },
    "text/vnd.hans": {
        source: "iana"
    },
    "text/vnd.hgl": {
        source: "iana"
    },
    "text/vnd.in3d.3dml": {
        source: "iana",
        extensions: ["3dml"]
    },
    "text/vnd.in3d.spot": {
        source: "iana",
        extensions: ["spot"]
    },
    "text/vnd.iptc.newsml": {
        source: "iana"
    },
    "text/vnd.iptc.nitf": {
        source: "iana"
    },
    "text/vnd.latex-z": {
        source: "iana"
    },
    "text/vnd.motorola.reflex": {
        source: "iana"
    },
    "text/vnd.ms-mediapackage": {
        source: "iana"
    },
    "text/vnd.net2phone.commcenter.command": {
        source: "iana"
    },
    "text/vnd.radisys.msml-basic-layout": {
        source: "iana"
    },
    "text/vnd.senx.warpscript": {
        source: "iana"
    },
    "text/vnd.si.uricatalogue": {
        source: "iana"
    },
    "text/vnd.sosi": {
        source: "iana"
    },
    "text/vnd.sun.j2me.app-descriptor": {
        source: "iana",
        charset: "UTF-8",
        extensions: ["jad"]
    },
    "text/vnd.trolltech.linguist": {
        source: "iana",
        charset: "UTF-8"
    },
    "text/vnd.wap.si": {
        source: "iana"
    },
    "text/vnd.wap.sl": {
        source: "iana"
    },
    "text/vnd.wap.wml": {
        source: "iana",
        extensions: ["wml"]
    },
    "text/vnd.wap.wmlscript": {
        source: "iana",
        extensions: ["wmls"]
    },
    "text/vtt": {
        source: "iana",
        charset: "UTF-8",
        compressible: !0,
        extensions: ["vtt"]
    },
    "text/x-asm": {
        source: "apache",
        extensions: ["s", "asm"]
    },
    "text/x-c": {
        source: "apache",
        extensions: ["c", "cc", "cxx", "cpp", "h", "hh", "dic"]
    },
    "text/x-component": {
        source: "nginx",
        extensions: ["htc"]
    },
    "text/x-fortran": {
        source: "apache",
        extensions: ["f", "for", "f77", "f90"]
    },
    "text/x-gwt-rpc": {
        compressible: !0
    },
    "text/x-handlebars-template": {
        extensions: ["hbs"]
    },
    "text/x-java-source": {
        source: "apache",
        extensions: ["java"]
    },
    "text/x-jquery-tmpl": {
        compressible: !0
    },
    "text/x-lua": {
        extensions: ["lua"]
    },
    "text/x-markdown": {
        compressible: !0,
        extensions: ["mkd"]
    },
    "text/x-nfo": {
        source: "apache",
        extensions: ["nfo"]
    },
    "text/x-opml": {
        source: "apache",
        extensions: ["opml"]
    },
    "text/x-org": {
        compressible: !0,
        extensions: ["org"]
    },
    "text/x-pascal": {
        source: "apache",
        extensions: ["p", "pas"]
    },
    "text/x-processing": {
        compressible: !0,
        extensions: ["pde"]
    },
    "text/x-sass": {
        extensions: ["sass"]
    },
    "text/x-scss": {
        extensions: ["scss"]
    },
    "text/x-setext": {
        source: "apache",
        extensions: ["etx"]
    },
    "text/x-sfv": {
        source: "apache",
        extensions: ["sfv"]
    },
    "text/x-suse-ymp": {
        compressible: !0,
        extensions: ["ymp"]
    },
    "text/x-uuencode": {
        source: "apache",
        extensions: ["uu"]
    },
    "text/x-vcalendar": {
        source: "apache",
        extensions: ["vcs"]
    },
    "text/x-vcard": {
        source: "apache",
        extensions: ["vcf"]
    },
    "text/xml": {
        source: "iana",
        compressible: !0,
        extensions: ["xml"]
    },
    "text/xml-external-parsed-entity": {
        source: "iana"
    },
    "text/yaml": {
        compressible: !0,
        extensions: ["yaml", "yml"]
    },
    "video/1d-interleaved-parityfec": {
        source: "iana"
    },
    "video/3gpp": {
        source: "iana",
        extensions: ["3gp", "3gpp"]
    },
    "video/3gpp-tt": {
        source: "iana"
    },
    "video/3gpp2": {
        source: "iana",
        extensions: ["3g2"]
    },
    "video/av1": {
        source: "iana"
    },
    "video/bmpeg": {
        source: "iana"
    },
    "video/bt656": {
        source: "iana"
    },
    "video/celb": {
        source: "iana"
    },
    "video/dv": {
        source: "iana"
    },
    "video/encaprtp": {
        source: "iana"
    },
    "video/ffv1": {
        source: "iana"
    },
    "video/flexfec": {
        source: "iana"
    },
    "video/h261": {
        source: "iana",
        extensions: ["h261"]
    },
    "video/h263": {
        source: "iana",
        extensions: ["h263"]
    },
    "video/h263-1998": {
        source: "iana"
    },
    "video/h263-2000": {
        source: "iana"
    },
    "video/h264": {
        source: "iana",
        extensions: ["h264"]
    },
    "video/h264-rcdo": {
        source: "iana"
    },
    "video/h264-svc": {
        source: "iana"
    },
    "video/h265": {
        source: "iana"
    },
    "video/iso.segment": {
        source: "iana",
        extensions: ["m4s"]
    },
    "video/jpeg": {
        source: "iana",
        extensions: ["jpgv"]
    },
    "video/jpeg2000": {
        source: "iana"
    },
    "video/jpm": {
        source: "apache",
        extensions: ["jpm", "jpgm"]
    },
    "video/jxsv": {
        source: "iana"
    },
    "video/mj2": {
        source: "iana",
        extensions: ["mj2", "mjp2"]
    },
    "video/mp1s": {
        source: "iana"
    },
    "video/mp2p": {
        source: "iana"
    },
    "video/mp2t": {
        source: "iana",
        extensions: ["ts"]
    },
    "video/mp4": {
        source: "iana",
        compressible: !1,
        extensions: ["mp4", "mp4v", "mpg4"]
    },
    "video/mp4v-es": {
        source: "iana"
    },
    "video/mpeg": {
        source: "iana",
        compressible: !1,
        extensions: ["mpeg", "mpg", "mpe", "m1v", "m2v"]
    },
    "video/mpeg4-generic": {
        source: "iana"
    },
    "video/mpv": {
        source: "iana"
    },
    "video/nv": {
        source: "iana"
    },
    "video/ogg": {
        source: "iana",
        compressible: !1,
        extensions: ["ogv"]
    },
    "video/parityfec": {
        source: "iana"
    },
    "video/pointer": {
        source: "iana"
    },
    "video/quicktime": {
        source: "iana",
        compressible: !1,
        extensions: ["qt", "mov"]
    },
    "video/raptorfec": {
        source: "iana"
    },
    "video/raw": {
        source: "iana"
    },
    "video/rtp-enc-aescm128": {
        source: "iana"
    },
    "video/rtploopback": {
        source: "iana"
    },
    "video/rtx": {
        source: "iana"
    },
    "video/scip": {
        source: "iana"
    },
    "video/smpte291": {
        source: "iana"
    },
    "video/smpte292m": {
        source: "iana"
    },
    "video/ulpfec": {
        source: "iana"
    },
    "video/vc1": {
        source: "iana"
    },
    "video/vc2": {
        source: "iana"
    },
    "video/vnd.cctv": {
        source: "iana"
    },
    "video/vnd.dece.hd": {
        source: "iana",
        extensions: ["uvh", "uvvh"]
    },
    "video/vnd.dece.mobile": {
        source: "iana",
        extensions: ["uvm", "uvvm"]
    },
    "video/vnd.dece.mp4": {
        source: "iana"
    },
    "video/vnd.dece.pd": {
        source: "iana",
        extensions: ["uvp", "uvvp"]
    },
    "video/vnd.dece.sd": {
        source: "iana",
        extensions: ["uvs", "uvvs"]
    },
    "video/vnd.dece.video": {
        source: "iana",
        extensions: ["uvv", "uvvv"]
    },
    "video/vnd.directv.mpeg": {
        source: "iana"
    },
    "video/vnd.directv.mpeg-tts": {
        source: "iana"
    },
    "video/vnd.dlna.mpeg-tts": {
        source: "iana"
    },
    "video/vnd.dvb.file": {
        source: "iana",
        extensions: ["dvb"]
    },
    "video/vnd.fvt": {
        source: "iana",
        extensions: ["fvt"]
    },
    "video/vnd.hns.video": {
        source: "iana"
    },
    "video/vnd.iptvforum.1dparityfec-1010": {
        source: "iana"
    },
    "video/vnd.iptvforum.1dparityfec-2005": {
        source: "iana"
    },
    "video/vnd.iptvforum.2dparityfec-1010": {
        source: "iana"
    },
    "video/vnd.iptvforum.2dparityfec-2005": {
        source: "iana"
    },
    "video/vnd.iptvforum.ttsavc": {
        source: "iana"
    },
    "video/vnd.iptvforum.ttsmpeg2": {
        source: "iana"
    },
    "video/vnd.motorola.video": {
        source: "iana"
    },
    "video/vnd.motorola.videop": {
        source: "iana"
    },
    "video/vnd.mpegurl": {
        source: "iana",
        extensions: ["mxu", "m4u"]
    },
    "video/vnd.ms-playready.media.pyv": {
        source: "iana",
        extensions: ["pyv"]
    },
    "video/vnd.nokia.interleaved-multimedia": {
        source: "iana"
    },
    "video/vnd.nokia.mp4vr": {
        source: "iana"
    },
    "video/vnd.nokia.videovoip": {
        source: "iana"
    },
    "video/vnd.objectvideo": {
        source: "iana"
    },
    "video/vnd.radgamettools.bink": {
        source: "iana"
    },
    "video/vnd.radgamettools.smacker": {
        source: "iana"
    },
    "video/vnd.sealed.mpeg1": {
        source: "iana"
    },
    "video/vnd.sealed.mpeg4": {
        source: "iana"
    },
    "video/vnd.sealed.swf": {
        source: "iana"
    },
    "video/vnd.sealedmedia.softseal.mov": {
        source: "iana"
    },
    "video/vnd.uvvu.mp4": {
        source: "iana",
        extensions: ["uvu", "uvvu"]
    },
    "video/vnd.vivo": {
        source: "iana",
        extensions: ["viv"]
    },
    "video/vnd.youtube.yt": {
        source: "iana"
    },
    "video/vp8": {
        source: "iana"
    },
    "video/vp9": {
        source: "iana"
    },
    "video/webm": {
        source: "apache",
        compressible: !1,
        extensions: ["webm"]
    },
    "video/x-f4v": {
        source: "apache",
        extensions: ["f4v"]
    },
    "video/x-fli": {
        source: "apache",
        extensions: ["fli"]
    },
    "video/x-flv": {
        source: "apache",
        compressible: !1,
        extensions: ["flv"]
    },
    "video/x-m4v": {
        source: "apache",
        extensions: ["m4v"]
    },
    "video/x-matroska": {
        source: "apache",
        compressible: !1,
        extensions: ["mkv", "mk3d", "mks"]
    },
    "video/x-mng": {
        source: "apache",
        extensions: ["mng"]
    },
    "video/x-ms-asf": {
        source: "apache",
        extensions: ["asf", "asx"]
    },
    "video/x-ms-vob": {
        source: "apache",
        extensions: ["vob"]
    },
    "video/x-ms-wm": {
        source: "apache",
        extensions: ["wm"]
    },
    "video/x-ms-wmv": {
        source: "apache",
        compressible: !1,
        extensions: ["wmv"]
    },
    "video/x-ms-wmx": {
        source: "apache",
        extensions: ["wmx"]
    },
    "video/x-ms-wvx": {
        source: "apache",
        extensions: ["wvx"]
    },
    "video/x-msvideo": {
        source: "apache",
        extensions: ["avi"]
    },
    "video/x-sgi-movie": {
        source: "apache",
        extensions: ["movie"]
    },
    "video/x-smv": {
        source: "apache",
        extensions: ["smv"]
    },
    "x-conference/x-cooltalk": {
        source: "apache",
        extensions: ["ice"]
    },
    "x-shader/x-fragment": {
        compressible: !0
    },
    "x-shader/x-vertex": {
        compressible: !0
    }
},
/*!
 * mime-types
 * Copyright(c) 2014 Jonathan Ong
 * Copyright(c) 2015 Douglas Christopher Wilson
 * MIT Licensed
 */
function (e) {
    var t,
    a,
    n,
    i = ke.exports,
    s = P.default.extname,
    o = /^\s*([^;\s]*)(?:;|\s|$)/,
    r = /^text\//i;
    function c(e) {
        if (!e || "string" != typeof e)
            return !1;
        var t = o.exec(e),
        a = t && i[t[1].toLowerCase()];
        return a && a.charset ? a.charset : !(!t || !r.test(t[1])) && "UTF-8"
    }
    e.charset = c,
    e.charsets = {
        lookup: c
    },
    e.contentType = function (t) {
        if (!t || "string" != typeof t)
            return !1;
        var a = -1 === t.indexOf("/") ? e.lookup(t) : t;
        if (!a)
            return !1;
        if (-1 === a.indexOf("charset")) {
            var n = e.charset(a);
            n && (a += "; charset=" + n.toLowerCase())
        }
        return a
    },
    e.extension = function (t) {
        if (!t || "string" != typeof t)
            return !1;
        var a = o.exec(t),
        n = a && e.extensions[a[1].toLowerCase()];
        return !(!n || !n.length) && n[0]
    },
    e.extensions = Object.create(null),
    e.lookup = function (t) {
        if (!t || "string" != typeof t)
            return !1;
        var a = s("x." + t).toLowerCase().substr(1);
        return a && e.types[a] || !1
    },
    e.types = Object.create(null),
    t = e.extensions,
    a = e.types,
    n = ["nginx", "apache", void 0, "iana"],
    Object.keys(i).forEach((function (e) {
            var s = i[e],
            o = s.extensions;
            if (o && o.length) {
                t[e] = o;
                for (var r = 0; r < o.length; r++) {
                    var c = o[r];
                    if (a[c]) {
                        var l = n.indexOf(i[a[c]].source),
                        p = n.indexOf(s.source);
                        if ("application/octet-stream" !== a[c] && (l > p || l === p && "application/" === a[c].substr(0, 12)))
                            continue
                    }
                    a[c] = e
                }
            }
        }))
}
(Ie);
var Re = function (e) {
    var t = "function" == typeof setImmediate ? setImmediate : "object" == typeof process && "function" == typeof process.nextTick ? process.nextTick : null;
    t ? t(e) : setTimeout(e, 0)
}, Oe = function (e) {
    var t = !1;
    return Re((function () {
            t = !0
        })),
    function (a, n) {
        t ? e(a, n) : Re((function () {
                e(a, n)
            }))
    }
}, De = function (e) {
    Object.keys(e.jobs).forEach(Le.bind(e)),
    e.jobs = {}
};
function Le(e) {
    "function" == typeof this.jobs[e] && this.jobs[e]()
}
var Me = Oe, Pe = De, Be = function (e, t, a, n) {
    var i = a.keyedList ? a.keyedList[a.index] : a.index;
    a.jobs[i] = function (e, t, a, n) {
        return 2 == e.length ? e(a, Me(n)) : e(a, t, Me(n))
    }
    (t, i, e[i], (function (e, t) {
            i in a.jobs && (delete a.jobs[i], e ? Pe(a) : a.results[i] = t, n(e, a.results))
        }))
}, Ue = function (e, t) {
    var a = !Array.isArray(e),
    n = {
        index: 0,
        keyedList: a || t ? Object.keys(e) : null,
        jobs: {},
        results: a ? {}
         : [],
        size: a ? Object.keys(e).length : e.length
    };
    return t && n.keyedList.sort(a ? t : function (a, n) {
        return t(e[a], e[n])
    }),
    n
}, Fe = De, He = Oe, je = function (e) {
    Object.keys(this.jobs).length && (this.index = this.size, Fe(this), He(e)(null, this.results))
}, ze = Be, Ge = Ue, qe = je, Ye = {
    exports: {}
}, Ve = Be, Qe = Ue, We = je;
function Ke(e, t) {
    return e < t ? -1 : e > t ? 1 : 0
}
Ye.exports = function (e, t, a, n) {
    var i = Qe(e, a);
    return Ve(e, t, i, (function a(s, o) {
            s ? n(s, o) : (i.index++, i.index < (i.keyedList || e).length ? Ve(e, t, i, a) : n(null, i.results))
        })),
    We.bind(i, n)
}, Ye.exports.ascending = Ke, Ye.exports.descending = function (e, t) {
    return -1 * Ke(e, t)
};
var Ze = Ye.exports, Xe = {
    parallel: function (e, t, a) {
        for (var n = Ge(e); n.index < (n.keyedList || e).length; )
            ze(e, t, n, (function (e, t) {
                    e ? a(e, t) : 0 !== Object.keys(n.jobs).length || a(null, n.results)
                })), n.index++;
        return qe.bind(n, a)
    },
    serial: function (e, t, a) {
        return Ze(e, t, null, a)
    },
    serialOrdered: Ye.exports
}, $e = Ne, Je = L.default, et = P.default, tt = B.default, at = U.default, nt = F.default.parse, it = H.default, st = M.default.Stream, ot = Ie, rt = Xe, ct = function (e, t) {
    return Object.keys(t).forEach((function (a) {
            e[a] = e[a] || t[a]
        })),
    e
}, lt = pt;
function pt(e) {
    if (!(this instanceof pt))
        return new pt(e);
    for (var t in this._overheadLength = 0, this._valueLength = 0, this._valuesToMeasure = [], $e.call(this), e = e || {})
        this[t] = e[t]
}
function ut(e) {
    return Ee.isPlainObject(e) || Ee.isArray(e)
}
function dt(e) {
    return Ee.endsWith(e, "[]") ? e.slice(0, -2) : e
}
function ht(e, t, a) {
    return e ? e.concat(t).map((function (e, t) {
            return e = dt(e),
            !a && t ? "[" + e + "]" : e
        })).join(a ? "." : "") : t
}
Je.inherits(pt, $e), pt.LINE_BREAK = "\r\n", pt.DEFAULT_CONTENT_TYPE = "application/octet-stream", pt.prototype.append = function (e, t, a) {
    "string" == typeof(a = a || {}) && (a = {
            filename: a
        });
    var n = $e.prototype.append.bind(this);
    if ("number" == typeof t && (t = "" + t), Je.isArray(t))
        this._error(new Error("Arrays are not supported."));
    else {
        var i = this._multiPartHeader(e, t, a),
        s = this._multiPartFooter();
        n(i),
        n(t),
        n(s),
        this._trackLength(i, t, a)
    }
}, pt.prototype._trackLength = function (e, t, a) {
    var n = 0;
    null != a.knownLength ? n += +a.knownLength : Buffer.isBuffer(t) ? n = t.length : "string" == typeof t && (n = Buffer.byteLength(t)),
    this._valueLength += n,
    this._overheadLength += Buffer.byteLength(e) + pt.LINE_BREAK.length,
    t && (t.path || t.readable && t.hasOwnProperty("httpVersion") || t instanceof st) && (a.knownLength || this._valuesToMeasure.push(t))
}, pt.prototype._lengthRetriever = function (e, t) {
    e.hasOwnProperty("fd") ? null != e.end && e.end != 1 / 0 && null != e.start ? t(null, e.end + 1 - (e.start ? e.start : 0)) : it.stat(e.path, (function (a, n) {
            var i;
            a ? t(a) : (i = n.size - (e.start ? e.start : 0), t(null, i))
        })) : e.hasOwnProperty("httpVersion") ? t(null, +e.headers["content-length"]) : e.hasOwnProperty("httpModule") ? (e.on("response", (function (a) {
                e.pause(),
                t(null, +a.headers["content-length"])
            })), e.resume()) : t("Unknown stream")
}, pt.prototype._multiPartHeader = function (e, t, a) {
    if ("string" == typeof a.header)
        return a.header;
    var n,
    i = this._getContentDisposition(t, a),
    s = this._getContentType(t, a),
    o = "",
    r = {
        "Content-Disposition": ["form-data", 'name="' + e + '"'].concat(i || []),
        "Content-Type": [].concat(s || [])
    };
    for (var c in "object" == typeof a.header && ct(r, a.header), r)
        r.hasOwnProperty(c) && null != (n = r[c]) && (Array.isArray(n) || (n = [n]), n.length && (o += c + ": " + n.join("; ") + pt.LINE_BREAK));
    return "--" + this.getBoundary() + pt.LINE_BREAK + o + pt.LINE_BREAK
}, pt.prototype._getContentDisposition = function (e, t) {
    var a,
    n;
    return "string" == typeof t.filepath ? a = et.normalize(t.filepath).replace(/\\/g, "/") : t.filename || e.name || e.path ? a = et.basename(t.filename || e.name || e.path) : e.readable && e.hasOwnProperty("httpVersion") && (a = et.basename(e.client._httpMessage.path || "")),
    a && (n = 'filename="' + a + '"'),
    n
}, pt.prototype._getContentType = function (e, t) {
    var a = t.contentType;
    return !a && e.name && (a = ot.lookup(e.name)),
    !a && e.path && (a = ot.lookup(e.path)),
    !a && e.readable && e.hasOwnProperty("httpVersion") && (a = e.headers["content-type"]),
    a || !t.filepath && !t.filename || (a = ot.lookup(t.filepath || t.filename)),
    a || "object" != typeof e || (a = pt.DEFAULT_CONTENT_TYPE),
    a
}, pt.prototype._multiPartFooter = function () {
    return function (e) {
        var t = pt.LINE_BREAK;
        0 === this._streams.length && (t += this._lastBoundary()),
        e(t)
    }
    .bind(this)
}, pt.prototype._lastBoundary = function () {
    return "--" + this.getBoundary() + "--" + pt.LINE_BREAK
}, pt.prototype.getHeaders = function (e) {
    var t,
    a = {
        "content-type": "multipart/form-data; boundary=" + this.getBoundary()
    };
    for (t in e)
        e.hasOwnProperty(t) && (a[t.toLowerCase()] = e[t]);
    return a
}, pt.prototype.setBoundary = function (e) {
    this._boundary = e
}, pt.prototype.getBoundary = function () {
    return this._boundary || this._generateBoundary(),
    this._boundary
}, pt.prototype.getBuffer = function () {
    for (var e = new Buffer.alloc(0), t = this.getBoundary(), a = 0, n = this._streams.length; a < n; a++)
        "function" != typeof this._streams[a] && (e = Buffer.isBuffer(this._streams[a]) ? Buffer.concat([e, this._streams[a]]) : Buffer.concat([e, Buffer.from(this._streams[a])]), "string" == typeof this._streams[a] && this._streams[a].substring(2, t.length + 2) === t || (e = Buffer.concat([e, Buffer.from(pt.LINE_BREAK)])));
    return Buffer.concat([e, Buffer.from(this._lastBoundary())])
}, pt.prototype._generateBoundary = function () {
    for (var e = "--------------------------", t = 0; t < 24; t++)
        e += Math.floor(10 * Math.random()).toString(16);
    this._boundary = e
}, pt.prototype.getLengthSync = function () {
    var e = this._overheadLength + this._valueLength;
    return this._streams.length && (e += this._lastBoundary().length),
    this.hasKnownLength() || this._error(new Error("Cannot calculate proper length in synchronous way.")),
    e
}, pt.prototype.hasKnownLength = function () {
    var e = !0;
    return this._valuesToMeasure.length && (e = !1),
    e
}, pt.prototype.getLength = function (e) {
    var t = this._overheadLength + this._valueLength;
    this._streams.length && (t += this._lastBoundary().length),
    this._valuesToMeasure.length ? rt.parallel(this._valuesToMeasure, this._lengthRetriever, (function (a, n) {
            a ? e(a) : (n.forEach((function (e) {
                        t += e
                    })), e(null, t))
        })) : process.nextTick(e.bind(this, null, t))
}, pt.prototype.submit = function (e, t) {
    var a,
    n,
    i = {
        method: "post"
    };
    return "string" == typeof e ? (e = nt(e), n = ct({
            port: e.port,
            path: e.pathname,
            host: e.hostname,
            protocol: e.protocol
        }, i)) : (n = ct(e, i)).port || (n.port = "https:" == n.protocol ? 443 : 80),
    n.headers = this.getHeaders(e.headers),
    a = "https:" == n.protocol ? at.request(n) : tt.request(n),
    this.getLength(function (e, n) {
        if (e && "Unknown stream" !== e)
            this._error(e);
        else if (n && a.setHeader("Content-Length", n), this.pipe(a), t) {
            var i,
            s = function (e, n) {
                return a.removeListener("error", s),
                a.removeListener("response", i),
                t.call(this, e, n)
            };
            i = s.bind(this, null),
            a.on("error", s),
            a.on("response", i)
        }
    }
        .bind(this)),
    a
}, pt.prototype._error = function (e) {
    this.error || (this.error = e, this.pause(), this.emit("error", e))
}, pt.prototype.toString = function () {
    return "[object FormData]"
};
const mt = Ee.toFlatObject(Ee, {}, null, (function (e) {
        return /^is[A-Z]/.test(e)
    }));
function ft(e, t, a) {
    if (!Ee.isObject(e))
        throw new TypeError("target must be an object");
    t = t || new(lt || FormData);
    const n = (a = Ee.toFlatObject(a, {
            metaTokens: !0,
            dots: !1,
            indexes: !1
        }, !1, (function (e, t) {
                    return !Ee.isUndefined(t[e])
                }))).metaTokens,
    i = a.visitor || p,
    s = a.dots,
    o = a.indexes,
    r = (a.Blob || "undefined" != typeof Blob && Blob) && (c = t) && Ee.isFunction(c.append) && "FormData" === c[Symbol.toStringTag] && c[Symbol.iterator];
    var c;
    if (!Ee.isFunction(i))
        throw new TypeError("visitor must be a function");
    function l(e) {
        if (null === e)
            return "";
        if (Ee.isDate(e))
            return e.toISOString();
        if (!r && Ee.isBlob(e))
            throw new ge("Blob is not supported. Use a Buffer instead.");
        return Ee.isArrayBuffer(e) || Ee.isTypedArray(e) ? r && "function" == typeof Blob ? new Blob([e]) : Buffer.from(e) : e
    }
    function p(e, a, i) {
        let r = e;
        if (e && !i && "object" == typeof e)
            if (Ee.endsWith(a, "{}"))
                a = n ? a : a.slice(0, -2), e = JSON.stringify(e);
            else if (Ee.isArray(e) && function (e) {
                return Ee.isArray(e) && !e.some(ut)
            }
                (e) || Ee.isFileList(e) || Ee.endsWith(a, "[]") && (r = Ee.toArray(e)))
                return a = dt(a), r.forEach((function (e, n) {
                        !Ee.isUndefined(e) && null !== e && t.append(!0 === o ? ht([a], n, s) : null === o ? a : a + "[]", l(e))
                    })), !1;
        return !!ut(e) || (t.append(ht(i, a, s), l(e)), !1)
    }
    const u = [],
    d = Object.assign(mt, {
        defaultVisitor: p,
        convertValue: l,
        isVisitable: ut
    });
    if (!Ee.isObject(e))
        throw new TypeError("data must be an object");
    return function e(a, n) {
        if (!Ee.isUndefined(a)) {
            if (-1 !== u.indexOf(a))
                throw Error("Circular reference detected in " + n.join("."));
            u.push(a),
            Ee.forEach(a, (function (a, s) {
                    !0 === (!(Ee.isUndefined(a) || null === a) && i.call(t, a, Ee.isString(s) ? s.trim() : s, n, d)) && e(a, n ? n.concat(s) : [s])
                })),
            u.pop()
        }
    }
    (e),
    t
}
function _t(e) {
    const t = {
        "!": "%21",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "~": "%7E",
        "%20": "+",
        "%00": "\0"
    };
    return encodeURIComponent(e).replace(/[!'()~]|%20|%00/g, (function (e) {
            return t[e]
        }))
}
function Et(e, t) {
    this._pairs = [],
    e && ft(e, this, t)
}
const gt = Et.prototype;
function bt(e) {
    return encodeURIComponent(e).replace(/%3A/gi, ":").replace(/%24/g, "$").replace(/%2C/gi, ",").replace(/%20/g, "+").replace(/%5B/gi, "[").replace(/%5D/gi, "]")
}
function xt(e, t, a) {
    if (!t)
        return e;
    const n = a && a.encode || bt,
    i = a && a.serialize;
    let s;
    if (s = i ? i(t, a) : Ee.isURLSearchParams(t) ? t.toString() : new Et(t, a).toString(n), s) {
        const t = e.indexOf("#");
        -1 !== t && (e = e.slice(0, t)),
        e += (-1 === e.indexOf("?") ? "?" : "&") + s
    }
    return e
}
gt.append = function (e, t) {
    this._pairs.push([e, t])
}, gt.toString = function (e) {
    const t = e ? function (t) {
        return e.call(this, t, _t)
    }
     : _t;
    return this._pairs.map((function (e) {
            return t(e[0]) + "=" + t(e[1])
        }), "").join("&")
};
class Tt {
    constructor() {
        this.handlers = []
    }
    use(e, t, a) {
        return this.handlers.push({
            fulfilled: e,
            rejected: t,
            synchronous: !!a && a.synchronous,
            runWhen: a ? a.runWhen : null
        }),
        this.handlers.length - 1
    }
    eject(e) {
        this.handlers[e] && (this.handlers[e] = null)
    }
    clear() {
        this.handlers && (this.handlers = [])
    }
    forEach(e) {
        Ee.forEach(this.handlers, (function (t) {
                null !== t && e(t)
            }))
    }
}
var vt = {
    silentJSONParsing: !0,
    forcedJSONParsing: !0,
    clarifyTimeoutError: !1
}, At = {
    isNode: !0,
    classes: {
        URLSearchParams: F.default.URLSearchParams,
        FormData: lt,
        Blob: "undefined" != typeof Blob && Blob || null
    },
    protocols: ["http", "https", "file", "data"]
};
function yt(e) {
    function t(e, a, n, i) {
        let s = e[i++];
        const o = Number.isFinite(+s),
        r = i >= e.length;
        return s = !s && Ee.isArray(n) ? n.length : s,
        r ? (Ee.hasOwnProp(n, s) ? n[s] = [n[s], a] : n[s] = a, !o) : (n[s] && Ee.isObject(n[s]) || (n[s] = []), t(e, a, n[s], i) && Ee.isArray(n[s]) && (n[s] = function (e) {
                const t = {},
                a = Object.keys(e);
                let n;
                const i = a.length;
                let s;
                for (n = 0; n < i; n++)
                    s = a[n], t[s] = e[s];
                return t
            }
                (n[s])), !o)
    }
    if (Ee.isFormData(e) && Ee.isFunction(e.entries)) {
        const a = {};
        return Ee.forEachEntry(e, ((e, n) => {
                t(function (e) {
                    return Ee.matchAll(/\w+|\[(\w*)]/g, e).map((e => "[]" === e[0] ? "" : e[1] || e[0]))
                }
                    (e), n, a, 0)
            })),
        a
    }
    return null
}
function wt(e, t, a) {
    const n = a.config.validateStatus;
    a.status && n && !n(a.status) ? t(new ge("Request failed with status code " + a.status, [ge.ERR_BAD_REQUEST, ge.ERR_BAD_RESPONSE][Math.floor(a.status / 100) - 4], a.config, a.request, a)) : e(a)
}
function St(e, t) {
    return e && !function (e) {
        return /^([a-z][a-z\d+\-.]*:)?\/\//i.test(e)
    }
    (t) ? function (e, t) {
        return t ? e.replace(/\/+$/, "") + "/" + t.replace(/^\/+/, "") : e
    }
    (e, t) : t
}
var Nt = F.default.parse, Ct = {
    ftp: 21,
    gopher: 70,
    http: 80,
    https: 443,
    ws: 80,
    wss: 443
}, It = String.prototype.endsWith || function (e) {
    return e.length <= this.length && -1 !== this.indexOf(e, this.length - e.length)
};
function kt(e) {
    return process.env[e.toLowerCase()] || process.env[e.toUpperCase()] || ""
}
var Rt, Ot = {
    exports: {}
}, Dt = F.default, Lt = Dt.URL, Mt = B.default, Pt = U.default, Bt = M.default.Writable, Ut = j.default, Ft = function () {
    if (!Rt) {
        try {
            Rt = require("debug")("follow-redirects")
        } catch (e) {}
        "function" != typeof Rt && (Rt = function () {})
    }
    Rt.apply(null, arguments)
}, Ht = ["abort", "aborted", "connect", "error", "socket", "timeout"], jt = Object.create(null);
Ht.forEach((function (e) {
        jt[e] = function (t, a, n) {
            this._redirectable.emit(e, t, a, n)
        }
    }));
var zt = $t("ERR_INVALID_URL", "Invalid URL", TypeError), Gt = $t("ERR_FR_REDIRECTION_FAILURE", "Redirected request failed"), qt = $t("ERR_FR_TOO_MANY_REDIRECTS", "Maximum number of redirects exceeded"), Yt = $t("ERR_FR_MAX_BODY_LENGTH_EXCEEDED", "Request body larger than maxBodyLength limit"), Vt = $t("ERR_STREAM_WRITE_AFTER_END", "write after end");
function Qt(e, t) {
    Bt.call(this),
    this._sanitizeOptions(e),
    this._options = e,
    this._ended = !1,
    this._ending = !1,
    this._redirectCount = 0,
    this._redirects = [],
    this._requestBodyLength = 0,
    this._requestBodyBuffers = [],
    t && this.on("response", t);
    var a = this;
    this._onNativeResponse = function (e) {
        a._processResponse(e)
    },
    this._performRequest()
}
function Wt(e) {
    var t = {
        maxRedirects: 21,
        maxBodyLength: 10485760
    },
    a = {};
    return Object.keys(e).forEach((function (n) {
            var i = n + ":",
            s = a[i] = e[n],
            o = t[n] = Object.create(s);
            Object.defineProperties(o, {
                request: {
                    value: function (e, n, s) {
                        if (ea(e)) {
                            var o;
                            try {
                                o = Zt(new Lt(e))
                            } catch (t) {
                                o = Dt.parse(e)
                            }
                            if (!ea(o.protocol))
                                throw new zt({
                                    input: e
                                });
                            e = o
                        } else
                            Lt && e instanceof Lt ? e = Zt(e) : (s = n, n = e, e = {
                                        protocol: i
                                    });
                        return ta(n) && (s = n, n = null),
                        (n = Object.assign({
                                maxRedirects: t.maxRedirects,
                                maxBodyLength: t.maxBodyLength
                            }, e, n)).nativeProtocols = a,
                        ea(n.host) || ea(n.hostname) || (n.hostname = "::1"),
                        Ut.equal(n.protocol, i, "protocol mismatch"),
                        Ft("options", n),
                        new Qt(n, s)
                    },
                    configurable: !0,
                    enumerable: !0,
                    writable: !0
                },
                get: {
                    value: function (e, t, a) {
                        var n = o.request(e, t, a);
                        return n.end(),
                        n
                    },
                    configurable: !0,
                    enumerable: !0,
                    writable: !0
                }
            })
        })),
    t
}
function Kt() {}
function Zt(e) {
    var t = {
        protocol: e.protocol,
        hostname: e.hostname.startsWith("[") ? e.hostname.slice(1, -1) : e.hostname,
        hash: e.hash,
        search: e.search,
        pathname: e.pathname,
        path: e.pathname + e.search,
        href: e.href
    };
    return "" !== e.port && (t.port = Number(e.port)),
    t
}
function Xt(e, t) {
    var a;
    for (var n in t)
        e.test(n) && (a = t[n], delete t[n]);
    return null == a ? void 0 : String(a).trim()
}
function $t(e, t, a) {
    function n(a) {
        Error.captureStackTrace(this, this.constructor),
        Object.assign(this, a || {}),
        this.code = e,
        this.message = this.cause ? t + ": " + this.cause.message : t
    }
    return n.prototype = new(a || Error),
    n.prototype.constructor = n,
    n.prototype.name = "Error [" + e + "]",
    n
}
function Jt(e) {
    for (var t of Ht)
        e.removeListener(t, jt[t]);
    e.on("error", Kt),
    e.abort()
}
function ea(e) {
    return "string" == typeof e || e instanceof String
}
function ta(e) {
    return "function" == typeof e
}
function aa(e, t, a) {
    ge.call(this, null == e ? "canceled" : e, ge.ERR_CANCELED, t, a),
    this.name = "CanceledError"
}
function na(e) {
    const t = /^([-+\w]{1,25})(:?\/\/|:)/.exec(e);
    return t && t[1] || ""
}
Qt.prototype = Object.create(Bt.prototype), Qt.prototype.abort = function () {
    Jt(this._currentRequest),
    this.emit("abort")
}, Qt.prototype.write = function (e, t, a) {
    if (this._ending)
        throw new Vt;
    if (!(ea(e) || "object" == typeof(n = e) && "length" in n))
        throw new TypeError("data should be a string, Buffer or Uint8Array");
    var n;
    ta(t) && (a = t, t = null),
    0 !== e.length ? this._requestBodyLength + e.length <= this._options.maxBodyLength ? (this._requestBodyLength += e.length, this._requestBodyBuffers.push({
            data: e,
            encoding: t
        }), this._currentRequest.write(e, t, a)) : (this.emit("error", new Yt), this.abort()) : a && a()
}, Qt.prototype.end = function (e, t, a) {
    if (ta(e) ? (a = e, e = t = null) : ta(t) && (a = t, t = null), e) {
        var n = this,
        i = this._currentRequest;
        this.write(e, t, (function () {
                n._ended = !0,
                i.end(null, null, a)
            })),
        this._ending = !0
    } else
        this._ended = this._ending = !0, this._currentRequest.end(null, null, a)
}, Qt.prototype.setHeader = function (e, t) {
    this._options.headers[e] = t,
    this._currentRequest.setHeader(e, t)
}, Qt.prototype.removeHeader = function (e) {
    delete this._options.headers[e],
    this._currentRequest.removeHeader(e)
}, Qt.prototype.setTimeout = function (e, t) {
    var a = this;
    function n(t) {
        t.setTimeout(e),
        t.removeListener("timeout", t.destroy),
        t.addListener("timeout", t.destroy)
    }
    function i(t) {
        a._timeout && clearTimeout(a._timeout),
        a._timeout = setTimeout((function () {
                    a.emit("timeout"),
                    s()
                }), e),
        n(t)
    }
    function s() {
        a._timeout && (clearTimeout(a._timeout), a._timeout = null),
        a.removeListener("abort", s),
        a.removeListener("error", s),
        a.removeListener("response", s),
        t && a.removeListener("timeout", t),
        a.socket || a._currentRequest.removeListener("socket", i)
    }
    return t && this.on("timeout", t),
    this.socket ? i(this.socket) : this._currentRequest.once("socket", i),
    this.on("socket", n),
    this.on("abort", s),
    this.on("error", s),
    this.on("response", s),
    this
}, ["flushHeaders", "getHeader", "setNoDelay", "setSocketKeepAlive"].forEach((function (e) {
        Qt.prototype[e] = function (t, a) {
            return this._currentRequest[e](t, a)
        }
    })), ["aborted", "connection", "socket"].forEach((function (e) {
        Object.defineProperty(Qt.prototype, e, {
            get: function () {
                return this._currentRequest[e]
            }
        })
    })), Qt.prototype._sanitizeOptions = function (e) {
    if (e.headers || (e.headers = {}), e.host && (e.hostname || (e.hostname = e.host), delete e.host), !e.pathname && e.path) {
        var t = e.path.indexOf("?");
        t < 0 ? e.pathname = e.path : (e.pathname = e.path.substring(0, t), e.search = e.path.substring(t))
    }
}, Qt.prototype._performRequest = function () {
    var e = this._options.protocol,
    t = this._options.nativeProtocols[e];
    if (t) {
        if (this._options.agents) {
            var a = e.slice(0, -1);
            this._options.agent = this._options.agents[a]
        }
        var n = this._currentRequest = t.request(this._options, this._onNativeResponse);
        for (var i of(n._redirectable = this, Ht))
            n.on(i, jt[i]);
        if (this._currentUrl = /^\//.test(this._options.path) ? Dt.format(this._options) : this._options.path, this._isRedirect) {
            var s = 0,
            o = this,
            r = this._requestBodyBuffers;
            !function e(t) {
                if (n === o._currentRequest)
                    if (t)
                        o.emit("error", t);
                    else if (s < r.length) {
                        var a = r[s++];
                        n.finished || n.write(a.data, a.encoding, e)
                    } else
                        o._ended && n.end()
            }
            ()
        }
    } else
        this.emit("error", new TypeError("Unsupported protocol " + e))
}, Qt.prototype._processResponse = function (e) {
    var t = e.statusCode;
    this._options.trackRedirects && this._redirects.push({
        url: this._currentUrl,
        headers: e.headers,
        statusCode: t
    });
    var a = e.headers.location;
    if (!a || !1 === this._options.followRedirects || t < 300 || t >= 400)
        return e.responseUrl = this._currentUrl, e.redirects = this._redirects, this.emit("response", e), void(this._requestBodyBuffers = []);
    if (Jt(this._currentRequest), e.destroy(), ++this._redirectCount > this._options.maxRedirects)
        this.emit("error", new qt);
    else {
        var n,
        i = this._options.beforeRedirect;
        i && (n = Object.assign({
                Host: e.req.getHeader("host")
            }, this._options.headers));
        var s = this._options.method;
        ((301 === t || 302 === t) && "POST" === this._options.method || 303 === t && !/^(?:GET|HEAD)$/.test(this._options.method)) && (this._options.method = "GET", this._requestBodyBuffers = [], Xt(/^content-/i, this._options.headers));
        var o,
        r = Xt(/^host$/i, this._options.headers),
        c = Dt.parse(this._currentUrl),
        l = r || c.host,
        p = /^\w+:/.test(a) ? this._currentUrl : Dt.format(Object.assign(c, {
                    host: l
                }));
        try {
            o = Dt.resolve(p, a)
        } catch (e) {
            return void this.emit("error", new Gt({
                    cause: e
                }))
        }
        Ft("redirecting to", o),
        this._isRedirect = !0;
        var u = Dt.parse(o);
        if (Object.assign(this._options, u), (u.protocol !== c.protocol && "https:" !== u.protocol || u.host !== l && !function (e, t) {
                Ut(ea(e) && ea(t));
                var a = e.length - t.length - 1;
                return a > 0 && "." === e[a] && e.endsWith(t)
            }
                (u.host, l)) && Xt(/^(?:authorization|cookie)$/i, this._options.headers), ta(i)) {
            var d = {
                headers: e.headers,
                statusCode: t
            },
            h = {
                url: p,
                method: s,
                headers: n
            };
            try {
                i(this._options, d, h)
            } catch (e) {
                return void this.emit("error", e)
            }
            this._sanitizeOptions(this._options)
        }
        try {
            this._performRequest()
        } catch (e) {
            this.emit("error", new Gt({
                    cause: e
                }))
        }
    }
}, Ot.exports = Wt({
    http: Mt,
    https: Pt
}), Ot.exports.wrap = Wt, Ee.inherits(aa, ge, {
    __CANCEL__: !0
});
const ia = /^(?:([^;]+);)?(?:[^;]+;)?(base64|),([\s\S]*)$/, sa = Ee.toObjectSet(["age", "authorization", "content-length", "content-type", "etag", "expires", "from", "host", "if-modified-since", "if-unmodified-since", "last-modified", "location", "max-forwards", "proxy-authorization", "referer", "retry-after", "user-agent"]), oa = Symbol("internals"), ra = Symbol("defaults");
function ca(e) {
    return e && String(e).trim().toLowerCase()
}
function la(e) {
    return !1 === e || null == e ? e : Ee.isArray(e) ? e.map(la) : String(e)
}
function pa(e, t, a, n) {
    return Ee.isFunction(n) ? n.call(this, t, a) : Ee.isString(t) ? Ee.isString(n) ? -1 !== t.indexOf(n) : Ee.isRegExp(n) ? n.test(t) : void 0 : void 0
}
function ua(e, t) {
    t = t.toLowerCase();
    const a = Object.keys(e);
    let n,
    i = a.length;
    for (; i-- > 0; )
        if (n = a[i], t === n.toLowerCase())
            return n;
    return null
}
function da(e, t) {
    e && this.set(e),
    this[ra] = t || null
}
function ha(e, t) {
    e = e || 10;
    const a = new Array(e),
    n = new Array(e);
    let i,
    s = 0,
    o = 0;
    return t = void 0 !== t ? t : 1e3,
    function (r) {
        const c = Date.now(),
        l = n[o];
        i || (i = c),
        a[s] = r,
        n[s] = c;
        let p = o,
        u = 0;
        for (; p !== s; )
            u += a[p++], p %= e;
        if (s = (s + 1) % e, s === o && (o = (o + 1) % e), c - i < t)
            return;
        const d = l && c - l;
        return d ? Math.round(1e3 * u / d) : void 0
    }
}
Object.assign(da.prototype, {
    set: function (e, t, a) {
        const n = this;
        function i(e, t, a) {
            const i = ca(t);
            if (!i)
                throw new Error("header name must be a non-empty string");
            const s = ua(n, i);
            (!s || !0 === a || !1 !== n[s] && !1 !== a) && (n[s || t] = la(e))
        }
        return Ee.isPlainObject(e) ? Ee.forEach(e, ((e, a) => {
                i(e, a, t)
            })) : i(t, e, a),
        this
    },
    get: function (e, t) {
        if (!(e = ca(e)))
            return;
        const a = ua(this, e);
        if (a) {
            const e = this[a];
            if (!t)
                return e;
            if (!0 === t)
                return function (e) {
                    const t = Object.create(null),
                    a = /([^\s,;=]+)\s*(?:=\s*([^,;]+))?/g;
                    let n;
                    for (; n = a.exec(e); )
                        t[n[1]] = n[2];
                    return t
                }
            (e);
            if (Ee.isFunction(t))
                return t.call(this, e, a);
            if (Ee.isRegExp(t))
                return t.exec(e);
            throw new TypeError("parser must be boolean|regexp|function")
        }
    },
    has: function (e, t) {
        if (e = ca(e)) {
            const a = ua(this, e);
            return !(!a || t && !pa(0, this[a], a, t))
        }
        return !1
    },
    delete : function (e, t) {
        const a = this;
        let n = !1;
        function i(e) {
            if (e = ca(e)) {
                const i = ua(a, e);
                !i || t && !pa(0, a[i], i, t) || (delete a[i], n = !0)
            }
        }
        return Ee.isArray(e) ? e.forEach(i) : i(e),
        n
    },
    clear: function () {
        return Object.keys(this).forEach(this.delete.bind(this))
    },
    normalize: function (e) {
        const t = this,
        a = {};
        return Ee.forEach(this, ((n, i) => {
                const s = ua(a, i);
                if (s)
                    return t[s] = la(n), void delete t[i];
                const o = e ? function (e) {
                    return e.trim().toLowerCase().replace(/([a-z\d])(\w*)/g, ((e, t, a) => t.toUpperCase() + a))
                }
                (i) : String(i).trim();
                o !== i && delete t[i],
                t[o] = la(n),
                a[o] = !0
            })),
        this
    },
    toJSON: function (e) {
        const t = Object.create(null);
        return Ee.forEach(Object.assign({}, this[ra] || null, this), ((a, n) => {
                null != a && !1 !== a && (t[n] = e && Ee.isArray(a) ? a.join(", ") : a)
            })),
        t
    }
}), Object.assign(da, {
    from: function (e) {
        return Ee.isString(e) ? new this((e => {
                const t = {};
                let a,
                n,
                i;
                return e && e.split("\n").forEach((function (e) {
                        i = e.indexOf(":"),
                        a = e.substring(0, i).trim().toLowerCase(),
                        n = e.substring(i + 1).trim(),
                        !a || t[a] && sa[a] || ("set-cookie" === a ? t[a] ? t[a].push(n) : t[a] = [n] : t[a] = t[a] ? t[a] + ", " + n : n)
                    })),
                t
            })(e)) : e instanceof this ? e : new this(e)
    },
    accessor: function (e) {
        const t = (this[oa] = this[oa] = {
                accessors: {}
            }).accessors,
        a = this.prototype;
        function n(e) {
            const n = ca(e);
            t[n] || (function (e, t) {
                const a = Ee.toCamelCase(" " + t);
                ["get", "set", "has"].forEach((n => {
                        Object.defineProperty(e, n + a, {
                            value: function (e, a, i) {
                                return this[n].call(this, t, e, a, i)
                            },
                            configurable: !0
                        })
                    }))
            }
                (a, e), t[n] = !0)
        }
        return Ee.isArray(e) ? e.forEach(n) : n(e),
        this
    }
}), da.accessor(["Content-Type", "Content-Length", "Accept", "Accept-Encoding", "User-Agent"]), Ee.freezeMethods(da.prototype), Ee.freezeMethods(da);
const ma = Symbol("internals");
class fa extends M.default.Transform {
    constructor(e) {
        e = Ee.toFlatObject(e, {
            maxRate: 0,
            chunkSize: 65536,
            minChunkSize: 100,
            timeWindow: 500,
            ticksRate: 2,
            samplesCount: 15
        }, null, ((e, t) => !Ee.isUndefined(t[e]))),
        super({
            readableHighWaterMark: e.chunkSize
        });
        const t = this,
        a = this[ma] = {
            length: e.length,
            timeWindow: e.timeWindow,
            ticksRate: e.ticksRate,
            chunkSize: e.chunkSize,
            maxRate: e.maxRate,
            minChunkSize: e.minChunkSize,
            bytesSeen: 0,
            isCaptured: !1,
            notifiedBytesLoaded: 0,
            ts: Date.now(),
            bytes: 0,
            onReadCallback: null
        },
        n = ha(a.ticksRate * e.samplesCount, a.timeWindow);
        this.on("newListener", (e => {
                "progress" === e && (a.isCaptured || (a.isCaptured = !0))
            }));
        let i = 0;
        a.updateProgress = function (e, t) {
            let a = 0;
            const n = 1e3 / t;
            let i = null;
            return function (t, s) {
                const o = Date.now();
                if (t || o - a > n)
                    return i && (clearTimeout(i), i = null), a = o, e.apply(null, s);
                i || (i = setTimeout((() => (i = null, a = Date.now(), e.apply(null, s))), n - (o - a)))
            }
        }
        ((function () {
                const e = a.length,
                s = a.bytesSeen,
                o = s - i;
                if (!o || t.destroyed)
                    return;
                const r = n(o);
                i = s,
                process.nextTick((() => {
                        t.emit("progress", {
                            loaded: s,
                            total: e,
                            progress: e ? s / e : void 0,
                            bytes: o,
                            rate: r || void 0,
                            estimated: r && e && s <= e ? (e - s) / r : void 0
                        })
                    }))
            }), a.ticksRate);
        const s = () => {
            a.updateProgress(!0)
        };
        this.once("end", s),
        this.once("error", s)
    }
    _read(e) {
        const t = this[ma];
        return t.onReadCallback && t.onReadCallback(),
        super._read(e)
    }
    _transform(e, t, a) {
        const n = this,
        i = this[ma],
        s = i.maxRate,
        o = this.readableHighWaterMark,
        r = i.timeWindow,
        c = s / (1e3 / r),
        l = !1 !== i.minChunkSize ? Math.max(i.minChunkSize, .01 * c) : 0,
        p = (e, t) => {
            const a = Buffer.byteLength(e);
            let p,
            u = null,
            d = o,
            h = 0;
            if (s) {
                const e = Date.now();
                (!i.ts || (h = e - i.ts) >= r) && (i.ts = e, p = c - i.bytes, i.bytes = p < 0 ? -p : 0, h = 0),
                p = c - i.bytes
            }
            if (s) {
                if (p <= 0)
                    return setTimeout((() => {
                            t(null, e)
                        }), r - h);
                p < d && (d = p)
            }
            d && a > d && a - d > l && (u = e.subarray(d), e = e.subarray(0, d)),
            function (e, t) {
                const a = Buffer.byteLength(e);
                i.bytesSeen += a,
                i.bytes += a,
                i.isCaptured && i.updateProgress(),
                n.push(e) ? process.nextTick(t) : i.onReadCallback = () => {
                    i.onReadCallback = null,
                    process.nextTick(t)
                }
            }
            (e, u ? () => {
                process.nextTick(t, null, u)
            }
                 : t)
        };
        p(e, (function e(t, n) {
                if (t)
                    return a(t);
                n ? p(n, e) : a(null)
            }))
    }
    setLength(e) {
        return this[ma].length = +e,
        this
    }
}
const _a = Ee.isFunction(z.default.createBrotliDecompress), {
    http: Ea,
    https: ga
} = Ot.exports, ba = /https:?/, xa = At.protocols.map((e => e + ":"));
function Ta(e) {
    e.beforeRedirects.proxy && e.beforeRedirects.proxy(e),
    e.beforeRedirects.config && e.beforeRedirects.config(e)
}
function va(e, t, a) {
    let n = t;
    if (!n && !1 !== n) {
        const e = function (e) {
            var t = "string" == typeof e ? Nt(e) : e || {},
            a = t.protocol,
            n = t.host,
            i = t.port;
            if ("string" != typeof n || !n || "string" != typeof a)
                return "";
            if (a = a.split(":", 1)[0], !function (e, t) {
                var a = (kt("npm_config_no_proxy") || kt("no_proxy")).toLowerCase();
                return !a || "*" !== a && a.split(/[,\s]/).every((function (a) {
                        if (!a)
                            return !0;
                        var n = a.match(/^(.+):(\d+)$/),
                        i = n ? n[1] : a,
                        s = n ? parseInt(n[2]) : 0;
                        return !(!s || s === t) || (/^[.*]/.test(i) ? ("*" === i.charAt(0) && (i = i.slice(1)), !It.call(e, i)) : e !== i)
                    }))
            }
                (n = n.replace(/:\d*$/, ""), i = parseInt(i) || Ct[a] || 0))
                return "";
            var s = kt("npm_config_" + a + "_proxy") || kt(a + "_proxy") || kt("npm_config_proxy") || kt("all_proxy");
            return s && -1 === s.indexOf("://") && (s = a + "://" + s),
            s
        }
        (a);
        e && (n = new URL(e))
    }
    if (n) {
        if (n.username && (n.auth = (n.username || "") + ":" + (n.password || "")), n.auth) {
            (n.auth.username || n.auth.password) && (n.auth = (n.auth.username || "") + ":" + (n.auth.password || ""));
            const t = Buffer.from(n.auth, "utf8").toString("base64");
            e.headers["Proxy-Authorization"] = "Basic " + t
        }
        e.headers.host = e.hostname + (e.port ? ":" + e.port : "");
        const t = n.hostname || n.host;
        e.hostname = t,
        e.host = t,
        e.port = n.port,
        e.path = a,
        n.protocol && (e.protocol = n.protocol.includes(":") ? n.protocol : `${n.protocol}:`)
    }
    e.beforeRedirects.proxy = function (e) {
        va(e, t, e.href)
    }
}
var Aa = At.isStandardBrowserEnv ? {
    write: function (e, t, a, n, i, s) {
        const o = [];
        o.push(e + "=" + encodeURIComponent(t)),
        Ee.isNumber(a) && o.push("expires=" + new Date(a).toGMTString()),
        Ee.isString(n) && o.push("path=" + n),
        Ee.isString(i) && o.push("domain=" + i),
        !0 === s && o.push("secure"),
        document.cookie = o.join("; ")
    },
    read: function (e) {
        const t = document.cookie.match(new RegExp("(^|;\\s*)(" + e + ")=([^;]*)"));
        return t ? decodeURIComponent(t[3]) : null
    },
    remove: function (e) {
        this.write(e, "", Date.now() - 864e5)
    }
}
 : {
    write: function () {},
    read: function () {
        return null
    },
    remove: function () {}
}, ya = At.isStandardBrowserEnv ? function () {
    const e = /(msie|trident)/i.test(navigator.userAgent),
    t = document.createElement("a");
    let a;
    function n(a) {
        let n = a;
        return e && (t.setAttribute("href", n), n = t.href),
        t.setAttribute("href", n), {
            href: t.href,
            protocol: t.protocol ? t.protocol.replace(/:$/, "") : "",
            host: t.host,
            search: t.search ? t.search.replace(/^\?/, "") : "",
            hash: t.hash ? t.hash.replace(/^#/, "") : "",
            hostname: t.hostname,
            port: t.port,
            pathname: "/" === t.pathname.charAt(0) ? t.pathname : "/" + t.pathname
        }
    }
    return a = n(window.location.href),
    function (e) {
        const t = Ee.isString(e) ? n(e) : e;
        return t.protocol === a.protocol && t.host === a.host
    }
}
() : function () {
    return !0
};
function wa(e, t) {
    let a = 0;
    const n = ha(50, 250);
    return i => {
        const s = i.loaded,
        o = i.lengthComputable ? i.total : void 0,
        r = s - a,
        c = n(r);
        a = s;
        const l = {
            loaded: s,
            total: o,
            progress: o ? s / o : void 0,
            bytes: r,
            rate: c || void 0,
            estimated: c && o && s <= o ? (o - s) / c : void 0
        };
        l[t ? "download" : "upload"] = !0,
        e(l)
    }
}
const Sa = {
    http: function (e) {
        return new Promise((function (t, a) {
                let n = e.data;
                const i = e.responseType,
                s = e.responseEncoding,
                o = e.method.toUpperCase();
                let r,
                c,
                l,
                p = !1;
                const u = new G.default;
                function d() {
                    r || (r = !0, e.cancelToken && e.cancelToken.unsubscribe(_), e.signal && e.signal.removeEventListener("abort", _), u.removeAllListeners())
                }
                function h(e, n) {
                    c || (c = !0, n && (p = !0, d()), n ? a(e) : t(e))
                }
                const m = function (e) {
                    h(e)
                },
                f = function (e) {
                    h(e, !0)
                };
                function _(t) {
                    u.emit("abort", !t || t.type ? new aa(null, e, l) : t)
                }
                u.once("abort", f),
                (e.cancelToken || e.signal) && (e.cancelToken && e.cancelToken.subscribe(_), e.signal && (e.signal.aborted ? _() : e.signal.addEventListener("abort", _)));
                const E = St(e.baseURL, e.url),
                g = new URL(E),
                b = g.protocol || xa[0];
                if ("data:" === b) {
                    let a;
                    if ("GET" !== o)
                        return wt(m, f, {
                            status: 405,
                            statusText: "method not allowed",
                            headers: {},
                            config: e
                        });
                    try {
                        a = function (e, t, a) {
                            const n = a && a.Blob || At.classes.Blob,
                            i = na(e);
                            if (void 0 === t && n && (t = !0), "data" === i) {
                                e = i.length ? e.slice(i.length + 1) : e;
                                const a = ia.exec(e);
                                if (!a)
                                    throw new ge("Invalid URL", ge.ERR_INVALID_URL);
                                const s = a[1],
                                o = a[2],
                                r = a[3],
                                c = Buffer.from(decodeURIComponent(r), o ? "base64" : "utf8");
                                if (t) {
                                    if (!n)
                                        throw new ge("Blob is not supported", ge.ERR_NOT_SUPPORT);
                                    return new n([c], {
                                        type: s
                                    })
                                }
                                return c
                            }
                            throw new ge("Unsupported protocol " + i, ge.ERR_NOT_SUPPORT)
                        }
                        (e.url, "blob" === i, {
                            Blob: e.env && e.env.Blob
                        })
                    } catch (t) {
                        throw ge.from(t, ge.ERR_BAD_REQUEST, e)
                    }
                    return "text" === i ? (a = a.toString(s), s && "utf8" !== s || (n = Ee.stripBOM(a))) : "stream" === i && (a = M.default.Readable.from(a)),
                    wt(m, f, {
                        data: a,
                        status: 200,
                        statusText: "OK",
                        headers: {},
                        config: e
                    })
                }
                if (-1 === xa.indexOf(b))
                    return f(new ge("Unsupported protocol " + b, ge.ERR_BAD_REQUEST, e));
                const x = da.from(e.headers).normalize();
                x.set("User-Agent", "axios/1.1.3", !1);
                const T = e.onDownloadProgress,
                v = e.onUploadProgress,
                A = e.maxRate;
                let y,
                w;
                if (Ee.isFormData(n) && Ee.isFunction(n.getHeaders))
                    x.set(n.getHeaders());
                else if (n && !Ee.isStream(n)) {
                    if (Buffer.isBuffer(n));
                    else if (Ee.isArrayBuffer(n))
                        n = Buffer.from(new Uint8Array(n));
                    else {
                        if (!Ee.isString(n))
                            return f(new ge("Data after transformation must be a string, an ArrayBuffer, a Buffer, or a Stream", ge.ERR_BAD_REQUEST, e));
                        n = Buffer.from(n, "utf-8")
                    }
                    if (x.set("Content-Length", n.length, !1), e.maxBodyLength > -1 && n.length > e.maxBodyLength)
                        return f(new ge("Request body larger than maxBodyLength limit", ge.ERR_BAD_REQUEST, e))
                }
                const S = +x.getContentLength();
                let N,
                C;
                Ee.isArray(A) ? (y = A[0], w = A[1]) : y = w = A,
                n && (v || y) && (Ee.isStream(n) || (n = M.default.Readable.from(n, {
                            objectMode: !1
                        })), n = M.default.pipeline([n, new fa({
                                    length: Ee.toFiniteNumber(S),
                                    maxRate: Ee.toFiniteNumber(y)
                                })], Ee.noop), v && n.on("progress", (e => {
                            v(Object.assign(e, {
                                    upload: !0
                                }))
                        }))),
                e.auth && (N = (e.auth.username || "") + ":" + (e.auth.password || "")),
                !N && g.username && (N = g.username + ":" + g.password),
                N && x.delete("authorization");
                try {
                    C = xt(g.pathname + g.search, e.params, e.paramsSerializer).replace(/^\?/, "")
                } catch (t) {
                    const a = new Error(t.message);
                    return a.config = e,
                    a.url = e.url,
                    a.exists = !0,
                    f(a)
                }
                x.set("Accept-Encoding", "gzip, deflate, br", !1);
                const I = {
                    path: C,
                    method: o,
                    headers: x.toJSON(),
                    agents: {
                        http: e.httpAgent,
                        https: e.httpsAgent
                    },
                    auth: N,
                    protocol: b,
                    beforeRedirect: Ta,
                    beforeRedirects: {}
                };
                let k;
                e.socketPath ? I.socketPath = e.socketPath : (I.hostname = g.hostname, I.port = g.port, va(I, e.proxy, b + "//" + g.hostname + (g.port ? ":" + g.port : "") + I.path));
                const R = ba.test(I.protocol);
                if (I.agent = R ? e.httpsAgent : e.httpAgent, e.transport ? k = e.transport : 0 === e.maxRedirects ? k = R ? U.default : B.default : (e.maxRedirects && (I.maxRedirects = e.maxRedirects), e.beforeRedirect && (I.beforeRedirects.config = e.beforeRedirect), k = R ? ga : Ea), e.maxBodyLength > -1 ? I.maxBodyLength = e.maxBodyLength : I.maxBodyLength = 1 / 0, e.insecureHTTPParser && (I.insecureHTTPParser = e.insecureHTTPParser), l = k.request(I, (function (t) {
                                if (l.destroyed)
                                    return;
                                const a = [t];
                                let o = t;
                                const r = t.req || l;
                                if (!1 !== e.decompress)
                                    switch (n && 0 === n.length && t.headers["content-encoding"] && delete t.headers["content-encoding"], t.headers["content-encoding"]) {
                                    case "gzip":
                                    case "compress":
                                    case "deflate":
                                        a.push(z.default.createUnzip()),
                                        delete t.headers["content-encoding"];
                                        break;
                                    case "br":
                                        _a && (a.push(z.default.createBrotliDecompress()), delete t.headers["content-encoding"])
                                    }
                                if (T) {
                                    const e = +t.headers["content-length"],
                                    n = new fa({
                                        length: Ee.toFiniteNumber(e),
                                        maxRate: Ee.toFiniteNumber(w)
                                    });
                                    T && n.on("progress", (e => {
                                            T(Object.assign(e, {
                                                    download: !0
                                                }))
                                        })),
                                    a.push(n)
                                }
                                o = a.length > 1 ? M.default.pipeline(a, Ee.noop) : a[0];
                                const c = M.default.finished(o, (() => {
                                            c(),
                                            d()
                                        })),
                                h = {
                                    status: t.statusCode,
                                    statusText: t.statusMessage,
                                    headers: new da(t.headers),
                                    config: e,
                                    request: r
                                };
                                if ("stream" === i)
                                    h.data = o, wt(m, f, h);
                                    else {
                                        const t = [];
                                        let a = 0;
                                        o.on("data", (function (n) {
                                                t.push(n),
                                                a += n.length,
                                                e.maxContentLength > -1 && a > e.maxContentLength && (p = !0, o.destroy(), f(new ge("maxContentLength size of " + e.maxContentLength + " exceeded", ge.ERR_BAD_RESPONSE, e, r)))
                                            })),
                                        o.on("aborted", (function () {
                                                if (p)
                                                    return;
                                                const t = new ge("maxContentLength size of " + e.maxContentLength + " exceeded", ge.ERR_BAD_RESPONSE, e, r);
                                                o.destroy(t),
                                                f(t)
                                            })),
                                        o.on("error", (function (t) {
                                                l.destroyed || f(ge.from(t, null, e, r))
                                            })),
                                        o.on("end", (function () {
                                                try {
                                                    let e = 1 === t.length ? t[0] : Buffer.concat(t);
                                                    "arraybuffer" !== i && (e = e.toString(s), s && "utf8" !== s || (e = Ee.stripBOM(e))),
                                                    h.data = e
                                                } catch (t) {
                                                    f(ge.from(t, null, e, h.request, h))
                                                }
                                                wt(m, f, h)
                                            }))
                                    }
                                    u.once("abort", (e => {
                                            o.destroyed || (o.emit("error", e), o.destroy())
                                        }))
                                })), u.once("abort", (e => {
                                f(e),
                                l.destroy(e)
                            })), l.on("error", (function (t) {
                                f(ge.from(t, null, e, l))
                            })), l.on("socket", (function (e) {
                                e.setKeepAlive(!0, 6e4)
                            })), e.timeout) {
                        const t = parseInt(e.timeout, 10);
                        if (isNaN(t))
                            return void f(new ge("error trying to parse `config.timeout` to int", ge.ERR_BAD_OPTION_VALUE, e, l));
                        l.setTimeout(t, (function () {
                                if (c)
                                    return;
                                let t = e.timeout ? "timeout of " + e.timeout + "ms exceeded" : "timeout exceeded";
                                const a = e.transitional || vt;
                                e.timeoutErrorMessage && (t = e.timeoutErrorMessage),
                                f(new ge(t, a.clarifyTimeoutError ? ge.ETIMEDOUT : ge.ECONNABORTED, e, l)),
                                _()
                            }))
                    }
                if (Ee.isStream(n)) {
                    let t = !1,
                    a = !1;
                    n.on("end", (() => {
                            t = !0
                        })),
                    n.once("error", (e => {
                            a = !0,
                            l.destroy(e)
                        })),
                    n.on("close", (() => {
                            t || a || _(new aa("Request stream has been aborted", e, l))
                        })),
                    n.pipe(l)
                } else
                    l.end(n)
            }))
    },
    xhr: function (e) {
        return new Promise((function (t, a) {
                let n = e.data;
                const i = da.from(e.headers).normalize(),
                s = e.responseType;
                let o;
                function r() {
                    e.cancelToken && e.cancelToken.unsubscribe(o),
                    e.signal && e.signal.removeEventListener("abort", o)
                }
                Ee.isFormData(n) && At.isStandardBrowserEnv && i.setContentType(!1);
                let c = new XMLHttpRequest;
                if (e.auth) {
                    const t = e.auth.username || "",
                    a = e.auth.password ? unescape(encodeURIComponent(e.auth.password)) : "";
                    i.set("Authorization", "Basic " + btoa(t + ":" + a))
                }
                const l = St(e.baseURL, e.url);
                function p() {
                    if (!c)
                        return;
                    const n = da.from("getAllResponseHeaders" in c && c.getAllResponseHeaders());
                    wt((function (e) {
                            t(e),
                            r()
                        }), (function (e) {
                            a(e),
                            r()
                        }), {
                        data: s && "text" !== s && "json" !== s ? c.response : c.responseText,
                        status: c.status,
                        statusText: c.statusText,
                        headers: n,
                        config: e,
                        request: c
                    }),
                    c = null
                }
                if (c.open(e.method.toUpperCase(), xt(l, e.params, e.paramsSerializer), !0), c.timeout = e.timeout, "onloadend" in c ? c.onloadend = p : c.onreadystatechange = function () {
                    c && 4 === c.readyState && (0 !== c.status || c.responseURL && 0 === c.responseURL.indexOf("file:")) && setTimeout(p)
                }, c.onabort = function () {
                    c && (a(new ge("Request aborted", ge.ECONNABORTED, e, c)), c = null)
                }, c.onerror = function () {
                    a(new ge("Network Error", ge.ERR_NETWORK, e, c)),
                    c = null
                }, c.ontimeout = function () {
                    let t = e.timeout ? "timeout of " + e.timeout + "ms exceeded" : "timeout exceeded";
                    const n = e.transitional || vt;
                    e.timeoutErrorMessage && (t = e.timeoutErrorMessage),
                    a(new ge(t, n.clarifyTimeoutError ? ge.ETIMEDOUT : ge.ECONNABORTED, e, c)),
                    c = null
                }, At.isStandardBrowserEnv) {
                    const t = (e.withCredentials || ya(l)) && e.xsrfCookieName && Aa.read(e.xsrfCookieName);
                    t && i.set(e.xsrfHeaderName, t)
                }
                void 0 === n && i.setContentType(null),
                "setRequestHeader" in c && Ee.forEach(i.toJSON(), (function (e, t) {
                        c.setRequestHeader(t, e)
                    })),
                Ee.isUndefined(e.withCredentials) || (c.withCredentials = !!e.withCredentials),
                s && "json" !== s && (c.responseType = e.responseType),
                "function" == typeof e.onDownloadProgress && c.addEventListener("progress", wa(e.onDownloadProgress, !0)),
                "function" == typeof e.onUploadProgress && c.upload && c.upload.addEventListener("progress", wa(e.onUploadProgress)),
                (e.cancelToken || e.signal) && (o = t => {
                        c && (a(!t || t.type ? new aa(null, e, c) : t), c.abort(), c = null)
                    }, e.cancelToken && e.cancelToken.subscribe(o), e.signal && (e.signal.aborted ? o() : e.signal.addEventListener("abort", o)));
                const u = na(l);
                u && -1 === At.protocols.indexOf(u) ? a(new ge("Unsupported protocol " + u + ":", ge.ERR_BAD_REQUEST, e)) : c.send(n || null)
            }))
    }
};
var Na = e => {
    if (Ee.isString(e)) {
        const t = Sa[e];
        if (!e)
            throw Error(Ee.hasOwnProp(e) ? `Adapter '${e}' is not available in the build` : `Can not resolve adapter '${e}'`);
        return t
    }
    if (!Ee.isFunction(e))
        throw new TypeError("adapter is not a function");
    return e
};
const Ca = {
    "Content-Type": "application/x-www-form-urlencoded"
}, Ia = {
    transitional: vt,
    adapter: function () {
        let e;
        return "undefined" != typeof XMLHttpRequest ? e = Na("xhr") : "undefined" != typeof process && "process" === Ee.kindOf(process) && (e = Na("http")),
        e
    }
    (),
    transformRequest: [function (e, t) {
            const a = t.getContentType() || "",
            n = a.indexOf("application/json") > -1,
            i = Ee.isObject(e);
            if (i && Ee.isHTMLForm(e) && (e = new FormData(e)), Ee.isFormData(e))
                return n && n ? JSON.stringify(yt(e)) : e;
            if (Ee.isArrayBuffer(e) || Ee.isBuffer(e) || Ee.isStream(e) || Ee.isFile(e) || Ee.isBlob(e))
                return e;
            if (Ee.isArrayBufferView(e))
                return e.buffer;
            if (Ee.isURLSearchParams(e))
                return t.setContentType("application/x-www-form-urlencoded;charset=utf-8", !1), e.toString();
            let s;
            if (i) {
                if (a.indexOf("application/x-www-form-urlencoded") > -1)
                    return function (e, t) {
                        return ft(e, new At.classes.URLSearchParams, Object.assign({
                                visitor: function (e, t, a, n) {
                                    return Ee.isBuffer(e) ? (this.append(t, e.toString("base64")), !1) : n.defaultVisitor.apply(this, arguments)
                                }
                            }, t))
                    }
                (e, this.formSerializer).toString();
                if ((s = Ee.isFileList(e)) || a.indexOf("multipart/form-data") > -1) {
                    const t = this.env && this.env.FormData;
                    return ft(s ? {
                        "files[]": e
                    }
                         : e, t && new t, this.formSerializer)
                }
            }
            return i || n ? (t.setContentType("application/json", !1), function (e, t, a) {
                if (Ee.isString(e))
                    try {
                        return (0, JSON.parse)(e),
                        Ee.trim(e)
                    } catch (e) {
                        if ("SyntaxError" !== e.name)
                            throw e
                    }
                return (0, JSON.stringify)(e)
            }
                (e)) : e
        }
    ],
    transformResponse: [function (e) {
            const t = this.transitional || Ia.transitional,
            a = t && t.forcedJSONParsing,
            n = "json" === this.responseType;
            if (e && Ee.isString(e) && (a && !this.responseType || n)) {
                const a = !(t && t.silentJSONParsing) && n;
                try {
                    return JSON.parse(e)
                } catch (e) {
                    if (a) {
                        if ("SyntaxError" === e.name)
                            throw ge.from(e, ge.ERR_BAD_RESPONSE, this, null, this.response);
                        throw e
                    }
                }
            }
            return e
        }
    ],
    timeout: 0,
    xsrfCookieName: "XSRF-TOKEN",
    xsrfHeaderName: "X-XSRF-TOKEN",
    maxContentLength: -1,
    maxBodyLength: -1,
    env: {
        FormData: At.classes.FormData,
        Blob: At.classes.Blob
    },
    validateStatus: function (e) {
        return e >= 200 && e < 300
    },
    headers: {
        common: {
            Accept: "application/json, text/plain, */*"
        }
    }
};
function ka(e, t) {
    const a = this || Ia,
    n = t || a,
    i = da.from(n.headers);
    let s = n.data;
    return Ee.forEach(e, (function (e) {
            s = e.call(a, s, i.normalize(), t ? t.status : void 0)
        })),
    i.normalize(),
    s
}
function Ra(e) {
    return !(!e || !e.__CANCEL__)
}
function Oa(e) {
    if (e.cancelToken && e.cancelToken.throwIfRequested(), e.signal && e.signal.aborted)
        throw new aa
}
function Da(e) {
    return Oa(e),
    e.headers = da.from(e.headers),
    e.data = ka.call(e, e.transformRequest),
    (e.adapter || Ia.adapter)(e).then((function (t) {
            return Oa(e),
            t.data = ka.call(e, e.transformResponse, t),
            t.headers = da.from(t.headers),
            t
        }), (function (t) {
            return Ra(t) || (Oa(e), t && t.response && (t.response.data = ka.call(e, e.transformResponse, t.response), t.response.headers = da.from(t.response.headers))),
            Promise.reject(t)
        }))
}
function La(e, t) {
    t = t || {};
    const a = {};
    function n(e, t) {
        return Ee.isPlainObject(e) && Ee.isPlainObject(t) ? Ee.merge(e, t) : Ee.isPlainObject(t) ? Ee.merge({}, t) : Ee.isArray(t) ? t.slice() : t
    }
    function i(a) {
        return Ee.isUndefined(t[a]) ? Ee.isUndefined(e[a]) ? void 0 : n(void 0, e[a]) : n(e[a], t[a])
    }
    function s(e) {
        if (!Ee.isUndefined(t[e]))
            return n(void 0, t[e])
    }
    function o(a) {
        return Ee.isUndefined(t[a]) ? Ee.isUndefined(e[a]) ? void 0 : n(void 0, e[a]) : n(void 0, t[a])
    }
    function r(a) {
        return a in t ? n(e[a], t[a]) : a in e ? n(void 0, e[a]) : void 0
    }
    const c = {
        url: s,
        method: s,
        data: s,
        baseURL: o,
        transformRequest: o,
        transformResponse: o,
        paramsSerializer: o,
        timeout: o,
        timeoutMessage: o,
        withCredentials: o,
        adapter: o,
        responseType: o,
        xsrfCookieName: o,
        xsrfHeaderName: o,
        onUploadProgress: o,
        onDownloadProgress: o,
        decompress: o,
        maxContentLength: o,
        maxBodyLength: o,
        beforeRedirect: o,
        transport: o,
        httpAgent: o,
        httpsAgent: o,
        cancelToken: o,
        socketPath: o,
        responseEncoding: o,
        validateStatus: r
    };
    return Ee.forEach(Object.keys(e).concat(Object.keys(t)), (function (e) {
            const t = c[e] || i,
            n = t(e);
            Ee.isUndefined(n) && t !== r || (a[e] = n)
        })),
    a
}
Ee.forEach(["delete", "get", "head"], (function (e) {
        Ia.headers[e] = {}
    })), Ee.forEach(["post", "put", "patch"], (function (e) {
        Ia.headers[e] = Ee.merge(Ca)
    }));
const Ma = {};
["object", "boolean", "number", "function", "string", "symbol"].forEach(((e, t) => {
        Ma[e] = function (a) {
            return typeof a === e || "a" + (t < 1 ? "n " : " ") + e
        }
    }));
const Pa = {};
Ma.transitional = function (e, t, a) {
    function n(e, t) {
        return "[Axios v1.1.3] Transitional option '" + e + "'" + t + (a ? ". " + a : "")
    }
    return (a, i, s) => {
        if (!1 === e)
            throw new ge(n(i, " has been removed" + (t ? " in " + t : "")), ge.ERR_DEPRECATED);
        return t && !Pa[i] && (Pa[i] = !0, console.warn(n(i, " has been deprecated since v" + t + " and will be removed in the near future"))),
        !e || e(a, i, s)
    }
};
var Ba = {
    assertOptions: function (e, t, a) {
        if ("object" != typeof e)
            throw new ge("options must be an object", ge.ERR_BAD_OPTION_VALUE);
        const n = Object.keys(e);
        let i = n.length;
        for (; i-- > 0; ) {
            const s = n[i],
            o = t[s];
            if (o) {
                const t = e[s],
                a = void 0 === t || o(t, s, e);
                if (!0 !== a)
                    throw new ge("option " + s + " must be " + a, ge.ERR_BAD_OPTION_VALUE)
            } else if (!0 !== a)
                throw new ge("Unknown option " + s, ge.ERR_BAD_OPTION)
        }
    },
    validators: Ma
};
const Ua = Ba.validators;
class Fa {
    constructor(e) {
        this.defaults = e,
        this.interceptors = {
            request: new Tt,
            response: new Tt
        }
    }
    request(e, t) {
        "string" == typeof e ? (t = t || {}).url = e : t = e || {},
        t = La(this.defaults, t);
        const {
            transitional: a,
            paramsSerializer: n
        } = t;
        void 0 !== a && Ba.assertOptions(a, {
            silentJSONParsing: Ua.transitional(Ua.boolean),
            forcedJSONParsing: Ua.transitional(Ua.boolean),
            clarifyTimeoutError: Ua.transitional(Ua.boolean)
        }, !1),
        void 0 !== n && Ba.assertOptions(n, {
            encode: Ua.function,
            serialize: Ua.function
        }, !0),
        t.method = (t.method || this.defaults.method || "get").toLowerCase();
        const i = t.headers && Ee.merge(t.headers.common, t.headers[t.method]);
        i && Ee.forEach(["delete", "get", "head", "post", "put", "patch", "common"], (function (e) {
                delete t.headers[e]
            })),
        t.headers = new da(t.headers, i);
        const s = [];
        let o = !0;
        this.interceptors.request.forEach((function (e) {
                "function" == typeof e.runWhen && !1 === e.runWhen(t) || (o = o && e.synchronous, s.unshift(e.fulfilled, e.rejected))
            }));
        const r = [];
        let c;
        this.interceptors.response.forEach((function (e) {
                r.push(e.fulfilled, e.rejected)
            }));
        let l,
        p = 0;
        if (!o) {
            const e = [Da.bind(this), void 0];
            for (e.unshift.apply(e, s), e.push.apply(e, r), l = e.length, c = Promise.resolve(t); p < l; )
                c = c.then(e[p++], e[p++]);
            return c
        }
        l = s.length;
        let u = t;
        for (p = 0; p < l; ) {
            const t = s[p++],
            a = s[p++];
            try {
                u = t(u)
            } catch (e) {
                a.call(this, e);
                break
            }
        }
        try {
            c = Da.call(this, u)
        } catch (e) {
            return Promise.reject(e)
        }
        for (p = 0, l = r.length; p < l; )
            c = c.then(r[p++], r[p++]);
        return c
    }
    getUri(e) {
        return xt(St((e = La(this.defaults, e)).baseURL, e.url), e.params, e.paramsSerializer)
    }
}
Ee.forEach(["delete", "get", "head", "options"], (function (e) {
        Fa.prototype[e] = function (t, a) {
            return this.request(La(a || {}, {
                    method: e,
                    url: t,
                    data: (a || {}).data
                }))
        }
    })), Ee.forEach(["post", "put", "patch"], (function (e) {
        function t(t) {
            return function (a, n, i) {
                return this.request(La(i || {}, {
                        method: e,
                        headers: t ? {
                            "Content-Type": "multipart/form-data"
                        }
                         : {},
                        url: a,
                        data: n
                    }))
            }
        }
        Fa.prototype[e] = t(),
        Fa.prototype[e + "Form"] = t(!0)
    }));
class Ha {
    constructor(e) {
        if ("function" != typeof e)
            throw new TypeError("executor must be a function.");
        let t;
        this.promise = new Promise((function (e) {
                    t = e
                }));
        const a = this;
        this.promise.then((e => {
                if (!a._listeners)
                    return;
                let t = a._listeners.length;
                for (; t-- > 0; )
                    a._listeners[t](e);
                a._listeners = null
            })),
        this.promise.then = e => {
            let t;
            const n = new Promise((e => {
                        a.subscribe(e),
                        t = e
                    })).then(e);
            return n.cancel = function () {
                a.unsubscribe(t)
            },
            n
        },
        e((function (e, n, i) {
                a.reason || (a.reason = new aa(e, n, i), t(a.reason))
            }))
    }
    throwIfRequested() {
        if (this.reason)
            throw this.reason
    }
    subscribe(e) {
        this.reason ? e(this.reason) : this._listeners ? this._listeners.push(e) : this._listeners = [e]
    }
    unsubscribe(e) {
        if (!this._listeners)
            return;
        const t = this._listeners.indexOf(e);
        -1 !== t && this._listeners.splice(t, 1)
    }
    static source() {
        let e;
        return {
            token: new Ha((function (t) {
                    e = t
                })),
            cancel: e
        }
    }
}
const ja = function e(t) {
    const a = new Fa(t),
    n = q(Fa.prototype.request, a);
    return Ee.extend(n, Fa.prototype, a, {
        allOwnKeys: !0
    }),
    Ee.extend(n, a, null, {
        allOwnKeys: !0
    }),
    n.create = function (a) {
        return e(La(t, a))
    },
    n
}
(Ia);
ja.Axios = Fa, ja.CanceledError = aa, ja.CancelToken = Ha, ja.isCancel = Ra, ja.VERSION = "1.1.3", ja.toFormData = ft, ja.AxiosError = ge, ja.Cancel = ja.CanceledError, ja.all = function (e) {
    return Promise.all(e)
}, ja.spread = function (e) {
    return function (t) {
        return e.apply(null, t)
    }
}, ja.isAxiosError = function (e) {
    return Ee.isObject(e) && !0 === e.isAxiosError
}, ja.formToJSON = e => yt(Ee.isHTMLForm(e) ? new FormData(e) : e);
const za = e => {
    let t = [];
    return I.readdirSync(e).forEach((a => {
            let n = P.default.join(e, a);
            I.statSync(n).isDirectory() ? t = t.concat(za(n)) : t.push(n)
        })),
    t
}, Ga = e => {
    let t = [];
    I.existsSync(e) ? (t = I.readdirSync(e), t.forEach((function (t, a) {
                const n = P.default.join(e, t);
                I.statSync(n).isDirectory() ? Ga(n) : I.unlinkSync(n)
            })), I.rmdirSync(e)) : console.warn("The given path does not exist, please provide the correct path")
}, qa = (e, t) => {
    I.existsSync(t) && Ga(t),
    I.mkdirSync(t, {
        recursive: !0
    });
    let a = I.readdirSync(e);
    for (const n of a) {
        let a = P.default.join(e, n),
        i = P.default.join(t, n),
        s = I.lstatSync(a);
        s.isFile() && I.copyFileSync(a, i),
        s.isDirectory() && qa(a, i)
    }
}, Ya = (e, t) => I.readFileSync(e).toString(t), Va = (e, t) => {
    I.writeFileSync(e, t)
}, Qa = {
    playable_orientation: 0,
    playable_languages: ["ja", "zh", "ar", "es", "en", "ko", "pt", "ru", "vi"]
}, Wa = "{{__adv_channels_adapter__}}", Ka = [".txt", ".xml", ".vsh", ".fsh", ".atlas", ".tmx", ".tsx", ".json", ".ExportJson", ".plist", ".fnt", ".js", ".zip"], Za = [".ico", ".html", ".css"], Xa = async e => {
    const {
        destPath: t,
        orientation: a,
        languages: n
    } = e,
    i = (e => {
        const {
            orientation: t,
            languages: a
        } = e || {};
        return {
            playable_orientation: t ? {
                auto: 0,
                portrait: 1,
                landscape: 2
            }
            [t] : Qa.playable_orientation,
            playable_languages: a || Qa.playable_languages
        }
    })({
        orientation: a,
        languages: n
    }),
    s = w.join(t, "/config.json");
    Va(s, JSON.stringify(i))
}, $a = e => {
    let t = e;
    return -1 !== t.indexOf("\\") && (t = t.replace(/\\/g, "/")),
    t
}, Ja = (e, t) => {
    I.readdirSync(e).forEach((a => {
            const n = P.default.join(e, a),
            i = I.statSync(n);
            if (i.isDirectory())
                Ja(n, t);
            else if (i.isFile() && ".js" === P.default.extname(a)) {
                let e = Ya(n, "utf-8");
                -1 !== e.indexOf(Wa) && (e = e.replaceAll(Wa, t), Va(n, e))
            }
        }))
}, en = e => {
    let t = Ya(e, "base64");
    return `data:${Ie.lookup(e)};base64,${t}`
}, tn = e => {
    let t = "";
    const a = w.extname(e);
    return a ? (t = Ka.includes(a) ? Ya(e, "utf-8") : en(e), t) : ""
}, an = e => {
    T.__playable_ads_adapter_global__ && T.__playable_ads_adapter_global__.isMount || (T.__playable_ads_adapter_global__ = {
            isMount: !0,
            buildFolderPath: e.buildFolderPath,
            buildConfig: e.adapterBuildConfig ?? null
        })
}, nn = () => {
    T.__playable_ads_adapter_global__ = {
        isMount: !1,
        buildFolderPath: "",
        buildConfig: null
    }
}, sn = () => $a(T.__playable_ads_adapter_global__.buildFolderPath), on = () => P.default.join(sn(), "/single-file-2x.html"), rn = () => P.default.join(sn(), "/single-file-3x.html"), cn = () => T.__playable_ads_adapter_global__.buildConfig, ln = () => {
    const e = (cn() || {}).buildPlatform || "web-mobile";
    return P.default.join(sn(), e)
}, pn = () => {
    const e = cn();
    return e ? {
        tinify: !!e.tinify,
        tinifyApiKey: e.tinifyApiKey || ""
    }
     : {
        tinify: !1,
        tinifyApiKey: ""
    }
}, un = e => {
    const t = (e => {
        const t = cn();
        return t && t.injectOptions && t.injectOptions[e] ? t.injectOptions[e] : null
    })(e);
    return t && t.sdkScript ? t.sdkScript : ""
}, dn = (e, t) => {
    const {
        tinifyApiKey: a
    } = pn();
    return new Promise(((n, i) => {
            console.log("【Preparing to upload image to TinyPng】 ", e),
            ja.request({
                method: "post",
                url: "https://api.tinify.com/shrink",
                auth: {
                    username: `api:${a}`,
                    password: ""
                },
                data: t
            }).then((t => {
                    console.log("【Preparing to download compressed image】 ", e),
                    ja.request({
                        method: "get",
                        url: t.data.output.url,
                        responseType: "arraybuffer"
                    }).then((t => {
                            Va(e, Buffer.from(t.data)),
                            console.log("【Image compression completed】 ", e),
                            n()
                        })).catch((e => {
                            i(e)
                        }))
                })).catch((e => {
                    i(e)
                }))
        }))
}, hn = async() => {
    const {
        tinify: e,
        tinifyApiKey: t
    } = pn();
    if (!e)
        return {
            success: !1,
            msg: "Compression not enabled"
        };
    if (!t)
        return {
            success: !1,
            msg: "You need to provide your API key, get it from: https://tinify.cn/developers"
        };
    const a = ln(),
    n = za(a).filter((e => (e => {
                    let t = Ie.lookup(e);
                    return "boolean" != typeof t && /(gif|jpg|jpeg|png|webp|image)/i.test(t)
                })(e)));
    let i = [];
    for (let e = 0; e < n.length; e++) {
        const t = n[e];
        i.push(dn(t, I.readFileSync(t)))
    }
    return await Promise.all(i), {
        success: !0,
        msg: "Compression completed"
    }
}, mn = {
    xml: !1,
    decodeEntities: !0
}, fn = {
    _useHtmlParser2: !0,
    xmlMode: !0
};
function _n(e) {
    return (null == e ? void 0 : e.xml) ? "boolean" == typeof e.xml ? fn : {
        ...fn,
        ...e.xml
    }
     : null != e ? e : void 0
}
var En;
!function (e) {
    e.Root = "root",
    e.Text = "text",
    e.Directive = "directive",
    e.Comment = "comment",
    e.Script = "script",
    e.Style = "style",
    e.Tag = "tag",
    e.CDATA = "cdata",
    e.Doctype = "doctype"
}
(En || (En = {}));
const gn = En.Root, bn = En.Text, xn = En.Directive, Tn = En.Comment, vn = En.Script, An = En.Style, yn = En.Tag, wn = En.CDATA, Sn = En.Doctype;
class Nn {
    constructor() {
        this.parent = null,
        this.prev = null,
        this.next = null,
        this.startIndex = null,
        this.endIndex = null
    }
    get parentNode() {
        return this.parent
    }
    set parentNode(e) {
        this.parent = e
    }
    get previousSibling() {
        return this.prev
    }
    set previousSibling(e) {
        this.prev = e
    }
    get nextSibling() {
        return this.next
    }
    set nextSibling(e) {
        this.next = e
    }
    cloneNode(e = !1) {
        return Gn(this, e)
    }
}
class Cn extends Nn {
    constructor(e) {
        super(),
        this.data = e
    }
    get nodeValue() {
        return this.data
    }
    set nodeValue(e) {
        this.data = e
    }
}
class In extends Cn {
    constructor() {
        super(...arguments),
        this.type = En.Text
    }
    get nodeType() {
        return 3
    }
}
class kn extends Cn {
    constructor() {
        super(...arguments),
        this.type = En.Comment
    }
    get nodeType() {
        return 8
    }
}
class Rn extends Cn {
    constructor(e, t) {
        super(t),
        this.name = e,
        this.type = En.Directive
    }
    get nodeType() {
        return 1
    }
}
class On extends Nn {
    constructor(e) {
        super(),
        this.children = e
    }
    get firstChild() {
        var e;
        return null !== (e = this.children[0]) && void 0 !== e ? e : null
    }
    get lastChild() {
        return this.children.length > 0 ? this.children[this.children.length - 1] : null
    }
    get childNodes() {
        return this.children
    }
    set childNodes(e) {
        this.children = e
    }
}
class Dn extends On {
    constructor() {
        super(...arguments),
        this.type = En.CDATA
    }
    get nodeType() {
        return 4
    }
}
class Ln extends On {
    constructor() {
        super(...arguments),
        this.type = En.Root
    }
    get nodeType() {
        return 9
    }
}
class Mn extends On {
    constructor(e, t, a = [], n = ("script" === e ? En.Script : "style" === e ? En.Style : En.Tag)) {
        super(a),
        this.name = e,
        this.attribs = t,
        this.type = n
    }
    get nodeType() {
        return 1
    }
    get tagName() {
        return this.name
    }
    set tagName(e) {
        this.name = e
    }
    get attributes() {
        return Object.keys(this.attribs).map((e => {
                var t,
                a;
                return {
                    name: e,
                    value: this.attribs[e],
                    namespace: null === (t = this["x-attribsNamespace"]) || void 0 === t ? void 0 : t[e],
                    prefix: null === (a = this["x-attribsPrefix"]) || void 0 === a ? void 0 : a[e]
                }
            }))
    }
}
function Pn(e) {
    return (t = e).type === En.Tag || t.type === En.Script || t.type === En.Style;
    var t
}
function Bn(e) {
    return e.type === En.CDATA
}
function Un(e) {
    return e.type === En.Text
}
function Fn(e) {
    return e.type === En.Comment
}
function Hn(e) {
    return e.type === En.Directive
}
function jn(e) {
    return e.type === En.Root
}
function zn(e) {
    return Object.prototype.hasOwnProperty.call(e, "children")
}
function Gn(e, t = !1) {
    let a;
    if (Un(e))
        a = new In(e.data);
    else if (Fn(e))
        a = new kn(e.data);
    else if (Pn(e)) {
        const n = t ? qn(e.children) : [],
        i = new Mn(e.name, {
            ...e.attribs
        }, n);
        n.forEach((e => e.parent = i)),
        null != e.namespace && (i.namespace = e.namespace),
        e["x-attribsNamespace"] && (i["x-attribsNamespace"] = {
                ...e["x-attribsNamespace"]
            }),
        e["x-attribsPrefix"] && (i["x-attribsPrefix"] = {
                ...e["x-attribsPrefix"]
            }),
        a = i
    } else if (Bn(e)) {
        const n = t ? qn(e.children) : [],
        i = new Dn(n);
        n.forEach((e => e.parent = i)),
        a = i
    } else if (jn(e)) {
        const n = t ? qn(e.children) : [],
        i = new Ln(n);
        n.forEach((e => e.parent = i)),
        e["x-mode"] && (i["x-mode"] = e["x-mode"]),
        a = i
    } else {
        if (!Hn(e))
            throw new Error(`Not implemented yet: ${e.type}`); {
            const t = new Rn(e.name, e.data);
            null != e["x-name"] && (t["x-name"] = e["x-name"], t["x-publicId"] = e["x-publicId"], t["x-systemId"] = e["x-systemId"]),
            a = t
        }
    }
    return a.startIndex = e.startIndex,
    a.endIndex = e.endIndex,
    null != e.sourceCodeLocation && (a.sourceCodeLocation = e.sourceCodeLocation),
    a
}
function qn(e) {
    const t = e.map((e => Gn(e, !0)));
    for (let e = 1; e < t.length; e++)
        t[e].prev = t[e - 1], t[e - 1].next = t[e];
    return t
}
const Yn = {
    withStartIndices: !1,
    withEndIndices: !1,
    xmlMode: !1
};
class Vn {
    constructor(e, t, a) {
        this.dom = [],
        this.root = new Ln(this.dom),
        this.done = !1,
        this.tagStack = [this.root],
        this.lastNode = null,
        this.parser = null,
        "function" == typeof t && (a = t, t = Yn),
        "object" == typeof e && (t = e, e = void 0),
        this.callback = null != e ? e : null,
        this.options = null != t ? t : Yn,
        this.elementCB = null != a ? a : null
    }
    onparserinit(e) {
        this.parser = e
    }
    onreset() {
        this.dom = [],
        this.root = new Ln(this.dom),
        this.done = !1,
        this.tagStack = [this.root],
        this.lastNode = null,
        this.parser = null
    }
    onend() {
        this.done || (this.done = !0, this.parser = null, this.handleCallback(null))
    }
    onerror(e) {
        this.handleCallback(e)
    }
    onclosetag() {
        this.lastNode = null;
        const e = this.tagStack.pop();
        this.options.withEndIndices && (e.endIndex = this.parser.endIndex),
        this.elementCB && this.elementCB(e)
    }
    onopentag(e, t) {
        const a = this.options.xmlMode ? En.Tag : void 0,
        n = new Mn(e, t, void 0, a);
        this.addNode(n),
        this.tagStack.push(n)
    }
    ontext(e) {
        const {
            lastNode: t
        } = this;
        if (t && t.type === En.Text)
            t.data += e, this.options.withEndIndices && (t.endIndex = this.parser.endIndex);
        else {
            const t = new In(e);
            this.addNode(t),
            this.lastNode = t
        }
    }
    oncomment(e) {
        if (this.lastNode && this.lastNode.type === En.Comment)
            return void(this.lastNode.data += e);
        const t = new kn(e);
        this.addNode(t),
        this.lastNode = t
    }
    oncommentend() {
        this.lastNode = null
    }
    oncdatastart() {
        const e = new In(""),
        t = new Dn([e]);
        this.addNode(t),
        e.parent = t,
        this.lastNode = e
    }
    oncdataend() {
        this.lastNode = null
    }
    onprocessinginstruction(e, t) {
        const a = new Rn(e, t);
        this.addNode(a)
    }
    handleCallback(e) {
        if ("function" == typeof this.callback)
            this.callback(e, this.dom);
        else if (e)
            throw e
    }
    addNode(e) {
        const t = this.tagStack[this.tagStack.length - 1],
        a = t.children[t.children.length - 1];
        this.options.withStartIndices && (e.startIndex = this.parser.startIndex),
        this.options.withEndIndices && (e.endIndex = this.parser.endIndex),
        t.children.push(e),
        a && (e.prev = a, a.next = e),
        e.parent = t,
        this.lastNode = null
    }
}
var Qn, Wn = new Uint16Array('ᵁ<Õıʊҝջאٵ۞ޢߖࠏ੊ઑඡ๭༉༦჊ረዡᐕᒝᓃᓟᔥ\0\0\0\0\0\0ᕫᛍᦍᰒᷝ὾⁠↰⊍⏀⏻⑂⠤⤒ⴈ⹈⿎〖㊺㘹㞬㣾㨨㩱㫠㬮ࠀEMabcfglmnoprstu\\bfms¦³¹ÈÏlig耻Æ䃆P耻&䀦cute耻Á䃁reve;䄂Āiyx}rc耻Â䃂;䐐r;쀀𝔄rave耻À䃀pha;䎑acr;䄀d;橓Āgp¡on;䄄f;쀀𝔸plyFunction;恡ing耻Å䃅Ācs¾Ãr;쀀𝒜ign;扔ilde耻Ã䃃ml耻Ä䃄ЀaceforsuåûþėĜĢħĪĀcrêòkslash;或Ŷöø;櫧ed;挆y;䐑ƀcrtąċĔause;戵noullis;愬a;䎒r;쀀𝔅pf;쀀𝔹eve;䋘còēmpeq;扎܀HOacdefhilorsuōőŖƀƞƢƵƷƺǜȕɳɸɾcy;䐧PY耻©䂩ƀcpyŝŢźute;䄆Ā;iŧŨ拒talDifferentialD;慅leys;愭ȀaeioƉƎƔƘron;䄌dil耻Ç䃇rc;䄈nint;戰ot;䄊ĀdnƧƭilla;䂸terDot;䂷òſi;䎧rcleȀDMPTǇǋǑǖot;抙inus;抖lus;投imes;抗oĀcsǢǸkwiseContourIntegral;戲eCurlyĀDQȃȏoubleQuote;思uote;怙ȀlnpuȞȨɇɕonĀ;eȥȦ户;橴ƀgitȯȶȺruent;扡nt;戯ourIntegral;戮ĀfrɌɎ;愂oduct;成nterClockwiseContourIntegral;戳oss;樯cr;쀀𝒞pĀ;Cʄʅ拓ap;才րDJSZacefiosʠʬʰʴʸˋ˗ˡ˦̳ҍĀ;oŹʥtrahd;椑cy;䐂cy;䐅cy;䐏ƀgrsʿ˄ˇger;怡r;憡hv;櫤Āayː˕ron;䄎;䐔lĀ;t˝˞戇a;䎔r;쀀𝔇Āaf˫̧Ācm˰̢riticalȀADGT̖̜̀̆cute;䂴oŴ̋̍;䋙bleAcute;䋝rave;䁠ilde;䋜ond;拄ferentialD;慆Ѱ̽\0\0\0͔͂\0Ѕf;쀀𝔻ƀ;DE͈͉͍䂨ot;惜qual;扐blèCDLRUVͣͲ΂ϏϢϸontourIntegraìȹoɴ͹\0\0ͻ»͉nArrow;懓Āeo·ΤftƀARTΐΖΡrrow;懐ightArrow;懔eåˊngĀLRΫτeftĀARγιrrow;柸ightArrow;柺ightArrow;柹ightĀATϘϞrrow;懒ee;抨pɁϩ\0\0ϯrrow;懑ownArrow;懕erticalBar;戥ǹABLRTaВЪаўѿͼrrowƀ;BUНОТ憓ar;椓pArrow;懵reve;䌑eft˒к\0ц\0ѐightVector;楐eeVector;楞ectorĀ;Bљњ憽ar;楖ightǔѧ\0ѱeeVector;楟ectorĀ;BѺѻ懁ar;楗eeĀ;A҆҇护rrow;憧ĀctҒҗr;쀀𝒟rok;䄐ࠀNTacdfglmopqstuxҽӀӄӋӞӢӧӮӵԡԯԶՒ՝ՠեG;䅊H耻Ð䃐cute耻É䃉ƀaiyӒӗӜron;䄚rc耻Ê䃊;䐭ot;䄖r;쀀𝔈rave耻È䃈ement;戈ĀapӺӾcr;䄒tyɓԆ\0\0ԒmallSquare;旻erySmallSquare;斫ĀgpԦԪon;䄘f;쀀𝔼silon;䎕uĀaiԼՉlĀ;TՂՃ橵ilde;扂librium;懌Āci՗՚r;愰m;橳a;䎗ml耻Ë䃋Āipժկsts;戃onentialE;慇ʀcfiosօֈ֍ֲ׌y;䐤r;쀀𝔉lledɓ֗\0\0֣mallSquare;旼erySmallSquare;斪Ͱֺ\0ֿ\0\0ׄf;쀀𝔽All;戀riertrf;愱cò׋؀JTabcdfgorstר׬ׯ׺؀ؒؖ؛؝أ٬ٲcy;䐃耻>䀾mmaĀ;d׷׸䎓;䏜reve;䄞ƀeiy؇،ؐdil;䄢rc;䄜;䐓ot;䄠r;쀀𝔊;拙pf;쀀𝔾eater̀EFGLSTصلَٖٛ٦qualĀ;Lؾؿ扥ess;招ullEqual;执reater;檢ess;扷lantEqual;橾ilde;扳cr;쀀𝒢;扫ЀAacfiosuڅڋږڛڞڪھۊRDcy;䐪Āctڐڔek;䋇;䁞irc;䄤r;愌lbertSpace;愋ǰگ\0ڲf;愍izontalLine;攀Āctۃۅòکrok;䄦mpńېۘownHumðįqual;扏܀EJOacdfgmnostuۺ۾܃܇܎ܚܞܡܨ݄ݸދޏޕcy;䐕lig;䄲cy;䐁cute耻Í䃍Āiyܓܘrc耻Î䃎;䐘ot;䄰r;愑rave耻Ì䃌ƀ;apܠܯܿĀcgܴܷr;䄪inaryI;慈lieóϝǴ݉\0ݢĀ;eݍݎ戬Āgrݓݘral;戫section;拂isibleĀCTݬݲomma;恣imes;恢ƀgptݿރވon;䄮f;쀀𝕀a;䎙cr;愐ilde;䄨ǫޚ\0ޞcy;䐆l耻Ï䃏ʀcfosuެ޷޼߂ߐĀiyޱ޵rc;䄴;䐙r;쀀𝔍pf;쀀𝕁ǣ߇\0ߌr;쀀𝒥rcy;䐈kcy;䐄΀HJacfosߤߨ߽߬߱ࠂࠈcy;䐥cy;䐌ppa;䎚Āey߶߻dil;䄶;䐚r;쀀𝔎pf;쀀𝕂cr;쀀𝒦րJTaceflmostࠥࠩࠬࡐࡣ঳সে্਷ੇcy;䐉耻<䀼ʀcmnpr࠷࠼ࡁࡄࡍute;䄹bda;䎛g;柪lacetrf;愒r;憞ƀaeyࡗ࡜ࡡron;䄽dil;䄻;䐛Āfsࡨ॰tԀACDFRTUVarࡾࢩࢱࣦ࣠ࣼयज़ΐ४Ānrࢃ࢏gleBracket;柨rowƀ;BR࢙࢚࢞憐ar;懤ightArrow;懆eiling;挈oǵࢷ\0ࣃbleBracket;柦nǔࣈ\0࣒eeVector;楡ectorĀ;Bࣛࣜ懃ar;楙loor;挊ightĀAV࣯ࣵrrow;憔ector;楎Āerँगeƀ;AVउऊऐ抣rrow;憤ector;楚iangleƀ;BEतथऩ抲ar;槏qual;抴pƀDTVषूौownVector;楑eeVector;楠ectorĀ;Bॖॗ憿ar;楘ectorĀ;B॥०憼ar;楒ightáΜs̀EFGLSTॾঋকঝঢভqualGreater;拚ullEqual;扦reater;扶ess;檡lantEqual;橽ilde;扲r;쀀𝔏Ā;eঽা拘ftarrow;懚idot;䄿ƀnpw৔ਖਛgȀLRlr৞৷ਂਐeftĀAR০৬rrow;柵ightArrow;柷ightArrow;柶eftĀarγਊightáοightáϊf;쀀𝕃erĀLRਢਬeftArrow;憙ightArrow;憘ƀchtਾੀੂòࡌ;憰rok;䅁;扪Ѐacefiosuਗ਼੝੠੷੼અઋ઎p;椅y;䐜Ādl੥੯iumSpace;恟lintrf;愳r;쀀𝔐nusPlus;戓pf;쀀𝕄cò੶;䎜ҀJacefostuણધભીଔଙඑ඗ඞcy;䐊cute;䅃ƀaey઴હાron;䅇dil;䅅;䐝ƀgswે૰଎ativeƀMTV૓૟૨ediumSpace;怋hiĀcn૦૘ë૙eryThiî૙tedĀGL૸ଆreaterGreateòٳessLesóੈLine;䀊r;쀀𝔑ȀBnptଢନଷ଺reak;恠BreakingSpace;䂠f;愕ڀ;CDEGHLNPRSTV୕ୖ୪୼஡௫ఄ౞಄ದ೘ൡඅ櫬Āou୛୤ngruent;扢pCap;扭oubleVerticalBar;戦ƀlqxஃஊ஛ement;戉ualĀ;Tஒஓ扠ilde;쀀≂̸ists;戄reater΀;EFGLSTஶஷ஽௉௓௘௥扯qual;扱ullEqual;쀀≧̸reater;쀀≫̸ess;批lantEqual;쀀⩾̸ilde;扵umpń௲௽ownHump;쀀≎̸qual;쀀≏̸eĀfsఊధtTriangleƀ;BEచఛడ拪ar;쀀⧏̸qual;括s̀;EGLSTవశ఼ౄోౘ扮qual;扰reater;扸ess;쀀≪̸lantEqual;쀀⩽̸ilde;扴estedĀGL౨౹reaterGreater;쀀⪢̸essLess;쀀⪡̸recedesƀ;ESಒಓಛ技qual;쀀⪯̸lantEqual;拠ĀeiಫಹverseElement;戌ghtTriangleƀ;BEೋೌ೒拫ar;쀀⧐̸qual;拭ĀquೝഌuareSuĀbp೨೹setĀ;E೰ೳ쀀⊏̸qual;拢ersetĀ;Eഃആ쀀⊐̸qual;拣ƀbcpഓതൎsetĀ;Eഛഞ쀀⊂⃒qual;抈ceedsȀ;ESTലള഻െ抁qual;쀀⪰̸lantEqual;拡ilde;쀀≿̸ersetĀ;E൘൛쀀⊃⃒qual;抉ildeȀ;EFT൮൯൵ൿ扁qual;扄ullEqual;扇ilde;扉erticalBar;戤cr;쀀𝒩ilde耻Ñ䃑;䎝܀Eacdfgmoprstuvලෂ෉෕ෛ෠෧෼ขภยา฿ไlig;䅒cute耻Ó䃓Āiy෎ීrc耻Ô䃔;䐞blac;䅐r;쀀𝔒rave耻Ò䃒ƀaei෮ෲ෶cr;䅌ga;䎩cron;䎟pf;쀀𝕆enCurlyĀDQฎบoubleQuote;怜uote;怘;橔Āclวฬr;쀀𝒪ash耻Ø䃘iŬื฼de耻Õ䃕es;樷ml耻Ö䃖erĀBP๋๠Āar๐๓r;怾acĀek๚๜;揞et;掴arenthesis;揜Ҁacfhilors๿ງຊຏຒດຝະ໼rtialD;戂y;䐟r;쀀𝔓i;䎦;䎠usMinus;䂱Āipຢອncareplanåڝf;愙Ȁ;eio຺ູ໠໤檻cedesȀ;EST່້໏໚扺qual;檯lantEqual;扼ilde;找me;怳Ādp໩໮uct;戏ortionĀ;aȥ໹l;戝Āci༁༆r;쀀𝒫;䎨ȀUfos༑༖༛༟OT耻"䀢r;쀀𝔔pf;愚cr;쀀𝒬؀BEacefhiorsu༾གྷཇའཱིྦྷྪྭ႖ႩႴႾarr;椐G耻®䂮ƀcnrཎནབute;䅔g;柫rĀ;tཛྷཝ憠l;椖ƀaeyཧཬཱron;䅘dil;䅖;䐠Ā;vླྀཹ愜erseĀEUྂྙĀlq྇ྎement;戋uilibrium;懋pEquilibrium;楯r»ཹo;䎡ghtЀACDFTUVa࿁࿫࿳ဢဨၛႇϘĀnr࿆࿒gleBracket;柩rowƀ;BL࿜࿝࿡憒ar;懥eftArrow;懄eiling;按oǵ࿹\0စbleBracket;柧nǔည\0နeeVector;楝ectorĀ;Bဝသ懂ar;楕loor;挋Āerိ၃eƀ;AVဵံြ抢rrow;憦ector;楛iangleƀ;BEၐၑၕ抳ar;槐qual;抵pƀDTVၣၮၸownVector;楏eeVector;楜ectorĀ;Bႂႃ憾ar;楔ectorĀ;B႑႒懀ar;楓Āpuႛ႞f;愝ndImplies;楰ightarrow;懛ĀchႹႼr;愛;憱leDelayed;槴ڀHOacfhimoqstuფჱჷჽᄙᄞᅑᅖᅡᅧᆵᆻᆿĀCcჩხHcy;䐩y;䐨FTcy;䐬cute;䅚ʀ;aeiyᄈᄉᄎᄓᄗ檼ron;䅠dil;䅞rc;䅜;䐡r;쀀𝔖ortȀDLRUᄪᄴᄾᅉownArrow»ОeftArrow»࢚ightArrow»࿝pArrow;憑gma;䎣allCircle;战pf;쀀𝕊ɲᅭ\0\0ᅰt;戚areȀ;ISUᅻᅼᆉᆯ斡ntersection;抓uĀbpᆏᆞsetĀ;Eᆗᆘ抏qual;抑ersetĀ;Eᆨᆩ抐qual;抒nion;抔cr;쀀𝒮ar;拆ȀbcmpᇈᇛሉላĀ;sᇍᇎ拐etĀ;Eᇍᇕqual;抆ĀchᇠህeedsȀ;ESTᇭᇮᇴᇿ扻qual;檰lantEqual;扽ilde;承Tháྌ;我ƀ;esሒሓሣ拑rsetĀ;Eሜም抃qual;抇et»ሓրHRSacfhiorsሾቄ቉ቕ቞ቱቶኟዂወዑORN耻Þ䃞ADE;愢ĀHc቎ቒcy;䐋y;䐦Ābuቚቜ;䀉;䎤ƀaeyብቪቯron;䅤dil;䅢;䐢r;쀀𝔗Āeiቻ኉ǲኀ\0ኇefore;戴a;䎘Ācn኎ኘkSpace;쀀  Space;怉ldeȀ;EFTካኬኲኼ戼qual;扃ullEqual;扅ilde;扈pf;쀀𝕋ipleDot;惛Āctዖዛr;쀀𝒯rok;䅦ૡዷጎጚጦ\0ጬጱ\0\0\0\0\0ጸጽ፷ᎅ\0᏿ᐄᐊᐐĀcrዻጁute耻Ú䃚rĀ;oጇገ憟cir;楉rǣጓ\0጖y;䐎ve;䅬Āiyጞጣrc耻Û䃛;䐣blac;䅰r;쀀𝔘rave耻Ù䃙acr;䅪Ādiፁ፩erĀBPፈ፝Āarፍፐr;䁟acĀekፗፙ;揟et;掵arenthesis;揝onĀ;P፰፱拃lus;抎Āgp፻፿on;䅲f;쀀𝕌ЀADETadps᎕ᎮᎸᏄϨᏒᏗᏳrrowƀ;BDᅐᎠᎤar;椒ownArrow;懅ownArrow;憕quilibrium;楮eeĀ;AᏋᏌ报rrow;憥ownáϳerĀLRᏞᏨeftArrow;憖ightArrow;憗iĀ;lᏹᏺ䏒on;䎥ing;䅮cr;쀀𝒰ilde;䅨ml耻Ü䃜ҀDbcdefosvᐧᐬᐰᐳᐾᒅᒊᒐᒖash;披ar;櫫y;䐒ashĀ;lᐻᐼ抩;櫦Āerᑃᑅ;拁ƀbtyᑌᑐᑺar;怖Ā;iᑏᑕcalȀBLSTᑡᑥᑪᑴar;戣ine;䁼eparator;杘ilde;所ThinSpace;怊r;쀀𝔙pf;쀀𝕍cr;쀀𝒱dash;抪ʀcefosᒧᒬᒱᒶᒼirc;䅴dge;拀r;쀀𝔚pf;쀀𝕎cr;쀀𝒲Ȁfiosᓋᓐᓒᓘr;쀀𝔛;䎞pf;쀀𝕏cr;쀀𝒳ҀAIUacfosuᓱᓵᓹᓽᔄᔏᔔᔚᔠcy;䐯cy;䐇cy;䐮cute耻Ý䃝Āiyᔉᔍrc;䅶;䐫r;쀀𝔜pf;쀀𝕐cr;쀀𝒴ml;䅸ЀHacdefosᔵᔹᔿᕋᕏᕝᕠᕤcy;䐖cute;䅹Āayᕄᕉron;䅽;䐗ot;䅻ǲᕔ\0ᕛoWidtè૙a;䎖r;愨pf;愤cr;쀀𝒵௡ᖃᖊᖐ\0ᖰᖶᖿ\0\0\0\0ᗆᗛᗫᙟ᙭\0ᚕ᚛ᚲᚹ\0ᚾcute耻á䃡reve;䄃̀;Ediuyᖜᖝᖡᖣᖨᖭ戾;쀀∾̳;房rc耻â䃢te肻´̆;䐰lig耻æ䃦Ā;r²ᖺ;쀀𝔞rave耻à䃠ĀepᗊᗖĀfpᗏᗔsym;愵èᗓha;䎱ĀapᗟcĀclᗤᗧr;䄁g;樿ɤᗰ\0\0ᘊʀ;adsvᗺᗻᗿᘁᘇ戧nd;橕;橜lope;橘;橚΀;elmrszᘘᘙᘛᘞᘿᙏᙙ戠;榤e»ᘙsdĀ;aᘥᘦ戡ѡᘰᘲᘴᘶᘸᘺᘼᘾ;榨;榩;榪;榫;榬;榭;榮;榯tĀ;vᙅᙆ戟bĀ;dᙌᙍ抾;榝Āptᙔᙗh;戢»¹arr;捼Āgpᙣᙧon;䄅f;쀀𝕒΀;Eaeiop዁ᙻᙽᚂᚄᚇᚊ;橰cir;橯;扊d;手s;䀧roxĀ;e዁ᚒñᚃing耻å䃥ƀctyᚡᚦᚨr;쀀𝒶;䀪mpĀ;e዁ᚯñʈilde耻ã䃣ml耻ä䃤Āciᛂᛈoninôɲnt;樑ࠀNabcdefiklnoprsu᛭ᛱᜰ᜼ᝃᝈ᝸᝽០៦ᠹᡐᜍ᤽᥈ᥰot;櫭Ācrᛶ᜞kȀcepsᜀᜅᜍᜓong;扌psilon;䏶rime;怵imĀ;e᜚᜛戽q;拍Ŷᜢᜦee;抽edĀ;gᜬᜭ挅e»ᜭrkĀ;t፜᜷brk;掶Āoyᜁᝁ;䐱quo;怞ʀcmprtᝓ᝛ᝡᝤᝨausĀ;eĊĉptyv;榰séᜌnoõēƀahwᝯ᝱ᝳ;䎲;愶een;扬r;쀀𝔟g΀costuvwឍឝឳេ៕៛៞ƀaiuបពរðݠrc;旯p»፱ƀdptឤឨឭot;樀lus;樁imes;樂ɱឹ\0\0ើcup;樆ar;昅riangleĀdu៍្own;施p;斳plus;樄eåᑄåᒭarow;植ƀako៭ᠦᠵĀcn៲ᠣkƀlst៺֫᠂ozenge;槫riangleȀ;dlr᠒᠓᠘᠝斴own;斾eft;旂ight;斸k;搣Ʊᠫ\0ᠳƲᠯ\0ᠱ;斒;斑4;斓ck;斈ĀeoᠾᡍĀ;qᡃᡆ쀀=⃥uiv;쀀≡⃥t;挐Ȁptwxᡙᡞᡧᡬf;쀀𝕓Ā;tᏋᡣom»Ꮜtie;拈؀DHUVbdhmptuvᢅᢖᢪᢻᣗᣛᣬ᣿ᤅᤊᤐᤡȀLRlrᢎᢐᢒᢔ;敗;敔;敖;敓ʀ;DUduᢡᢢᢤᢦᢨ敐;敦;敩;敤;敧ȀLRlrᢳᢵᢷᢹ;敝;敚;敜;教΀;HLRhlrᣊᣋᣍᣏᣑᣓᣕ救;敬;散;敠;敫;敢;敟ox;槉ȀLRlrᣤᣦᣨᣪ;敕;敒;攐;攌ʀ;DUduڽ᣷᣹᣻᣽;敥;敨;攬;攴inus;抟lus;択imes;抠ȀLRlrᤙᤛᤝ᤟;敛;敘;攘;攔΀;HLRhlrᤰᤱᤳᤵᤷ᤻᤹攂;敪;敡;敞;攼;攤;攜Āevģ᥂bar耻¦䂦Ȁceioᥑᥖᥚᥠr;쀀𝒷mi;恏mĀ;e᜚᜜lƀ;bhᥨᥩᥫ䁜;槅sub;柈Ŭᥴ᥾lĀ;e᥹᥺怢t»᥺pƀ;Eeįᦅᦇ;檮Ā;qۜۛೡᦧ\0᧨ᨑᨕᨲ\0ᨷᩐ\0\0᪴\0\0᫁\0\0ᬡᬮ᭍᭒\0᯽\0ᰌƀcpr᦭ᦲ᧝ute;䄇̀;abcdsᦿᧀᧄ᧊᧕᧙戩nd;橄rcup;橉Āau᧏᧒p;橋p;橇ot;橀;쀀∩︀Āeo᧢᧥t;恁îړȀaeiu᧰᧻ᨁᨅǰ᧵\0᧸s;橍on;䄍dil耻ç䃧rc;䄉psĀ;sᨌᨍ橌m;橐ot;䄋ƀdmnᨛᨠᨦil肻¸ƭptyv;榲t脀¢;eᨭᨮ䂢räƲr;쀀𝔠ƀceiᨽᩀᩍy;䑇ckĀ;mᩇᩈ朓ark»ᩈ;䏇r΀;Ecefms᩟᩠ᩢᩫ᪤᪪᪮旋;槃ƀ;elᩩᩪᩭ䋆q;扗eɡᩴ\0\0᪈rrowĀlr᩼᪁eft;憺ight;憻ʀRSacd᪒᪔᪖᪚᪟»ཇ;擈st;抛irc;抚ash;抝nint;樐id;櫯cir;槂ubsĀ;u᪻᪼晣it»᪼ˬ᫇᫔᫺\0ᬊonĀ;eᫍᫎ䀺Ā;qÇÆɭ᫙\0\0᫢aĀ;t᫞᫟䀬;䁀ƀ;fl᫨᫩᫫戁îᅠeĀmx᫱᫶ent»᫩eóɍǧ᫾\0ᬇĀ;dኻᬂot;橭nôɆƀfryᬐᬔᬗ;쀀𝕔oäɔ脀©;sŕᬝr;愗Āaoᬥᬩrr;憵ss;朗Ācuᬲᬷr;쀀𝒸Ābpᬼ᭄Ā;eᭁᭂ櫏;櫑Ā;eᭉᭊ櫐;櫒dot;拯΀delprvw᭠᭬᭷ᮂᮬᯔ᯹arrĀlr᭨᭪;椸;椵ɰ᭲\0\0᭵r;拞c;拟arrĀ;p᭿ᮀ憶;椽̀;bcdosᮏᮐᮖᮡᮥᮨ截rcap;橈Āauᮛᮞp;橆p;橊ot;抍r;橅;쀀∪︀Ȁalrv᮵ᮿᯞᯣrrĀ;mᮼᮽ憷;椼yƀevwᯇᯔᯘqɰᯎ\0\0ᯒreã᭳uã᭵ee;拎edge;拏en耻¤䂤earrowĀlrᯮ᯳eft»ᮀight»ᮽeäᯝĀciᰁᰇoninôǷnt;戱lcty;挭ঀAHabcdefhijlorstuwz᰸᰻᰿ᱝᱩᱵᲊᲞᲬᲷ᳻᳿ᴍᵻᶑᶫᶻ᷆᷍rò΁ar;楥Ȁglrs᱈ᱍ᱒᱔ger;怠eth;愸òᄳhĀ;vᱚᱛ怐»ऊūᱡᱧarow;椏aã̕Āayᱮᱳron;䄏;䐴ƀ;ao̲ᱼᲄĀgrʿᲁr;懊tseq;橷ƀglmᲑᲔᲘ耻°䂰ta;䎴ptyv;榱ĀirᲣᲨsht;楿;쀀𝔡arĀlrᲳᲵ»ࣜ»သʀaegsv᳂͸᳖᳜᳠mƀ;oș᳊᳔ndĀ;ș᳑uit;晦amma;䏝in;拲ƀ;io᳧᳨᳸䃷de脀÷;o᳧ᳰntimes;拇nø᳷cy;䑒cɯᴆ\0\0ᴊrn;挞op;挍ʀlptuwᴘᴝᴢᵉᵕlar;䀤f;쀀𝕕ʀ;emps̋ᴭᴷᴽᵂqĀ;d͒ᴳot;扑inus;戸lus;戔quare;抡blebarwedgåúnƀadhᄮᵝᵧownarrowóᲃarpoonĀlrᵲᵶefôᲴighôᲶŢᵿᶅkaro÷གɯᶊ\0\0ᶎrn;挟op;挌ƀcotᶘᶣᶦĀryᶝᶡ;쀀𝒹;䑕l;槶rok;䄑Ādrᶰᶴot;拱iĀ;fᶺ᠖斿Āah᷀᷃ròЩaòྦangle;榦Āci᷒ᷕy;䑟grarr;柿ऀDacdefglmnopqrstuxḁḉḙḸոḼṉṡṾấắẽỡἪἷὄ὎὚ĀDoḆᴴoôᲉĀcsḎḔute耻é䃩ter;橮ȀaioyḢḧḱḶron;䄛rĀ;cḭḮ扖耻ê䃪lon;払;䑍ot;䄗ĀDrṁṅot;扒;쀀𝔢ƀ;rsṐṑṗ檚ave耻è䃨Ā;dṜṝ檖ot;檘Ȁ;ilsṪṫṲṴ檙nters;揧;愓Ā;dṹṺ檕ot;檗ƀapsẅẉẗcr;䄓tyƀ;svẒẓẕ戅et»ẓpĀ1;ẝẤĳạả;怄;怅怃ĀgsẪẬ;䅋p;怂ĀgpẴẸon;䄙f;쀀𝕖ƀalsỄỎỒrĀ;sỊị拕l;槣us;橱iƀ;lvỚớở䎵on»ớ;䏵ȀcsuvỪỳἋἣĀioữḱrc»Ḯɩỹ\0\0ỻíՈantĀglἂἆtr»ṝess»Ṻƀaeiἒ἖Ἒls;䀽st;扟vĀ;DȵἠD;橸parsl;槥ĀDaἯἳot;打rr;楱ƀcdiἾὁỸr;愯oô͒ĀahὉὋ;䎷耻ð䃰Āmrὓὗl耻ë䃫o;悬ƀcipὡὤὧl;䀡sôծĀeoὬὴctatioîՙnentialåչৡᾒ\0ᾞ\0ᾡᾧ\0\0ῆῌ\0ΐ\0ῦῪ \0 ⁚llingdotseñṄy;䑄male;晀ƀilrᾭᾳ῁lig;耀ﬃɩᾹ\0\0᾽g;耀ﬀig;耀ﬄ;쀀𝔣lig;耀ﬁlig;쀀fjƀaltῙ῜ῡt;晭ig;耀ﬂns;斱of;䆒ǰ΅\0ῳf;쀀𝕗ĀakֿῷĀ;vῼ´拔;櫙artint;樍Āao‌⁕Ācs‑⁒α‚‰‸⁅⁈\0⁐β•‥‧‪‬\0‮耻½䂽;慓耻¼䂼;慕;慙;慛Ƴ‴\0‶;慔;慖ʴ‾⁁\0\0⁃耻¾䂾;慗;慜5;慘ƶ⁌\0⁎;慚;慝8;慞l;恄wn;挢cr;쀀𝒻ࢀEabcdefgijlnorstv₂₉₟₥₰₴⃰⃵⃺⃿℃ℒℸ̗ℾ⅒↞Ā;lٍ₇;檌ƀcmpₐₕ₝ute;䇵maĀ;dₜ᳚䎳;檆reve;䄟Āiy₪₮rc;䄝;䐳ot;䄡Ȁ;lqsؾق₽⃉ƀ;qsؾٌ⃄lanô٥Ȁ;cdl٥⃒⃥⃕c;檩otĀ;o⃜⃝檀Ā;l⃢⃣檂;檄Ā;e⃪⃭쀀⋛︀s;檔r;쀀𝔤Ā;gٳ؛mel;愷cy;䑓Ȁ;Eajٚℌℎℐ;檒;檥;檤ȀEaesℛℝ℩ℴ;扩pĀ;p℣ℤ檊rox»ℤĀ;q℮ℯ檈Ā;q℮ℛim;拧pf;쀀𝕘Āci⅃ⅆr;愊mƀ;el٫ⅎ⅐;檎;檐茀>;cdlqr׮ⅠⅪⅮⅳⅹĀciⅥⅧ;檧r;橺ot;拗Par;榕uest;橼ʀadelsↄⅪ←ٖ↛ǰ↉\0↎proø₞r;楸qĀlqؿ↖lesó₈ií٫Āen↣↭rtneqq;쀀≩︀Å↪ԀAabcefkosy⇄⇇⇱⇵⇺∘∝∯≨≽ròΠȀilmr⇐⇔⇗⇛rsðᒄf»․ilôکĀdr⇠⇤cy;䑊ƀ;cwࣴ⇫⇯ir;楈;憭ar;意irc;䄥ƀalr∁∎∓rtsĀ;u∉∊晥it»∊lip;怦con;抹r;쀀𝔥sĀew∣∩arow;椥arow;椦ʀamopr∺∾≃≞≣rr;懿tht;戻kĀlr≉≓eftarrow;憩ightarrow;憪f;쀀𝕙bar;怕ƀclt≯≴≸r;쀀𝒽asè⇴rok;䄧Ābp⊂⊇ull;恃hen»ᱛૡ⊣\0⊪\0⊸⋅⋎\0⋕⋳\0\0⋸⌢⍧⍢⍿\0⎆⎪⎴cute耻í䃭ƀ;iyݱ⊰⊵rc耻î䃮;䐸Ācx⊼⊿y;䐵cl耻¡䂡ĀfrΟ⋉;쀀𝔦rave耻ì䃬Ȁ;inoܾ⋝⋩⋮Āin⋢⋦nt;樌t;戭fin;槜ta;愩lig;䄳ƀaop⋾⌚⌝ƀcgt⌅⌈⌗r;䄫ƀelpܟ⌏⌓inåގarôܠh;䄱f;抷ed;䆵ʀ;cfotӴ⌬⌱⌽⍁are;愅inĀ;t⌸⌹戞ie;槝doô⌙ʀ;celpݗ⍌⍐⍛⍡al;抺Āgr⍕⍙eróᕣã⍍arhk;樗rod;樼Ȁcgpt⍯⍲⍶⍻y;䑑on;䄯f;쀀𝕚a;䎹uest耻¿䂿Āci⎊⎏r;쀀𝒾nʀ;EdsvӴ⎛⎝⎡ӳ;拹ot;拵Ā;v⎦⎧拴;拳Ā;iݷ⎮lde;䄩ǫ⎸\0⎼cy;䑖l耻ï䃯̀cfmosu⏌⏗⏜⏡⏧⏵Āiy⏑⏕rc;䄵;䐹r;쀀𝔧ath;䈷pf;쀀𝕛ǣ⏬\0⏱r;쀀𝒿rcy;䑘kcy;䑔Ѐacfghjos␋␖␢␧␭␱␵␻ppaĀ;v␓␔䎺;䏰Āey␛␠dil;䄷;䐺r;쀀𝔨reen;䄸cy;䑅cy;䑜pf;쀀𝕜cr;쀀𝓀஀ABEHabcdefghjlmnoprstuv⑰⒁⒆⒍⒑┎┽╚▀♎♞♥♹♽⚚⚲⛘❝❨➋⟀⠁⠒ƀart⑷⑺⑼rò৆òΕail;椛arr;椎Ā;gঔ⒋;檋ar;楢ॣ⒥\0⒪\0⒱\0\0\0\0\0⒵Ⓔ\0ⓆⓈⓍ\0⓹ute;䄺mptyv;榴raîࡌbda;䎻gƀ;dlࢎⓁⓃ;榑åࢎ;檅uo耻«䂫rЀ;bfhlpst࢙ⓞⓦⓩ⓫⓮⓱⓵Ā;f࢝ⓣs;椟s;椝ë≒p;憫l;椹im;楳l;憢ƀ;ae⓿─┄檫il;椙Ā;s┉┊檭;쀀⪭︀ƀabr┕┙┝rr;椌rk;杲Āak┢┬cĀek┨┪;䁻;䁛Āes┱┳;榋lĀdu┹┻;榏;榍Ȁaeuy╆╋╖╘ron;䄾Ādi═╔il;䄼ìࢰâ┩;䐻Ȁcqrs╣╦╭╽a;椶uoĀ;rนᝆĀdu╲╷har;楧shar;楋h;憲ʀ;fgqs▋▌উ◳◿扤tʀahlrt▘▤▷◂◨rrowĀ;t࢙□aé⓶arpoonĀdu▯▴own»њp»०eftarrows;懇ightƀahs◍◖◞rrowĀ;sࣴࢧarpoonó྘quigarro÷⇰hreetimes;拋ƀ;qs▋ও◺lanôবʀ;cdgsব☊☍☝☨c;檨otĀ;o☔☕橿Ā;r☚☛檁;檃Ā;e☢☥쀀⋚︀s;檓ʀadegs☳☹☽♉♋pproøⓆot;拖qĀgq♃♅ôউgtò⒌ôছiíলƀilr♕࣡♚sht;楼;쀀𝔩Ā;Eজ♣;檑š♩♶rĀdu▲♮Ā;l॥♳;楪lk;斄cy;䑙ʀ;achtੈ⚈⚋⚑⚖rò◁orneòᴈard;楫ri;旺Āio⚟⚤dot;䅀ustĀ;a⚬⚭掰che»⚭ȀEaes⚻⚽⛉⛔;扨pĀ;p⛃⛄檉rox»⛄Ā;q⛎⛏檇Ā;q⛎⚻im;拦Ѐabnoptwz⛩⛴⛷✚✯❁❇❐Ānr⛮⛱g;柬r;懽rëࣁgƀlmr⛿✍✔eftĀar০✇ightá৲apsto;柼ightá৽parrowĀlr✥✩efô⓭ight;憬ƀafl✶✹✽r;榅;쀀𝕝us;樭imes;樴š❋❏st;戗áፎƀ;ef❗❘᠀旊nge»❘arĀ;l❤❥䀨t;榓ʀachmt❳❶❼➅➇ròࢨorneòᶌarĀ;d྘➃;業;怎ri;抿̀achiqt➘➝ੀ➢➮➻quo;怹r;쀀𝓁mƀ;egল➪➬;檍;檏Ābu┪➳oĀ;rฟ➹;怚rok;䅂萀<;cdhilqrࠫ⟒☹⟜⟠⟥⟪⟰Āci⟗⟙;檦r;橹reå◲mes;拉arr;楶uest;橻ĀPi⟵⟹ar;榖ƀ;ef⠀भ᠛旃rĀdu⠇⠍shar;楊har;楦Āen⠗⠡rtneqq;쀀≨︀Å⠞܀Dacdefhilnopsu⡀⡅⢂⢎⢓⢠⢥⢨⣚⣢⣤ઃ⣳⤂Dot;戺Ȁclpr⡎⡒⡣⡽r耻¯䂯Āet⡗⡙;時Ā;e⡞⡟朠se»⡟Ā;sျ⡨toȀ;dluျ⡳⡷⡻owîҌefôएðᏑker;斮Āoy⢇⢌mma;権;䐼ash;怔asuredangle»ᘦr;쀀𝔪o;愧ƀcdn⢯⢴⣉ro耻µ䂵Ȁ;acdᑤ⢽⣀⣄sôᚧir;櫰ot肻·Ƶusƀ;bd⣒ᤃ⣓戒Ā;uᴼ⣘;横ţ⣞⣡p;櫛ò−ðઁĀdp⣩⣮els;抧f;쀀𝕞Āct⣸⣽r;쀀𝓂pos»ᖝƀ;lm⤉⤊⤍䎼timap;抸ఀGLRVabcdefghijlmoprstuvw⥂⥓⥾⦉⦘⧚⧩⨕⨚⩘⩝⪃⪕⪤⪨⬄⬇⭄⭿⮮ⰴⱧⱼ⳩Āgt⥇⥋;쀀⋙̸Ā;v⥐௏쀀≫⃒ƀelt⥚⥲⥶ftĀar⥡⥧rrow;懍ightarrow;懎;쀀⋘̸Ā;v⥻ే쀀≪⃒ightarrow;懏ĀDd⦎⦓ash;抯ash;抮ʀbcnpt⦣⦧⦬⦱⧌la»˞ute;䅄g;쀀∠⃒ʀ;Eiop඄⦼⧀⧅⧈;쀀⩰̸d;쀀≋̸s;䅉roø඄urĀ;a⧓⧔普lĀ;s⧓ସǳ⧟\0⧣p肻 ଷmpĀ;e௹ఀʀaeouy⧴⧾⨃⨐⨓ǰ⧹\0⧻;橃on;䅈dil;䅆ngĀ;dൾ⨊ot;쀀⩭̸p;橂;䐽ash;怓΀;Aadqsxஒ⨩⨭⨻⩁⩅⩐rr;懗rĀhr⨳⨶k;椤Ā;oᏲᏰot;쀀≐̸uiöୣĀei⩊⩎ar;椨í஘istĀ;s஠டr;쀀𝔫ȀEest௅⩦⩹⩼ƀ;qs஼⩭௡ƀ;qs஼௅⩴lanô௢ií௪Ā;rஶ⪁»ஷƀAap⪊⪍⪑rò⥱rr;憮ar;櫲ƀ;svྍ⪜ྌĀ;d⪡⪢拼;拺cy;䑚΀AEadest⪷⪺⪾⫂⫅⫶⫹rò⥦;쀀≦̸rr;憚r;急Ȁ;fqs఻⫎⫣⫯tĀar⫔⫙rro÷⫁ightarro÷⪐ƀ;qs఻⪺⫪lanôౕĀ;sౕ⫴»శiíౝĀ;rవ⫾iĀ;eచథiäඐĀpt⬌⬑f;쀀𝕟膀¬;in⬙⬚⬶䂬nȀ;Edvஉ⬤⬨⬮;쀀⋹̸ot;쀀⋵̸ǡஉ⬳⬵;拷;拶iĀ;vಸ⬼ǡಸ⭁⭃;拾;拽ƀaor⭋⭣⭩rȀ;ast୻⭕⭚⭟lleì୻l;쀀⫽⃥;쀀∂̸lint;樔ƀ;ceಒ⭰⭳uåಥĀ;cಘ⭸Ā;eಒ⭽ñಘȀAait⮈⮋⮝⮧rò⦈rrƀ;cw⮔⮕⮙憛;쀀⤳̸;쀀↝̸ghtarrow»⮕riĀ;eೋೖ΀chimpqu⮽⯍⯙⬄୸⯤⯯Ȁ;cerല⯆ഷ⯉uå൅;쀀𝓃ortɭ⬅\0\0⯖ará⭖mĀ;e൮⯟Ā;q൴൳suĀbp⯫⯭å೸åഋƀbcp⯶ⰑⰙȀ;Ees⯿ⰀഢⰄ抄;쀀⫅̸etĀ;eഛⰋqĀ;qണⰀcĀ;eലⰗñസȀ;EesⰢⰣൟⰧ抅;쀀⫆̸etĀ;e൘ⰮqĀ;qൠⰣȀgilrⰽⰿⱅⱇìௗlde耻ñ䃱çృiangleĀlrⱒⱜeftĀ;eచⱚñదightĀ;eೋⱥñ೗Ā;mⱬⱭ䎽ƀ;esⱴⱵⱹ䀣ro;愖p;怇ҀDHadgilrsⲏⲔⲙⲞⲣⲰⲶⳓⳣash;抭arr;椄p;쀀≍⃒ash;抬ĀetⲨⲬ;쀀≥⃒;쀀>⃒nfin;槞ƀAetⲽⳁⳅrr;椂;쀀≤⃒Ā;rⳊⳍ쀀<⃒ie;쀀⊴⃒ĀAtⳘⳜrr;椃rie;쀀⊵⃒im;쀀∼⃒ƀAan⳰⳴ⴂrr;懖rĀhr⳺⳽k;椣Ā;oᏧᏥear;椧ቓ᪕\0\0\0\0\0\0\0\0\0\0\0\0\0ⴭ\0ⴸⵈⵠⵥ⵲ⶄᬇ\0\0ⶍⶫ\0ⷈⷎ\0ⷜ⸙⸫⸾⹃Ācsⴱ᪗ute耻ó䃳ĀiyⴼⵅrĀ;c᪞ⵂ耻ô䃴;䐾ʀabios᪠ⵒⵗǈⵚlac;䅑v;樸old;榼lig;䅓Ācr⵩⵭ir;榿;쀀𝔬ͯ⵹\0\0⵼\0ⶂn;䋛ave耻ò䃲;槁Ābmⶈ෴ar;榵Ȁacitⶕ⶘ⶥⶨrò᪀Āir⶝ⶠr;榾oss;榻nå๒;槀ƀaeiⶱⶵⶹcr;䅍ga;䏉ƀcdnⷀⷅǍron;䎿;榶pf;쀀𝕠ƀaelⷔ⷗ǒr;榷rp;榹΀;adiosvⷪⷫⷮ⸈⸍⸐⸖戨rò᪆Ȁ;efmⷷⷸ⸂⸅橝rĀ;oⷾⷿ愴f»ⷿ耻ª䂪耻º䂺gof;抶r;橖lope;橗;橛ƀclo⸟⸡⸧ò⸁ash耻ø䃸l;折iŬⸯ⸴de耻õ䃵esĀ;aǛ⸺s;樶ml耻ö䃶bar;挽ૡ⹞\0⹽\0⺀⺝\0⺢⺹\0\0⻋ຜ\0⼓\0\0⼫⾼\0⿈rȀ;astЃ⹧⹲຅脀¶;l⹭⹮䂶leìЃɩ⹸\0\0⹻m;櫳;櫽y;䐿rʀcimpt⺋⺏⺓ᡥ⺗nt;䀥od;䀮il;怰enk;怱r;쀀𝔭ƀimo⺨⺰⺴Ā;v⺭⺮䏆;䏕maô੶ne;明ƀ;tv⺿⻀⻈䏀chfork»´;䏖Āau⻏⻟nĀck⻕⻝kĀ;h⇴⻛;愎ö⇴sҀ;abcdemst⻳⻴ᤈ⻹⻽⼄⼆⼊⼎䀫cir;樣ir;樢Āouᵀ⼂;樥;橲n肻±ຝim;樦wo;樧ƀipu⼙⼠⼥ntint;樕f;쀀𝕡nd耻£䂣Ԁ;Eaceinosu່⼿⽁⽄⽇⾁⾉⾒⽾⾶;檳p;檷uå໙Ā;c໎⽌̀;acens່⽙⽟⽦⽨⽾pproø⽃urlyeñ໙ñ໎ƀaes⽯⽶⽺pprox;檹qq;檵im;拨iíໟmeĀ;s⾈ຮ怲ƀEas⽸⾐⽺ð⽵ƀdfp໬⾙⾯ƀals⾠⾥⾪lar;挮ine;挒urf;挓Ā;t໻⾴ï໻rel;抰Āci⿀⿅r;쀀𝓅;䏈ncsp;怈̀fiopsu⿚⋢⿟⿥⿫⿱r;쀀𝔮pf;쀀𝕢rime;恗cr;쀀𝓆ƀaeo⿸〉〓tĀei⿾々rnionóڰnt;樖stĀ;e【】䀿ñἙô༔઀ABHabcdefhilmnoprstux぀けさすムㄎㄫㅇㅢㅲㆎ㈆㈕㈤㈩㉘㉮㉲㊐㊰㊷ƀartぇおがròႳòϝail;検aròᱥar;楤΀cdenqrtとふへみわゔヌĀeuねぱ;쀀∽̱te;䅕iãᅮmptyv;榳gȀ;del࿑らるろ;榒;榥å࿑uo耻»䂻rր;abcfhlpstw࿜ガクシスゼゾダッデナp;極Ā;f࿠ゴs;椠;椳s;椞ë≝ð✮l;楅im;楴l;憣;憝Āaiパフil;椚oĀ;nホボ戶aló༞ƀabrョリヮrò៥rk;杳ĀakンヽcĀekヹ・;䁽;䁝Āes㄂㄄;榌lĀduㄊㄌ;榎;榐Ȁaeuyㄗㄜㄧㄩron;䅙Ādiㄡㄥil;䅗ì࿲âヺ;䑀Ȁclqsㄴㄷㄽㅄa;椷dhar;楩uoĀ;rȎȍh;憳ƀacgㅎㅟངlȀ;ipsླྀㅘㅛႜnåႻarôྩt;断ƀilrㅩဣㅮsht;楽;쀀𝔯ĀaoㅷㆆrĀduㅽㅿ»ѻĀ;l႑ㆄ;楬Ā;vㆋㆌ䏁;䏱ƀgns㆕ㇹㇼht̀ahlrstㆤㆰ㇂㇘㇤㇮rrowĀ;t࿜ㆭaéトarpoonĀduㆻㆿowîㅾp»႒eftĀah㇊㇐rrowó࿪arpoonóՑightarrows;應quigarro÷ニhreetimes;拌g;䋚ingdotseñἲƀahm㈍㈐㈓rò࿪aòՑ;怏oustĀ;a㈞㈟掱che»㈟mid;櫮Ȁabpt㈲㈽㉀㉒Ānr㈷㈺g;柭r;懾rëဃƀafl㉇㉊㉎r;榆;쀀𝕣us;樮imes;樵Āap㉝㉧rĀ;g㉣㉤䀩t;榔olint;樒arò㇣Ȁachq㉻㊀Ⴜ㊅quo;怺r;쀀𝓇Ābu・㊊oĀ;rȔȓƀhir㊗㊛㊠reåㇸmes;拊iȀ;efl㊪ၙᠡ㊫方tri;槎luhar;楨;愞ൡ㋕㋛㋟㌬㌸㍱\0㍺㎤\0\0㏬㏰\0㐨㑈㑚㒭㒱㓊㓱\0㘖\0\0㘳cute;䅛quï➺Ԁ;Eaceinpsyᇭ㋳㋵㋿㌂㌋㌏㌟㌦㌩;檴ǰ㋺\0㋼;檸on;䅡uåᇾĀ;dᇳ㌇il;䅟rc;䅝ƀEas㌖㌘㌛;檶p;檺im;择olint;樓iíሄ;䑁otƀ;be㌴ᵇ㌵担;橦΀Aacmstx㍆㍊㍗㍛㍞㍣㍭rr;懘rĀhr㍐㍒ë∨Ā;oਸ਼਴t耻§䂧i;䀻war;椩mĀin㍩ðnuóñt;朶rĀ;o㍶⁕쀀𝔰Ȁacoy㎂㎆㎑㎠rp;景Āhy㎋㎏cy;䑉;䑈rtɭ㎙\0\0㎜iäᑤaraì⹯耻­䂭Āgm㎨㎴maƀ;fv㎱㎲㎲䏃;䏂Ѐ;deglnprካ㏅㏉㏎㏖㏞㏡㏦ot;橪Ā;q኱ኰĀ;E㏓㏔檞;檠Ā;E㏛㏜檝;檟e;扆lus;樤arr;楲aròᄽȀaeit㏸㐈㐏㐗Āls㏽㐄lsetmé㍪hp;樳parsl;槤Ādlᑣ㐔e;挣Ā;e㐜㐝檪Ā;s㐢㐣檬;쀀⪬︀ƀflp㐮㐳㑂tcy;䑌Ā;b㐸㐹䀯Ā;a㐾㐿槄r;挿f;쀀𝕤aĀdr㑍ЂesĀ;u㑔㑕晠it»㑕ƀcsu㑠㑹㒟Āau㑥㑯pĀ;sᆈ㑫;쀀⊓︀pĀ;sᆴ㑵;쀀⊔︀uĀbp㑿㒏ƀ;esᆗᆜ㒆etĀ;eᆗ㒍ñᆝƀ;esᆨᆭ㒖etĀ;eᆨ㒝ñᆮƀ;afᅻ㒦ְrť㒫ֱ»ᅼaròᅈȀcemt㒹㒾㓂㓅r;쀀𝓈tmîñiì㐕aræᆾĀar㓎㓕rĀ;f㓔ឿ昆Āan㓚㓭ightĀep㓣㓪psiloîỠhé⺯s»⡒ʀbcmnp㓻㕞ሉ㖋㖎Ҁ;Edemnprs㔎㔏㔑㔕㔞㔣㔬㔱㔶抂;櫅ot;檽Ā;dᇚ㔚ot;櫃ult;櫁ĀEe㔨㔪;櫋;把lus;檿arr;楹ƀeiu㔽㕒㕕tƀ;en㔎㕅㕋qĀ;qᇚ㔏eqĀ;q㔫㔨m;櫇Ābp㕚㕜;櫕;櫓c̀;acensᇭ㕬㕲㕹㕻㌦pproø㋺urlyeñᇾñᇳƀaes㖂㖈㌛pproø㌚qñ㌗g;晪ڀ123;Edehlmnps㖩㖬㖯ሜ㖲㖴㗀㗉㗕㗚㗟㗨㗭耻¹䂹耻²䂲耻³䂳;櫆Āos㖹㖼t;檾ub;櫘Ā;dሢ㗅ot;櫄sĀou㗏㗒l;柉b;櫗arr;楻ult;櫂ĀEe㗤㗦;櫌;抋lus;櫀ƀeiu㗴㘉㘌tƀ;enሜ㗼㘂qĀ;qሢ㖲eqĀ;q㗧㗤m;櫈Ābp㘑㘓;櫔;櫖ƀAan㘜㘠㘭rr;懙rĀhr㘦㘨ë∮Ā;oਫ਩war;椪lig耻ß䃟௡㙑㙝㙠ዎ㙳㙹\0㙾㛂\0\0\0\0\0㛛㜃\0㜉㝬\0\0\0㞇ɲ㙖\0\0㙛get;挖;䏄rë๟ƀaey㙦㙫㙰ron;䅥dil;䅣;䑂lrec;挕r;쀀𝔱Ȁeiko㚆㚝㚵㚼ǲ㚋\0㚑eĀ4fኄኁaƀ;sv㚘㚙㚛䎸ym;䏑Ācn㚢㚲kĀas㚨㚮pproø዁im»ኬsðኞĀas㚺㚮ð዁rn耻þ䃾Ǭ̟㛆⋧es膀×;bd㛏㛐㛘䃗Ā;aᤏ㛕r;樱;樰ƀeps㛡㛣㜀á⩍Ȁ;bcf҆㛬㛰㛴ot;挶ir;櫱Ā;o㛹㛼쀀𝕥rk;櫚á㍢rime;怴ƀaip㜏㜒㝤dåቈ΀adempst㜡㝍㝀㝑㝗㝜㝟ngleʀ;dlqr㜰㜱㜶㝀㝂斵own»ᶻeftĀ;e⠀㜾ñम;扜ightĀ;e㊪㝋ñၚot;旬inus;樺lus;樹b;槍ime;樻ezium;揢ƀcht㝲㝽㞁Āry㝷㝻;쀀𝓉;䑆cy;䑛rok;䅧Āio㞋㞎xô᝷headĀlr㞗㞠eftarro÷ࡏightarrow»ཝऀAHabcdfghlmoprstuw㟐㟓㟗㟤㟰㟼㠎㠜㠣㠴㡑㡝㡫㢩㣌㣒㣪㣶ròϭar;楣Ācr㟜㟢ute耻ú䃺òᅐrǣ㟪\0㟭y;䑞ve;䅭Āiy㟵㟺rc耻û䃻;䑃ƀabh㠃㠆㠋ròᎭlac;䅱aòᏃĀir㠓㠘sht;楾;쀀𝔲rave耻ù䃹š㠧㠱rĀlr㠬㠮»ॗ»ႃlk;斀Āct㠹㡍ɯ㠿\0\0㡊rnĀ;e㡅㡆挜r»㡆op;挏ri;旸Āal㡖㡚cr;䅫肻¨͉Āgp㡢㡦on;䅳f;쀀𝕦̀adhlsuᅋ㡸㡽፲㢑㢠ownáᎳarpoonĀlr㢈㢌efô㠭ighô㠯iƀ;hl㢙㢚㢜䏅»ᏺon»㢚parrows;懈ƀcit㢰㣄㣈ɯ㢶\0\0㣁rnĀ;e㢼㢽挝r»㢽op;挎ng;䅯ri;旹cr;쀀𝓊ƀdir㣙㣝㣢ot;拰lde;䅩iĀ;f㜰㣨»᠓Āam㣯㣲rò㢨l耻ü䃼angle;榧ހABDacdeflnoprsz㤜㤟㤩㤭㦵㦸㦽㧟㧤㧨㧳㧹㧽㨁㨠ròϷarĀ;v㤦㤧櫨;櫩asèϡĀnr㤲㤷grt;榜΀eknprst㓣㥆㥋㥒㥝㥤㦖appá␕othinçẖƀhir㓫⻈㥙opô⾵Ā;hᎷ㥢ïㆍĀiu㥩㥭gmá㎳Ābp㥲㦄setneqĀ;q㥽㦀쀀⊊︀;쀀⫋︀setneqĀ;q㦏㦒쀀⊋︀;쀀⫌︀Āhr㦛㦟etá㚜iangleĀlr㦪㦯eft»थight»ၑy;䐲ash»ံƀelr㧄㧒㧗ƀ;beⷪ㧋㧏ar;抻q;扚lip;拮Ābt㧜ᑨaòᑩr;쀀𝔳tré㦮suĀbp㧯㧱»ജ»൙pf;쀀𝕧roð໻tré㦴Ācu㨆㨋r;쀀𝓋Ābp㨐㨘nĀEe㦀㨖»㥾nĀEe㦒㨞»㦐igzag;榚΀cefoprs㨶㨻㩖㩛㩔㩡㩪irc;䅵Ādi㩀㩑Ābg㩅㩉ar;機eĀ;qᗺ㩏;扙erp;愘r;쀀𝔴pf;쀀𝕨Ā;eᑹ㩦atèᑹcr;쀀𝓌ૣណ㪇\0㪋\0㪐㪛\0\0㪝㪨㪫㪯\0\0㫃㫎\0㫘ៜ៟tré៑r;쀀𝔵ĀAa㪔㪗ròσrò৶;䎾ĀAa㪡㪤ròθrò৫að✓is;拻ƀdptឤ㪵㪾Āfl㪺ឩ;쀀𝕩imåឲĀAa㫇㫊ròώròਁĀcq㫒ីr;쀀𝓍Āpt៖㫜ré។Ѐacefiosu㫰㫽㬈㬌㬑㬕㬛㬡cĀuy㫶㫻te耻ý䃽;䑏Āiy㬂㬆rc;䅷;䑋n耻¥䂥r;쀀𝔶cy;䑗pf;쀀𝕪cr;쀀𝓎Ācm㬦㬩y;䑎l耻ÿ䃿Ԁacdefhiosw㭂㭈㭔㭘㭤㭩㭭㭴㭺㮀cute;䅺Āay㭍㭒ron;䅾;䐷ot;䅼Āet㭝㭡træᕟa;䎶r;쀀𝔷cy;䐶grarr;懝pf;쀀𝕫cr;쀀𝓏Ājn㮅㮇;怍j;怌'.split("").map((e => e.charCodeAt(0)))), Kn = new Uint16Array("Ȁaglq\tɭ\0\0p;䀦os;䀧t;䀾t;䀼uot;䀢".split("").map((e => e.charCodeAt(0))));
const Zn = new Map([[0, 65533], [128, 8364], [130, 8218], [131, 402], [132, 8222], [133, 8230], [134, 8224], [135, 8225], [136, 710], [137, 8240], [138, 352], [139, 8249], [140, 338], [142, 381], [145, 8216], [146, 8217], [147, 8220], [148, 8221], [149, 8226], [150, 8211], [151, 8212], [152, 732], [153, 8482], [154, 353], [155, 8250], [156, 339], [158, 382], [159, 376]]), Xn = null !== (Qn = String.fromCodePoint) && void 0 !== Qn ? Qn : function (e) {
    let t = "";
    return e > 65535 && (e -= 65536, t += String.fromCharCode(e >>> 10 & 1023 | 55296), e = 56320 | 1023 & e),
    t += String.fromCharCode(e),
    t
};
var $n, Jn;
function ei(e, t, a, n) {
    const i = (t & Jn.BRANCH_LENGTH) >> 7,
    s = t & Jn.JUMP_TABLE;
    if (0 === i)
        return 0 !== s && n === s ? a : -1;
    if (s) {
        const t = n - s;
        return t < 0 || t >= i ? -1 : e[a + t] - 1
    }
    let o = a,
    r = o + i - 1;
    for (; o <= r; ) {
        const t = o + r >>> 1,
        a = e[t];
        if (a < n)
            o = t + 1;
        else {
            if (!(a > n))
                return e[t + i];
            r = t - 1
        }
    }
    return -1
}
!function (e) {
    e[e.NUM = 35] = "NUM",
    e[e.SEMI = 59] = "SEMI",
    e[e.ZERO = 48] = "ZERO",
    e[e.NINE = 57] = "NINE",
    e[e.LOWER_A = 97] = "LOWER_A",
    e[e.LOWER_F = 102] = "LOWER_F",
    e[e.LOWER_X = 120] = "LOWER_X",
    e[e.To_LOWER_BIT = 32] = "To_LOWER_BIT"
}
($n || ($n = {})), function (e) {
    e[e.VALUE_LENGTH = 49152] = "VALUE_LENGTH",
    e[e.BRANCH_LENGTH = 16256] = "BRANCH_LENGTH",
    e[e.JUMP_TABLE = 127] = "JUMP_TABLE"
}
(Jn || (Jn = {}));
const ti = /["&'<>$\x80-\uFFFF]/g, ai = new Map([[34, "&quot;"], [38, "&amp;"], [39, "&apos;"], [60, "&lt;"], [62, "&gt;"]]), ni = null != String.prototype.codePointAt ? (e, t) => e.codePointAt(t) : (e, t) => 55296 == (64512 & e.charCodeAt(t)) ? 1024 * (e.charCodeAt(t) - 55296) + e.charCodeAt(t + 1) - 56320 + 65536 : e.charCodeAt(t);
function ii(e) {
    let t,
    a = "",
    n = 0;
    for (; null !== (t = ti.exec(e)); ) {
        const i = t.index,
        s = e.charCodeAt(i),
        o = ai.get(s);
        void 0 !== o ? (a += e.substring(n, i) + o, n = i + 1) : (a += `${e.substring(n, i)}&#x${ni(e, i).toString(16)};`, n = ti.lastIndex += Number(55296 == (64512 & s)))
    }
    return a + e.substr(n)
}
function si(e, t) {
    return function (a) {
        let n,
        i = 0,
        s = "";
        for (; n = e.exec(a); )
            i !== n.index && (s += a.substring(i, n.index)), s += t.get(n[0].charCodeAt(0)), i = n.index + 1;
        return s + a.substring(i)
    }
}
const oi = si(/["&\u00A0]/g, new Map([[34, "&quot;"], [38, "&amp;"], [160, "&nbsp;"]])), ri = si(/[&<>\u00A0]/g, new Map([[38, "&amp;"], [60, "&lt;"], [62, "&gt;"], [160, "&nbsp;"]])), ci = new Map(["altGlyph", "altGlyphDef", "altGlyphItem", "animateColor", "animateMotion", "animateTransform", "clipPath", "feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feDropShadow", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence", "foreignObject", "glyphRef", "linearGradient", "radialGradient", "textPath"].map((e => [e.toLowerCase(), e]))), li = new Map(["definitionURL", "attributeName", "attributeType", "baseFrequency", "baseProfile", "calcMode", "clipPathUnits", "diffuseConstant", "edgeMode", "filterUnits", "glyphRef", "gradientTransform", "gradientUnits", "kernelMatrix", "kernelUnitLength", "keyPoints", "keySplines", "keyTimes", "lengthAdjust", "limitingConeAngle", "markerHeight", "markerUnits", "markerWidth", "maskContentUnits", "maskUnits", "numOctaves", "pathLength", "patternContentUnits", "patternTransform", "patternUnits", "pointsAtX", "pointsAtY", "pointsAtZ", "preserveAlpha", "preserveAspectRatio", "primitiveUnits", "refX", "refY", "repeatCount", "repeatDur", "requiredExtensions", "requiredFeatures", "specularConstant", "specularExponent", "spreadMethod", "startOffset", "stdDeviation", "stitchTiles", "surfaceScale", "systemLanguage", "tableValues", "targetX", "targetY", "textLength", "viewBox", "viewTarget", "xChannelSelector", "yChannelSelector", "zoomAndPan"].map((e => [e.toLowerCase(), e]))), pi = new Set(["style", "script", "xmp", "iframe", "noembed", "noframes", "plaintext", "noscript"]);
function ui(e) {
    return e.replace(/"/g, "&quot;")
}
const di = new Set(["area", "base", "basefont", "br", "col", "command", "embed", "frame", "hr", "img", "input", "isindex", "keygen", "link", "meta", "param", "source", "track", "wbr"]);
function hi(e, t = {}) {
    const a = "length" in e ? e : [e];
    let n = "";
    for (let e = 0; e < a.length; e++)
        n += mi(a[e], t);
    return n
}
function mi(e, t) {
    switch (e.type) {
    case gn:
        return hi(e.children, t);
    case Sn:
    case xn:
        return `<${e.data}>`;
    case Tn:
        return function (e) {
            return `\x3c!--${e.data}--\x3e`
        }
        (e);
    case wn:
        return function (e) {
            return `<![CDATA[${e.children[0].data}]]>`
        }
        (e);
    case vn:
    case An:
    case yn:
        return function (e, t) {
            var a;
            "foreign" === t.xmlMode && (e.name = null !== (a = ci.get(e.name)) && void 0 !== a ? a : e.name, e.parent && fi.has(e.parent.name) && (t = {
                        ...t,
                        xmlMode: !1
                    })),
            !t.xmlMode && _i.has(e.name) && (t = {
                    ...t,
                    xmlMode: "foreign"
                });
            let n = `<${e.name}`;
            const i = function (e, t) {
                var a;
                if (!e)
                    return;
                const n = !1 === (null !== (a = t.encodeEntities) && void 0 !== a ? a : t.decodeEntities) ? ui : t.xmlMode || "utf8" !== t.encodeEntities ? ii : oi;
                return Object.keys(e).map((a => {
                        var i,
                        s;
                        const o = null !== (i = e[a]) && void 0 !== i ? i : "";
                        return "foreign" === t.xmlMode && (a = null !== (s = li.get(a)) && void 0 !== s ? s : a),
                        t.emptyAttrs || t.xmlMode || "" !== o ? `${a}="${n(o)}"` : a
                    })).join(" ")
            }
            (e.attribs, t);
            return i && (n += ` ${i}`),
            0 === e.children.length && (t.xmlMode ? !1 !== t.selfClosingTags : t.selfClosingTags && di.has(e.name)) ? (t.xmlMode || (n += " "), n += "/>") : (n += ">", e.children.length > 0 && (n += hi(e.children, t)), !t.xmlMode && di.has(e.name) || (n += `</${e.name}>`)),
            n
        }
        (e, t);
    case bn:
        return function (e, t) {
            var a;
            let n = e.data || "";
            return !1 === (null !== (a = t.encodeEntities) && void 0 !== a ? a : t.decodeEntities) || !t.xmlMode && e.parent && pi.has(e.parent.name) || (n = t.xmlMode || "utf8" !== t.encodeEntities ? ii(n) : ri(n)),
            n
        }
        (e, t)
    }
}
const fi = new Set(["mi", "mo", "mn", "ms", "mtext", "annotation-xml", "foreignObject", "desc", "title"]), _i = new Set(["svg", "math"]);
function Ei(e, t) {
    return hi(e, t)
}
function gi(e) {
    return Array.isArray(e) ? e.map(gi).join("") : zn(e) && !Fn(e) ? gi(e.children) : Un(e) ? e.data : ""
}
function bi(e) {
    return Array.isArray(e) ? e.map(bi).join("") : zn(e) && (e.type === En.Tag || Bn(e)) ? bi(e.children) : Un(e) ? e.data : ""
}
function xi(e) {
    return zn(e) ? e.children : []
}
function Ti(e) {
    return e.parent || null
}
function vi(e) {
    const t = Ti(e);
    if (null != t)
        return xi(t);
    const a = [e];
    let {
        prev: n,
        next: i
    } = e;
    for (; null != n; )
        a.unshift(n), ({
            prev: n
        } = n);
    for (; null != i; )
        a.push(i), ({
            next: i
        } = i);
    return a
}
function Ai(e) {
    let {
        next: t
    } = e;
    for (; null !== t && !Pn(t); )
        ({
            next: t
        } = t);
    return t
}
function yi(e) {
    let {
        prev: t
    } = e;
    for (; null !== t && !Pn(t); )
        ({
            prev: t
        } = t);
    return t
}
function wi(e) {
    if (e.prev && (e.prev.next = e.next), e.next && (e.next.prev = e.prev), e.parent) {
        const t = e.parent.children;
        t.splice(t.lastIndexOf(e), 1)
    }
}
function Si(e, t, a = !0, n = 1 / 0) {
    return Array.isArray(t) || (t = [t]),
    Ni(e, t, a, n)
}
function Ni(e, t, a, n) {
    const i = [];
    for (const s of t) {
        if (e(s) && (i.push(s), --n <= 0))
            break;
        if (a && zn(s) && s.children.length > 0) {
            const t = Ni(e, s.children, a, n);
            if (i.push(...t), n -= t.length, n <= 0)
                break
        }
    }
    return i
}
function Ci(e, t, a = !0) {
    let n = null;
    for (let i = 0; i < t.length && !n; i++) {
        const s = t[i];
        Pn(s) && (e(s) ? n = s : a && s.children.length > 0 && (n = Ci(e, s.children, !0)))
    }
    return n
}
const Ii = {
    tag_name: e => "function" == typeof e ? t => Pn(t) && e(t.name) : "*" === e ? Pn : t => Pn(t) && t.name === e,
    tag_type: e => "function" == typeof e ? t => e(t.type) : t => t.type === e,
    tag_contains: e => "function" == typeof e ? t => Un(t) && e(t.data) : t => Un(t) && t.data === e
};
function ki(e, t) {
    return "function" == typeof t ? a => Pn(a) && t(a.attribs[e]) : a => Pn(a) && a.attribs[e] === t
}
function Ri(e, t) {
    return a => e(a) || t(a)
}
function Oi(e) {
    const t = Object.keys(e).map((t => {
                const a = e[t];
                return Object.prototype.hasOwnProperty.call(Ii, t) ? Ii[t](a) : ki(t, a)
            }));
    return 0 === t.length ? null : t.reduce(Ri)
}
function Di(e, t, a = !0, n = 1 / 0) {
    return Si(Ii.tag_name(e), t, a, n)
}
var Li;
function Mi(e, t) {
    const a = [],
    n = [];
    if (e === t)
        return 0;
    let i = zn(e) ? e : e.parent;
    for (; i; )
        a.unshift(i), i = i.parent;
    for (i = zn(t) ? t : t.parent; i; )
        n.unshift(i), i = i.parent;
    const s = Math.min(a.length, n.length);
    let o = 0;
    for (; o < s && a[o] === n[o]; )
        o++;
    if (0 === o)
        return Li.DISCONNECTED;
    const r = a[o - 1],
    c = r.children,
    l = a[o],
    p = n[o];
    return c.indexOf(l) > c.indexOf(p) ? r === t ? Li.FOLLOWING | Li.CONTAINED_BY : Li.FOLLOWING : r === e ? Li.PRECEDING | Li.CONTAINS : Li.PRECEDING
}
function Pi(e) {
    return (e = e.filter(((e, t, a) => !a.includes(e, t + 1)))).sort(((e, t) => {
            const a = Mi(e, t);
            return a & Li.PRECEDING ? -1 : a & Li.FOLLOWING ? 1 : 0
        })),
    e
}
!function (e) {
    e[e.DISCONNECTED = 1] = "DISCONNECTED",
    e[e.PRECEDING = 2] = "PRECEDING",
    e[e.FOLLOWING = 4] = "FOLLOWING",
    e[e.CONTAINS = 8] = "CONTAINS",
    e[e.CONTAINED_BY = 16] = "CONTAINED_BY"
}
(Li || (Li = {}));
const Bi = ["url", "type", "lang"], Ui = ["fileSize", "bitrate", "framerate", "samplingrate", "channels", "duration", "height", "width"];
function Fi(e) {
    return Di("media:content", e).map((e => {
            const {
                attribs: t
            } = e,
            a = {
                medium: t.medium,
                isDefault: !!t.isDefault
            };
            for (const e of Bi)
                t[e] && (a[e] = t[e]);
            for (const e of Ui)
                t[e] && (a[e] = parseInt(t[e], 10));
            return t.expression && (a.expression = t.expression),
            a
        }))
}
function Hi(e, t) {
    return Di(e, t, !0, 1)[0]
}
function ji(e, t, a = !1) {
    return gi(Di(e, t, a, 1)).trim()
}
function zi(e, t, a, n, i = !1) {
    const s = ji(a, n, i);
    s && (e[t] = s)
}
function Gi(e) {
    return "rss" === e || "feed" === e || "rdf:RDF" === e
}
var qi = Object.freeze({
    __proto__: null,
    isTag: Pn,
    isCDATA: Bn,
    isText: Un,
    isComment: Fn,
    isDocument: jn,
    hasChildren: zn,
    getOuterHTML: Ei,
    getInnerHTML: function (e, t) {
        return zn(e) ? e.children.map((e => Ei(e, t))).join("") : ""
    },
    getText: function e(t) {
        return Array.isArray(t) ? t.map(e).join("") : Pn(t) ? "br" === t.name ? "\n" : e(t.children) : Bn(t) ? e(t.children) : Un(t) ? t.data : ""
    },
    textContent: gi,
    innerText: bi,
    getChildren: xi,
    getParent: Ti,
    getSiblings: vi,
    getAttributeValue: function (e, t) {
        var a;
        return null === (a = e.attribs) || void 0 === a ? void 0 : a[t]
    },
    hasAttrib: function (e, t) {
        return null != e.attribs && Object.prototype.hasOwnProperty.call(e.attribs, t) && null != e.attribs[t]
    },
    getName: function (e) {
        return e.name
    },
    nextElementSibling: Ai,
    prevElementSibling: yi,
    removeElement: wi,
    replaceElement: function (e, t) {
        const a = t.prev = e.prev;
        a && (a.next = t);
        const n = t.next = e.next;
        n && (n.prev = t);
        const i = t.parent = e.parent;
        if (i) {
            const a = i.children;
            a[a.lastIndexOf(e)] = t,
            e.parent = null
        }
    },
    appendChild: function (e, t) {
        if (wi(t), t.next = null, t.parent = e, e.children.push(t) > 1) {
            const a = e.children[e.children.length - 2];
            a.next = t,
            t.prev = a
        } else
            t.prev = null
    },
    append: function (e, t) {
        wi(t);
        const {
            parent: a
        } = e,
        n = e.next;
        if (t.next = n, t.prev = e, e.next = t, t.parent = a, n) {
            if (n.prev = t, a) {
                const e = a.children;
                e.splice(e.lastIndexOf(n), 0, t)
            }
        } else
            a && a.children.push(t)
    },
    prependChild: function (e, t) {
        if (wi(t), t.parent = e, t.prev = null, 1 !== e.children.unshift(t)) {
            const a = e.children[1];
            a.prev = t,
            t.next = a
        } else
            t.next = null
    },
    prepend: function (e, t) {
        wi(t);
        const {
            parent: a
        } = e;
        if (a) {
            const n = a.children;
            n.splice(n.indexOf(e), 0, t)
        }
        e.prev && (e.prev.next = t),
        t.parent = a,
        t.prev = e.prev,
        t.next = e,
        e.prev = t
    },
    filter: Si,
    find: Ni,
    findOneChild: function (e, t) {
        return t.find(e)
    },
    findOne: Ci,
    existsOne: function e(t, a) {
        return a.some((a => Pn(a) && (t(a) || a.children.length > 0 && e(t, a.children))))
    },
    findAll: function (e, t) {
        var a;
        const n = [],
        i = t.filter(Pn);
        let s;
        for (; s = i.shift(); ) {
            const t = null === (a = s.children) || void 0 === a ? void 0 : a.filter(Pn);
            t && t.length > 0 && i.unshift(...t),
            e(s) && n.push(s)
        }
        return n
    },
    testElement: function (e, t) {
        const a = Oi(e);
        return !a || a(t)
    },
    getElements: function (e, t, a, n = 1 / 0) {
        const i = Oi(e);
        return i ? Si(i, t, a, n) : []
    },
    getElementById: function (e, t, a = !0) {
        return Array.isArray(t) || (t = [t]),
        Ci(ki("id", e), t, a)
    },
    getElementsByTagName: Di,
    getElementsByTagType: function (e, t, a = !0, n = 1 / 0) {
        return Si(Ii.tag_type(e), t, a, n)
    },
    removeSubsets: function (e) {
        let t = e.length;
        for (; --t >= 0; ) {
            const a = e[t];
            if (t > 0 && e.lastIndexOf(a, t - 1) >= 0)
                e.splice(t, 1);
            else
                for (let n = a.parent; n; n = n.parent)
                    if (e.includes(n)) {
                        e.splice(t, 1);
                        break
                    }
        }
        return e
    },
    get DocumentPosition() {
        return Li
    },
    compareDocumentPosition: Mi,
    uniqueSort: Pi,
    getFeed: function (e) {
        const t = Hi(Gi, e);
        return t ? "feed" === t.name ? function (e) {
            var t;
            const a = e.children,
            n = {
                type: "atom",
                items: Di("entry", a).map((e => {
                        var t;
                        const {
                            children: a
                        } = e,
                        n = {
                            media: Fi(a)
                        };
                        zi(n, "id", "id", a),
                        zi(n, "title", "title", a);
                        const i = null === (t = Hi("link", a)) || void 0 === t ? void 0 : t.attribs.href;
                        i && (n.link = i);
                        const s = ji("summary", a) || ji("content", a);
                        s && (n.description = s);
                        const o = ji("updated", a);
                        return o && (n.pubDate = new Date(o)),
                        n
                    }))
            };
            zi(n, "id", "id", a),
            zi(n, "title", "title", a);
            const i = null === (t = Hi("link", a)) || void 0 === t ? void 0 : t.attribs.href;
            i && (n.link = i),
            zi(n, "description", "subtitle", a);
            const s = ji("updated", a);
            return s && (n.updated = new Date(s)),
            zi(n, "author", "email", a, !0),
            n
        }
        (t) : function (e) {
            var t,
            a;
            const n = null !== (a = null === (t = Hi("channel", e.children)) || void 0 === t ? void 0 : t.children) && void 0 !== a ? a : [],
            i = {
                type: e.name.substr(0, 3),
                id: "",
                items: Di("item", e.children).map((e => {
                        const {
                            children: t
                        } = e,
                        a = {
                            media: Fi(t)
                        };
                        zi(a, "id", "guid", t),
                        zi(a, "title", "title", t),
                        zi(a, "link", "link", t),
                        zi(a, "description", "description", t);
                        const n = ji("pubDate", t);
                        return n && (a.pubDate = new Date(n)),
                        a
                    }))
            };
            zi(i, "title", "title", n),
            zi(i, "link", "link", n),
            zi(i, "description", "description", n);
            const s = ji("lastBuildDate", n);
            return s && (i.updated = new Date(s)),
            zi(i, "author", "managingEditor", n, !0),
            i
        }
        (t) : null
    }
});
function Yi(e, t, a) {
    return e ? e(null != t ? t : e._root.children, null, void 0, a).toString() : ""
}
function Vi(e) {
    const t = e || (this ? this.root() : []);
    let a = "";
    for (let e = 0; e < t.length; e++)
        a += gi(t[e]);
    return a
}
function Qi(e, t) {
    if (t === e)
        return !1;
    let a = t;
    for (; a && a !== a.parent; )
        if (a = a.parent, a === e)
            return !0;
    return !1
}
function Wi(e) {
    if (Array.isArray(e))
        return !0;
    if ("object" != typeof e || !Object.prototype.hasOwnProperty.call(e, "length") || "number" != typeof e.length || e.length < 0)
        return !1;
    for (let t = 0; t < e.length; t++)
        if (!(t in e))
            return !1;
    return !0
}
var Ki, Zi = Object.freeze({
    __proto__: null,
    html: function (e, t) {
        return Yi(this, function (e, t) {
            return "object" == typeof e && null != e && !("length" in e) && !("type" in e)
        }
            (e) ? void(t = e) : e, {
            ...mn,
            ...null == this ? void 0 : this._options,
            ..._n(null != t ? t : {})
        })
    },
    xml: function (e) {
        return Yi(this, e, {
            ...this._options,
            xmlMode: !0
        })
    },
    text: Vi,
    parseHTML: function (e, t, a = "boolean" == typeof t && t) {
        if (!e || "string" != typeof e)
            return null;
        "boolean" == typeof t && (a = t);
        const n = this.load(e, mn, !1);
        return a || n("script").remove(),
        n.root()[0].children.slice()
    },
    root: function () {
        return this(this._root)
    },
    contains: Qi,
    merge: function (e, t) {
        if (!Wi(e) || !Wi(t))
            return;
        let a = e.length;
        const n = +t.length;
        for (let i = 0; i < n; i++)
            e[a++] = t[i];
        return e.length = a,
        e
    }
});
function Xi(e) {
    return null != e.cheerio
}
function $i(e, t) {
    const a = e.length;
    for (let n = 0; n < a; n++)
        t(e[n], n);
    return e
}
function Ji(e) {
    const t = "length" in e ? Array.prototype.map.call(e, (e => Gn(e, !0))) : [Gn(e, !0)],
    a = new Ln(t);
    return t.forEach((e => {
            e.parent = a
        })),
    t
}
function es(e) {
    const t = e.indexOf("<");
    if (t < 0 || t > e.length - 3)
        return !1;
    const a = e.charCodeAt(t + 1);
    return (a >= Ki.LowerA && a <= Ki.LowerZ || a >= Ki.UpperA && a <= Ki.UpperZ || a === Ki.Exclamation) && e.includes(">", t + 2)
}
!function (e) {
    e[e.LowerA = 97] = "LowerA",
    e[e.LowerZ = 122] = "LowerZ",
    e[e.UpperA = 65] = "UpperA",
    e[e.UpperZ = 90] = "UpperZ",
    e[e.Exclamation = 33] = "Exclamation"
}
(Ki || (Ki = {}));
const ts = Object.prototype.hasOwnProperty, as = /\s+/, ns = {
    null: null,
    true: !0,
    false: !1
}, is = /^(?:autofocus|autoplay|async|checked|controls|defer|disabled|hidden|loop|multiple|open|readonly|required|scoped|selected)$/i, ss = /^{[^]*}$|^\[[^]*]$/;
function os(e, t, a) {
    var n;
    if (e && Pn(e))
        return null !== (n = e.attribs) && void 0 !== n || (e.attribs = {}), t ? ts.call(e.attribs, t) ? !a && is.test(t) ? t : e.attribs[t] : "option" === e.name && "value" === t ? Vi(e.children) : "input" !== e.name || "radio" !== e.attribs.type && "checkbox" !== e.attribs.type || "value" !== t ? void 0 : "on" : e.attribs
}
function rs(e, t, a) {
    null === a ? ds(e, t) : e.attribs[t] = `${a}`
}
function cs(e, t, a) {
    return t in e ? e[t] : !a && is.test(t) ? void 0 !== os(e, t, !1) : os(e, t, a)
}
function ls(e, t, a, n) {
    t in e ? e[t] = a : rs(e, t, !n && is.test(t) ? a ? "" : null : `${a}`)
}
function ps(e, t, a) {
    var n;
    const i = e;
    null !== (n = i.data) && void 0 !== n || (i.data = {}),
    "object" == typeof t ? Object.assign(i.data, t) : "string" == typeof t && void 0 !== a && (i.data[t] = a)
}
function us(e, t) {
    let a,
    n,
    i;
    var s;
    null == t ? (a = Object.keys(e.attribs).filter((e => e.startsWith("data-"))), n = a.map((e => e.slice("data-".length).replace(/[_.-](\w|$)/g, ((e, t) => t.toUpperCase()))))) : (a = ["data-" + (s = t, s.replace(/[A-Z]/g, "-$&").toLowerCase())], n = [t]);
    for (let t = 0; t < a.length; ++t) {
        const s = a[t],
        o = n[t];
        if (ts.call(e.attribs, s) && !ts.call(e.data, o)) {
            if (i = e.attribs[s], ts.call(ns, i))
                i = ns[i];
            else if (i === String(Number(i)))
                i = Number(i);
            else if (ss.test(i))
                try {
                    i = JSON.parse(i)
                } catch (e) {}
            e.data[o] = i
        }
    }
    return null == t ? e.data : i
}
function ds(e, t) {
    e.attribs && ts.call(e.attribs, t) && delete e.attribs[t]
}
function hs(e) {
    return e ? e.trim().split(as) : []
}
var ms, fs, _s = Object.freeze({
    __proto__: null,
    attr: function (e, t) {
        if ("object" == typeof e || void 0 !== t) {
            if ("function" == typeof t) {
                if ("string" != typeof e)
                    throw new Error("Bad combination of arguments.");
                return $i(this, ((a, n) => {
                        Pn(a) && rs(a, e, t.call(a, n, a.attribs[e]))
                    }))
            }
            return $i(this, (a => {
                    Pn(a) && ("object" == typeof e ? Object.keys(e).forEach((t => {
                                const n = e[t];
                                rs(a, t, n)
                            })) : rs(a, e, t))
                }))
        }
        return arguments.length > 1 ? this : os(this[0], e, this.options.xmlMode)
    },
    prop: function (e, t) {
        var a;
        if ("string" == typeof e && void 0 === t) {
            const t = this[0];
            if (!t || !Pn(t))
                return;
            switch (e) {
            case "style": {
                    const e = this.css(),
                    t = Object.keys(e);
                    return t.forEach(((t, a) => {
                            e[a] = t
                        })),
                    e.length = t.length,
                    e
                }
            case "tagName":
            case "nodeName":
                return t.name.toUpperCase();
            case "href":
            case "src": {
                    const n = null === (a = t.attribs) || void 0 === a ? void 0 : a[e];
                    return "undefined" == typeof URL || ("href" !== e || "a" !== t.tagName && "link" !== t.name) && ("src" !== e || "img" !== t.tagName && "iframe" !== t.tagName && "audio" !== t.tagName && "video" !== t.tagName && "source" !== t.tagName) || void 0 === n || !this.options.baseURI ? n : new URL(n, this.options.baseURI).href
                }
            case "innerText":
                return bi(t);
            case "textContent":
                return gi(t);
            case "outerHTML":
                return this.clone().wrap("<container />").parent().html();
            case "innerHTML":
                return this.html();
            default:
                return cs(t, e, this.options.xmlMode)
            }
        }
        if ("object" == typeof e || void 0 !== t) {
            if ("function" == typeof t) {
                if ("object" == typeof e)
                    throw new Error("Bad combination of arguments.");
                return $i(this, ((a, n) => {
                        Pn(a) && ls(a, e, t.call(a, n, cs(a, e, this.options.xmlMode)), this.options.xmlMode)
                    }))
            }
            return $i(this, (a => {
                    Pn(a) && ("object" == typeof e ? Object.keys(e).forEach((t => {
                                const n = e[t];
                                ls(a, t, n, this.options.xmlMode)
                            })) : ls(a, e, t, this.options.xmlMode))
                }))
        }
    },
    data: function (e, t) {
        var a;
        const n = this[0];
        if (!n || !Pn(n))
            return;
        const i = n;
        return null !== (a = i.data) && void 0 !== a || (i.data = {}),
        e ? "object" == typeof e || void 0 !== t ? ($i(this, (a => {
                    Pn(a) && ("object" == typeof e ? ps(a, e) : ps(a, e, t))
                })), this) : ts.call(i.data, e) ? i.data[e] : us(i, e) : us(i)
    },
    val: function (e) {
        const t = 0 === arguments.length,
        a = this[0];
        if (!a || !Pn(a))
            return t ? void 0 : this;
        switch (a.name) {
        case "textarea":
            return this.text(e);
        case "select": {
                const a = this.find("option:selected");
                if (!t) {
                    if (null == this.attr("multiple") && "object" == typeof e)
                        return this;
                    this.find("option").removeAttr("selected");
                    const t = "object" != typeof e ? [e] : e;
                    for (let e = 0; e < t.length; e++)
                        this.find(`option[value="${t[e]}"]`).attr("selected", "");
                    return this
                }
                return this.attr("multiple") ? a.toArray().map((e => Vi(e.children))) : a.attr("value")
            }
        case "input":
        case "option":
            return t ? this.attr("value") : this.attr("value", e)
        }
    },
    removeAttr: function (e) {
        const t = hs(e);
        for (let e = 0; e < t.length; e++)
            $i(this, (a => {
                    Pn(a) && ds(a, t[e])
                }));
        return this
    },
    hasClass: function (e) {
        return this.toArray().some((t => {
                const a = Pn(t) && t.attribs.class;
                let n = -1;
                if (a && e.length)
                    for (; (n = a.indexOf(e, n + 1)) > -1; ) {
                        const t = n + e.length;
                        if ((0 === n || as.test(a[n - 1])) && (t === a.length || as.test(a[t])))
                            return !0
                    }
                return !1
            }))
    },
    addClass: function e(t) {
        if ("function" == typeof t)
            return $i(this, ((a, n) => {
                    if (Pn(a)) {
                        const i = a.attribs.class || "";
                        e.call([a], t.call(a, n, i))
                    }
                }));
        if (!t || "string" != typeof t)
            return this;
        const a = t.split(as),
        n = this.length;
        for (let e = 0; e < n; e++) {
            const t = this[e];
            if (!Pn(t))
                continue;
            const n = os(t, "class", !1);
            if (n) {
                let e = ` ${n} `;
                for (let t = 0; t < a.length; t++) {
                    const n = `${a[t]} `;
                    e.includes(` ${n}`) || (e += n)
                }
                rs(t, "class", e.trim())
            } else
                rs(t, "class", a.join(" ").trim())
        }
        return this
    },
    removeClass: function e(t) {
        if ("function" == typeof t)
            return $i(this, ((a, n) => {
                    Pn(a) && e.call([a], t.call(a, n, a.attribs.class || ""))
                }));
        const a = hs(t),
        n = a.length,
        i = 0 === arguments.length;
        return $i(this, (e => {
                if (Pn(e))
                    if (i)
                        e.attribs.class = "";
                    else {
                        const t = hs(e.attribs.class);
                        let i = !1;
                        for (let e = 0; e < n; e++) {
                            const n = t.indexOf(a[e]);
                            n >= 0 && (t.splice(n, 1), i = !0, e--)
                        }
                        i && (e.attribs.class = t.join(" "))
                    }
            }))
    },
    toggleClass: function e(t, a) {
        if ("function" == typeof t)
            return $i(this, ((n, i) => {
                    Pn(n) && e.call([n], t.call(n, i, n.attribs.class || "", a), a)
                }));
        if (!t || "string" != typeof t)
            return this;
        const n = t.split(as),
        i = n.length,
        s = "boolean" == typeof a ? a ? 1 : -1 : 0,
        o = this.length;
        for (let e = 0; e < o; e++) {
            const t = this[e];
            if (!Pn(t))
                continue;
            const a = hs(t.attribs.class);
            for (let e = 0; e < i; e++) {
                const t = a.indexOf(n[e]);
                s >= 0 && t < 0 ? a.push(n[e]) : s <= 0 && t >= 0 && a.splice(t, 1)
            }
            t.attribs.class = a.join(" ")
        }
        return this
    }
});
!function (e) {
    e.Attribute = "attribute",
    e.Pseudo = "pseudo",
    e.PseudoElement = "pseudo-element",
    e.Tag = "tag",
    e.Universal = "universal",
    e.Adjacent = "adjacent",
    e.Child = "child",
    e.Descendant = "descendant",
    e.Parent = "parent",
    e.Sibling = "sibling",
    e.ColumnCombinator = "column-combinator"
}
(ms || (ms = {})), function (e) {
    e.Any = "any",
    e.Element = "element",
    e.End = "end",
    e.Equals = "equals",
    e.Exists = "exists",
    e.Hyphen = "hyphen",
    e.Not = "not",
    e.Start = "start"
}
(fs || (fs = {}));
const Es = /^[^\\#]?(?:\\(?:[\da-f]{1,6}\s?|.)|[\w\-\u00b0-\uFFFF])+/, gs = /\\([\da-f]{1,6}\s?|(\s)|.)/gi, bs = new Map([[126, fs.Element], [94, fs.Start], [36, fs.End], [42, fs.Any], [33, fs.Not], [124, fs.Hyphen]]), xs = new Set(["has", "not", "matches", "is", "where", "host", "host-context"]);
function Ts(e) {
    switch (e.type) {
    case ms.Adjacent:
    case ms.Child:
    case ms.Descendant:
    case ms.Parent:
    case ms.Sibling:
    case ms.ColumnCombinator:
        return !0;
    default:
        return !1
    }
}
const vs = new Set(["contains", "icontains"]);
function As(e, t, a) {
    const n = parseInt(t, 16) - 65536;
    return n != n || a ? t : n < 0 ? String.fromCharCode(n + 65536) : String.fromCharCode(n >> 10 | 55296, 1023 & n | 56320)
}
function ys(e) {
    return e.replace(gs, As)
}
function ws(e) {
    return 39 === e || 34 === e
}
function Ss(e) {
    return 32 === e || 9 === e || 10 === e || 12 === e || 13 === e
}
function Ns(e) {
    const t = [],
    a = Cs(t, `${e}`, 0);
    if (a < e.length)
        throw new Error(`Unmatched selector: ${e.slice(a)}`);
    return t
}
function Cs(e, t, a) {
    let n = [];
    function i(e) {
        const n = t.slice(a + e).match(Es);
        if (!n)
            throw new Error(`Expected name, found ${t.slice(a)}`);
        const [i] = n;
        return a += e + i.length,
        ys(i)
    }
    function s(e) {
        for (a += e; a < t.length && Ss(t.charCodeAt(a)); )
            a++
    }
    function o() {
        const e = a += 1;
        let n = 1;
        for (; n > 0 && a < t.length; a++)
            40 !== t.charCodeAt(a) || r(a) ? 41 !== t.charCodeAt(a) || r(a) || n-- : n++;
        if (n)
            throw new Error("Parenthesis not matched");
        return ys(t.slice(e, a - 1))
    }
    function r(e) {
        let a = 0;
        for (; 92 === t.charCodeAt(--e); )
            a++;
        return 1 == (1 & a)
    }
    function c() {
        if (n.length > 0 && Ts(n[n.length - 1]))
            throw new Error("Did not expect successive traversals.")
    }
    function l(e) {
        n.length > 0 && n[n.length - 1].type === ms.Descendant ? n[n.length - 1].type = e : (c(), n.push({
                    type: e
                }))
    }
    function p(e, t) {
        n.push({
            type: ms.Attribute,
            name: e,
            action: t,
            value: i(1),
            namespace: null,
            ignoreCase: "quirks"
        })
    }
    function u() {
        if (n.length && n[n.length - 1].type === ms.Descendant && n.pop(), 0 === n.length)
            throw new Error("Empty sub-selector");
        e.push(n)
    }
    if (s(0), t.length === a)
        return a;
    e: for (; a < t.length; ) {
        const e = t.charCodeAt(a);
        switch (e) {
        case 32:
        case 9:
        case 10:
        case 12:
        case 13:
            0 !== n.length && n[0].type === ms.Descendant || (c(), n.push({
                    type: ms.Descendant
                })),
            s(1);
            break;
        case 62:
            l(ms.Child),
            s(1);
            break;
        case 60:
            l(ms.Parent),
            s(1);
            break;
        case 126:
            l(ms.Sibling),
            s(1);
            break;
        case 43:
            l(ms.Adjacent),
            s(1);
            break;
        case 46:
            p("class", fs.Element);
            break;
        case 35:
            p("id", fs.Equals);
            break;
        case 91: {
                let e;
                s(1);
                let o = null;
                124 === t.charCodeAt(a) ? e = i(1) : t.startsWith("*|", a) ? (o = "*", e = i(2)) : (e = i(0), 124 === t.charCodeAt(a) && 61 !== t.charCodeAt(a + 1) && (o = e, e = i(1))),
                s(0);
                let c = fs.Exists;
                const l = bs.get(t.charCodeAt(a));
                if (l) {
                    if (c = l, 61 !== t.charCodeAt(a + 1))
                        throw new Error("Expected `=`");
                    s(2)
                } else
                    61 === t.charCodeAt(a) && (c = fs.Equals, s(1));
                let p = "",
                u = null;
                if ("exists" !== c) {
                    if (ws(t.charCodeAt(a))) {
                        const e = t.charCodeAt(a);
                        let n = a + 1;
                        for (; n < t.length && (t.charCodeAt(n) !== e || r(n)); )
                            n += 1;
                        if (t.charCodeAt(n) !== e)
                            throw new Error("Attribute value didn't end");
                        p = ys(t.slice(a + 1, n)),
                        a = n + 1
                    } else {
                        const e = a;
                        for (; a < t.length && (!Ss(t.charCodeAt(a)) && 93 !== t.charCodeAt(a) || r(a)); )
                            a += 1;
                        p = ys(t.slice(e, a))
                    }
                    s(0);
                    const e = 32 | t.charCodeAt(a);
                    115 === e ? (u = !1, s(1)) : 105 === e && (u = !0, s(1))
                }
                if (93 !== t.charCodeAt(a))
                    throw new Error("Attribute selector didn't terminate");
                a += 1;
                const d = {
                    type: ms.Attribute,
                    name: e,
                    action: c,
                    value: p,
                    namespace: o,
                    ignoreCase: u
                };
                n.push(d);
                break
            }
        case 58: {
                if (58 === t.charCodeAt(a + 1)) {
                    n.push({
                        type: ms.PseudoElement,
                        name: i(2).toLowerCase(),
                        data: 40 === t.charCodeAt(a) ? o() : null
                    });
                    continue
                }
                const e = i(1).toLowerCase();
                let s = null;
                if (40 === t.charCodeAt(a))
                    if (xs.has(e)) {
                        if (ws(t.charCodeAt(a + 1)))
                            throw new Error(`Pseudo-selector ${e} cannot be quoted`);
                        if (s = [], a = Cs(s, t, a + 1), 41 !== t.charCodeAt(a))
                            throw new Error(`Missing closing parenthesis in :${e} (${t})`);
                        a += 1
                    } else {
                        if (s = o(), vs.has(e)) {
                            const e = s.charCodeAt(0);
                            e === s.charCodeAt(s.length - 1) && ws(e) && (s = s.slice(1, -1))
                        }
                        s = ys(s)
                    }
                n.push({
                    type: ms.Pseudo,
                    name: e,
                    data: s
                });
                break
            }
        case 44:
            u(),
            n = [],
            s(1);
            break;
        default: {
                if (t.startsWith("/*", a)) {
                    const e = t.indexOf("*/", a + 2);
                    if (e < 0)
                        throw new Error("Comment was not terminated");
                    a = e + 2,
                    0 === n.length && s(0);
                    break
                }
                let o,
                r = null;
                if (42 === e)
                    a += 1, o = "*";
                else if (124 === e) {
                    if (o = "", 124 === t.charCodeAt(a + 1)) {
                        l(ms.ColumnCombinator),
                        s(2);
                        break
                    }
                } else {
                    if (!Es.test(t.slice(a)))
                        break e;
                    o = i(0)
                }
                124 === t.charCodeAt(a) && 124 !== t.charCodeAt(a + 1) && (r = o, 42 === t.charCodeAt(a + 1) ? (o = "*", a += 2) : o = i(1)),
                n.push("*" === o ? {
                    type: ms.Universal,
                    namespace: r
                }
                     : {
                    type: ms.Tag,
                    name: o,
                    namespace: r
                })
            }
        }
    }
    return u(),
    a
}
var Is = {
    trueFunc: function () {
        return !0
    },
    falseFunc: function () {
        return !1
    }
};
const ks = new Map([[ms.Universal, 50], [ms.Tag, 30], [ms.Attribute, 1], [ms.Pseudo, 0]]);
function Rs(e) {
    return !ks.has(e.type)
}
const Os = new Map([[fs.Exists, 10], [fs.Equals, 8], [fs.Not, 7], [fs.Start, 6], [fs.End, 6], [fs.Any, 5]]);
function Ds(e) {
    const t = e.map(Ls);
    for (let a = 1; a < e.length; a++) {
        const n = t[a];
        if (!(n < 0))
            for (let i = a - 1; i >= 0 && n < t[i]; i--) {
                const a = e[i + 1];
                e[i + 1] = e[i],
                e[i] = a,
                t[i + 1] = t[i],
                t[i] = n
            }
    }
}
function Ls(e) {
    var t,
    a;
    let n = null !== (t = ks.get(e.type)) && void 0 !== t ? t : -1;
    return e.type === ms.Attribute ? (n = null !== (a = Os.get(e.action)) && void 0 !== a ? a : 4, e.action === fs.Equals && "id" === e.name && (n = 9), e.ignoreCase && (n >>= 1)) : e.type === ms.Pseudo && (e.data ? "has" === e.name || "contains" === e.name ? n = 0 : Array.isArray(e.data) ? (n = Math.min(...e.data.map((e => Math.min(...e.map(Ls))))), n < 0 && (n = 0)) : n = 2 : n = 3),
    n
}
const Ms = /[-[\]{}()*+?.,\\^$|#\s]/g;
function Ps(e) {
    return e.replace(Ms, "\\$&")
}
const Bs = new Set(["accept", "accept-charset", "align", "alink", "axis", "bgcolor", "charset", "checked", "clear", "codetype", "color", "compact", "declare", "defer", "dir", "direction", "disabled", "enctype", "face", "frame", "hreflang", "http-equiv", "lang", "language", "link", "media", "method", "multiple", "nohref", "noresize", "noshade", "nowrap", "readonly", "rel", "rev", "rules", "scope", "scrolling", "selected", "shape", "target", "text", "type", "valign", "valuetype", "vlink"]);
function Us(e, t) {
    return "boolean" == typeof e.ignoreCase ? e.ignoreCase : "quirks" === e.ignoreCase ? !!t.quirksMode : !t.xmlMode && Bs.has(e.name)
}
const Fs = {
    equals(e, t, a) {
        const {
            adapter: n
        } = a, {
            name: i
        } = t;
        let {
            value: s
        } = t;
        return Us(t, a) ? (s = s.toLowerCase(), t => {
            const a = n.getAttributeValue(t, i);
            return null != a && a.length === s.length && a.toLowerCase() === s && e(t)
        }) : t => n.getAttributeValue(t, i) === s && e(t)
    },
    hyphen(e, t, a) {
        const {
            adapter: n
        } = a, {
            name: i
        } = t;
        let {
            value: s
        } = t;
        const o = s.length;
        return Us(t, a) ? (s = s.toLowerCase(), function (t) {
            const a = n.getAttributeValue(t, i);
            return null != a && (a.length === o || "-" === a.charAt(o)) && a.substr(0, o).toLowerCase() === s && e(t)
        }) : function (t) {
            const a = n.getAttributeValue(t, i);
            return null != a && (a.length === o || "-" === a.charAt(o)) && a.substr(0, o) === s && e(t)
        }
    },
    element(e, t, a) {
        const {
            adapter: n
        } = a, {
            name: i,
            value: s
        } = t;
        if (/\s/.test(s))
            return Is.falseFunc;
        const o = new RegExp(`(?:^|\\s)${Ps(s)}(?:$|\\s)`, Us(t, a) ? "i" : "");
        return function (t) {
            const a = n.getAttributeValue(t, i);
            return null != a && a.length >= s.length && o.test(a) && e(t)
        }
    },
    exists: (e, {
        name: t
    }, {
        adapter: a
    }) => n => a.hasAttrib(n, t) && e(n),
    start(e, t, a) {
        const {
            adapter: n
        } = a, {
            name: i
        } = t;
        let {
            value: s
        } = t;
        const o = s.length;
        return 0 === o ? Is.falseFunc : Us(t, a) ? (s = s.toLowerCase(), t => {
            const a = n.getAttributeValue(t, i);
            return null != a && a.length >= o && a.substr(0, o).toLowerCase() === s && e(t)
        }) : t => {
            var a;
            return !!(null === (a = n.getAttributeValue(t, i)) || void 0 === a ? void 0 : a.startsWith(s)) && e(t)
        }
    },
    end(e, t, a) {
        const {
            adapter: n
        } = a, {
            name: i
        } = t;
        let {
            value: s
        } = t;
        const o = -s.length;
        return 0 === o ? Is.falseFunc : Us(t, a) ? (s = s.toLowerCase(), t => {
            var a;
            return (null === (a = n.getAttributeValue(t, i)) || void 0 === a ? void 0 : a.substr(o).toLowerCase()) === s && e(t)
        }) : t => {
            var a;
            return !!(null === (a = n.getAttributeValue(t, i)) || void 0 === a ? void 0 : a.endsWith(s)) && e(t)
        }
    },
    any(e, t, a) {
        const {
            adapter: n
        } = a, {
            name: i,
            value: s
        } = t;
        if ("" === s)
            return Is.falseFunc;
        if (Us(t, a)) {
            const t = new RegExp(Ps(s), "i");
            return function (a) {
                const o = n.getAttributeValue(a, i);
                return null != o && o.length >= s.length && t.test(o) && e(a)
            }
        }
        return t => {
            var a;
            return !!(null === (a = n.getAttributeValue(t, i)) || void 0 === a ? void 0 : a.includes(s)) && e(t)
        }
    },
    not(e, t, a) {
        const {
            adapter: n
        } = a, {
            name: i
        } = t;
        let {
            value: s
        } = t;
        return "" === s ? t => !!n.getAttributeValue(t, i) && e(t) : Us(t, a) ? (s = s.toLowerCase(), t => {
            const a = n.getAttributeValue(t, i);
            return (null == a || a.length !== s.length || a.toLowerCase() !== s) && e(t)
        }) : t => n.getAttributeValue(t, i) !== s && e(t)
    }
}, Hs = new Set([9, 10, 12, 13, 32]), js = "0".charCodeAt(0), zs = "9".charCodeAt(0);
function Gs(e) {
    return function (e) {
        const t = e[0],
        a = e[1] - 1;
        if (a < 0 && t <= 0)
            return Is.falseFunc;
        if (-1 === t)
            return e => e <= a;
        if (0 === t)
            return e => e === a;
        if (1 === t)
            return a < 0 ? Is.trueFunc : e => e >= a;
        const n = Math.abs(t),
        i = (a % n + n) % n;
        return t > 1 ? e => e >= a && e % n === i : e => e <= a && e % n === i
    }
    (function (e) {
        if ("even" === (e = e.trim().toLowerCase()))
            return [2, 0];
        if ("odd" === e)
            return [2, 1];
        let t = 0,
        a = 0,
        n = s(),
        i = o();
        if (t < e.length && "n" === e.charAt(t) && (t++, a = n * (null != i ? i : 1), r(), t < e.length ? (n = s(), r(), i = o()) : n = i = 0), null === i || t < e.length)
            throw new Error(`n-th rule couldn't be parsed ('${e}')`);
        return [a, n * i];
        function s() {
            return "-" === e.charAt(t) ? (t++, -1) : ("+" === e.charAt(t) && t++, 1)
        }
        function o() {
            const a = t;
            let n = 0;
            for (; t < e.length && e.charCodeAt(t) >= js && e.charCodeAt(t) <= zs; )
                n = 10 * n + (e.charCodeAt(t) - js), t++;
            return t === a ? null : n
        }
        function r() {
            for (; t < e.length && Hs.has(e.charCodeAt(t)); )
                t++
        }
    }
        (e))
}
function qs(e, t) {
    return a => {
        const n = t.getParent(a);
        return null != n && t.isTag(n) && e(a)
    }
}
const Ys = {
    contains: (e, t, {
        adapter: a
    }) => function (n) {
        return e(n) && a.getText(n).includes(t)
    },
    icontains(e, t, {
        adapter: a
    }) {
        const n = t.toLowerCase();
        return function (t) {
            return e(t) && a.getText(t).toLowerCase().includes(n)
        }
    },
    "nth-child"(e, t, {
        adapter: a,
        equals: n
    }) {
        const i = Gs(t);
        return i === Is.falseFunc ? Is.falseFunc : i === Is.trueFunc ? qs(e, a) : function (t) {
            const s = a.getSiblings(t);
            let o = 0;
            for (let e = 0; e < s.length && !n(t, s[e]); e++)
                a.isTag(s[e]) && o++;
            return i(o) && e(t)
        }
    },
    "nth-last-child"(e, t, {
        adapter: a,
        equals: n
    }) {
        const i = Gs(t);
        return i === Is.falseFunc ? Is.falseFunc : i === Is.trueFunc ? qs(e, a) : function (t) {
            const s = a.getSiblings(t);
            let o = 0;
            for (let e = s.length - 1; e >= 0 && !n(t, s[e]); e--)
                a.isTag(s[e]) && o++;
            return i(o) && e(t)
        }
    },
    "nth-of-type"(e, t, {
        adapter: a,
        equals: n
    }) {
        const i = Gs(t);
        return i === Is.falseFunc ? Is.falseFunc : i === Is.trueFunc ? qs(e, a) : function (t) {
            const s = a.getSiblings(t);
            let o = 0;
            for (let e = 0; e < s.length; e++) {
                const i = s[e];
                if (n(t, i))
                    break;
                a.isTag(i) && a.getName(i) === a.getName(t) && o++
            }
            return i(o) && e(t)
        }
    },
    "nth-last-of-type"(e, t, {
        adapter: a,
        equals: n
    }) {
        const i = Gs(t);
        return i === Is.falseFunc ? Is.falseFunc : i === Is.trueFunc ? qs(e, a) : function (t) {
            const s = a.getSiblings(t);
            let o = 0;
            for (let e = s.length - 1; e >= 0; e--) {
                const i = s[e];
                if (n(t, i))
                    break;
                a.isTag(i) && a.getName(i) === a.getName(t) && o++
            }
            return i(o) && e(t)
        }
    },
    root: (e, t, {
        adapter: a
    }) => t => {
        const n = a.getParent(t);
        return (null == n || !a.isTag(n)) && e(t)
    },
    scope(e, t, a, n) {
        const {
            equals: i
        } = a;
        return n && 0 !== n.length ? 1 === n.length ? t => i(n[0], t) && e(t) : t => n.includes(t) && e(t) : Ys.root(e, t, a)
    },
    hover: Vs("isHovered"),
    visited: Vs("isVisited"),
    active: Vs("isActive")
};
function Vs(e) {
    return function (t, a, {
        adapter: n
    }) {
        const i = n[e];
        return "function" != typeof i ? Is.falseFunc : function (e) {
            return i(e) && t(e)
        }
    }
}
const Qs = {
    empty: (e, {
        adapter: t
    }) => !t.getChildren(e).some((e => t.isTag(e) || "" !== t.getText(e))),
    "first-child"(e, {
        adapter: t,
        equals: a
    }) {
        if (t.prevElementSibling)
            return null == t.prevElementSibling(e);
        const n = t.getSiblings(e).find((e => t.isTag(e)));
        return null != n && a(e, n)
    },
    "last-child"(e, {
        adapter: t,
        equals: a
    }) {
        const n = t.getSiblings(e);
        for (let i = n.length - 1; i >= 0; i--) {
            if (a(e, n[i]))
                return !0;
            if (t.isTag(n[i]))
                break
        }
        return !1
    },
    "first-of-type"(e, {
        adapter: t,
        equals: a
    }) {
        const n = t.getSiblings(e),
        i = t.getName(e);
        for (let s = 0; s < n.length; s++) {
            const o = n[s];
            if (a(e, o))
                return !0;
            if (t.isTag(o) && t.getName(o) === i)
                break
        }
        return !1
    },
    "last-of-type"(e, {
        adapter: t,
        equals: a
    }) {
        const n = t.getSiblings(e),
        i = t.getName(e);
        for (let s = n.length - 1; s >= 0; s--) {
            const o = n[s];
            if (a(e, o))
                return !0;
            if (t.isTag(o) && t.getName(o) === i)
                break
        }
        return !1
    },
    "only-of-type"(e, {
        adapter: t,
        equals: a
    }) {
        const n = t.getName(e);
        return t.getSiblings(e).every((i => a(e, i) || !t.isTag(i) || t.getName(i) !== n))
    },
    "only-child": (e, {
        adapter: t,
        equals: a
    }) => t.getSiblings(e).every((n => a(e, n) || !t.isTag(n)))
};
function Ws(e, t, a, n) {
    if (null === a) {
        if (e.length > n)
            throw new Error(`Pseudo-class :${t} requires an argument`)
    } else if (e.length === n)
        throw new Error(`Pseudo-class :${t} doesn't have any arguments`)
}
const Ks = {
    "any-link": ":is(a, area, link)[href]",
    link: ":any-link:not(:visited)",
    disabled: ":is(\n        :is(button, input, select, textarea, optgroup, option)[disabled],\n        optgroup[disabled] > option,\n        fieldset[disabled]:not(fieldset[disabled] legend:first-of-type *)\n    )",
    enabled: ":not(:disabled)",
    checked: ":is(:is(input[type=radio], input[type=checkbox])[checked], option:selected)",
    required: ":is(input, select, textarea)[required]",
    optional: ":is(input, select, textarea):not([required])",
    selected: "option:is([selected], select:not([multiple]):not(:has(> option[selected])) > :first-of-type)",
    checkbox: "[type=checkbox]",
    file: "[type=file]",
    password: "[type=password]",
    radio: "[type=radio]",
    reset: "[type=reset]",
    image: "[type=image]",
    submit: "[type=submit]",
    parent: ":not(:empty)",
    header: ":is(h1, h2, h3, h4, h5, h6)",
    button: ":is(button, input[type=button])",
    input: ":is(input, textarea, select, button)",
    text: "input:is(:not([type!='']), [type=text])"
}, Zs = {};
function Xs(e, t) {
    const a = t.getSiblings(e);
    if (a.length <= 1)
        return [];
    const n = a.indexOf(e);
    return n < 0 || n === a.length - 1 ? [] : a.slice(n + 1).filter(t.isTag)
}
function $s(e) {
    return {
        xmlMode: !!e.xmlMode,
        lowerCaseAttributeNames: !!e.lowerCaseAttributeNames,
        lowerCaseTags: !!e.lowerCaseTags,
        quirksMode: !!e.quirksMode,
        cacheResults: !!e.cacheResults,
        pseudos: e.pseudos,
        adapter: e.adapter,
        equals: e.equals
    }
}
const Js = (e, t, a, n, i) => {
    const s = i(t, $s(a), n);
    return s === Is.trueFunc ? e : s === Is.falseFunc ? Is.falseFunc : t => s(t) && e(t)
}, eo = {
    is: Js,
    matches: Js,
    where: Js,
    not(e, t, a, n, i) {
        const s = i(t, $s(a), n);
        return s === Is.falseFunc ? e : s === Is.trueFunc ? Is.falseFunc : t => !s(t) && e(t)
    },
    has(e, t, a, n, i) {
        const {
            adapter: s
        } = a,
        o = $s(a);
        o.relativeSelector = !0;
        const r = t.some((e => e.some(Rs))) ? [Zs] : void 0,
        c = i(t, o, r);
        if (c === Is.falseFunc)
            return Is.falseFunc;
        const l = function (e, t) {
            return e === Is.falseFunc ? Is.falseFunc : a => t.isTag(a) && e(a)
        }
        (c, s);
        if (r && c !== Is.trueFunc) {
            const {
                shouldTestNextSiblings: t = !1
            } = c;
            return a => {
                if (!e(a))
                    return !1;
                r[0] = a;
                const n = s.getChildren(a),
                i = t ? [...n, ...Xs(a, s)] : n;
                return s.existsOne(l, i)
            }
        }
        return t => e(t) && s.existsOne(l, s.getChildren(t))
    }
};
function to(e, t) {
    const a = t.getParent(e);
    return a && t.isTag(a) ? a : null
}
function ao(e) {
    return e.type === ms.Pseudo && ("scope" === e.name || Array.isArray(e.data) && e.data.some((e => e.some(ao))))
}
const no = {
    type: ms.Descendant
}, io = {
    type: "_flexibleDescendant"
}, so = {
    type: ms.Pseudo,
    name: "scope",
    data: null
};
function oo(e, t) {
    return t === Is.falseFunc || e === Is.trueFunc ? e : e === Is.falseFunc || t === Is.trueFunc ? t : function (a) {
        return e(a) || t(a)
    }
}
const ro = (e, t) => e === t, co = {
    adapter: qi,
    equals: ro
}, lo = (po = function e(t, a, n) {
    var i;
    t.forEach(Ds),
    n = null !== (i = a.context) && void 0 !== i ? i : n;
    const s = Array.isArray(n),
    o = n && (Array.isArray(n) ? n : [n]);
    if (!1 !== a.relativeSelector)
        !function (e, {
            adapter: t
        }, a) {
            const n = !!(null == a ? void 0 : a.every((e => {
                        const a = t.isTag(e) && t.getParent(e);
                        return e === Zs || a && t.isTag(a)
                    })));
            for (const t of e) {
                if (t.length > 0 && Rs(t[0]) && t[0].type !== ms.Descendant);
                else {
                    if (!n || t.some(ao))
                        continue;
                    t.unshift(no)
                }
                t.unshift(so)
            }
        }
    (t, a, o);
    else if (t.some((e => e.length > 0 && Rs(e[0]))))
        throw new Error("Relative selectors are not allowed when the `relativeSelector` option is disabled");
    let r = !1;
    const c = t.map((t => {
                if (t.length >= 2) {
                    const [e, a] = t;
                    e.type !== ms.Pseudo || "scope" !== e.name || (s && a.type === ms.Descendant ? t[1] = io : a.type !== ms.Adjacent && a.type !== ms.Sibling || (r = !0))
                }
                return function (t, a, n) {
                    var i;
                    return t.reduce(((t, i) => t === Is.falseFunc ? Is.falseFunc : function (e, t, a, n, i) {
                            const {
                                adapter: s,
                                equals: o
                            } = a;
                            switch (t.type) {
                            case ms.PseudoElement:
                                throw new Error("Pseudo-elements are not supported by css-select");
                            case ms.ColumnCombinator:
                                throw new Error("Column combinators are not yet supported by css-select");
                            case ms.Attribute:
                                if (null != t.namespace)
                                    throw new Error("Namespaced attributes are not yet supported by css-select");
                                return a.xmlMode && !a.lowerCaseAttributeNames || (t.name = t.name.toLowerCase()),
                                Fs[t.action](e, t, a);
                            case ms.Pseudo:
                                return function (e, t, a, n, i) {
                                    var s;
                                    const {
                                        name: o,
                                        data: r
                                    } = t;
                                    if (Array.isArray(r)) {
                                        if (!(o in eo))
                                            throw new Error(`Unknown pseudo-class :${o}(${r})`);
                                        return eo[o](e, r, a, n, i)
                                    }
                                    const c = null === (s = a.pseudos) || void 0 === s ? void 0 : s[o],
                                    l = "string" == typeof c ? c : Ks[o];
                                    if ("string" == typeof l) {
                                        if (null != r)
                                            throw new Error(`Pseudo ${o} doesn't have any arguments`);
                                        const t = Ns(l);
                                        return eo.is(e, t, a, n, i)
                                    }
                                    if ("function" == typeof c)
                                        return Ws(c, o, r, 1), t => c(t, r) && e(t);
                                    if (o in Ys)
                                        return Ys[o](e, r, a, n);
                                    if (o in Qs) {
                                        const t = Qs[o];
                                        return Ws(t, o, r, 2),
                                        n => t(n, a, r) && e(n)
                                    }
                                    throw new Error(`Unknown pseudo-class :${o}`)
                                }
                                (e, t, a, n, i);
                            case ms.Tag: {
                                    if (null != t.namespace)
                                        throw new Error("Namespaced tag names are not yet supported by css-select");
                                    let {
                                        name: n
                                    } = t;
                                    return a.xmlMode && !a.lowerCaseTags || (n = n.toLowerCase()),
                                    function (t) {
                                        return s.getName(t) === n && e(t)
                                    }
                                }
                            case ms.Descendant: {
                                    if (!1 === a.cacheResults || "undefined" == typeof WeakSet)
                                        return function (t) {
                                            let a = t;
                                            for (; a = to(a, s); )
                                                if (e(a))
                                                    return !0;
                                            return !1
                                        };
                                    const t = new WeakSet;
                                    return function (a) {
                                        let n = a;
                                        for (; n = to(n, s); )
                                            if (!t.has(n)) {
                                                if (s.isTag(n) && e(n))
                                                    return !0;
                                                t.add(n)
                                            }
                                        return !1
                                    }
                                }
                            case "_flexibleDescendant":
                                return function (t) {
                                    let a = t;
                                    do {
                                        if (e(a))
                                            return !0
                                    } while (a = to(a, s));
                                    return !1
                                };
                            case ms.Parent:
                                return function (t) {
                                    return s.getChildren(t).some((t => s.isTag(t) && e(t)))
                                };
                            case ms.Child:
                                return function (t) {
                                    const a = s.getParent(t);
                                    return null != a && s.isTag(a) && e(a)
                                };
                            case ms.Sibling:
                                return function (t) {
                                    const a = s.getSiblings(t);
                                    for (let n = 0; n < a.length; n++) {
                                        const i = a[n];
                                        if (o(t, i))
                                            break;
                                        if (s.isTag(i) && e(i))
                                            return !0
                                    }
                                    return !1
                                };
                            case ms.Adjacent:
                                return s.prevElementSibling ? function (t) {
                                    const a = s.prevElementSibling(t);
                                    return null != a && e(a)
                                }
                                 : function (t) {
                                    const a = s.getSiblings(t);
                                    let n;
                                    for (let e = 0; e < a.length; e++) {
                                        const i = a[e];
                                        if (o(t, i))
                                            break;
                                        s.isTag(i) && (n = i)
                                    }
                                    return !!n && e(n)
                                };
                            case ms.Universal:
                                if (null != t.namespace && "*" !== t.namespace)
                                    throw new Error("Namespaced universal selectors are not yet supported by css-select");
                                return e
                            }
                        }
                            (t, i, a, n, e)), null !== (i = a.rootFunc) && void 0 !== i ? i : Is.trueFunc)
                }
                (t, a, o)
            })).reduce(oo, Is.falseFunc);
    return c.shouldTestNextSiblings = r,
    c
}, function (e, t, a) {
    const n = function (e) {
        var t,
        a,
        n,
        i;
        const s = null != e ? e : co;
        return null !== (t = s.adapter) && void 0 !== t || (s.adapter = qi),
        null !== (a = s.equals) && void 0 !== a || (s.equals = null !== (i = null === (n = s.adapter) || void 0 === n ? void 0 : n.equals) && void 0 !== i ? i : ro),
        s
    }
    (t);
    return po(e, n, a)
});
var po;
function uo(e, t, a = !1) {
    return a && (e = function (e, t) {
        const a = Array.isArray(e) ? e.slice(0) : [e],
        n = a.length;
        for (let e = 0; e < n; e++) {
            const n = Xs(a[e], t);
            a.push(...n)
        }
        return a
    }
        (e, t)),
    Array.isArray(e) ? t.removeSubsets(e) : t.getChildren(e)
}
const ho = new Set(["first", "last", "eq", "gt", "nth", "lt", "even", "odd"]);
function mo(e) {
    return "pseudo" === e.type && (!!ho.has(e.name) || !("not" !== e.name || !Array.isArray(e.data)) && e.data.some((e => e.some(mo))))
}
function fo(e) {
    const t = [],
    a = [];
    for (const n of e)
        n.some(mo) ? t.push(n) : a.push(n);
    return [a, t]
}
const _o = {
    type: ms.Universal,
    namespace: null
}, Eo = {
    type: ms.Pseudo,
    name: "scope",
    data: null
};
function go(e, t, a = {}) {
    return bo([e], t, a)
}
function bo(e, t, a = {}) {
    if ("function" == typeof t)
        return e.some(t);
    const [n, i] = fo(Ns(t));
    return n.length > 0 && e.some(lo(n, a)) || i.some((t => vo(t, e, a).length > 0))
}
function xo(e, t, a = {}) {
    return To(Ns(e), t, a)
}
function To(e, t, a) {
    if (0 === t.length)
        return [];
    const [n, i] = fo(e);
    let s;
    if (n.length) {
        const e = So(t, n, a);
        if (0 === i.length)
            return e;
        e.length && (s = new Set(e))
    }
    for (let e = 0; e < i.length && (null == s ? void 0 : s.size) !== t.length; e++) {
        const n = i[e];
        if (0 === (s ? t.filter((e => Pn(e) && !s.has(e))) : t).length)
            break;
        const o = vo(n, t, a);
        if (o.length)
            if (s)
                o.forEach((e => s.add(e)));
            else {
                if (e === i.length - 1)
                    return o;
                s = new Set(o)
            }
    }
    return void 0 !== s ? s.size === t.length ? t : t.filter((e => s.has(e))) : []
}
function vo(e, t, a) {
    var n;
    if (e.some(Ts)) {
        const i = null !== (n = a.root) && void 0 !== n ? n : function (e) {
            for (; e.parent; )
                e = e.parent;
            return e
        }
        (t[0]),
        s = {
            ...a,
            context: t,
            relativeSelector: !1
        };
        return e.push(Eo),
        Ao(i, e, s, !0, t.length)
    }
    return Ao(t, e, a, !1, t.length)
}
function Ao(e, t, a, n, i) {
    const s = t.findIndex(mo),
    o = t.slice(0, s),
    r = t[s],
    c = t.length - 1 === s ? i : 1 / 0,
    l = function (e, t, a) {
        const n = null != t ? parseInt(t, 10) : NaN;
        switch (e) {
        case "first":
            return 1;
        case "nth":
        case "eq":
            return isFinite(n) ? n >= 0 ? n + 1 : 1 / 0 : 0;
        case "lt":
            return isFinite(n) ? n >= 0 ? Math.min(n, a) : 1 / 0 : 0;
        case "gt":
            return isFinite(n) ? 1 / 0 : 0;
        case "odd":
            return 2 * a;
        case "even":
            return 2 * a - 1;
        case "last":
        case "not":
            return 1 / 0
        }
    }
    (r.name, r.data, c);
    if (0 === l)
        return [];
    const p = (0 !== o.length || Array.isArray(e) ? 0 === o.length ? (Array.isArray(e) ? e : [e]).filter(Pn) : n || o.some(Ts) ? yo(e, [o], a, l) : So(e, [o], a) : xi(e).filter(Pn)).slice(0, l);
    let u = function (e, t, a, n) {
        const i = "string" == typeof a ? parseInt(a, 10) : NaN;
        switch (e) {
        case "first":
        case "lt":
            return t;
        case "last":
            return t.length > 0 ? [t[t.length - 1]] : t;
        case "nth":
        case "eq":
            return isFinite(i) && Math.abs(i) < t.length ? [i < 0 ? t[t.length + i] : t[i]] : [];
        case "gt":
            return isFinite(i) ? t.slice(i + 1) : [];
        case "even":
            return t.filter(((e, t) => t % 2 == 0));
        case "odd":
            return t.filter(((e, t) => t % 2 == 1));
        case "not": {
                const e = new Set(To(a, t, n));
                return t.filter((t => !e.has(t)))
            }
        }
    }
    (r.name, p, r.data, a);
    if (0 === u.length || t.length === s + 1)
        return u;
    const d = t.slice(s + 1),
    h = d.some(Ts);
    if (h) {
        if (Ts(d[0])) {
            const {
                type: e
            } = d[0];
            e !== ms.Sibling && e !== ms.Adjacent || (u = uo(u, qi, !0)),
            d.unshift(_o)
        }
        a = {
            ...a,
            relativeSelector: !1,
            rootFunc: e => u.includes(e)
        }
    } else
        a.rootFunc && a.rootFunc !== Is.trueFunc && (a = {
                ...a,
                rootFunc: Is.trueFunc
            });
    return d.some(mo) ? Ao(u, d, a, !1, i) : h ? yo(u, [d], a, i) : So(u, [d], a)
}
function yo(e, t, a, n) {
    return wo(e, lo(t, a, e), n)
}
function wo(e, t, a = 1 / 0) {
    return Ni((e => Pn(e) && t(e)), uo(e, qi, t.shouldTestNextSiblings), !0, a)
}
function So(e, t, a) {
    const n = (Array.isArray(e) ? e : [e]).filter(Pn);
    if (0 === n.length)
        return n;
    const i = lo(t, a);
    return i === Is.trueFunc ? n : n.filter(i)
}
const No = /^\s*[~+]/;
function Co(e) {
    return function (t, ...a) {
        return function (n) {
            var i;
            let s = e(t, this);
            return n && (s = Yo(s, n, this.options.xmlMode, null === (i = this._root) || void 0 === i ? void 0 : i[0])),
            this._make(this.length > 1 && s.length > 1 ? a.reduce(((e, t) => t(e)), s) : s)
        }
    }
}
const Io = Co(((e, t) => {
            const a = [];
            for (let n = 0; n < t.length; n++) {
                const i = e(t[n]);
                a.push(i)
            }
            return (new Array).concat(...a)
        })), ko = Co(((e, t) => {
            const a = [];
            for (let n = 0; n < t.length; n++) {
                const i = e(t[n]);
                null !== i && a.push(i)
            }
            return a
        }));
function Ro(e, ...t) {
    let a = null;
    const n = Co(((e, t) => {
                const n = [];
                return $i(t, (t => {
                        for (let i; (i = e(t)) && !(null == a ? void 0 : a(i, n.length)); t = i)
                            n.push(i)
                    })),
                n
            }))(e, ...t);
    return function (e, t) {
        a = "string" == typeof e ? t => go(t, e, this.options) : e ? qo(e) : null;
        const i = n.call(this, t);
        return a = null,
        i
    }
}
function Oo(e) {
    return Array.from(new Set(e))
}
const Do = ko((({
                parent: e
            }) => e && !jn(e) ? e : null), Oo), Lo = Io((e => {
            const t = [];
            for (; e.parent && !jn(e.parent); )
                t.push(e.parent), e = e.parent;
            return t
        }), Pi, (e => e.reverse())), Mo = Ro((({
                parent: e
            }) => e && !jn(e) ? e : null), Pi, (e => e.reverse())), Po = ko((e => Ai(e))), Bo = Io((e => {
            const t = [];
            for (; e.next; )
                Pn(e = e.next) && t.push(e);
            return t
        }), Oo), Uo = Ro((e => Ai(e)), Oo), Fo = ko((e => yi(e))), Ho = Io((e => {
            const t = [];
            for (; e.prev; )
                Pn(e = e.prev) && t.push(e);
            return t
        }), Oo), jo = Ro((e => yi(e)), Oo), zo = Io((e => vi(e).filter((t => Pn(t) && t !== e))), Pi), Go = Io((e => xi(e).filter(Pn)), Oo);
function qo(e) {
    return "function" == typeof e ? (t, a) => e.call(t, a, t) : Xi(e) ? t => Array.prototype.includes.call(e, t) : function (t) {
        return e === t
    }
}
function Yo(e, t, a, n) {
    return "string" == typeof t ? xo(t, e, {
        xmlMode: a,
        root: n
    }) : e.filter(qo(t))
}
var Vo = Object.freeze({
    __proto__: null,
    find: function (e) {
        var t;
        if (!e)
            return this._make([]);
        const a = this.toArray();
        if ("string" != typeof e) {
            const t = Xi(e) ? e.toArray() : [e];
            return this._make(t.filter((e => a.some((t => Qi(t, e))))))
        }
        const n = No.test(e) ? a : this.children().toArray(),
        i = {
            context: a,
            root: null === (t = this._root) || void 0 === t ? void 0 : t[0],
            xmlMode: this.options.xmlMode,
            lowerCaseTags: this.options.lowerCaseTags,
            lowerCaseAttributeNames: this.options.lowerCaseAttributeNames,
            pseudos: this.options.pseudos,
            quirksMode: this.options.quirksMode
        };
        return this._make(function (e, t, a = {}, n = 1 / 0) {
            if ("function" == typeof e)
                return wo(t, e);
            const [i, s] = fo(Ns(e)),
            o = s.map((e => Ao(t, e, a, !0, n)));
            return i.length && o.push(yo(t, i, a, n)),
            0 === o.length ? [] : 1 === o.length ? o[0] : Pi(o.reduce(((e, t) => [...e, ...t])))
        }
            (e, n, i))
    },
    parent: Do,
    parents: Lo,
    parentsUntil: Mo,
    closest: function (e) {
        var t;
        const a = [];
        if (!e)
            return this._make(a);
        const n = {
            xmlMode: this.options.xmlMode,
            root: null === (t = this._root) || void 0 === t ? void 0 : t[0]
        },
        i = "string" == typeof e ? t => go(t, e, n) : qo(e);
        return $i(this, (e => {
                for (; e && Pn(e); ) {
                    if (i(e, 0)) {
                        a.includes(e) || a.push(e);
                        break
                    }
                    e = e.parent
                }
            })),
        this._make(a)
    },
    next: Po,
    nextAll: Bo,
    nextUntil: Uo,
    prev: Fo,
    prevAll: Ho,
    prevUntil: jo,
    siblings: zo,
    children: Go,
    contents: function () {
        const e = this.toArray().reduce(((e, t) => zn(t) ? e.concat(t.children) : e), []);
        return this._make(e)
    },
    each: function (e) {
        let t = 0;
        const a = this.length;
        for (; t < a && !1 !== e.call(this[t], t, this[t]); )
            ++t;
        return this
    },
    map: function (e) {
        let t = [];
        for (let a = 0; a < this.length; a++) {
            const n = this[a],
            i = e.call(n, a, n);
            null != i && (t = t.concat(i))
        }
        return this._make(t)
    },
    filter: function (e) {
        var t;
        return this._make(Yo(this.toArray(), e, this.options.xmlMode, null === (t = this._root) || void 0 === t ? void 0 : t[0]))
    },
    filterArray: Yo,
    is: function (e) {
        const t = this.toArray();
        return "string" == typeof e ? bo(t.filter(Pn), e, this.options) : !!e && t.some(qo(e))
    },
    not: function (e) {
        let t = this.toArray();
        if ("string" == typeof e) {
            const a = new Set(xo(e, t, this.options));
            t = t.filter((e => !a.has(e)))
        } else {
            const a = qo(e);
            t = t.filter(((e, t) => !a(e, t)))
        }
        return this._make(t)
    },
    has: function (e) {
        return this.filter("string" == typeof e ? `:has(${e})` : (t, a) => this._make(a).find(e).length > 0)
    },
    first: function () {
        return this.length > 1 ? this._make(this[0]) : this
    },
    last: function () {
        return this.length > 0 ? this._make(this[this.length - 1]) : this
    },
    eq: function (e) {
        var t;
        return 0 == (e = +e) && this.length <= 1 ? this : (e < 0 && (e = this.length + e), this._make(null !== (t = this[e]) && void 0 !== t ? t : []))
    },
    get: function (e) {
        return null == e ? this.toArray() : this[e < 0 ? this.length + e : e]
    },
    toArray: function () {
        return Array.prototype.slice.call(this)
    },
    index: function (e) {
        let t,
        a;
        return null == e ? (t = this.parent().children(), a = this[0]) : "string" == typeof e ? (t = this._make(e), a = this[0]) : (t = this, a = Xi(e) ? e[0] : e),
        Array.prototype.indexOf.call(t, a)
    },
    slice: function (e, t) {
        return this._make(Array.prototype.slice.call(this, e, t))
    },
    end: function () {
        var e;
        return null !== (e = this.prevObject) && void 0 !== e ? e : this._make([])
    },
    add: function (e, t) {
        const a = this._make(e, t),
        n = Pi([...this.get(), ...a.get()]);
        return this._make(n)
    },
    addBack: function (e) {
        return this.prevObject ? this.add(e ? this.prevObject.filter(e) : this.prevObject) : this
    }
});
function Qo(e, t) {
    const a = Array.isArray(e) ? e : [e];
    t ? t.children = a : t = null;
    for (let e = 0; e < a.length; e++) {
        const n = a[e];
        n.parent && n.parent.children !== a && wi(n),
        t ? (n.prev = a[e - 1] || null, n.next = a[e + 1] || null) : n.prev = n.next = null,
        n.parent = t
    }
    return t
}
function Wo(e) {
    return function (...t) {
        const a = this.length - 1;
        return $i(this, ((n, i) => {
                if (!zn(n))
                    return;
                const s = "function" == typeof t[0] ? t[0].call(n, i, this._render(n.children)) : t,
                o = this._makeDomArray(s, i < a);
                e(o, n.children, n)
            }))
    }
}
function Ko(e, t, a, n, i) {
    var s,
    o;
    const r = [t, a, ...n],
    c = 0 === t ? null : e[t - 1],
    l = t + a >= e.length ? null : e[t + a];
    for (let e = 0; e < n.length; ++e) {
        const a = n[e],
        p = a.parent;
        if (p) {
            const e = p.children.indexOf(a);
            e > -1 && (p.children.splice(e, 1), i === p && t > e && r[0]--)
        }
        a.parent = i,
        a.prev && (a.prev.next = null !== (s = a.next) && void 0 !== s ? s : null),
        a.next && (a.next.prev = null !== (o = a.prev) && void 0 !== o ? o : null),
        a.prev = 0 === e ? c : n[e - 1],
        a.next = e === n.length - 1 ? l : n[e + 1]
    }
    return c && (c.next = n[0]),
    l && (l.prev = n[n.length - 1]),
    e.splice(...r)
}
const Zo = Wo(((e, t, a) => {
            Ko(t, t.length, 0, e, a)
        })), Xo = Wo(((e, t, a) => {
            Ko(t, 0, 0, e, a)
        }));
function $o(e) {
    return function (t) {
        const a = this.length - 1,
        n = this.parents().last();
        for (let i = 0; i < this.length; i++) {
            const s = this[i],
            o = "function" == typeof t ? t.call(s, i, s) : "string" != typeof t || es(t) ? t : n.find(t).clone(),
            [r] = this._makeDomArray(o, i < a);
            if (!r || !zn(r))
                continue;
            let c = r,
            l = 0;
            for (; l < c.children.length; ) {
                const e = c.children[l];
                Pn(e) ? (c = e, l = 0) : l++
            }
            e(s, c, [r])
        }
        return this
    }
}
const Jo = $o(((e, t, a) => {
            const {
                parent: n
            } = e;
            if (!n)
                return;
            const i = n.children,
            s = i.indexOf(e);
            Qo([e], t),
            Ko(i, s, 0, a, n)
        })), er = $o(((e, t, a) => {
            zn(e) && (Qo(e.children, t), Qo(a, e))
        }));
var tr = Object.freeze({
    __proto__: null,
    _makeDomArray: function (e, t) {
        return null == e ? [] : Xi(e) ? t ? Ji(e.get()) : e.get() : Array.isArray(e) ? e.reduce(((e, a) => e.concat(this._makeDomArray(a, t))), []) : "string" == typeof e ? this._parse(e, this.options, !1, null).children : t ? Ji([e]) : [e]
    },
    appendTo: function (e) {
        return (Xi(e) ? e : this._make(e)).append(this),
        this
    },
    prependTo: function (e) {
        return (Xi(e) ? e : this._make(e)).prepend(this),
        this
    },
    append: Zo,
    prepend: Xo,
    wrap: Jo,
    wrapInner: er,
    unwrap: function (e) {
        return this.parent(e).not("body").each(((e, t) => {
                this._make(t).replaceWith(t.children)
            })),
        this
    },
    wrapAll: function (e) {
        const t = this[0];
        if (t) {
            const a = this._make("function" == typeof e ? e.call(t, 0, t) : e).insertBefore(t);
            let n;
            for (let e = 0; e < a.length; e++)
                "tag" === a[e].type && (n = a[e]);
            let i = 0;
            for (; n && i < n.children.length; ) {
                const e = n.children[i];
                "tag" === e.type ? (n = e, i = 0) : i++
            }
            n && this._make(n).append(this)
        }
        return this
    },
    after: function (...e) {
        const t = this.length - 1;
        return $i(this, ((a, n) => {
                const {
                    parent: i
                } = a;
                if (!zn(a) || !i)
                    return;
                const s = i.children,
                o = s.indexOf(a);
                if (o < 0)
                    return;
                const r = "function" == typeof e[0] ? e[0].call(a, n, this._render(a.children)) : e;
                Ko(s, o + 1, 0, this._makeDomArray(r, n < t), i)
            }))
    },
    insertAfter: function (e) {
        "string" == typeof e && (e = this._make(e)),
        this.remove();
        const t = [];
        return this._makeDomArray(e).forEach((e => {
                const a = this.clone().toArray(), {
                    parent: n
                } = e;
                if (!n)
                    return;
                const i = n.children,
                s = i.indexOf(e);
                s < 0 || (Ko(i, s + 1, 0, a, n), t.push(...a))
            })),
        this._make(t)
    },
    before: function (...e) {
        const t = this.length - 1;
        return $i(this, ((a, n) => {
                const {
                    parent: i
                } = a;
                if (!zn(a) || !i)
                    return;
                const s = i.children,
                o = s.indexOf(a);
                if (o < 0)
                    return;
                const r = "function" == typeof e[0] ? e[0].call(a, n, this._render(a.children)) : e;
                Ko(s, o, 0, this._makeDomArray(r, n < t), i)
            }))
    },
    insertBefore: function (e) {
        const t = this._make(e);
        this.remove();
        const a = [];
        return $i(t, (e => {
                const t = this.clone().toArray(), {
                    parent: n
                } = e;
                if (!n)
                    return;
                const i = n.children,
                s = i.indexOf(e);
                s < 0 || (Ko(i, s, 0, t, n), a.push(...t))
            })),
        this._make(a)
    },
    remove: function (e) {
        return $i(e ? this.filter(e) : this, (e => {
                wi(e),
                e.prev = e.next = e.parent = null
            })),
        this
    },
    replaceWith: function (e) {
        return $i(this, ((t, a) => {
                const {
                    parent: n
                } = t;
                if (!n)
                    return;
                const i = n.children,
                s = "function" == typeof e ? e.call(t, a, t) : e,
                o = this._makeDomArray(s);
                Qo(o, null);
                const r = i.indexOf(t);
                Ko(i, r, 1, o, n),
                o.includes(t) || (t.parent = t.prev = t.next = null)
            }))
    },
    empty: function () {
        return $i(this, (e => {
                zn(e) && (e.children.forEach((e => {
                            e.next = e.prev = e.parent = null
                        })), e.children.length = 0)
            }))
    },
    html: function (e) {
        if (void 0 === e) {
            const e = this[0];
            return e && zn(e) ? this._render(e.children) : null
        }
        return $i(this, (t => {
                zn(t) && (t.children.forEach((e => {
                            e.next = e.prev = e.parent = null
                        })), Qo(Xi(e) ? e.toArray() : this._parse(`${e}`, this.options, !1, t).children, t))
            }))
    },
    toString: function () {
        return this._render(this)
    },
    text: function (e) {
        return void 0 === e ? Vi(this) : $i(this, "function" == typeof e ? (t, a) => this._make(t).text(e.call(t, a, Vi([t]))) : t => {
            zn(t) && (t.children.forEach((e => {
                        e.next = e.prev = e.parent = null
                    })), Qo(new In(`${e}`), t))
        })
    },
    clone: function () {
        return this._make(Ji(this.get()))
    }
});
function ar(e, t, a, n) {
    if ("string" == typeof t) {
        const s = nr(e),
        o = "function" == typeof a ? a.call(e, n, s[t]) : a;
        "" === o ? delete s[t] : null != o && (s[t] = o),
        e.attribs.style = (i = s, Object.keys(i).reduce(((e, t) => `${e}${e ? " " : ""}${t}: ${i[t]};`), ""))
    } else
        "object" == typeof t && Object.keys(t).forEach(((a, n) => {
                ar(e, a, t[a], n)
            }));
    var i
}
function nr(e, t) {
    if (!e || !Pn(e))
        return;
    const a = function (e) {
        if (!(e = (e || "").trim()))
            return {};
        const t = {};
        let a;
        for (const n of e.split(";")) {
            const e = n.indexOf(":");
            if (e < 1 || e === n.length - 1) {
                const e = n.trimEnd();
                e.length > 0 && void 0 !== a && (t[a] += `;${e}`)
            } else
                a = n.slice(0, e).trim(), t[a] = n.slice(e + 1).trim()
        }
        return t
    }
    (e.attribs.style);
    if ("string" == typeof t)
        return a[t];
    if (Array.isArray(t)) {
        const e = {};
        return t.forEach((t => {
                null != a[t] && (e[t] = a[t])
            })),
        e
    }
    return a
}
var ir = Object.freeze({
    __proto__: null,
    css: function (e, t) {
        return null != e && null != t || "object" == typeof e && !Array.isArray(e) ? $i(this, ((a, n) => {
                Pn(a) && ar(a, e, t, n)
            })) : 0 !== this.length ? nr(this[0], e) : void 0
    }
});
const sr = /%20/g, or = /\r?\n/g;
var rr = Object.freeze({
    __proto__: null,
    serialize: function () {
        return this.serializeArray().map((e => `${encodeURIComponent(e.name)}=${encodeURIComponent(e.value)}`)).join("&").replace(sr, "+")
    },
    serializeArray: function () {
        return this.map(((e, t) => {
                const a = this._make(t);
                return Pn(t) && "form" === t.name ? a.find("input,select,textarea,keygen").toArray() : a.filter("input,select,textarea,keygen").toArray()
            })).filter('[name!=""]:enabled:not(:submit, :button, :image, :reset, :file):matches([checked], :not(:checkbox, :radio))').map(((e, t) => {
                var a;
                const n = this._make(t),
                i = n.attr("name"),
                s = null !== (a = n.val()) && void 0 !== a ? a : "";
                return Array.isArray(s) ? s.map((e => ({
                            name: i,
                            value: e.replace(or, "\r\n")
                        }))) : {
                    name: i,
                    value: s.replace(or, "\r\n")
                }
            })).toArray()
    }
});
class cr {
    constructor(e, t, a) {
        if (this.length = 0, this.options = a, this._root = t, e) {
            for (let t = 0; t < e.length; t++)
                this[t] = e[t];
            this.length = e.length
        }
    }
}
cr.prototype.cheerio = "[cheerio object]", cr.prototype.splice = Array.prototype.splice, cr.prototype[Symbol.iterator] = Array.prototype[Symbol.iterator], Object.assign(cr.prototype, _s, Vo, tr, ir, rr);
const lr = new Set([65534, 65535, 131070, 131071, 196606, 196607, 262142, 262143, 327678, 327679, 393214, 393215, 458750, 458751, 524286, 524287, 589822, 589823, 655358, 655359, 720894, 720895, 786430, 786431, 851966, 851967, 917502, 917503, 983038, 983039, 1048574, 1048575, 1114110, 1114111]);
var pr;
!function (e) {
    e[e.EOF = -1] = "EOF",
    e[e.NULL = 0] = "NULL",
    e[e.TABULATION = 9] = "TABULATION",
    e[e.CARRIAGE_RETURN = 13] = "CARRIAGE_RETURN",
    e[e.LINE_FEED = 10] = "LINE_FEED",
    e[e.FORM_FEED = 12] = "FORM_FEED",
    e[e.SPACE = 32] = "SPACE",
    e[e.EXCLAMATION_MARK = 33] = "EXCLAMATION_MARK",
    e[e.QUOTATION_MARK = 34] = "QUOTATION_MARK",
    e[e.NUMBER_SIGN = 35] = "NUMBER_SIGN",
    e[e.AMPERSAND = 38] = "AMPERSAND",
    e[e.APOSTROPHE = 39] = "APOSTROPHE",
    e[e.HYPHEN_MINUS = 45] = "HYPHEN_MINUS",
    e[e.SOLIDUS = 47] = "SOLIDUS",
    e[e.DIGIT_0 = 48] = "DIGIT_0",
    e[e.DIGIT_9 = 57] = "DIGIT_9",
    e[e.SEMICOLON = 59] = "SEMICOLON",
    e[e.LESS_THAN_SIGN = 60] = "LESS_THAN_SIGN",
    e[e.EQUALS_SIGN = 61] = "EQUALS_SIGN",
    e[e.GREATER_THAN_SIGN = 62] = "GREATER_THAN_SIGN",
    e[e.QUESTION_MARK = 63] = "QUESTION_MARK",
    e[e.LATIN_CAPITAL_A = 65] = "LATIN_CAPITAL_A",
    e[e.LATIN_CAPITAL_F = 70] = "LATIN_CAPITAL_F",
    e[e.LATIN_CAPITAL_X = 88] = "LATIN_CAPITAL_X",
    e[e.LATIN_CAPITAL_Z = 90] = "LATIN_CAPITAL_Z",
    e[e.RIGHT_SQUARE_BRACKET = 93] = "RIGHT_SQUARE_BRACKET",
    e[e.GRAVE_ACCENT = 96] = "GRAVE_ACCENT",
    e[e.LATIN_SMALL_A = 97] = "LATIN_SMALL_A",
    e[e.LATIN_SMALL_F = 102] = "LATIN_SMALL_F",
    e[e.LATIN_SMALL_X = 120] = "LATIN_SMALL_X",
    e[e.LATIN_SMALL_Z = 122] = "LATIN_SMALL_Z",
    e[e.REPLACEMENT_CHARACTER = 65533] = "REPLACEMENT_CHARACTER"
}
(pr = pr || (pr = {}));
const ur = "[CDATA[", dr = "doctype", hr = "script";
function mr(e) {
    return e >= 55296 && e <= 57343
}
function fr(e) {
    return 32 !== e && 10 !== e && 13 !== e && 9 !== e && 12 !== e && e >= 1 && e <= 31 || e >= 127 && e <= 159
}
function _r(e) {
    return e >= 64976 && e <= 65007 || lr.has(e)
}
var Er, gr, br, xr, Tr, vr, Ar;
!function (e) {
    e.controlCharacterInInputStream = "control-character-in-input-stream",
    e.noncharacterInInputStream = "noncharacter-in-input-stream",
    e.surrogateInInputStream = "surrogate-in-input-stream",
    e.nonVoidHtmlElementStartTagWithTrailingSolidus = "non-void-html-element-start-tag-with-trailing-solidus",
    e.endTagWithAttributes = "end-tag-with-attributes",
    e.endTagWithTrailingSolidus = "end-tag-with-trailing-solidus",
    e.unexpectedSolidusInTag = "unexpected-solidus-in-tag",
    e.unexpectedNullCharacter = "unexpected-null-character",
    e.unexpectedQuestionMarkInsteadOfTagName = "unexpected-question-mark-instead-of-tag-name",
    e.invalidFirstCharacterOfTagName = "invalid-first-character-of-tag-name",
    e.unexpectedEqualsSignBeforeAttributeName = "unexpected-equals-sign-before-attribute-name",
    e.missingEndTagName = "missing-end-tag-name",
    e.unexpectedCharacterInAttributeName = "unexpected-character-in-attribute-name",
    e.unknownNamedCharacterReference = "unknown-named-character-reference",
    e.missingSemicolonAfterCharacterReference = "missing-semicolon-after-character-reference",
    e.unexpectedCharacterAfterDoctypeSystemIdentifier = "unexpected-character-after-doctype-system-identifier",
    e.unexpectedCharacterInUnquotedAttributeValue = "unexpected-character-in-unquoted-attribute-value",
    e.eofBeforeTagName = "eof-before-tag-name",
    e.eofInTag = "eof-in-tag",
    e.missingAttributeValue = "missing-attribute-value",
    e.missingWhitespaceBetweenAttributes = "missing-whitespace-between-attributes",
    e.missingWhitespaceAfterDoctypePublicKeyword = "missing-whitespace-after-doctype-public-keyword",
    e.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers = "missing-whitespace-between-doctype-public-and-system-identifiers",
    e.missingWhitespaceAfterDoctypeSystemKeyword = "missing-whitespace-after-doctype-system-keyword",
    e.missingQuoteBeforeDoctypePublicIdentifier = "missing-quote-before-doctype-public-identifier",
    e.missingQuoteBeforeDoctypeSystemIdentifier = "missing-quote-before-doctype-system-identifier",
    e.missingDoctypePublicIdentifier = "missing-doctype-public-identifier",
    e.missingDoctypeSystemIdentifier = "missing-doctype-system-identifier",
    e.abruptDoctypePublicIdentifier = "abrupt-doctype-public-identifier",
    e.abruptDoctypeSystemIdentifier = "abrupt-doctype-system-identifier",
    e.cdataInHtmlContent = "cdata-in-html-content",
    e.incorrectlyOpenedComment = "incorrectly-opened-comment",
    e.eofInScriptHtmlCommentLikeText = "eof-in-script-html-comment-like-text",
    e.eofInDoctype = "eof-in-doctype",
    e.nestedComment = "nested-comment",
    e.abruptClosingOfEmptyComment = "abrupt-closing-of-empty-comment",
    e.eofInComment = "eof-in-comment",
    e.incorrectlyClosedComment = "incorrectly-closed-comment",
    e.eofInCdata = "eof-in-cdata",
    e.absenceOfDigitsInNumericCharacterReference = "absence-of-digits-in-numeric-character-reference",
    e.nullCharacterReference = "null-character-reference",
    e.surrogateCharacterReference = "surrogate-character-reference",
    e.characterReferenceOutsideUnicodeRange = "character-reference-outside-unicode-range",
    e.controlCharacterReference = "control-character-reference",
    e.noncharacterCharacterReference = "noncharacter-character-reference",
    e.missingWhitespaceBeforeDoctypeName = "missing-whitespace-before-doctype-name",
    e.missingDoctypeName = "missing-doctype-name",
    e.invalidCharacterSequenceAfterDoctypeName = "invalid-character-sequence-after-doctype-name",
    e.duplicateAttribute = "duplicate-attribute",
    e.nonConformingDoctype = "non-conforming-doctype",
    e.missingDoctype = "missing-doctype",
    e.misplacedDoctype = "misplaced-doctype",
    e.endTagWithoutMatchingOpenElement = "end-tag-without-matching-open-element",
    e.closingOfElementWithOpenChildElements = "closing-of-element-with-open-child-elements",
    e.disallowedContentInNoscriptInHead = "disallowed-content-in-noscript-in-head",
    e.openElementsLeftAfterEof = "open-elements-left-after-eof",
    e.abandonedHeadElementChild = "abandoned-head-element-child",
    e.misplacedStartTagForHeadElement = "misplaced-start-tag-for-head-element",
    e.nestedNoscriptInHead = "nested-noscript-in-head",
    e.eofInElementThatCanContainOnlyText = "eof-in-element-that-can-contain-only-text"
}
(Er = Er || (Er = {}));
class yr {
    constructor(e) {
        this.handler = e,
        this.html = "",
        this.pos = -1,
        this.lastGapPos = -2,
        this.gapStack = [],
        this.skipNextNewLine = !1,
        this.lastChunkWritten = !1,
        this.endOfChunkHit = !1,
        this.bufferWaterline = 65536,
        this.isEol = !1,
        this.lineStartPos = 0,
        this.droppedBufferSize = 0,
        this.line = 1,
        this.lastErrOffset = -1
    }
    get col() {
        return this.pos - this.lineStartPos + Number(this.lastGapPos !== this.pos)
    }
    get offset() {
        return this.droppedBufferSize + this.pos
    }
    getError(e) {
        const {
            line: t,
            col: a,
            offset: n
        } = this;
        return {
            code: e,
            startLine: t,
            endLine: t,
            startCol: a,
            endCol: a,
            startOffset: n,
            endOffset: n
        }
    }
    _err(e) {
        this.handler.onParseError && this.lastErrOffset !== this.offset && (this.lastErrOffset = this.offset, this.handler.onParseError(this.getError(e)))
    }
    _addGap() {
        this.gapStack.push(this.lastGapPos),
        this.lastGapPos = this.pos
    }
    _processSurrogate(e) {
        if (this.pos !== this.html.length - 1) {
            const t = this.html.charCodeAt(this.pos + 1);
            if (function (e) {
                return e >= 56320 && e <= 57343
            }
                (t))
                return this.pos++, this._addGap(), 1024 * (e - 55296) + 9216 + t
        } else if (!this.lastChunkWritten)
            return this.endOfChunkHit = !0, pr.EOF;
        return this._err(Er.surrogateInInputStream),
        e
    }
    willDropParsedChunk() {
        return this.pos > this.bufferWaterline
    }
    dropParsedChunk() {
        this.willDropParsedChunk() && (this.html = this.html.substring(this.pos), this.lineStartPos -= this.pos, this.droppedBufferSize += this.pos, this.pos = 0, this.lastGapPos = -2, this.gapStack.length = 0)
    }
    write(e, t) {
        this.html.length > 0 ? this.html += e : this.html = e,
        this.endOfChunkHit = !1,
        this.lastChunkWritten = t
    }
    insertHtmlAtCurrentPos(e) {
        this.html = this.html.substring(0, this.pos + 1) + e + this.html.substring(this.pos + 1),
        this.endOfChunkHit = !1
    }
    startsWith(e, t) {
        if (this.pos + e.length > this.html.length)
            return this.endOfChunkHit = !this.lastChunkWritten, !1;
        if (t)
            return this.html.startsWith(e, this.pos);
        for (let t = 0; t < e.length; t++)
            if ((32 | this.html.charCodeAt(this.pos + t)) !== e.charCodeAt(t))
                return !1;
        return !0
    }
    peek(e) {
        const t = this.pos + e;
        return t >= this.html.length ? (this.endOfChunkHit = !this.lastChunkWritten, pr.EOF) : this.html.charCodeAt(t)
    }
    advance() {
        if (this.pos++, this.isEol && (this.isEol = !1, this.line++, this.lineStartPos = this.pos), this.pos >= this.html.length)
            return this.endOfChunkHit = !this.lastChunkWritten, pr.EOF;
        let e = this.html.charCodeAt(this.pos);
        return e === pr.CARRIAGE_RETURN ? (this.isEol = !0, this.skipNextNewLine = !0, pr.LINE_FEED) : e === pr.LINE_FEED && (this.isEol = !0, this.skipNextNewLine) ? (this.line--, this.skipNextNewLine = !1, this._addGap(), this.advance()) : (this.skipNextNewLine = !1, mr(e) && (e = this._processSurrogate(e)), null === this.handler.onParseError || e > 31 && e < 127 || e === pr.LINE_FEED || e === pr.CARRIAGE_RETURN || e > 159 && e < 64976 || this._checkForProblematicCharacters(e), e)
    }
    _checkForProblematicCharacters(e) {
        fr(e) ? this._err(Er.controlCharacterInInputStream) : _r(e) && this._err(Er.noncharacterInInputStream)
    }
    retreat(e) {
        for (this.pos -= e; this.pos < this.lastGapPos; )
            this.lastGapPos = this.gapStack.pop(), this.pos--;
        this.isEol = !1
    }
}
function wr(e, t) {
    for (let a = e.attrs.length - 1; a >= 0; a--)
        if (e.attrs[a].name === t)
            return e.attrs[a].value;
    return null
}
!function (e) {
    e[e.CHARACTER = 0] = "CHARACTER",
    e[e.NULL_CHARACTER = 1] = "NULL_CHARACTER",
    e[e.WHITESPACE_CHARACTER = 2] = "WHITESPACE_CHARACTER",
    e[e.START_TAG = 3] = "START_TAG",
    e[e.END_TAG = 4] = "END_TAG",
    e[e.COMMENT = 5] = "COMMENT",
    e[e.DOCTYPE = 6] = "DOCTYPE",
    e[e.EOF = 7] = "EOF",
    e[e.HIBERNATION = 8] = "HIBERNATION"
}
(gr = gr || (gr = {})), function (e) {
    e.HTML = "http://www.w3.org/1999/xhtml",
    e.MATHML = "http://www.w3.org/1998/Math/MathML",
    e.SVG = "http://www.w3.org/2000/svg",
    e.XLINK = "http://www.w3.org/1999/xlink",
    e.XML = "http://www.w3.org/XML/1998/namespace",
    e.XMLNS = "http://www.w3.org/2000/xmlns/"
}
(br = br || (br = {})), function (e) {
    e.TYPE = "type",
    e.ACTION = "action",
    e.ENCODING = "encoding",
    e.PROMPT = "prompt",
    e.NAME = "name",
    e.COLOR = "color",
    e.FACE = "face",
    e.SIZE = "size"
}
(xr = xr || (xr = {})), function (e) {
    e.NO_QUIRKS = "no-quirks",
    e.QUIRKS = "quirks",
    e.LIMITED_QUIRKS = "limited-quirks"
}
(Tr = Tr || (Tr = {})), function (e) {
    e.A = "a",
    e.ADDRESS = "address",
    e.ANNOTATION_XML = "annotation-xml",
    e.APPLET = "applet",
    e.AREA = "area",
    e.ARTICLE = "article",
    e.ASIDE = "aside",
    e.B = "b",
    e.BASE = "base",
    e.BASEFONT = "basefont",
    e.BGSOUND = "bgsound",
    e.BIG = "big",
    e.BLOCKQUOTE = "blockquote",
    e.BODY = "body",
    e.BR = "br",
    e.BUTTON = "button",
    e.CAPTION = "caption",
    e.CENTER = "center",
    e.CODE = "code",
    e.COL = "col",
    e.COLGROUP = "colgroup",
    e.DD = "dd",
    e.DESC = "desc",
    e.DETAILS = "details",
    e.DIALOG = "dialog",
    e.DIR = "dir",
    e.DIV = "div",
    e.DL = "dl",
    e.DT = "dt",
    e.EM = "em",
    e.EMBED = "embed",
    e.FIELDSET = "fieldset",
    e.FIGCAPTION = "figcaption",
    e.FIGURE = "figure",
    e.FONT = "font",
    e.FOOTER = "footer",
    e.FOREIGN_OBJECT = "foreignObject",
    e.FORM = "form",
    e.FRAME = "frame",
    e.FRAMESET = "frameset",
    e.H1 = "h1",
    e.H2 = "h2",
    e.H3 = "h3",
    e.H4 = "h4",
    e.H5 = "h5",
    e.H6 = "h6",
    e.HEAD = "head",
    e.HEADER = "header",
    e.HGROUP = "hgroup",
    e.HR = "hr",
    e.HTML = "html",
    e.I = "i",
    e.IMG = "img",
    e.IMAGE = "image",
    e.INPUT = "input",
    e.IFRAME = "iframe",
    e.KEYGEN = "keygen",
    e.LABEL = "label",
    e.LI = "li",
    e.LINK = "link",
    e.LISTING = "listing",
    e.MAIN = "main",
    e.MALIGNMARK = "malignmark",
    e.MARQUEE = "marquee",
    e.MATH = "math",
    e.MENU = "menu",
    e.META = "meta",
    e.MGLYPH = "mglyph",
    e.MI = "mi",
    e.MO = "mo",
    e.MN = "mn",
    e.MS = "ms",
    e.MTEXT = "mtext",
    e.NAV = "nav",
    e.NOBR = "nobr",
    e.NOFRAMES = "noframes",
    e.NOEMBED = "noembed",
    e.NOSCRIPT = "noscript",
    e.OBJECT = "object",
    e.OL = "ol",
    e.OPTGROUP = "optgroup",
    e.OPTION = "option",
    e.P = "p",
    e.PARAM = "param",
    e.PLAINTEXT = "plaintext",
    e.PRE = "pre",
    e.RB = "rb",
    e.RP = "rp",
    e.RT = "rt",
    e.RTC = "rtc",
    e.RUBY = "ruby",
    e.S = "s",
    e.SCRIPT = "script",
    e.SECTION = "section",
    e.SELECT = "select",
    e.SOURCE = "source",
    e.SMALL = "small",
    e.SPAN = "span",
    e.STRIKE = "strike",
    e.STRONG = "strong",
    e.STYLE = "style",
    e.SUB = "sub",
    e.SUMMARY = "summary",
    e.SUP = "sup",
    e.TABLE = "table",
    e.TBODY = "tbody",
    e.TEMPLATE = "template",
    e.TEXTAREA = "textarea",
    e.TFOOT = "tfoot",
    e.TD = "td",
    e.TH = "th",
    e.THEAD = "thead",
    e.TITLE = "title",
    e.TR = "tr",
    e.TRACK = "track",
    e.TT = "tt",
    e.U = "u",
    e.UL = "ul",
    e.SVG = "svg",
    e.VAR = "var",
    e.WBR = "wbr",
    e.XMP = "xmp"
}
(vr = vr || (vr = {})), function (e) {
    e[e.UNKNOWN = 0] = "UNKNOWN",
    e[e.A = 1] = "A",
    e[e.ADDRESS = 2] = "ADDRESS",
    e[e.ANNOTATION_XML = 3] = "ANNOTATION_XML",
    e[e.APPLET = 4] = "APPLET",
    e[e.AREA = 5] = "AREA",
    e[e.ARTICLE = 6] = "ARTICLE",
    e[e.ASIDE = 7] = "ASIDE",
    e[e.B = 8] = "B",
    e[e.BASE = 9] = "BASE",
    e[e.BASEFONT = 10] = "BASEFONT",
    e[e.BGSOUND = 11] = "BGSOUND",
    e[e.BIG = 12] = "BIG",
    e[e.BLOCKQUOTE = 13] = "BLOCKQUOTE",
    e[e.BODY = 14] = "BODY",
    e[e.BR = 15] = "BR",
    e[e.BUTTON = 16] = "BUTTON",
    e[e.CAPTION = 17] = "CAPTION",
    e[e.CENTER = 18] = "CENTER",
    e[e.CODE = 19] = "CODE",
    e[e.COL = 20] = "COL",
    e[e.COLGROUP = 21] = "COLGROUP",
    e[e.DD = 22] = "DD",
    e[e.DESC = 23] = "DESC",
    e[e.DETAILS = 24] = "DETAILS",
    e[e.DIALOG = 25] = "DIALOG",
    e[e.DIR = 26] = "DIR",
    e[e.DIV = 27] = "DIV",
    e[e.DL = 28] = "DL",
    e[e.DT = 29] = "DT",
    e[e.EM = 30] = "EM",
    e[e.EMBED = 31] = "EMBED",
    e[e.FIELDSET = 32] = "FIELDSET",
    e[e.FIGCAPTION = 33] = "FIGCAPTION",
    e[e.FIGURE = 34] = "FIGURE",
    e[e.FONT = 35] = "FONT",
    e[e.FOOTER = 36] = "FOOTER",
    e[e.FOREIGN_OBJECT = 37] = "FOREIGN_OBJECT",
    e[e.FORM = 38] = "FORM",
    e[e.FRAME = 39] = "FRAME",
    e[e.FRAMESET = 40] = "FRAMESET",
    e[e.H1 = 41] = "H1",
    e[e.H2 = 42] = "H2",
    e[e.H3 = 43] = "H3",
    e[e.H4 = 44] = "H4",
    e[e.H5 = 45] = "H5",
    e[e.H6 = 46] = "H6",
    e[e.HEAD = 47] = "HEAD",
    e[e.HEADER = 48] = "HEADER",
    e[e.HGROUP = 49] = "HGROUP",
    e[e.HR = 50] = "HR",
    e[e.HTML = 51] = "HTML",
    e[e.I = 52] = "I",
    e[e.IMG = 53] = "IMG",
    e[e.IMAGE = 54] = "IMAGE",
    e[e.INPUT = 55] = "INPUT",
    e[e.IFRAME = 56] = "IFRAME",
    e[e.KEYGEN = 57] = "KEYGEN",
    e[e.LABEL = 58] = "LABEL",
    e[e.LI = 59] = "LI",
    e[e.LINK = 60] = "LINK",
    e[e.LISTING = 61] = "LISTING",
    e[e.MAIN = 62] = "MAIN",
    e[e.MALIGNMARK = 63] = "MALIGNMARK",
    e[e.MARQUEE = 64] = "MARQUEE",
    e[e.MATH = 65] = "MATH",
    e[e.MENU = 66] = "MENU",
    e[e.META = 67] = "META",
    e[e.MGLYPH = 68] = "MGLYPH",
    e[e.MI = 69] = "MI",
    e[e.MO = 70] = "MO",
    e[e.MN = 71] = "MN",
    e[e.MS = 72] = "MS",
    e[e.MTEXT = 73] = "MTEXT",
    e[e.NAV = 74] = "NAV",
    e[e.NOBR = 75] = "NOBR",
    e[e.NOFRAMES = 76] = "NOFRAMES",
    e[e.NOEMBED = 77] = "NOEMBED",
    e[e.NOSCRIPT = 78] = "NOSCRIPT",
    e[e.OBJECT = 79] = "OBJECT",
    e[e.OL = 80] = "OL",
    e[e.OPTGROUP = 81] = "OPTGROUP",
    e[e.OPTION = 82] = "OPTION",
    e[e.P = 83] = "P",
    e[e.PARAM = 84] = "PARAM",
    e[e.PLAINTEXT = 85] = "PLAINTEXT",
    e[e.PRE = 86] = "PRE",
    e[e.RB = 87] = "RB",
    e[e.RP = 88] = "RP",
    e[e.RT = 89] = "RT",
    e[e.RTC = 90] = "RTC",
    e[e.RUBY = 91] = "RUBY",
    e[e.S = 92] = "S",
    e[e.SCRIPT = 93] = "SCRIPT",
    e[e.SECTION = 94] = "SECTION",
    e[e.SELECT = 95] = "SELECT",
    e[e.SOURCE = 96] = "SOURCE",
    e[e.SMALL = 97] = "SMALL",
    e[e.SPAN = 98] = "SPAN",
    e[e.STRIKE = 99] = "STRIKE",
    e[e.STRONG = 100] = "STRONG",
    e[e.STYLE = 101] = "STYLE",
    e[e.SUB = 102] = "SUB",
    e[e.SUMMARY = 103] = "SUMMARY",
    e[e.SUP = 104] = "SUP",
    e[e.TABLE = 105] = "TABLE",
    e[e.TBODY = 106] = "TBODY",
    e[e.TEMPLATE = 107] = "TEMPLATE",
    e[e.TEXTAREA = 108] = "TEXTAREA",
    e[e.TFOOT = 109] = "TFOOT",
    e[e.TD = 110] = "TD",
    e[e.TH = 111] = "TH",
    e[e.THEAD = 112] = "THEAD",
    e[e.TITLE = 113] = "TITLE",
    e[e.TR = 114] = "TR",
    e[e.TRACK = 115] = "TRACK",
    e[e.TT = 116] = "TT",
    e[e.U = 117] = "U",
    e[e.UL = 118] = "UL",
    e[e.SVG = 119] = "SVG",
    e[e.VAR = 120] = "VAR",
    e[e.WBR = 121] = "WBR",
    e[e.XMP = 122] = "XMP"
}
(Ar = Ar || (Ar = {}));
const Sr = new Map([[vr.A, Ar.A], [vr.ADDRESS, Ar.ADDRESS], [vr.ANNOTATION_XML, Ar.ANNOTATION_XML], [vr.APPLET, Ar.APPLET], [vr.AREA, Ar.AREA], [vr.ARTICLE, Ar.ARTICLE], [vr.ASIDE, Ar.ASIDE], [vr.B, Ar.B], [vr.BASE, Ar.BASE], [vr.BASEFONT, Ar.BASEFONT], [vr.BGSOUND, Ar.BGSOUND], [vr.BIG, Ar.BIG], [vr.BLOCKQUOTE, Ar.BLOCKQUOTE], [vr.BODY, Ar.BODY], [vr.BR, Ar.BR], [vr.BUTTON, Ar.BUTTON], [vr.CAPTION, Ar.CAPTION], [vr.CENTER, Ar.CENTER], [vr.CODE, Ar.CODE], [vr.COL, Ar.COL], [vr.COLGROUP, Ar.COLGROUP], [vr.DD, Ar.DD], [vr.DESC, Ar.DESC], [vr.DETAILS, Ar.DETAILS], [vr.DIALOG, Ar.DIALOG], [vr.DIR, Ar.DIR], [vr.DIV, Ar.DIV], [vr.DL, Ar.DL], [vr.DT, Ar.DT], [vr.EM, Ar.EM], [vr.EMBED, Ar.EMBED], [vr.FIELDSET, Ar.FIELDSET], [vr.FIGCAPTION, Ar.FIGCAPTION], [vr.FIGURE, Ar.FIGURE], [vr.FONT, Ar.FONT], [vr.FOOTER, Ar.FOOTER], [vr.FOREIGN_OBJECT, Ar.FOREIGN_OBJECT], [vr.FORM, Ar.FORM], [vr.FRAME, Ar.FRAME], [vr.FRAMESET, Ar.FRAMESET], [vr.H1, Ar.H1], [vr.H2, Ar.H2], [vr.H3, Ar.H3], [vr.H4, Ar.H4], [vr.H5, Ar.H5], [vr.H6, Ar.H6], [vr.HEAD, Ar.HEAD], [vr.HEADER, Ar.HEADER], [vr.HGROUP, Ar.HGROUP], [vr.HR, Ar.HR], [vr.HTML, Ar.HTML], [vr.I, Ar.I], [vr.IMG, Ar.IMG], [vr.IMAGE, Ar.IMAGE], [vr.INPUT, Ar.INPUT], [vr.IFRAME, Ar.IFRAME], [vr.KEYGEN, Ar.KEYGEN], [vr.LABEL, Ar.LABEL], [vr.LI, Ar.LI], [vr.LINK, Ar.LINK], [vr.LISTING, Ar.LISTING], [vr.MAIN, Ar.MAIN], [vr.MALIGNMARK, Ar.MALIGNMARK], [vr.MARQUEE, Ar.MARQUEE], [vr.MATH, Ar.MATH], [vr.MENU, Ar.MENU], [vr.META, Ar.META], [vr.MGLYPH, Ar.MGLYPH], [vr.MI, Ar.MI], [vr.MO, Ar.MO], [vr.MN, Ar.MN], [vr.MS, Ar.MS], [vr.MTEXT, Ar.MTEXT], [vr.NAV, Ar.NAV], [vr.NOBR, Ar.NOBR], [vr.NOFRAMES, Ar.NOFRAMES], [vr.NOEMBED, Ar.NOEMBED], [vr.NOSCRIPT, Ar.NOSCRIPT], [vr.OBJECT, Ar.OBJECT], [vr.OL, Ar.OL], [vr.OPTGROUP, Ar.OPTGROUP], [vr.OPTION, Ar.OPTION], [vr.P, Ar.P], [vr.PARAM, Ar.PARAM], [vr.PLAINTEXT, Ar.PLAINTEXT], [vr.PRE, Ar.PRE], [vr.RB, Ar.RB], [vr.RP, Ar.RP], [vr.RT, Ar.RT], [vr.RTC, Ar.RTC], [vr.RUBY, Ar.RUBY], [vr.S, Ar.S], [vr.SCRIPT, Ar.SCRIPT], [vr.SECTION, Ar.SECTION], [vr.SELECT, Ar.SELECT], [vr.SOURCE, Ar.SOURCE], [vr.SMALL, Ar.SMALL], [vr.SPAN, Ar.SPAN], [vr.STRIKE, Ar.STRIKE], [vr.STRONG, Ar.STRONG], [vr.STYLE, Ar.STYLE], [vr.SUB, Ar.SUB], [vr.SUMMARY, Ar.SUMMARY], [vr.SUP, Ar.SUP], [vr.TABLE, Ar.TABLE], [vr.TBODY, Ar.TBODY], [vr.TEMPLATE, Ar.TEMPLATE], [vr.TEXTAREA, Ar.TEXTAREA], [vr.TFOOT, Ar.TFOOT], [vr.TD, Ar.TD], [vr.TH, Ar.TH], [vr.THEAD, Ar.THEAD], [vr.TITLE, Ar.TITLE], [vr.TR, Ar.TR], [vr.TRACK, Ar.TRACK], [vr.TT, Ar.TT], [vr.U, Ar.U], [vr.UL, Ar.UL], [vr.SVG, Ar.SVG], [vr.VAR, Ar.VAR], [vr.WBR, Ar.WBR], [vr.XMP, Ar.XMP]]);
function Nr(e) {
    var t;
    return null !== (t = Sr.get(e)) && void 0 !== t ? t : Ar.UNKNOWN
}
const Cr = Ar, Ir = {
    [br.HTML]: new Set([Cr.ADDRESS, Cr.APPLET, Cr.AREA, Cr.ARTICLE, Cr.ASIDE, Cr.BASE, Cr.BASEFONT, Cr.BGSOUND, Cr.BLOCKQUOTE, Cr.BODY, Cr.BR, Cr.BUTTON, Cr.CAPTION, Cr.CENTER, Cr.COL, Cr.COLGROUP, Cr.DD, Cr.DETAILS, Cr.DIR, Cr.DIV, Cr.DL, Cr.DT, Cr.EMBED, Cr.FIELDSET, Cr.FIGCAPTION, Cr.FIGURE, Cr.FOOTER, Cr.FORM, Cr.FRAME, Cr.FRAMESET, Cr.H1, Cr.H2, Cr.H3, Cr.H4, Cr.H5, Cr.H6, Cr.HEAD, Cr.HEADER, Cr.HGROUP, Cr.HR, Cr.HTML, Cr.IFRAME, Cr.IMG, Cr.INPUT, Cr.LI, Cr.LINK, Cr.LISTING, Cr.MAIN, Cr.MARQUEE, Cr.MENU, Cr.META, Cr.NAV, Cr.NOEMBED, Cr.NOFRAMES, Cr.NOSCRIPT, Cr.OBJECT, Cr.OL, Cr.P, Cr.PARAM, Cr.PLAINTEXT, Cr.PRE, Cr.SCRIPT, Cr.SECTION, Cr.SELECT, Cr.SOURCE, Cr.STYLE, Cr.SUMMARY, Cr.TABLE, Cr.TBODY, Cr.TD, Cr.TEMPLATE, Cr.TEXTAREA, Cr.TFOOT, Cr.TH, Cr.THEAD, Cr.TITLE, Cr.TR, Cr.TRACK, Cr.UL, Cr.WBR, Cr.XMP]),
    [br.MATHML]: new Set([Cr.MI, Cr.MO, Cr.MN, Cr.MS, Cr.MTEXT, Cr.ANNOTATION_XML]),
    [br.SVG]: new Set([Cr.TITLE, Cr.FOREIGN_OBJECT, Cr.DESC]),
    [br.XLINK]: new Set,
    [br.XML]: new Set,
    [br.XMLNS]: new Set
};
function kr(e) {
    return e === Cr.H1 || e === Cr.H2 || e === Cr.H3 || e === Cr.H4 || e === Cr.H5 || e === Cr.H6
}
const Rr = new Set([vr.STYLE, vr.SCRIPT, vr.XMP, vr.IFRAME, vr.NOEMBED, vr.NOFRAMES, vr.PLAINTEXT]), Or = new Map([[128, 8364], [130, 8218], [131, 402], [132, 8222], [133, 8230], [134, 8224], [135, 8225], [136, 710], [137, 8240], [138, 352], [139, 8249], [140, 338], [142, 381], [145, 8216], [146, 8217], [147, 8220], [148, 8221], [149, 8226], [150, 8211], [151, 8212], [152, 732], [153, 8482], [154, 353], [155, 8250], [156, 339], [158, 382], [159, 376]]);
var Dr;
!function (e) {
    e[e.DATA = 0] = "DATA",
    e[e.RCDATA = 1] = "RCDATA",
    e[e.RAWTEXT = 2] = "RAWTEXT",
    e[e.SCRIPT_DATA = 3] = "SCRIPT_DATA",
    e[e.PLAINTEXT = 4] = "PLAINTEXT",
    e[e.TAG_OPEN = 5] = "TAG_OPEN",
    e[e.END_TAG_OPEN = 6] = "END_TAG_OPEN",
    e[e.TAG_NAME = 7] = "TAG_NAME",
    e[e.RCDATA_LESS_THAN_SIGN = 8] = "RCDATA_LESS_THAN_SIGN",
    e[e.RCDATA_END_TAG_OPEN = 9] = "RCDATA_END_TAG_OPEN",
    e[e.RCDATA_END_TAG_NAME = 10] = "RCDATA_END_TAG_NAME",
    e[e.RAWTEXT_LESS_THAN_SIGN = 11] = "RAWTEXT_LESS_THAN_SIGN",
    e[e.RAWTEXT_END_TAG_OPEN = 12] = "RAWTEXT_END_TAG_OPEN",
    e[e.RAWTEXT_END_TAG_NAME = 13] = "RAWTEXT_END_TAG_NAME",
    e[e.SCRIPT_DATA_LESS_THAN_SIGN = 14] = "SCRIPT_DATA_LESS_THAN_SIGN",
    e[e.SCRIPT_DATA_END_TAG_OPEN = 15] = "SCRIPT_DATA_END_TAG_OPEN",
    e[e.SCRIPT_DATA_END_TAG_NAME = 16] = "SCRIPT_DATA_END_TAG_NAME",
    e[e.SCRIPT_DATA_ESCAPE_START = 17] = "SCRIPT_DATA_ESCAPE_START",
    e[e.SCRIPT_DATA_ESCAPE_START_DASH = 18] = "SCRIPT_DATA_ESCAPE_START_DASH",
    e[e.SCRIPT_DATA_ESCAPED = 19] = "SCRIPT_DATA_ESCAPED",
    e[e.SCRIPT_DATA_ESCAPED_DASH = 20] = "SCRIPT_DATA_ESCAPED_DASH",
    e[e.SCRIPT_DATA_ESCAPED_DASH_DASH = 21] = "SCRIPT_DATA_ESCAPED_DASH_DASH",
    e[e.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN = 22] = "SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN",
    e[e.SCRIPT_DATA_ESCAPED_END_TAG_OPEN = 23] = "SCRIPT_DATA_ESCAPED_END_TAG_OPEN",
    e[e.SCRIPT_DATA_ESCAPED_END_TAG_NAME = 24] = "SCRIPT_DATA_ESCAPED_END_TAG_NAME",
    e[e.SCRIPT_DATA_DOUBLE_ESCAPE_START = 25] = "SCRIPT_DATA_DOUBLE_ESCAPE_START",
    e[e.SCRIPT_DATA_DOUBLE_ESCAPED = 26] = "SCRIPT_DATA_DOUBLE_ESCAPED",
    e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH = 27] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH",
    e[e.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH = 28] = "SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH",
    e[e.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN = 29] = "SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN",
    e[e.SCRIPT_DATA_DOUBLE_ESCAPE_END = 30] = "SCRIPT_DATA_DOUBLE_ESCAPE_END",
    e[e.BEFORE_ATTRIBUTE_NAME = 31] = "BEFORE_ATTRIBUTE_NAME",
    e[e.ATTRIBUTE_NAME = 32] = "ATTRIBUTE_NAME",
    e[e.AFTER_ATTRIBUTE_NAME = 33] = "AFTER_ATTRIBUTE_NAME",
    e[e.BEFORE_ATTRIBUTE_VALUE = 34] = "BEFORE_ATTRIBUTE_VALUE",
    e[e.ATTRIBUTE_VALUE_DOUBLE_QUOTED = 35] = "ATTRIBUTE_VALUE_DOUBLE_QUOTED",
    e[e.ATTRIBUTE_VALUE_SINGLE_QUOTED = 36] = "ATTRIBUTE_VALUE_SINGLE_QUOTED",
    e[e.ATTRIBUTE_VALUE_UNQUOTED = 37] = "ATTRIBUTE_VALUE_UNQUOTED",
    e[e.AFTER_ATTRIBUTE_VALUE_QUOTED = 38] = "AFTER_ATTRIBUTE_VALUE_QUOTED",
    e[e.SELF_CLOSING_START_TAG = 39] = "SELF_CLOSING_START_TAG",
    e[e.BOGUS_COMMENT = 40] = "BOGUS_COMMENT",
    e[e.MARKUP_DECLARATION_OPEN = 41] = "MARKUP_DECLARATION_OPEN",
    e[e.COMMENT_START = 42] = "COMMENT_START",
    e[e.COMMENT_START_DASH = 43] = "COMMENT_START_DASH",
    e[e.COMMENT = 44] = "COMMENT",
    e[e.COMMENT_LESS_THAN_SIGN = 45] = "COMMENT_LESS_THAN_SIGN",
    e[e.COMMENT_LESS_THAN_SIGN_BANG = 46] = "COMMENT_LESS_THAN_SIGN_BANG",
    e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH = 47] = "COMMENT_LESS_THAN_SIGN_BANG_DASH",
    e[e.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH = 48] = "COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH",
    e[e.COMMENT_END_DASH = 49] = "COMMENT_END_DASH",
    e[e.COMMENT_END = 50] = "COMMENT_END",
    e[e.COMMENT_END_BANG = 51] = "COMMENT_END_BANG",
    e[e.DOCTYPE = 52] = "DOCTYPE",
    e[e.BEFORE_DOCTYPE_NAME = 53] = "BEFORE_DOCTYPE_NAME",
    e[e.DOCTYPE_NAME = 54] = "DOCTYPE_NAME",
    e[e.AFTER_DOCTYPE_NAME = 55] = "AFTER_DOCTYPE_NAME",
    e[e.AFTER_DOCTYPE_PUBLIC_KEYWORD = 56] = "AFTER_DOCTYPE_PUBLIC_KEYWORD",
    e[e.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER = 57] = "BEFORE_DOCTYPE_PUBLIC_IDENTIFIER",
    e[e.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED = 58] = "DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED",
    e[e.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED = 59] = "DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED",
    e[e.AFTER_DOCTYPE_PUBLIC_IDENTIFIER = 60] = "AFTER_DOCTYPE_PUBLIC_IDENTIFIER",
    e[e.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS = 61] = "BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS",
    e[e.AFTER_DOCTYPE_SYSTEM_KEYWORD = 62] = "AFTER_DOCTYPE_SYSTEM_KEYWORD",
    e[e.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER = 63] = "BEFORE_DOCTYPE_SYSTEM_IDENTIFIER",
    e[e.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED = 64] = "DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED",
    e[e.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED = 65] = "DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED",
    e[e.AFTER_DOCTYPE_SYSTEM_IDENTIFIER = 66] = "AFTER_DOCTYPE_SYSTEM_IDENTIFIER",
    e[e.BOGUS_DOCTYPE = 67] = "BOGUS_DOCTYPE",
    e[e.CDATA_SECTION = 68] = "CDATA_SECTION",
    e[e.CDATA_SECTION_BRACKET = 69] = "CDATA_SECTION_BRACKET",
    e[e.CDATA_SECTION_END = 70] = "CDATA_SECTION_END",
    e[e.CHARACTER_REFERENCE = 71] = "CHARACTER_REFERENCE",
    e[e.NAMED_CHARACTER_REFERENCE = 72] = "NAMED_CHARACTER_REFERENCE",
    e[e.AMBIGUOUS_AMPERSAND = 73] = "AMBIGUOUS_AMPERSAND",
    e[e.NUMERIC_CHARACTER_REFERENCE = 74] = "NUMERIC_CHARACTER_REFERENCE",
    e[e.HEXADEMICAL_CHARACTER_REFERENCE_START = 75] = "HEXADEMICAL_CHARACTER_REFERENCE_START",
    e[e.HEXADEMICAL_CHARACTER_REFERENCE = 76] = "HEXADEMICAL_CHARACTER_REFERENCE",
    e[e.DECIMAL_CHARACTER_REFERENCE = 77] = "DECIMAL_CHARACTER_REFERENCE",
    e[e.NUMERIC_CHARACTER_REFERENCE_END = 78] = "NUMERIC_CHARACTER_REFERENCE_END"
}
(Dr || (Dr = {}));
const Lr = {
    DATA: Dr.DATA,
    RCDATA: Dr.RCDATA,
    RAWTEXT: Dr.RAWTEXT,
    SCRIPT_DATA: Dr.SCRIPT_DATA,
    PLAINTEXT: Dr.PLAINTEXT,
    CDATA_SECTION: Dr.CDATA_SECTION
};
function Mr(e) {
    return e >= pr.DIGIT_0 && e <= pr.DIGIT_9
}
function Pr(e) {
    return e >= pr.LATIN_CAPITAL_A && e <= pr.LATIN_CAPITAL_Z
}
function Br(e) {
    return function (e) {
        return e >= pr.LATIN_SMALL_A && e <= pr.LATIN_SMALL_Z
    }
    (e) || Pr(e)
}
function Ur(e) {
    return Br(e) || Mr(e)
}
function Fr(e) {
    return e >= pr.LATIN_CAPITAL_A && e <= pr.LATIN_CAPITAL_F
}
function Hr(e) {
    return e >= pr.LATIN_SMALL_A && e <= pr.LATIN_SMALL_F
}
function jr(e) {
    return e + 32
}
function zr(e) {
    return e === pr.SPACE || e === pr.LINE_FEED || e === pr.TABULATION || e === pr.FORM_FEED
}
function Gr(e) {
    return zr(e) || e === pr.SOLIDUS || e === pr.GREATER_THAN_SIGN
}
class qr {
    constructor(e, t) {
        this.options = e,
        this.handler = t,
        this.paused = !1,
        this.inLoop = !1,
        this.inForeignNode = !1,
        this.lastStartTagName = "",
        this.active = !1,
        this.state = Dr.DATA,
        this.returnState = Dr.DATA,
        this.charRefCode = -1,
        this.consumedAfterSnapshot = -1,
        this.currentCharacterToken = null,
        this.currentToken = null,
        this.currentAttr = {
            name: "",
            value: ""
        },
        this.preprocessor = new yr(t),
        this.currentLocation = this.getCurrentLocation(-1)
    }
    _err(e) {
        var t,
        a;
        null === (a = (t = this.handler).onParseError) || void 0 === a || a.call(t, this.preprocessor.getError(e))
    }
    getCurrentLocation(e) {
        return this.options.sourceCodeLocationInfo ? {
            startLine: this.preprocessor.line,
            startCol: this.preprocessor.col - e,
            startOffset: this.preprocessor.offset - e,
            endLine: -1,
            endCol: -1,
            endOffset: -1
        }
         : null
    }
    _runParsingLoop() {
        if (!this.inLoop) {
            for (this.inLoop = !0; this.active && !this.paused; ) {
                this.consumedAfterSnapshot = 0;
                const e = this._consume();
                this._ensureHibernation() || this._callState(e)
            }
            this.inLoop = !1
        }
    }
    pause() {
        this.paused = !0
    }
    resume(e) {
        if (!this.paused)
            throw new Error("Parser was already resumed");
        this.paused = !1,
        this.inLoop || (this._runParsingLoop(), this.paused || null == e || e())
    }
    write(e, t, a) {
        this.active = !0,
        this.preprocessor.write(e, t),
        this._runParsingLoop(),
        this.paused || null == a || a()
    }
    insertHtmlAtCurrentPos(e) {
        this.active = !0,
        this.preprocessor.insertHtmlAtCurrentPos(e),
        this._runParsingLoop()
    }
    _ensureHibernation() {
        return !!this.preprocessor.endOfChunkHit && (this._unconsume(this.consumedAfterSnapshot), this.active = !1, !0)
    }
    _consume() {
        return this.consumedAfterSnapshot++,
        this.preprocessor.advance()
    }
    _unconsume(e) {
        this.consumedAfterSnapshot -= e,
        this.preprocessor.retreat(e)
    }
    _reconsumeInState(e, t) {
        this.state = e,
        this._callState(t)
    }
    _advanceBy(e) {
        this.consumedAfterSnapshot += e;
        for (let t = 0; t < e; t++)
            this.preprocessor.advance()
    }
    _consumeSequenceIfMatch(e, t) {
        return !!this.preprocessor.startsWith(e, t) && (this._advanceBy(e.length - 1), !0)
    }
    _createStartTagToken() {
        this.currentToken = {
            type: gr.START_TAG,
            tagName: "",
            tagID: Ar.UNKNOWN,
            selfClosing: !1,
            ackSelfClosing: !1,
            attrs: [],
            location: this.getCurrentLocation(1)
        }
    }
    _createEndTagToken() {
        this.currentToken = {
            type: gr.END_TAG,
            tagName: "",
            tagID: Ar.UNKNOWN,
            selfClosing: !1,
            ackSelfClosing: !1,
            attrs: [],
            location: this.getCurrentLocation(2)
        }
    }
    _createCommentToken(e) {
        this.currentToken = {
            type: gr.COMMENT,
            data: "",
            location: this.getCurrentLocation(e)
        }
    }
    _createDoctypeToken(e) {
        this.currentToken = {
            type: gr.DOCTYPE,
            name: e,
            forceQuirks: !1,
            publicId: null,
            systemId: null,
            location: this.currentLocation
        }
    }
    _createCharacterToken(e, t) {
        this.currentCharacterToken = {
            type: e,
            chars: t,
            location: this.currentLocation
        }
    }
    _createAttr(e) {
        this.currentAttr = {
            name: e,
            value: ""
        },
        this.currentLocation = this.getCurrentLocation(0)
    }
    _leaveAttrName() {
        var e,
        t;
        const a = this.currentToken;
        null === wr(a, this.currentAttr.name) ? (a.attrs.push(this.currentAttr), a.location && this.currentLocation && ((null !== (e = (t = a.location).attrs) && void 0 !== e ? e : t.attrs = Object.create(null))[this.currentAttr.name] = this.currentLocation, this._leaveAttrValue())) : this._err(Er.duplicateAttribute)
    }
    _leaveAttrValue() {
        this.currentLocation && (this.currentLocation.endLine = this.preprocessor.line, this.currentLocation.endCol = this.preprocessor.col, this.currentLocation.endOffset = this.preprocessor.offset)
    }
    prepareToken(e) {
        this._emitCurrentCharacterToken(e.location),
        this.currentToken = null,
        e.location && (e.location.endLine = this.preprocessor.line, e.location.endCol = this.preprocessor.col + 1, e.location.endOffset = this.preprocessor.offset + 1),
        this.currentLocation = this.getCurrentLocation(-1)
    }
    emitCurrentTagToken() {
        const e = this.currentToken;
        this.prepareToken(e),
        e.tagID = Nr(e.tagName),
        e.type === gr.START_TAG ? (this.lastStartTagName = e.tagName, this.handler.onStartTag(e)) : (e.attrs.length > 0 && this._err(Er.endTagWithAttributes), e.selfClosing && this._err(Er.endTagWithTrailingSolidus), this.handler.onEndTag(e)),
        this.preprocessor.dropParsedChunk()
    }
    emitCurrentComment(e) {
        this.prepareToken(e),
        this.handler.onComment(e),
        this.preprocessor.dropParsedChunk()
    }
    emitCurrentDoctype(e) {
        this.prepareToken(e),
        this.handler.onDoctype(e),
        this.preprocessor.dropParsedChunk()
    }
    _emitCurrentCharacterToken(e) {
        if (this.currentCharacterToken) {
            switch (e && this.currentCharacterToken.location && (this.currentCharacterToken.location.endLine = e.startLine, this.currentCharacterToken.location.endCol = e.startCol, this.currentCharacterToken.location.endOffset = e.startOffset), this.currentCharacterToken.type) {
            case gr.CHARACTER:
                this.handler.onCharacter(this.currentCharacterToken);
                break;
            case gr.NULL_CHARACTER:
                this.handler.onNullCharacter(this.currentCharacterToken);
                break;
            case gr.WHITESPACE_CHARACTER:
                this.handler.onWhitespaceCharacter(this.currentCharacterToken)
            }
            this.currentCharacterToken = null
        }
    }
    _emitEOFToken() {
        const e = this.getCurrentLocation(0);
        e && (e.endLine = e.startLine, e.endCol = e.startCol, e.endOffset = e.startOffset),
        this._emitCurrentCharacterToken(e),
        this.handler.onEof({
            type: gr.EOF,
            location: e
        }),
        this.active = !1
    }
    _appendCharToCurrentCharacterToken(e, t) {
        if (this.currentCharacterToken) {
            if (this.currentCharacterToken.type === e)
                return void(this.currentCharacterToken.chars += t);
            this.currentLocation = this.getCurrentLocation(0),
            this._emitCurrentCharacterToken(this.currentLocation),
            this.preprocessor.dropParsedChunk()
        }
        this._createCharacterToken(e, t)
    }
    _emitCodePoint(e) {
        const t = zr(e) ? gr.WHITESPACE_CHARACTER : e === pr.NULL ? gr.NULL_CHARACTER : gr.CHARACTER;
        this._appendCharToCurrentCharacterToken(t, String.fromCodePoint(e))
    }
    _emitChars(e) {
        this._appendCharToCurrentCharacterToken(gr.CHARACTER, e)
    }
    _matchNamedCharacterReference(e) {
        let t = null,
        a = 0,
        n = !1;
        for (let s = 0, o = Wn[0]; s >= 0 && (s = ei(Wn, o, s + 1, e), !(s < 0)); e = this._consume()) {
            a += 1,
            o = Wn[s];
            const r = o & Jn.VALUE_LENGTH;
            if (r) {
                const o = (r >> 14) - 1;
                if (e !== pr.SEMICOLON && this._isCharacterReferenceInAttribute() && ((i = this.preprocessor.peek(1)) === pr.EQUALS_SIGN || Ur(i)) ? (t = [pr.AMPERSAND], s += o) : (t = 0 === o ? [Wn[s] & ~Jn.VALUE_LENGTH] : 1 === o ? [Wn[++s]] : [Wn[++s], Wn[++s]], a = 0, n = e !== pr.SEMICOLON), 0 === o) {
                    this._consume();
                    break
                }
            }
        }
        var i;
        return this._unconsume(a),
        n && !this.preprocessor.endOfChunkHit && this._err(Er.missingSemicolonAfterCharacterReference),
        this._unconsume(1),
        t
    }
    _isCharacterReferenceInAttribute() {
        return this.returnState === Dr.ATTRIBUTE_VALUE_DOUBLE_QUOTED || this.returnState === Dr.ATTRIBUTE_VALUE_SINGLE_QUOTED || this.returnState === Dr.ATTRIBUTE_VALUE_UNQUOTED
    }
    _flushCodePointConsumedAsCharacterReference(e) {
        this._isCharacterReferenceInAttribute() ? this.currentAttr.value += String.fromCodePoint(e) : this._emitCodePoint(e)
    }
    _callState(e) {
        switch (this.state) {
        case Dr.DATA:
            this._stateData(e);
            break;
        case Dr.RCDATA:
            this._stateRcdata(e);
            break;
        case Dr.RAWTEXT:
            this._stateRawtext(e);
            break;
        case Dr.SCRIPT_DATA:
            this._stateScriptData(e);
            break;
        case Dr.PLAINTEXT:
            this._statePlaintext(e);
            break;
        case Dr.TAG_OPEN:
            this._stateTagOpen(e);
            break;
        case Dr.END_TAG_OPEN:
            this._stateEndTagOpen(e);
            break;
        case Dr.TAG_NAME:
            this._stateTagName(e);
            break;
        case Dr.RCDATA_LESS_THAN_SIGN:
            this._stateRcdataLessThanSign(e);
            break;
        case Dr.RCDATA_END_TAG_OPEN:
            this._stateRcdataEndTagOpen(e);
            break;
        case Dr.RCDATA_END_TAG_NAME:
            this._stateRcdataEndTagName(e);
            break;
        case Dr.RAWTEXT_LESS_THAN_SIGN:
            this._stateRawtextLessThanSign(e);
            break;
        case Dr.RAWTEXT_END_TAG_OPEN:
            this._stateRawtextEndTagOpen(e);
            break;
        case Dr.RAWTEXT_END_TAG_NAME:
            this._stateRawtextEndTagName(e);
            break;
        case Dr.SCRIPT_DATA_LESS_THAN_SIGN:
            this._stateScriptDataLessThanSign(e);
            break;
        case Dr.SCRIPT_DATA_END_TAG_OPEN:
            this._stateScriptDataEndTagOpen(e);
            break;
        case Dr.SCRIPT_DATA_END_TAG_NAME:
            this._stateScriptDataEndTagName(e);
            break;
        case Dr.SCRIPT_DATA_ESCAPE_START:
            this._stateScriptDataEscapeStart(e);
            break;
        case Dr.SCRIPT_DATA_ESCAPE_START_DASH:
            this._stateScriptDataEscapeStartDash(e);
            break;
        case Dr.SCRIPT_DATA_ESCAPED:
            this._stateScriptDataEscaped(e);
            break;
        case Dr.SCRIPT_DATA_ESCAPED_DASH:
            this._stateScriptDataEscapedDash(e);
            break;
        case Dr.SCRIPT_DATA_ESCAPED_DASH_DASH:
            this._stateScriptDataEscapedDashDash(e);
            break;
        case Dr.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN:
            this._stateScriptDataEscapedLessThanSign(e);
            break;
        case Dr.SCRIPT_DATA_ESCAPED_END_TAG_OPEN:
            this._stateScriptDataEscapedEndTagOpen(e);
            break;
        case Dr.SCRIPT_DATA_ESCAPED_END_TAG_NAME:
            this._stateScriptDataEscapedEndTagName(e);
            break;
        case Dr.SCRIPT_DATA_DOUBLE_ESCAPE_START:
            this._stateScriptDataDoubleEscapeStart(e);
            break;
        case Dr.SCRIPT_DATA_DOUBLE_ESCAPED:
            this._stateScriptDataDoubleEscaped(e);
            break;
        case Dr.SCRIPT_DATA_DOUBLE_ESCAPED_DASH:
            this._stateScriptDataDoubleEscapedDash(e);
            break;
        case Dr.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH:
            this._stateScriptDataDoubleEscapedDashDash(e);
            break;
        case Dr.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN:
            this._stateScriptDataDoubleEscapedLessThanSign(e);
            break;
        case Dr.SCRIPT_DATA_DOUBLE_ESCAPE_END:
            this._stateScriptDataDoubleEscapeEnd(e);
            break;
        case Dr.BEFORE_ATTRIBUTE_NAME:
            this._stateBeforeAttributeName(e);
            break;
        case Dr.ATTRIBUTE_NAME:
            this._stateAttributeName(e);
            break;
        case Dr.AFTER_ATTRIBUTE_NAME:
            this._stateAfterAttributeName(e);
            break;
        case Dr.BEFORE_ATTRIBUTE_VALUE:
            this._stateBeforeAttributeValue(e);
            break;
        case Dr.ATTRIBUTE_VALUE_DOUBLE_QUOTED:
            this._stateAttributeValueDoubleQuoted(e);
            break;
        case Dr.ATTRIBUTE_VALUE_SINGLE_QUOTED:
            this._stateAttributeValueSingleQuoted(e);
            break;
        case Dr.ATTRIBUTE_VALUE_UNQUOTED:
            this._stateAttributeValueUnquoted(e);
            break;
        case Dr.AFTER_ATTRIBUTE_VALUE_QUOTED:
            this._stateAfterAttributeValueQuoted(e);
            break;
        case Dr.SELF_CLOSING_START_TAG:
            this._stateSelfClosingStartTag(e);
            break;
        case Dr.BOGUS_COMMENT:
            this._stateBogusComment(e);
            break;
        case Dr.MARKUP_DECLARATION_OPEN:
            this._stateMarkupDeclarationOpen(e);
            break;
        case Dr.COMMENT_START:
            this._stateCommentStart(e);
            break;
        case Dr.COMMENT_START_DASH:
            this._stateCommentStartDash(e);
            break;
        case Dr.COMMENT:
            this._stateComment(e);
            break;
        case Dr.COMMENT_LESS_THAN_SIGN:
            this._stateCommentLessThanSign(e);
            break;
        case Dr.COMMENT_LESS_THAN_SIGN_BANG:
            this._stateCommentLessThanSignBang(e);
            break;
        case Dr.COMMENT_LESS_THAN_SIGN_BANG_DASH:
            this._stateCommentLessThanSignBangDash(e);
            break;
        case Dr.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH:
            this._stateCommentLessThanSignBangDashDash(e);
            break;
        case Dr.COMMENT_END_DASH:
            this._stateCommentEndDash(e);
            break;
        case Dr.COMMENT_END:
            this._stateCommentEnd(e);
            break;
        case Dr.COMMENT_END_BANG:
            this._stateCommentEndBang(e);
            break;
        case Dr.DOCTYPE:
            this._stateDoctype(e);
            break;
        case Dr.BEFORE_DOCTYPE_NAME:
            this._stateBeforeDoctypeName(e);
            break;
        case Dr.DOCTYPE_NAME:
            this._stateDoctypeName(e);
            break;
        case Dr.AFTER_DOCTYPE_NAME:
            this._stateAfterDoctypeName(e);
            break;
        case Dr.AFTER_DOCTYPE_PUBLIC_KEYWORD:
            this._stateAfterDoctypePublicKeyword(e);
            break;
        case Dr.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER:
            this._stateBeforeDoctypePublicIdentifier(e);
            break;
        case Dr.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED:
            this._stateDoctypePublicIdentifierDoubleQuoted(e);
            break;
        case Dr.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED:
            this._stateDoctypePublicIdentifierSingleQuoted(e);
            break;
        case Dr.AFTER_DOCTYPE_PUBLIC_IDENTIFIER:
            this._stateAfterDoctypePublicIdentifier(e);
            break;
        case Dr.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS:
            this._stateBetweenDoctypePublicAndSystemIdentifiers(e);
            break;
        case Dr.AFTER_DOCTYPE_SYSTEM_KEYWORD:
            this._stateAfterDoctypeSystemKeyword(e);
            break;
        case Dr.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER:
            this._stateBeforeDoctypeSystemIdentifier(e);
            break;
        case Dr.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED:
            this._stateDoctypeSystemIdentifierDoubleQuoted(e);
            break;
        case Dr.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED:
            this._stateDoctypeSystemIdentifierSingleQuoted(e);
            break;
        case Dr.AFTER_DOCTYPE_SYSTEM_IDENTIFIER:
            this._stateAfterDoctypeSystemIdentifier(e);
            break;
        case Dr.BOGUS_DOCTYPE:
            this._stateBogusDoctype(e);
            break;
        case Dr.CDATA_SECTION:
            this._stateCdataSection(e);
            break;
        case Dr.CDATA_SECTION_BRACKET:
            this._stateCdataSectionBracket(e);
            break;
        case Dr.CDATA_SECTION_END:
            this._stateCdataSectionEnd(e);
            break;
        case Dr.CHARACTER_REFERENCE:
            this._stateCharacterReference(e);
            break;
        case Dr.NAMED_CHARACTER_REFERENCE:
            this._stateNamedCharacterReference(e);
            break;
        case Dr.AMBIGUOUS_AMPERSAND:
            this._stateAmbiguousAmpersand(e);
            break;
        case Dr.NUMERIC_CHARACTER_REFERENCE:
            this._stateNumericCharacterReference(e);
            break;
        case Dr.HEXADEMICAL_CHARACTER_REFERENCE_START:
            this._stateHexademicalCharacterReferenceStart(e);
            break;
        case Dr.HEXADEMICAL_CHARACTER_REFERENCE:
            this._stateHexademicalCharacterReference(e);
            break;
        case Dr.DECIMAL_CHARACTER_REFERENCE:
            this._stateDecimalCharacterReference(e);
            break;
        case Dr.NUMERIC_CHARACTER_REFERENCE_END:
            this._stateNumericCharacterReferenceEnd(e);
            break;
        default:
            throw new Error("Unknown state")
        }
    }
    _stateData(e) {
        switch (e) {
        case pr.LESS_THAN_SIGN:
            this.state = Dr.TAG_OPEN;
            break;
        case pr.AMPERSAND:
            this.returnState = Dr.DATA,
            this.state = Dr.CHARACTER_REFERENCE;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this._emitCodePoint(e);
            break;
        case pr.EOF:
            this._emitEOFToken();
            break;
        default:
            this._emitCodePoint(e)
        }
    }
    _stateRcdata(e) {
        switch (e) {
        case pr.AMPERSAND:
            this.returnState = Dr.RCDATA,
            this.state = Dr.CHARACTER_REFERENCE;
            break;
        case pr.LESS_THAN_SIGN:
            this.state = Dr.RCDATA_LESS_THAN_SIGN;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this._emitChars("�");
            break;
        case pr.EOF:
            this._emitEOFToken();
            break;
        default:
            this._emitCodePoint(e)
        }
    }
    _stateRawtext(e) {
        switch (e) {
        case pr.LESS_THAN_SIGN:
            this.state = Dr.RAWTEXT_LESS_THAN_SIGN;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this._emitChars("�");
            break;
        case pr.EOF:
            this._emitEOFToken();
            break;
        default:
            this._emitCodePoint(e)
        }
    }
    _stateScriptData(e) {
        switch (e) {
        case pr.LESS_THAN_SIGN:
            this.state = Dr.SCRIPT_DATA_LESS_THAN_SIGN;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this._emitChars("�");
            break;
        case pr.EOF:
            this._emitEOFToken();
            break;
        default:
            this._emitCodePoint(e)
        }
    }
    _statePlaintext(e) {
        switch (e) {
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this._emitChars("�");
            break;
        case pr.EOF:
            this._emitEOFToken();
            break;
        default:
            this._emitCodePoint(e)
        }
    }
    _stateTagOpen(e) {
        if (Br(e))
            this._createStartTagToken(), this.state = Dr.TAG_NAME, this._stateTagName(e);
        else
            switch (e) {
            case pr.EXCLAMATION_MARK:
                this.state = Dr.MARKUP_DECLARATION_OPEN;
                break;
            case pr.SOLIDUS:
                this.state = Dr.END_TAG_OPEN;
                break;
            case pr.QUESTION_MARK:
                this._err(Er.unexpectedQuestionMarkInsteadOfTagName),
                this._createCommentToken(1),
                this.state = Dr.BOGUS_COMMENT,
                this._stateBogusComment(e);
                break;
            case pr.EOF:
                this._err(Er.eofBeforeTagName),
                this._emitChars("<"),
                this._emitEOFToken();
                break;
            default:
                this._err(Er.invalidFirstCharacterOfTagName),
                this._emitChars("<"),
                this.state = Dr.DATA,
                this._stateData(e)
            }
    }
    _stateEndTagOpen(e) {
        if (Br(e))
            this._createEndTagToken(), this.state = Dr.TAG_NAME, this._stateTagName(e);
        else
            switch (e) {
            case pr.GREATER_THAN_SIGN:
                this._err(Er.missingEndTagName),
                this.state = Dr.DATA;
                break;
            case pr.EOF:
                this._err(Er.eofBeforeTagName),
                this._emitChars("</"),
                this._emitEOFToken();
                break;
            default:
                this._err(Er.invalidFirstCharacterOfTagName),
                this._createCommentToken(2),
                this.state = Dr.BOGUS_COMMENT,
                this._stateBogusComment(e)
            }
    }
    _stateTagName(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            this.state = Dr.BEFORE_ATTRIBUTE_NAME;
            break;
        case pr.SOLIDUS:
            this.state = Dr.SELF_CLOSING_START_TAG;
            break;
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.DATA,
            this.emitCurrentTagToken();
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            t.tagName += "�";
            break;
        case pr.EOF:
            this._err(Er.eofInTag),
            this._emitEOFToken();
            break;
        default:
            t.tagName += String.fromCodePoint(Pr(e) ? jr(e) : e)
        }
    }
    _stateRcdataLessThanSign(e) {
        e === pr.SOLIDUS ? this.state = Dr.RCDATA_END_TAG_OPEN : (this._emitChars("<"), this.state = Dr.RCDATA, this._stateRcdata(e))
    }
    _stateRcdataEndTagOpen(e) {
        Br(e) ? (this.state = Dr.RCDATA_END_TAG_NAME, this._stateRcdataEndTagName(e)) : (this._emitChars("</"), this.state = Dr.RCDATA, this._stateRcdata(e))
    }
    handleSpecialEndTag(e) {
        if (!this.preprocessor.startsWith(this.lastStartTagName, !1))
            return !this._ensureHibernation();
        switch (this._createEndTagToken(), this.currentToken.tagName = this.lastStartTagName, this.preprocessor.peek(this.lastStartTagName.length)) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            return this._advanceBy(this.lastStartTagName.length),
            this.state = Dr.BEFORE_ATTRIBUTE_NAME,
            !1;
        case pr.SOLIDUS:
            return this._advanceBy(this.lastStartTagName.length),
            this.state = Dr.SELF_CLOSING_START_TAG,
            !1;
        case pr.GREATER_THAN_SIGN:
            return this._advanceBy(this.lastStartTagName.length),
            this.emitCurrentTagToken(),
            this.state = Dr.DATA,
            !1;
        default:
            return !this._ensureHibernation()
        }
    }
    _stateRcdataEndTagName(e) {
        this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = Dr.RCDATA, this._stateRcdata(e))
    }
    _stateRawtextLessThanSign(e) {
        e === pr.SOLIDUS ? this.state = Dr.RAWTEXT_END_TAG_OPEN : (this._emitChars("<"), this.state = Dr.RAWTEXT, this._stateRawtext(e))
    }
    _stateRawtextEndTagOpen(e) {
        Br(e) ? (this.state = Dr.RAWTEXT_END_TAG_NAME, this._stateRawtextEndTagName(e)) : (this._emitChars("</"), this.state = Dr.RAWTEXT, this._stateRawtext(e))
    }
    _stateRawtextEndTagName(e) {
        this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = Dr.RAWTEXT, this._stateRawtext(e))
    }
    _stateScriptDataLessThanSign(e) {
        switch (e) {
        case pr.SOLIDUS:
            this.state = Dr.SCRIPT_DATA_END_TAG_OPEN;
            break;
        case pr.EXCLAMATION_MARK:
            this.state = Dr.SCRIPT_DATA_ESCAPE_START,
            this._emitChars("<!");
            break;
        default:
            this._emitChars("<"),
            this.state = Dr.SCRIPT_DATA,
            this._stateScriptData(e)
        }
    }
    _stateScriptDataEndTagOpen(e) {
        Br(e) ? (this.state = Dr.SCRIPT_DATA_END_TAG_NAME, this._stateScriptDataEndTagName(e)) : (this._emitChars("</"), this.state = Dr.SCRIPT_DATA, this._stateScriptData(e))
    }
    _stateScriptDataEndTagName(e) {
        this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = Dr.SCRIPT_DATA, this._stateScriptData(e))
    }
    _stateScriptDataEscapeStart(e) {
        e === pr.HYPHEN_MINUS ? (this.state = Dr.SCRIPT_DATA_ESCAPE_START_DASH, this._emitChars("-")) : (this.state = Dr.SCRIPT_DATA, this._stateScriptData(e))
    }
    _stateScriptDataEscapeStartDash(e) {
        e === pr.HYPHEN_MINUS ? (this.state = Dr.SCRIPT_DATA_ESCAPED_DASH_DASH, this._emitChars("-")) : (this.state = Dr.SCRIPT_DATA, this._stateScriptData(e))
    }
    _stateScriptDataEscaped(e) {
        switch (e) {
        case pr.HYPHEN_MINUS:
            this.state = Dr.SCRIPT_DATA_ESCAPED_DASH,
            this._emitChars("-");
            break;
        case pr.LESS_THAN_SIGN:
            this.state = Dr.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this._emitChars("�");
            break;
        case pr.EOF:
            this._err(Er.eofInScriptHtmlCommentLikeText),
            this._emitEOFToken();
            break;
        default:
            this._emitCodePoint(e)
        }
    }
    _stateScriptDataEscapedDash(e) {
        switch (e) {
        case pr.HYPHEN_MINUS:
            this.state = Dr.SCRIPT_DATA_ESCAPED_DASH_DASH,
            this._emitChars("-");
            break;
        case pr.LESS_THAN_SIGN:
            this.state = Dr.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this.state = Dr.SCRIPT_DATA_ESCAPED,
            this._emitChars("�");
            break;
        case pr.EOF:
            this._err(Er.eofInScriptHtmlCommentLikeText),
            this._emitEOFToken();
            break;
        default:
            this.state = Dr.SCRIPT_DATA_ESCAPED,
            this._emitCodePoint(e)
        }
    }
    _stateScriptDataEscapedDashDash(e) {
        switch (e) {
        case pr.HYPHEN_MINUS:
            this._emitChars("-");
            break;
        case pr.LESS_THAN_SIGN:
            this.state = Dr.SCRIPT_DATA_ESCAPED_LESS_THAN_SIGN;
            break;
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.SCRIPT_DATA,
            this._emitChars(">");
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this.state = Dr.SCRIPT_DATA_ESCAPED,
            this._emitChars("�");
            break;
        case pr.EOF:
            this._err(Er.eofInScriptHtmlCommentLikeText),
            this._emitEOFToken();
            break;
        default:
            this.state = Dr.SCRIPT_DATA_ESCAPED,
            this._emitCodePoint(e)
        }
    }
    _stateScriptDataEscapedLessThanSign(e) {
        e === pr.SOLIDUS ? this.state = Dr.SCRIPT_DATA_ESCAPED_END_TAG_OPEN : Br(e) ? (this._emitChars("<"), this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPE_START, this._stateScriptDataDoubleEscapeStart(e)) : (this._emitChars("<"), this.state = Dr.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e))
    }
    _stateScriptDataEscapedEndTagOpen(e) {
        Br(e) ? (this.state = Dr.SCRIPT_DATA_ESCAPED_END_TAG_NAME, this._stateScriptDataEscapedEndTagName(e)) : (this._emitChars("</"), this.state = Dr.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e))
    }
    _stateScriptDataEscapedEndTagName(e) {
        this.handleSpecialEndTag(e) && (this._emitChars("</"), this.state = Dr.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e))
    }
    _stateScriptDataDoubleEscapeStart(e) {
        if (this.preprocessor.startsWith(hr, !1) && Gr(this.preprocessor.peek(hr.length))) {
            this._emitCodePoint(e);
            for (let e = 0; e < hr.length; e++)
                this._emitCodePoint(this._consume());
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED
        } else
            this._ensureHibernation() || (this.state = Dr.SCRIPT_DATA_ESCAPED, this._stateScriptDataEscaped(e))
    }
    _stateScriptDataDoubleEscaped(e) {
        switch (e) {
        case pr.HYPHEN_MINUS:
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED_DASH,
            this._emitChars("-");
            break;
        case pr.LESS_THAN_SIGN:
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN,
            this._emitChars("<");
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this._emitChars("�");
            break;
        case pr.EOF:
            this._err(Er.eofInScriptHtmlCommentLikeText),
            this._emitEOFToken();
            break;
        default:
            this._emitCodePoint(e)
        }
    }
    _stateScriptDataDoubleEscapedDash(e) {
        switch (e) {
        case pr.HYPHEN_MINUS:
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED_DASH_DASH,
            this._emitChars("-");
            break;
        case pr.LESS_THAN_SIGN:
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN,
            this._emitChars("<");
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED,
            this._emitChars("�");
            break;
        case pr.EOF:
            this._err(Er.eofInScriptHtmlCommentLikeText),
            this._emitEOFToken();
            break;
        default:
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED,
            this._emitCodePoint(e)
        }
    }
    _stateScriptDataDoubleEscapedDashDash(e) {
        switch (e) {
        case pr.HYPHEN_MINUS:
            this._emitChars("-");
            break;
        case pr.LESS_THAN_SIGN:
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED_LESS_THAN_SIGN,
            this._emitChars("<");
            break;
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.SCRIPT_DATA,
            this._emitChars(">");
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED,
            this._emitChars("�");
            break;
        case pr.EOF:
            this._err(Er.eofInScriptHtmlCommentLikeText),
            this._emitEOFToken();
            break;
        default:
            this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED,
            this._emitCodePoint(e)
        }
    }
    _stateScriptDataDoubleEscapedLessThanSign(e) {
        e === pr.SOLIDUS ? (this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPE_END, this._emitChars("/")) : (this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e))
    }
    _stateScriptDataDoubleEscapeEnd(e) {
        if (this.preprocessor.startsWith(hr, !1) && Gr(this.preprocessor.peek(hr.length))) {
            this._emitCodePoint(e);
            for (let e = 0; e < hr.length; e++)
                this._emitCodePoint(this._consume());
            this.state = Dr.SCRIPT_DATA_ESCAPED
        } else
            this._ensureHibernation() || (this.state = Dr.SCRIPT_DATA_DOUBLE_ESCAPED, this._stateScriptDataDoubleEscaped(e))
    }
    _stateBeforeAttributeName(e) {
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            break;
        case pr.SOLIDUS:
        case pr.GREATER_THAN_SIGN:
        case pr.EOF:
            this.state = Dr.AFTER_ATTRIBUTE_NAME,
            this._stateAfterAttributeName(e);
            break;
        case pr.EQUALS_SIGN:
            this._err(Er.unexpectedEqualsSignBeforeAttributeName),
            this._createAttr("="),
            this.state = Dr.ATTRIBUTE_NAME;
            break;
        default:
            this._createAttr(""),
            this.state = Dr.ATTRIBUTE_NAME,
            this._stateAttributeName(e)
        }
    }
    _stateAttributeName(e) {
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
        case pr.SOLIDUS:
        case pr.GREATER_THAN_SIGN:
        case pr.EOF:
            this._leaveAttrName(),
            this.state = Dr.AFTER_ATTRIBUTE_NAME,
            this._stateAfterAttributeName(e);
            break;
        case pr.EQUALS_SIGN:
            this._leaveAttrName(),
            this.state = Dr.BEFORE_ATTRIBUTE_VALUE;
            break;
        case pr.QUOTATION_MARK:
        case pr.APOSTROPHE:
        case pr.LESS_THAN_SIGN:
            this._err(Er.unexpectedCharacterInAttributeName),
            this.currentAttr.name += String.fromCodePoint(e);
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this.currentAttr.name += "�";
            break;
        default:
            this.currentAttr.name += String.fromCodePoint(Pr(e) ? jr(e) : e)
        }
    }
    _stateAfterAttributeName(e) {
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            break;
        case pr.SOLIDUS:
            this.state = Dr.SELF_CLOSING_START_TAG;
            break;
        case pr.EQUALS_SIGN:
            this.state = Dr.BEFORE_ATTRIBUTE_VALUE;
            break;
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.DATA,
            this.emitCurrentTagToken();
            break;
        case pr.EOF:
            this._err(Er.eofInTag),
            this._emitEOFToken();
            break;
        default:
            this._createAttr(""),
            this.state = Dr.ATTRIBUTE_NAME,
            this._stateAttributeName(e)
        }
    }
    _stateBeforeAttributeValue(e) {
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            break;
        case pr.QUOTATION_MARK:
            this.state = Dr.ATTRIBUTE_VALUE_DOUBLE_QUOTED;
            break;
        case pr.APOSTROPHE:
            this.state = Dr.ATTRIBUTE_VALUE_SINGLE_QUOTED;
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.missingAttributeValue),
            this.state = Dr.DATA,
            this.emitCurrentTagToken();
            break;
        default:
            this.state = Dr.ATTRIBUTE_VALUE_UNQUOTED,
            this._stateAttributeValueUnquoted(e)
        }
    }
    _stateAttributeValueDoubleQuoted(e) {
        switch (e) {
        case pr.QUOTATION_MARK:
            this.state = Dr.AFTER_ATTRIBUTE_VALUE_QUOTED;
            break;
        case pr.AMPERSAND:
            this.returnState = Dr.ATTRIBUTE_VALUE_DOUBLE_QUOTED,
            this.state = Dr.CHARACTER_REFERENCE;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this.currentAttr.value += "�";
            break;
        case pr.EOF:
            this._err(Er.eofInTag),
            this._emitEOFToken();
            break;
        default:
            this.currentAttr.value += String.fromCodePoint(e)
        }
    }
    _stateAttributeValueSingleQuoted(e) {
        switch (e) {
        case pr.APOSTROPHE:
            this.state = Dr.AFTER_ATTRIBUTE_VALUE_QUOTED;
            break;
        case pr.AMPERSAND:
            this.returnState = Dr.ATTRIBUTE_VALUE_SINGLE_QUOTED,
            this.state = Dr.CHARACTER_REFERENCE;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this.currentAttr.value += "�";
            break;
        case pr.EOF:
            this._err(Er.eofInTag),
            this._emitEOFToken();
            break;
        default:
            this.currentAttr.value += String.fromCodePoint(e)
        }
    }
    _stateAttributeValueUnquoted(e) {
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            this._leaveAttrValue(),
            this.state = Dr.BEFORE_ATTRIBUTE_NAME;
            break;
        case pr.AMPERSAND:
            this.returnState = Dr.ATTRIBUTE_VALUE_UNQUOTED,
            this.state = Dr.CHARACTER_REFERENCE;
            break;
        case pr.GREATER_THAN_SIGN:
            this._leaveAttrValue(),
            this.state = Dr.DATA,
            this.emitCurrentTagToken();
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            this.currentAttr.value += "�";
            break;
        case pr.QUOTATION_MARK:
        case pr.APOSTROPHE:
        case pr.LESS_THAN_SIGN:
        case pr.EQUALS_SIGN:
        case pr.GRAVE_ACCENT:
            this._err(Er.unexpectedCharacterInUnquotedAttributeValue),
            this.currentAttr.value += String.fromCodePoint(e);
            break;
        case pr.EOF:
            this._err(Er.eofInTag),
            this._emitEOFToken();
            break;
        default:
            this.currentAttr.value += String.fromCodePoint(e)
        }
    }
    _stateAfterAttributeValueQuoted(e) {
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            this._leaveAttrValue(),
            this.state = Dr.BEFORE_ATTRIBUTE_NAME;
            break;
        case pr.SOLIDUS:
            this._leaveAttrValue(),
            this.state = Dr.SELF_CLOSING_START_TAG;
            break;
        case pr.GREATER_THAN_SIGN:
            this._leaveAttrValue(),
            this.state = Dr.DATA,
            this.emitCurrentTagToken();
            break;
        case pr.EOF:
            this._err(Er.eofInTag),
            this._emitEOFToken();
            break;
        default:
            this._err(Er.missingWhitespaceBetweenAttributes),
            this.state = Dr.BEFORE_ATTRIBUTE_NAME,
            this._stateBeforeAttributeName(e)
        }
    }
    _stateSelfClosingStartTag(e) {
        switch (e) {
        case pr.GREATER_THAN_SIGN:
            this.currentToken.selfClosing = !0,
            this.state = Dr.DATA,
            this.emitCurrentTagToken();
            break;
        case pr.EOF:
            this._err(Er.eofInTag),
            this._emitEOFToken();
            break;
        default:
            this._err(Er.unexpectedSolidusInTag),
            this.state = Dr.BEFORE_ATTRIBUTE_NAME,
            this._stateBeforeAttributeName(e)
        }
    }
    _stateBogusComment(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.DATA,
            this.emitCurrentComment(t);
            break;
        case pr.EOF:
            this.emitCurrentComment(t),
            this._emitEOFToken();
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            t.data += "�";
            break;
        default:
            t.data += String.fromCodePoint(e)
        }
    }
    _stateMarkupDeclarationOpen(e) {
        this._consumeSequenceIfMatch("--", !0) ? (this._createCommentToken("--".length + 1), this.state = Dr.COMMENT_START) : this._consumeSequenceIfMatch(dr, !1) ? (this.currentLocation = this.getCurrentLocation(dr.length + 1), this.state = Dr.DOCTYPE) : this._consumeSequenceIfMatch(ur, !0) ? this.inForeignNode ? this.state = Dr.CDATA_SECTION : (this._err(Er.cdataInHtmlContent), this._createCommentToken(ur.length + 1), this.currentToken.data = "[CDATA[", this.state = Dr.BOGUS_COMMENT) : this._ensureHibernation() || (this._err(Er.incorrectlyOpenedComment), this._createCommentToken(2), this.state = Dr.BOGUS_COMMENT, this._stateBogusComment(e))
    }
    _stateCommentStart(e) {
        switch (e) {
        case pr.HYPHEN_MINUS:
            this.state = Dr.COMMENT_START_DASH;
            break;
        case pr.GREATER_THAN_SIGN: {
                this._err(Er.abruptClosingOfEmptyComment),
                this.state = Dr.DATA;
                const e = this.currentToken;
                this.emitCurrentComment(e);
                break
            }
        default:
            this.state = Dr.COMMENT,
            this._stateComment(e)
        }
    }
    _stateCommentStartDash(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.HYPHEN_MINUS:
            this.state = Dr.COMMENT_END;
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.abruptClosingOfEmptyComment),
            this.state = Dr.DATA,
            this.emitCurrentComment(t);
            break;
        case pr.EOF:
            this._err(Er.eofInComment),
            this.emitCurrentComment(t),
            this._emitEOFToken();
            break;
        default:
            t.data += "-",
            this.state = Dr.COMMENT,
            this._stateComment(e)
        }
    }
    _stateComment(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.HYPHEN_MINUS:
            this.state = Dr.COMMENT_END_DASH;
            break;
        case pr.LESS_THAN_SIGN:
            t.data += "<",
            this.state = Dr.COMMENT_LESS_THAN_SIGN;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            t.data += "�";
            break;
        case pr.EOF:
            this._err(Er.eofInComment),
            this.emitCurrentComment(t),
            this._emitEOFToken();
            break;
        default:
            t.data += String.fromCodePoint(e)
        }
    }
    _stateCommentLessThanSign(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.EXCLAMATION_MARK:
            t.data += "!",
            this.state = Dr.COMMENT_LESS_THAN_SIGN_BANG;
            break;
        case pr.LESS_THAN_SIGN:
            t.data += "<";
            break;
        default:
            this.state = Dr.COMMENT,
            this._stateComment(e)
        }
    }
    _stateCommentLessThanSignBang(e) {
        e === pr.HYPHEN_MINUS ? this.state = Dr.COMMENT_LESS_THAN_SIGN_BANG_DASH : (this.state = Dr.COMMENT, this._stateComment(e))
    }
    _stateCommentLessThanSignBangDash(e) {
        e === pr.HYPHEN_MINUS ? this.state = Dr.COMMENT_LESS_THAN_SIGN_BANG_DASH_DASH : (this.state = Dr.COMMENT_END_DASH, this._stateCommentEndDash(e))
    }
    _stateCommentLessThanSignBangDashDash(e) {
        e !== pr.GREATER_THAN_SIGN && e !== pr.EOF && this._err(Er.nestedComment),
        this.state = Dr.COMMENT_END,
        this._stateCommentEnd(e)
    }
    _stateCommentEndDash(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.HYPHEN_MINUS:
            this.state = Dr.COMMENT_END;
            break;
        case pr.EOF:
            this._err(Er.eofInComment),
            this.emitCurrentComment(t),
            this._emitEOFToken();
            break;
        default:
            t.data += "-",
            this.state = Dr.COMMENT,
            this._stateComment(e)
        }
    }
    _stateCommentEnd(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.DATA,
            this.emitCurrentComment(t);
            break;
        case pr.EXCLAMATION_MARK:
            this.state = Dr.COMMENT_END_BANG;
            break;
        case pr.HYPHEN_MINUS:
            t.data += "-";
            break;
        case pr.EOF:
            this._err(Er.eofInComment),
            this.emitCurrentComment(t),
            this._emitEOFToken();
            break;
        default:
            t.data += "--",
            this.state = Dr.COMMENT,
            this._stateComment(e)
        }
    }
    _stateCommentEndBang(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.HYPHEN_MINUS:
            t.data += "--!",
            this.state = Dr.COMMENT_END_DASH;
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.incorrectlyClosedComment),
            this.state = Dr.DATA,
            this.emitCurrentComment(t);
            break;
        case pr.EOF:
            this._err(Er.eofInComment),
            this.emitCurrentComment(t),
            this._emitEOFToken();
            break;
        default:
            t.data += "--!",
            this.state = Dr.COMMENT,
            this._stateComment(e)
        }
    }
    _stateDoctype(e) {
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            this.state = Dr.BEFORE_DOCTYPE_NAME;
            break;
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.BEFORE_DOCTYPE_NAME,
            this._stateBeforeDoctypeName(e);
            break;
        case pr.EOF: {
                this._err(Er.eofInDoctype),
                this._createDoctypeToken(null);
                const e = this.currentToken;
                e.forceQuirks = !0,
                this.emitCurrentDoctype(e),
                this._emitEOFToken();
                break
            }
        default:
            this._err(Er.missingWhitespaceBeforeDoctypeName),
            this.state = Dr.BEFORE_DOCTYPE_NAME,
            this._stateBeforeDoctypeName(e)
        }
    }
    _stateBeforeDoctypeName(e) {
        if (Pr(e))
            this._createDoctypeToken(String.fromCharCode(jr(e))), this.state = Dr.DOCTYPE_NAME;
        else
            switch (e) {
            case pr.SPACE:
            case pr.LINE_FEED:
            case pr.TABULATION:
            case pr.FORM_FEED:
                break;
            case pr.NULL:
                this._err(Er.unexpectedNullCharacter),
                this._createDoctypeToken("�"),
                this.state = Dr.DOCTYPE_NAME;
                break;
            case pr.GREATER_THAN_SIGN: {
                    this._err(Er.missingDoctypeName),
                    this._createDoctypeToken(null);
                    const e = this.currentToken;
                    e.forceQuirks = !0,
                    this.emitCurrentDoctype(e),
                    this.state = Dr.DATA;
                    break
                }
            case pr.EOF: {
                    this._err(Er.eofInDoctype),
                    this._createDoctypeToken(null);
                    const e = this.currentToken;
                    e.forceQuirks = !0,
                    this.emitCurrentDoctype(e),
                    this._emitEOFToken();
                    break
                }
            default:
                this._createDoctypeToken(String.fromCodePoint(e)),
                this.state = Dr.DOCTYPE_NAME
            }
    }
    _stateDoctypeName(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            this.state = Dr.AFTER_DOCTYPE_NAME;
            break;
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.DATA,
            this.emitCurrentDoctype(t);
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            t.name += "�";
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            t.name += String.fromCodePoint(Pr(e) ? jr(e) : e)
        }
    }
    _stateAfterDoctypeName(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            break;
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.DATA,
            this.emitCurrentDoctype(t);
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            this._consumeSequenceIfMatch("public", !1) ? this.state = Dr.AFTER_DOCTYPE_PUBLIC_KEYWORD : this._consumeSequenceIfMatch("system", !1) ? this.state = Dr.AFTER_DOCTYPE_SYSTEM_KEYWORD : this._ensureHibernation() || (this._err(Er.invalidCharacterSequenceAfterDoctypeName), t.forceQuirks = !0, this.state = Dr.BOGUS_DOCTYPE, this._stateBogusDoctype(e))
        }
    }
    _stateAfterDoctypePublicKeyword(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            this.state = Dr.BEFORE_DOCTYPE_PUBLIC_IDENTIFIER;
            break;
        case pr.QUOTATION_MARK:
            this._err(Er.missingWhitespaceAfterDoctypePublicKeyword),
            t.publicId = "",
            this.state = Dr.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
            break;
        case pr.APOSTROPHE:
            this._err(Er.missingWhitespaceAfterDoctypePublicKeyword),
            t.publicId = "",
            this.state = Dr.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.missingDoctypePublicIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.DATA,
            this.emitCurrentDoctype(t);
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            this._err(Er.missingQuoteBeforeDoctypePublicIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.BOGUS_DOCTYPE,
            this._stateBogusDoctype(e)
        }
    }
    _stateBeforeDoctypePublicIdentifier(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            break;
        case pr.QUOTATION_MARK:
            t.publicId = "",
            this.state = Dr.DOCTYPE_PUBLIC_IDENTIFIER_DOUBLE_QUOTED;
            break;
        case pr.APOSTROPHE:
            t.publicId = "",
            this.state = Dr.DOCTYPE_PUBLIC_IDENTIFIER_SINGLE_QUOTED;
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.missingDoctypePublicIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.DATA,
            this.emitCurrentDoctype(t);
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            this._err(Er.missingQuoteBeforeDoctypePublicIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.BOGUS_DOCTYPE,
            this._stateBogusDoctype(e)
        }
    }
    _stateDoctypePublicIdentifierDoubleQuoted(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.QUOTATION_MARK:
            this.state = Dr.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            t.publicId += "�";
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.abruptDoctypePublicIdentifier),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this.state = Dr.DATA;
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            t.publicId += String.fromCodePoint(e)
        }
    }
    _stateDoctypePublicIdentifierSingleQuoted(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.APOSTROPHE:
            this.state = Dr.AFTER_DOCTYPE_PUBLIC_IDENTIFIER;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            t.publicId += "�";
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.abruptDoctypePublicIdentifier),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this.state = Dr.DATA;
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            t.publicId += String.fromCodePoint(e)
        }
    }
    _stateAfterDoctypePublicIdentifier(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            this.state = Dr.BETWEEN_DOCTYPE_PUBLIC_AND_SYSTEM_IDENTIFIERS;
            break;
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.DATA,
            this.emitCurrentDoctype(t);
            break;
        case pr.QUOTATION_MARK:
            this._err(Er.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers),
            t.systemId = "",
            this.state = Dr.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
            break;
        case pr.APOSTROPHE:
            this._err(Er.missingWhitespaceBetweenDoctypePublicAndSystemIdentifiers),
            t.systemId = "",
            this.state = Dr.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            this._err(Er.missingQuoteBeforeDoctypeSystemIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.BOGUS_DOCTYPE,
            this._stateBogusDoctype(e)
        }
    }
    _stateBetweenDoctypePublicAndSystemIdentifiers(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            break;
        case pr.GREATER_THAN_SIGN:
            this.emitCurrentDoctype(t),
            this.state = Dr.DATA;
            break;
        case pr.QUOTATION_MARK:
            t.systemId = "",
            this.state = Dr.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
            break;
        case pr.APOSTROPHE:
            t.systemId = "",
            this.state = Dr.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            this._err(Er.missingQuoteBeforeDoctypeSystemIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.BOGUS_DOCTYPE,
            this._stateBogusDoctype(e)
        }
    }
    _stateAfterDoctypeSystemKeyword(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            this.state = Dr.BEFORE_DOCTYPE_SYSTEM_IDENTIFIER;
            break;
        case pr.QUOTATION_MARK:
            this._err(Er.missingWhitespaceAfterDoctypeSystemKeyword),
            t.systemId = "",
            this.state = Dr.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
            break;
        case pr.APOSTROPHE:
            this._err(Er.missingWhitespaceAfterDoctypeSystemKeyword),
            t.systemId = "",
            this.state = Dr.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.missingDoctypeSystemIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.DATA,
            this.emitCurrentDoctype(t);
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            this._err(Er.missingQuoteBeforeDoctypeSystemIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.BOGUS_DOCTYPE,
            this._stateBogusDoctype(e)
        }
    }
    _stateBeforeDoctypeSystemIdentifier(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            break;
        case pr.QUOTATION_MARK:
            t.systemId = "",
            this.state = Dr.DOCTYPE_SYSTEM_IDENTIFIER_DOUBLE_QUOTED;
            break;
        case pr.APOSTROPHE:
            t.systemId = "",
            this.state = Dr.DOCTYPE_SYSTEM_IDENTIFIER_SINGLE_QUOTED;
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.missingDoctypeSystemIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.DATA,
            this.emitCurrentDoctype(t);
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            this._err(Er.missingQuoteBeforeDoctypeSystemIdentifier),
            t.forceQuirks = !0,
            this.state = Dr.BOGUS_DOCTYPE,
            this._stateBogusDoctype(e)
        }
    }
    _stateDoctypeSystemIdentifierDoubleQuoted(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.QUOTATION_MARK:
            this.state = Dr.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            t.systemId += "�";
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.abruptDoctypeSystemIdentifier),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this.state = Dr.DATA;
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            t.systemId += String.fromCodePoint(e)
        }
    }
    _stateDoctypeSystemIdentifierSingleQuoted(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.APOSTROPHE:
            this.state = Dr.AFTER_DOCTYPE_SYSTEM_IDENTIFIER;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter),
            t.systemId += "�";
            break;
        case pr.GREATER_THAN_SIGN:
            this._err(Er.abruptDoctypeSystemIdentifier),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this.state = Dr.DATA;
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            t.systemId += String.fromCodePoint(e)
        }
    }
    _stateAfterDoctypeSystemIdentifier(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.SPACE:
        case pr.LINE_FEED:
        case pr.TABULATION:
        case pr.FORM_FEED:
            break;
        case pr.GREATER_THAN_SIGN:
            this.emitCurrentDoctype(t),
            this.state = Dr.DATA;
            break;
        case pr.EOF:
            this._err(Er.eofInDoctype),
            t.forceQuirks = !0,
            this.emitCurrentDoctype(t),
            this._emitEOFToken();
            break;
        default:
            this._err(Er.unexpectedCharacterAfterDoctypeSystemIdentifier),
            this.state = Dr.BOGUS_DOCTYPE,
            this._stateBogusDoctype(e)
        }
    }
    _stateBogusDoctype(e) {
        const t = this.currentToken;
        switch (e) {
        case pr.GREATER_THAN_SIGN:
            this.emitCurrentDoctype(t),
            this.state = Dr.DATA;
            break;
        case pr.NULL:
            this._err(Er.unexpectedNullCharacter);
            break;
        case pr.EOF:
            this.emitCurrentDoctype(t),
            this._emitEOFToken()
        }
    }
    _stateCdataSection(e) {
        switch (e) {
        case pr.RIGHT_SQUARE_BRACKET:
            this.state = Dr.CDATA_SECTION_BRACKET;
            break;
        case pr.EOF:
            this._err(Er.eofInCdata),
            this._emitEOFToken();
            break;
        default:
            this._emitCodePoint(e)
        }
    }
    _stateCdataSectionBracket(e) {
        e === pr.RIGHT_SQUARE_BRACKET ? this.state = Dr.CDATA_SECTION_END : (this._emitChars("]"), this.state = Dr.CDATA_SECTION, this._stateCdataSection(e))
    }
    _stateCdataSectionEnd(e) {
        switch (e) {
        case pr.GREATER_THAN_SIGN:
            this.state = Dr.DATA;
            break;
        case pr.RIGHT_SQUARE_BRACKET:
            this._emitChars("]");
            break;
        default:
            this._emitChars("]]"),
            this.state = Dr.CDATA_SECTION,
            this._stateCdataSection(e)
        }
    }
    _stateCharacterReference(e) {
        e === pr.NUMBER_SIGN ? this.state = Dr.NUMERIC_CHARACTER_REFERENCE : Ur(e) ? (this.state = Dr.NAMED_CHARACTER_REFERENCE, this._stateNamedCharacterReference(e)) : (this._flushCodePointConsumedAsCharacterReference(pr.AMPERSAND), this._reconsumeInState(this.returnState, e))
    }
    _stateNamedCharacterReference(e) {
        const t = this._matchNamedCharacterReference(e);
        if (this._ensureHibernation());
        else if (t) {
            for (let e = 0; e < t.length; e++)
                this._flushCodePointConsumedAsCharacterReference(t[e]);
            this.state = this.returnState
        } else
            this._flushCodePointConsumedAsCharacterReference(pr.AMPERSAND), this.state = Dr.AMBIGUOUS_AMPERSAND
    }
    _stateAmbiguousAmpersand(e) {
        Ur(e) ? this._flushCodePointConsumedAsCharacterReference(e) : (e === pr.SEMICOLON && this._err(Er.unknownNamedCharacterReference), this._reconsumeInState(this.returnState, e))
    }
    _stateNumericCharacterReference(e) {
        this.charRefCode = 0,
        e === pr.LATIN_SMALL_X || e === pr.LATIN_CAPITAL_X ? this.state = Dr.HEXADEMICAL_CHARACTER_REFERENCE_START : Mr(e) ? (this.state = Dr.DECIMAL_CHARACTER_REFERENCE, this._stateDecimalCharacterReference(e)) : (this._err(Er.absenceOfDigitsInNumericCharacterReference), this._flushCodePointConsumedAsCharacterReference(pr.AMPERSAND), this._flushCodePointConsumedAsCharacterReference(pr.NUMBER_SIGN), this._reconsumeInState(this.returnState, e))
    }
    _stateHexademicalCharacterReferenceStart(e) {
        !function (e) {
            return Mr(e) || Fr(e) || Hr(e)
        }
        (e) ? (this._err(Er.absenceOfDigitsInNumericCharacterReference), this._flushCodePointConsumedAsCharacterReference(pr.AMPERSAND), this._flushCodePointConsumedAsCharacterReference(pr.NUMBER_SIGN), this._unconsume(2), this.state = this.returnState) : (this.state = Dr.HEXADEMICAL_CHARACTER_REFERENCE, this._stateHexademicalCharacterReference(e))
    }
    _stateHexademicalCharacterReference(e) {
        Fr(e) ? this.charRefCode = 16 * this.charRefCode + e - 55 : Hr(e) ? this.charRefCode = 16 * this.charRefCode + e - 87 : Mr(e) ? this.charRefCode = 16 * this.charRefCode + e - 48 : e === pr.SEMICOLON ? this.state = Dr.NUMERIC_CHARACTER_REFERENCE_END : (this._err(Er.missingSemicolonAfterCharacterReference), this.state = Dr.NUMERIC_CHARACTER_REFERENCE_END, this._stateNumericCharacterReferenceEnd(e))
    }
    _stateDecimalCharacterReference(e) {
        Mr(e) ? this.charRefCode = 10 * this.charRefCode + e - 48 : e === pr.SEMICOLON ? this.state = Dr.NUMERIC_CHARACTER_REFERENCE_END : (this._err(Er.missingSemicolonAfterCharacterReference), this.state = Dr.NUMERIC_CHARACTER_REFERENCE_END, this._stateNumericCharacterReferenceEnd(e))
    }
    _stateNumericCharacterReferenceEnd(e) {
        if (this.charRefCode === pr.NULL)
            this._err(Er.nullCharacterReference), this.charRefCode = pr.REPLACEMENT_CHARACTER;
        else if (this.charRefCode > 1114111)
            this._err(Er.characterReferenceOutsideUnicodeRange), this.charRefCode = pr.REPLACEMENT_CHARACTER;
        else if (mr(this.charRefCode))
            this._err(Er.surrogateCharacterReference), this.charRefCode = pr.REPLACEMENT_CHARACTER;
        else if (_r(this.charRefCode))
            this._err(Er.noncharacterCharacterReference);
        else if (fr(this.charRefCode) || this.charRefCode === pr.CARRIAGE_RETURN) {
            this._err(Er.controlCharacterReference);
            const e = Or.get(this.charRefCode);
            void 0 !== e && (this.charRefCode = e)
        }
        this._flushCodePointConsumedAsCharacterReference(this.charRefCode),
        this._reconsumeInState(this.returnState, e)
    }
}
const Yr = new Set([Ar.DD, Ar.DT, Ar.LI, Ar.OPTGROUP, Ar.OPTION, Ar.P, Ar.RB, Ar.RP, Ar.RT, Ar.RTC]), Vr = new Set([...Yr, Ar.CAPTION, Ar.COLGROUP, Ar.TBODY, Ar.TD, Ar.TFOOT, Ar.TH, Ar.THEAD, Ar.TR]), Qr = new Map([[Ar.APPLET, br.HTML], [Ar.CAPTION, br.HTML], [Ar.HTML, br.HTML], [Ar.MARQUEE, br.HTML], [Ar.OBJECT, br.HTML], [Ar.TABLE, br.HTML], [Ar.TD, br.HTML], [Ar.TEMPLATE, br.HTML], [Ar.TH, br.HTML], [Ar.ANNOTATION_XML, br.MATHML], [Ar.MI, br.MATHML], [Ar.MN, br.MATHML], [Ar.MO, br.MATHML], [Ar.MS, br.MATHML], [Ar.MTEXT, br.MATHML], [Ar.DESC, br.SVG], [Ar.FOREIGN_OBJECT, br.SVG], [Ar.TITLE, br.SVG]]), Wr = [Ar.H1, Ar.H2, Ar.H3, Ar.H4, Ar.H5, Ar.H6], Kr = [Ar.TR, Ar.TEMPLATE, Ar.HTML], Zr = [Ar.TBODY, Ar.TFOOT, Ar.THEAD, Ar.TEMPLATE, Ar.HTML], Xr = [Ar.TABLE, Ar.TEMPLATE, Ar.HTML], $r = [Ar.TD, Ar.TH];
class Jr {
    constructor(e, t, a) {
        this.treeAdapter = t,
        this.handler = a,
        this.items = [],
        this.tagIDs = [],
        this.stackTop = -1,
        this.tmplCount = 0,
        this.currentTagId = Ar.UNKNOWN,
        this.current = e
    }
    get currentTmplContentOrNode() {
        return this._isInTemplate() ? this.treeAdapter.getTemplateContent(this.current) : this.current
    }
    _indexOf(e) {
        return this.items.lastIndexOf(e, this.stackTop)
    }
    _isInTemplate() {
        return this.currentTagId === Ar.TEMPLATE && this.treeAdapter.getNamespaceURI(this.current) === br.HTML
    }
    _updateCurrentElement() {
        this.current = this.items[this.stackTop],
        this.currentTagId = this.tagIDs[this.stackTop]
    }
    push(e, t) {
        this.stackTop++,
        this.items[this.stackTop] = e,
        this.current = e,
        this.tagIDs[this.stackTop] = t,
        this.currentTagId = t,
        this._isInTemplate() && this.tmplCount++,
        this.handler.onItemPush(e, t, !0)
    }
    pop() {
        const e = this.current;
        this.tmplCount > 0 && this._isInTemplate() && this.tmplCount--,
        this.stackTop--,
        this._updateCurrentElement(),
        this.handler.onItemPop(e, !0)
    }
    replace(e, t) {
        const a = this._indexOf(e);
        this.items[a] = t,
        a === this.stackTop && (this.current = t)
    }
    insertAfter(e, t, a) {
        const n = this._indexOf(e) + 1;
        this.items.splice(n, 0, t),
        this.tagIDs.splice(n, 0, a),
        this.stackTop++,
        n === this.stackTop && this._updateCurrentElement(),
        this.handler.onItemPush(this.current, this.currentTagId, n === this.stackTop)
    }
    popUntilTagNamePopped(e) {
        let t = this.stackTop + 1;
        do {
            t = this.tagIDs.lastIndexOf(e, t - 1)
        } while (t > 0 && this.treeAdapter.getNamespaceURI(this.items[t]) !== br.HTML);
        this.shortenToLength(t < 0 ? 0 : t)
    }
    shortenToLength(e) {
        for (; this.stackTop >= e; ) {
            const t = this.current;
            this.tmplCount > 0 && this._isInTemplate() && (this.tmplCount -= 1),
            this.stackTop--,
            this._updateCurrentElement(),
            this.handler.onItemPop(t, this.stackTop < e)
        }
    }
    popUntilElementPopped(e) {
        const t = this._indexOf(e);
        this.shortenToLength(t < 0 ? 0 : t)
    }
    popUntilPopped(e, t) {
        const a = this._indexOfTagNames(e, t);
        this.shortenToLength(a < 0 ? 0 : a)
    }
    popUntilNumberedHeaderPopped() {
        this.popUntilPopped(Wr, br.HTML)
    }
    popUntilTableCellPopped() {
        this.popUntilPopped($r, br.HTML)
    }
    popAllUpToHtmlElement() {
        this.tmplCount = 0,
        this.shortenToLength(1)
    }
    _indexOfTagNames(e, t) {
        for (let a = this.stackTop; a >= 0; a--)
            if (e.includes(this.tagIDs[a]) && this.treeAdapter.getNamespaceURI(this.items[a]) === t)
                return a;
        return -1
    }
    clearBackTo(e, t) {
        const a = this._indexOfTagNames(e, t);
        this.shortenToLength(a + 1)
    }
    clearBackToTableContext() {
        this.clearBackTo(Xr, br.HTML)
    }
    clearBackToTableBodyContext() {
        this.clearBackTo(Zr, br.HTML)
    }
    clearBackToTableRowContext() {
        this.clearBackTo(Kr, br.HTML)
    }
    remove(e) {
        const t = this._indexOf(e);
        t >= 0 && (t === this.stackTop ? this.pop() : (this.items.splice(t, 1), this.tagIDs.splice(t, 1), this.stackTop--, this._updateCurrentElement(), this.handler.onItemPop(e, !1)))
    }
    tryPeekProperlyNestedBodyElement() {
        return this.stackTop >= 1 && this.tagIDs[1] === Ar.BODY ? this.items[1] : null
    }
    contains(e) {
        return this._indexOf(e) > -1
    }
    getCommonAncestor(e) {
        const t = this._indexOf(e) - 1;
        return t >= 0 ? this.items[t] : null
    }
    isRootHtmlElementCurrent() {
        return 0 === this.stackTop && this.tagIDs[0] === Ar.HTML
    }
    hasInScope(e) {
        for (let t = this.stackTop; t >= 0; t--) {
            const a = this.tagIDs[t],
            n = this.treeAdapter.getNamespaceURI(this.items[t]);
            if (a === e && n === br.HTML)
                return !0;
            if (Qr.get(a) === n)
                return !1
        }
        return !0
    }
    hasNumberedHeaderInScope() {
        for (let e = this.stackTop; e >= 0; e--) {
            const t = this.tagIDs[e],
            a = this.treeAdapter.getNamespaceURI(this.items[e]);
            if (kr(t) && a === br.HTML)
                return !0;
            if (Qr.get(t) === a)
                return !1
        }
        return !0
    }
    hasInListItemScope(e) {
        for (let t = this.stackTop; t >= 0; t--) {
            const a = this.tagIDs[t],
            n = this.treeAdapter.getNamespaceURI(this.items[t]);
            if (a === e && n === br.HTML)
                return !0;
            if ((a === Ar.UL || a === Ar.OL) && n === br.HTML || Qr.get(a) === n)
                return !1
        }
        return !0
    }
    hasInButtonScope(e) {
        for (let t = this.stackTop; t >= 0; t--) {
            const a = this.tagIDs[t],
            n = this.treeAdapter.getNamespaceURI(this.items[t]);
            if (a === e && n === br.HTML)
                return !0;
            if (a === Ar.BUTTON && n === br.HTML || Qr.get(a) === n)
                return !1
        }
        return !0
    }
    hasInTableScope(e) {
        for (let t = this.stackTop; t >= 0; t--) {
            const a = this.tagIDs[t];
            if (this.treeAdapter.getNamespaceURI(this.items[t]) === br.HTML) {
                if (a === e)
                    return !0;
                if (a === Ar.TABLE || a === Ar.TEMPLATE || a === Ar.HTML)
                    return !1
            }
        }
        return !0
    }
    hasTableBodyContextInTableScope() {
        for (let e = this.stackTop; e >= 0; e--) {
            const t = this.tagIDs[e];
            if (this.treeAdapter.getNamespaceURI(this.items[e]) === br.HTML) {
                if (t === Ar.TBODY || t === Ar.THEAD || t === Ar.TFOOT)
                    return !0;
                if (t === Ar.TABLE || t === Ar.HTML)
                    return !1
            }
        }
        return !0
    }
    hasInSelectScope(e) {
        for (let t = this.stackTop; t >= 0; t--) {
            const a = this.tagIDs[t];
            if (this.treeAdapter.getNamespaceURI(this.items[t]) === br.HTML) {
                if (a === e)
                    return !0;
                if (a !== Ar.OPTION && a !== Ar.OPTGROUP)
                    return !1
            }
        }
        return !0
    }
    generateImpliedEndTags() {
        for (; Yr.has(this.currentTagId); )
            this.pop()
    }
    generateImpliedEndTagsThoroughly() {
        for (; Vr.has(this.currentTagId); )
            this.pop()
    }
    generateImpliedEndTagsWithExclusion(e) {
        for (; this.currentTagId !== e && Vr.has(this.currentTagId); )
            this.pop()
    }
}
var ec;
!function (e) {
    e[e.Marker = 0] = "Marker",
    e[e.Element = 1] = "Element"
}
(ec = ec || (ec = {}));
const tc = {
    type: ec.Marker
};
class ac {
    constructor(e) {
        this.treeAdapter = e,
        this.entries = [],
        this.bookmark = null
    }
    _getNoahArkConditionCandidates(e, t) {
        const a = [],
        n = t.length,
        i = this.treeAdapter.getTagName(e),
        s = this.treeAdapter.getNamespaceURI(e);
        for (let e = 0; e < this.entries.length; e++) {
            const t = this.entries[e];
            if (t.type === ec.Marker)
                break;
            const {
                element: o
            } = t;
            if (this.treeAdapter.getTagName(o) === i && this.treeAdapter.getNamespaceURI(o) === s) {
                const t = this.treeAdapter.getAttrList(o);
                t.length === n && a.push({
                    idx: e,
                    attrs: t
                })
            }
        }
        return a
    }
    _ensureNoahArkCondition(e) {
        if (this.entries.length < 3)
            return;
        const t = this.treeAdapter.getAttrList(e),
        a = this._getNoahArkConditionCandidates(e, t);
        if (a.length < 3)
            return;
        const n = new Map(t.map((e => [e.name, e.value])));
        let i = 0;
        for (let e = 0; e < a.length; e++) {
            const t = a[e];
            t.attrs.every((e => n.get(e.name) === e.value)) && (i += 1, i >= 3 && this.entries.splice(t.idx, 1))
        }
    }
    insertMarker() {
        this.entries.unshift(tc)
    }
    pushElement(e, t) {
        this._ensureNoahArkCondition(e),
        this.entries.unshift({
            type: ec.Element,
            element: e,
            token: t
        })
    }
    insertElementAfterBookmark(e, t) {
        const a = this.entries.indexOf(this.bookmark);
        this.entries.splice(a, 0, {
            type: ec.Element,
            element: e,
            token: t
        })
    }
    removeEntry(e) {
        const t = this.entries.indexOf(e);
        t >= 0 && this.entries.splice(t, 1)
    }
    clearToLastMarker() {
        const e = this.entries.indexOf(tc);
        e >= 0 ? this.entries.splice(0, e + 1) : this.entries.length = 0
    }
    getElementEntryInScopeWithTagName(e) {
        const t = this.entries.find((t => t.type === ec.Marker || this.treeAdapter.getTagName(t.element) === e));
        return t && t.type === ec.Element ? t : null
    }
    getElementEntry(e) {
        return this.entries.find((t => t.type === ec.Element && t.element === e))
    }
}
function nc(e) {
    return {
        nodeName: "#text",
        value: e,
        parentNode: null
    }
}
const ic = {
    createDocument: () => ({
        nodeName: "#document",
        mode: Tr.NO_QUIRKS,
        childNodes: []
    }),
    createDocumentFragment: () => ({
        nodeName: "#document-fragment",
        childNodes: []
    }),
    createElement: (e, t, a) => ({
        nodeName: e,
        tagName: e,
        attrs: a,
        namespaceURI: t,
        childNodes: [],
        parentNode: null
    }),
    createCommentNode: e => ({
        nodeName: "#comment",
        data: e,
        parentNode: null
    }),
    appendChild(e, t) {
        e.childNodes.push(t),
        t.parentNode = e
    },
    insertBefore(e, t, a) {
        const n = e.childNodes.indexOf(a);
        e.childNodes.splice(n, 0, t),
        t.parentNode = e
    },
    setTemplateContent(e, t) {
        e.content = t
    },
    getTemplateContent: e => e.content,
    setDocumentType(e, t, a, n) {
        const i = e.childNodes.find((e => "#documentType" === e.nodeName));
        if (i)
            i.name = t, i.publicId = a, i.systemId = n;
        else {
            const i = {
                nodeName: "#documentType",
                name: t,
                publicId: a,
                systemId: n,
                parentNode: null
            };
            ic.appendChild(e, i)
        }
    },
    setDocumentMode(e, t) {
        e.mode = t
    },
    getDocumentMode: e => e.mode,
    detachNode(e) {
        if (e.parentNode) {
            const t = e.parentNode.childNodes.indexOf(e);
            e.parentNode.childNodes.splice(t, 1),
            e.parentNode = null
        }
    },
    insertText(e, t) {
        if (e.childNodes.length > 0) {
            const a = e.childNodes[e.childNodes.length - 1];
            if (ic.isTextNode(a))
                return void(a.value += t)
        }
        ic.appendChild(e, nc(t))
    },
    insertTextBefore(e, t, a) {
        const n = e.childNodes[e.childNodes.indexOf(a) - 1];
        n && ic.isTextNode(n) ? n.value += t : ic.insertBefore(e, nc(t), a)
    },
    adoptAttributes(e, t) {
        const a = new Set(e.attrs.map((e => e.name)));
        for (let n = 0; n < t.length; n++)
            a.has(t[n].name) || e.attrs.push(t[n])
    },
    getFirstChild: e => e.childNodes[0],
    getChildNodes: e => e.childNodes,
    getParentNode: e => e.parentNode,
    getAttrList: e => e.attrs,
    getTagName: e => e.tagName,
    getNamespaceURI: e => e.namespaceURI,
    getTextNodeContent: e => e.value,
    getCommentNodeContent: e => e.data,
    getDocumentTypeNodeName: e => e.name,
    getDocumentTypeNodePublicId: e => e.publicId,
    getDocumentTypeNodeSystemId: e => e.systemId,
    isTextNode: e => "#text" === e.nodeName,
    isCommentNode: e => "#comment" === e.nodeName,
    isDocumentTypeNode: e => "#documentType" === e.nodeName,
    isElementNode: e => Object.prototype.hasOwnProperty.call(e, "tagName"),
    setNodeSourceCodeLocation(e, t) {
        e.sourceCodeLocation = t
    },
    getNodeSourceCodeLocation: e => e.sourceCodeLocation,
    updateNodeSourceCodeLocation(e, t) {
        e.sourceCodeLocation = {
            ...e.sourceCodeLocation,
            ...t
        }
    }
}, sc = ["+//silmaril//dtd html pro v0r11 19970101//", "-//as//dtd html 3.0 aswedit + extensions//", "-//advasoft ltd//dtd html 3.0 aswedit + extensions//", "-//ietf//dtd html 2.0 level 1//", "-//ietf//dtd html 2.0 level 2//", "-//ietf//dtd html 2.0 strict level 1//", "-//ietf//dtd html 2.0 strict level 2//", "-//ietf//dtd html 2.0 strict//", "-//ietf//dtd html 2.0//", "-//ietf//dtd html 2.1e//", "-//ietf//dtd html 3.0//", "-//ietf//dtd html 3.2 final//", "-//ietf//dtd html 3.2//", "-//ietf//dtd html 3//", "-//ietf//dtd html level 0//", "-//ietf//dtd html level 1//", "-//ietf//dtd html level 2//", "-//ietf//dtd html level 3//", "-//ietf//dtd html strict level 0//", "-//ietf//dtd html strict level 1//", "-//ietf//dtd html strict level 2//", "-//ietf//dtd html strict level 3//", "-//ietf//dtd html strict//", "-//ietf//dtd html//", "-//metrius//dtd metrius presentational//", "-//microsoft//dtd internet explorer 2.0 html strict//", "-//microsoft//dtd internet explorer 2.0 html//", "-//microsoft//dtd internet explorer 2.0 tables//", "-//microsoft//dtd internet explorer 3.0 html strict//", "-//microsoft//dtd internet explorer 3.0 html//", "-//microsoft//dtd internet explorer 3.0 tables//", "-//netscape comm. corp.//dtd html//", "-//netscape comm. corp.//dtd strict html//", "-//o'reilly and associates//dtd html 2.0//", "-//o'reilly and associates//dtd html extended 1.0//", "-//o'reilly and associates//dtd html extended relaxed 1.0//", "-//sq//dtd html 2.0 hotmetal + extensions//", "-//softquad software//dtd hotmetal pro 6.0::19990601::extensions to html 4.0//", "-//softquad//dtd hotmetal pro 4.0::19971010::extensions to html 4.0//", "-//spyglass//dtd html 2.0 extended//", "-//sun microsystems corp.//dtd hotjava html//", "-//sun microsystems corp.//dtd hotjava strict html//", "-//w3c//dtd html 3 1995-03-24//", "-//w3c//dtd html 3.2 draft//", "-//w3c//dtd html 3.2 final//", "-//w3c//dtd html 3.2//", "-//w3c//dtd html 3.2s draft//", "-//w3c//dtd html 4.0 frameset//", "-//w3c//dtd html 4.0 transitional//", "-//w3c//dtd html experimental 19960712//", "-//w3c//dtd html experimental 970421//", "-//w3c//dtd w3 html//", "-//w3o//dtd w3 html 3.0//", "-//webtechs//dtd mozilla html 2.0//", "-//webtechs//dtd mozilla html//"], oc = [...sc, "-//w3c//dtd html 4.01 frameset//", "-//w3c//dtd html 4.01 transitional//"], rc = new Set(["-//w3o//dtd w3 html strict 3.0//en//", "-/w3c/dtd html 4.0 transitional/en", "html"]), cc = ["-//w3c//dtd xhtml 1.0 frameset//", "-//w3c//dtd xhtml 1.0 transitional//"], lc = [...cc, "-//w3c//dtd html 4.01 frameset//", "-//w3c//dtd html 4.01 transitional//"];
function pc(e, t) {
    return t.some((t => e.startsWith(t)))
}
const uc = new Map(["attributeName", "attributeType", "baseFrequency", "baseProfile", "calcMode", "clipPathUnits", "diffuseConstant", "edgeMode", "filterUnits", "glyphRef", "gradientTransform", "gradientUnits", "kernelMatrix", "kernelUnitLength", "keyPoints", "keySplines", "keyTimes", "lengthAdjust", "limitingConeAngle", "markerHeight", "markerUnits", "markerWidth", "maskContentUnits", "maskUnits", "numOctaves", "pathLength", "patternContentUnits", "patternTransform", "patternUnits", "pointsAtX", "pointsAtY", "pointsAtZ", "preserveAlpha", "preserveAspectRatio", "primitiveUnits", "refX", "refY", "repeatCount", "repeatDur", "requiredExtensions", "requiredFeatures", "specularConstant", "specularExponent", "spreadMethod", "startOffset", "stdDeviation", "stitchTiles", "surfaceScale", "systemLanguage", "tableValues", "targetX", "targetY", "textLength", "viewBox", "viewTarget", "xChannelSelector", "yChannelSelector", "zoomAndPan"].map((e => [e.toLowerCase(), e]))), dc = new Map([["xlink:actuate", {
                    prefix: "xlink",
                    name: "actuate",
                    namespace: br.XLINK
                }
            ], ["xlink:arcrole", {
                    prefix: "xlink",
                    name: "arcrole",
                    namespace: br.XLINK
                }
            ], ["xlink:href", {
                    prefix: "xlink",
                    name: "href",
                    namespace: br.XLINK
                }
            ], ["xlink:role", {
                    prefix: "xlink",
                    name: "role",
                    namespace: br.XLINK
                }
            ], ["xlink:show", {
                    prefix: "xlink",
                    name: "show",
                    namespace: br.XLINK
                }
            ], ["xlink:title", {
                    prefix: "xlink",
                    name: "title",
                    namespace: br.XLINK
                }
            ], ["xlink:type", {
                    prefix: "xlink",
                    name: "type",
                    namespace: br.XLINK
                }
            ], ["xml:base", {
                    prefix: "xml",
                    name: "base",
                    namespace: br.XML
                }
            ], ["xml:lang", {
                    prefix: "xml",
                    name: "lang",
                    namespace: br.XML
                }
            ], ["xml:space", {
                    prefix: "xml",
                    name: "space",
                    namespace: br.XML
                }
            ], ["xmlns", {
                    prefix: "",
                    name: "xmlns",
                    namespace: br.XMLNS
                }
            ], ["xmlns:xlink", {
                    prefix: "xmlns",
                    name: "xlink",
                    namespace: br.XMLNS
                }
            ]]), hc = new Map(["altGlyph", "altGlyphDef", "altGlyphItem", "animateColor", "animateMotion", "animateTransform", "clipPath", "feBlend", "feColorMatrix", "feComponentTransfer", "feComposite", "feConvolveMatrix", "feDiffuseLighting", "feDisplacementMap", "feDistantLight", "feFlood", "feFuncA", "feFuncB", "feFuncG", "feFuncR", "feGaussianBlur", "feImage", "feMerge", "feMergeNode", "feMorphology", "feOffset", "fePointLight", "feSpecularLighting", "feSpotLight", "feTile", "feTurbulence", "foreignObject", "glyphRef", "linearGradient", "radialGradient", "textPath"].map((e => [e.toLowerCase(), e]))), mc = new Set([Ar.B, Ar.BIG, Ar.BLOCKQUOTE, Ar.BODY, Ar.BR, Ar.CENTER, Ar.CODE, Ar.DD, Ar.DIV, Ar.DL, Ar.DT, Ar.EM, Ar.EMBED, Ar.H1, Ar.H2, Ar.H3, Ar.H4, Ar.H5, Ar.H6, Ar.HEAD, Ar.HR, Ar.I, Ar.IMG, Ar.LI, Ar.LISTING, Ar.MENU, Ar.META, Ar.NOBR, Ar.OL, Ar.P, Ar.PRE, Ar.RUBY, Ar.S, Ar.SMALL, Ar.SPAN, Ar.STRONG, Ar.STRIKE, Ar.SUB, Ar.SUP, Ar.TABLE, Ar.TT, Ar.U, Ar.UL, Ar.VAR]);
function fc(e) {
    for (let t = 0; t < e.attrs.length; t++)
        if ("definitionurl" === e.attrs[t].name) {
            e.attrs[t].name = "definitionURL";
            break
        }
}
function _c(e) {
    for (let t = 0; t < e.attrs.length; t++) {
        const a = uc.get(e.attrs[t].name);
        null != a && (e.attrs[t].name = a)
    }
}
function Ec(e) {
    for (let t = 0; t < e.attrs.length; t++) {
        const a = dc.get(e.attrs[t].name);
        a && (e.attrs[t].prefix = a.prefix, e.attrs[t].name = a.name, e.attrs[t].namespace = a.namespace)
    }
}
var gc;
!function (e) {
    e[e.INITIAL = 0] = "INITIAL",
    e[e.BEFORE_HTML = 1] = "BEFORE_HTML",
    e[e.BEFORE_HEAD = 2] = "BEFORE_HEAD",
    e[e.IN_HEAD = 3] = "IN_HEAD",
    e[e.IN_HEAD_NO_SCRIPT = 4] = "IN_HEAD_NO_SCRIPT",
    e[e.AFTER_HEAD = 5] = "AFTER_HEAD",
    e[e.IN_BODY = 6] = "IN_BODY",
    e[e.TEXT = 7] = "TEXT",
    e[e.IN_TABLE = 8] = "IN_TABLE",
    e[e.IN_TABLE_TEXT = 9] = "IN_TABLE_TEXT",
    e[e.IN_CAPTION = 10] = "IN_CAPTION",
    e[e.IN_COLUMN_GROUP = 11] = "IN_COLUMN_GROUP",
    e[e.IN_TABLE_BODY = 12] = "IN_TABLE_BODY",
    e[e.IN_ROW = 13] = "IN_ROW",
    e[e.IN_CELL = 14] = "IN_CELL",
    e[e.IN_SELECT = 15] = "IN_SELECT",
    e[e.IN_SELECT_IN_TABLE = 16] = "IN_SELECT_IN_TABLE",
    e[e.IN_TEMPLATE = 17] = "IN_TEMPLATE",
    e[e.AFTER_BODY = 18] = "AFTER_BODY",
    e[e.IN_FRAMESET = 19] = "IN_FRAMESET",
    e[e.AFTER_FRAMESET = 20] = "AFTER_FRAMESET",
    e[e.AFTER_AFTER_BODY = 21] = "AFTER_AFTER_BODY",
    e[e.AFTER_AFTER_FRAMESET = 22] = "AFTER_AFTER_FRAMESET"
}
(gc || (gc = {}));
const bc = {
    startLine: -1,
    startCol: -1,
    startOffset: -1,
    endLine: -1,
    endCol: -1,
    endOffset: -1
}, xc = new Set([Ar.TABLE, Ar.TBODY, Ar.TFOOT, Ar.THEAD, Ar.TR]), Tc = {
    scriptingEnabled: !0,
    sourceCodeLocationInfo: !1,
    treeAdapter: ic,
    onParseError: null
};
class vc {
    constructor(e, t, a = null, n = null) {
        this.fragmentContext = a,
        this.scriptHandler = n,
        this.currentToken = null,
        this.stopped = !1,
        this.insertionMode = gc.INITIAL,
        this.originalInsertionMode = gc.INITIAL,
        this.headElement = null,
        this.formElement = null,
        this.currentNotInHTML = !1,
        this.tmplInsertionModeStack = [],
        this.pendingCharacterTokens = [],
        this.hasNonWhitespacePendingCharacterToken = !1,
        this.framesetOk = !0,
        this.skipNextNewLine = !1,
        this.fosterParentingEnabled = !1,
        this.options = {
            ...Tc,
            ...e
        },
        this.treeAdapter = this.options.treeAdapter,
        this.onParseError = this.options.onParseError,
        this.onParseError && (this.options.sourceCodeLocationInfo = !0),
        this.document = null != t ? t : this.treeAdapter.createDocument(),
        this.tokenizer = new qr(this.options, this),
        this.activeFormattingElements = new ac(this.treeAdapter),
        this.fragmentContextID = a ? Nr(this.treeAdapter.getTagName(a)) : Ar.UNKNOWN,
        this._setContextModes(null != a ? a : this.document, this.fragmentContextID),
        this.openElements = new Jr(this.document, this.treeAdapter, this)
    }
    static parse(e, t) {
        const a = new this(t);
        return a.tokenizer.write(e, !0),
        a.document
    }
    static getFragmentParser(e, t) {
        const a = {
            ...Tc,
            ...t
        };
        null != e || (e = a.treeAdapter.createElement(vr.TEMPLATE, br.HTML, []));
        const n = a.treeAdapter.createElement("documentmock", br.HTML, []),
        i = new this(a, n, e);
        return i.fragmentContextID === Ar.TEMPLATE && i.tmplInsertionModeStack.unshift(gc.IN_TEMPLATE),
        i._initTokenizerForFragmentParsing(),
        i._insertFakeRootElement(),
        i._resetInsertionMode(),
        i._findFormInFragmentContext(),
        i
    }
    getFragment() {
        const e = this.treeAdapter.getFirstChild(this.document),
        t = this.treeAdapter.createDocumentFragment();
        return this._adoptNodes(e, t),
        t
    }
    _err(e, t, a) {
        var n;
        if (!this.onParseError)
            return;
        const i = null !== (n = e.location) && void 0 !== n ? n : bc,
        s = {
            code: t,
            startLine: i.startLine,
            startCol: i.startCol,
            startOffset: i.startOffset,
            endLine: a ? i.startLine : i.endLine,
            endCol: a ? i.startCol : i.endCol,
            endOffset: a ? i.startOffset : i.endOffset
        };
        this.onParseError(s)
    }
    onItemPush(e, t, a) {
        var n,
        i;
        null === (i = (n = this.treeAdapter).onItemPush) || void 0 === i || i.call(n, e),
        a && this.openElements.stackTop > 0 && this._setContextModes(e, t)
    }
    onItemPop(e, t) {
        var a,
        n;
        if (this.options.sourceCodeLocationInfo && this._setEndLocation(e, this.currentToken), null === (n = (a = this.treeAdapter).onItemPop) || void 0 === n || n.call(a, e, this.openElements.current), t) {
            let e,
            t;
            0 === this.openElements.stackTop && this.fragmentContext ? (e = this.fragmentContext, t = this.fragmentContextID) : ({
                current: e,
                currentTagId: t
            } = this.openElements),
            this._setContextModes(e, t)
        }
    }
    _setContextModes(e, t) {
        const a = e === this.document || this.treeAdapter.getNamespaceURI(e) === br.HTML;
        this.currentNotInHTML = !a,
        this.tokenizer.inForeignNode = !a && !this._isIntegrationPoint(t, e)
    }
    _switchToTextParsing(e, t) {
        this._insertElement(e, br.HTML),
        this.tokenizer.state = t,
        this.originalInsertionMode = this.insertionMode,
        this.insertionMode = gc.TEXT
    }
    switchToPlaintextParsing() {
        this.insertionMode = gc.TEXT,
        this.originalInsertionMode = gc.IN_BODY,
        this.tokenizer.state = Lr.PLAINTEXT
    }
    _getAdjustedCurrentElement() {
        return 0 === this.openElements.stackTop && this.fragmentContext ? this.fragmentContext : this.openElements.current
    }
    _findFormInFragmentContext() {
        let e = this.fragmentContext;
        for (; e; ) {
            if (this.treeAdapter.getTagName(e) === vr.FORM) {
                this.formElement = e;
                break
            }
            e = this.treeAdapter.getParentNode(e)
        }
    }
    _initTokenizerForFragmentParsing() {
        if (this.fragmentContext && this.treeAdapter.getNamespaceURI(this.fragmentContext) === br.HTML)
            switch (this.fragmentContextID) {
            case Ar.TITLE:
            case Ar.TEXTAREA:
                this.tokenizer.state = Lr.RCDATA;
                break;
            case Ar.STYLE:
            case Ar.XMP:
            case Ar.IFRAME:
            case Ar.NOEMBED:
            case Ar.NOFRAMES:
            case Ar.NOSCRIPT:
                this.tokenizer.state = Lr.RAWTEXT;
                break;
            case Ar.SCRIPT:
                this.tokenizer.state = Lr.SCRIPT_DATA;
                break;
            case Ar.PLAINTEXT:
                this.tokenizer.state = Lr.PLAINTEXT
            }
    }
    _setDocumentType(e) {
        const t = e.name || "",
        a = e.publicId || "",
        n = e.systemId || "";
        if (this.treeAdapter.setDocumentType(this.document, t, a, n), e.location) {
            const t = this.treeAdapter.getChildNodes(this.document).find((e => this.treeAdapter.isDocumentTypeNode(e)));
            t && this.treeAdapter.setNodeSourceCodeLocation(t, e.location)
        }
    }
    _attachElementToTree(e, t) {
        if (this.options.sourceCodeLocationInfo) {
            const a = t && {
                ...t,
                startTag: t
            };
            this.treeAdapter.setNodeSourceCodeLocation(e, a)
        }
        if (this._shouldFosterParentOnInsertion())
            this._fosterParentElement(e);
        else {
            const t = this.openElements.currentTmplContentOrNode;
            this.treeAdapter.appendChild(t, e)
        }
    }
    _appendElement(e, t) {
        const a = this.treeAdapter.createElement(e.tagName, t, e.attrs);
        this._attachElementToTree(a, e.location)
    }
    _insertElement(e, t) {
        const a = this.treeAdapter.createElement(e.tagName, t, e.attrs);
        this._attachElementToTree(a, e.location),
        this.openElements.push(a, e.tagID)
    }
    _insertFakeElement(e, t) {
        const a = this.treeAdapter.createElement(e, br.HTML, []);
        this._attachElementToTree(a, null),
        this.openElements.push(a, t)
    }
    _insertTemplate(e) {
        const t = this.treeAdapter.createElement(e.tagName, br.HTML, e.attrs),
        a = this.treeAdapter.createDocumentFragment();
        this.treeAdapter.setTemplateContent(t, a),
        this._attachElementToTree(t, e.location),
        this.openElements.push(t, e.tagID),
        this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(a, null)
    }
    _insertFakeRootElement() {
        const e = this.treeAdapter.createElement(vr.HTML, br.HTML, []);
        this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(e, null),
        this.treeAdapter.appendChild(this.openElements.current, e),
        this.openElements.push(e, Ar.HTML)
    }
    _appendCommentNode(e, t) {
        const a = this.treeAdapter.createCommentNode(e.data);
        this.treeAdapter.appendChild(t, a),
        this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(a, e.location)
    }
    _insertCharacters(e) {
        let t,
        a;
        if (this._shouldFosterParentOnInsertion() ? (({
                    parent: t,
                    beforeElement: a
                } = this._findFosterParentingLocation()), a ? this.treeAdapter.insertTextBefore(t, e.chars, a) : this.treeAdapter.insertText(t, e.chars)) : (t = this.openElements.currentTmplContentOrNode, this.treeAdapter.insertText(t, e.chars)), !e.location)
            return;
        const n = this.treeAdapter.getChildNodes(t),
        i = a ? n.lastIndexOf(a) : n.length,
        s = n[i - 1];
        if (this.treeAdapter.getNodeSourceCodeLocation(s)) {
            const {
                endLine: t,
                endCol: a,
                endOffset: n
            } = e.location;
            this.treeAdapter.updateNodeSourceCodeLocation(s, {
                endLine: t,
                endCol: a,
                endOffset: n
            })
        } else
            this.options.sourceCodeLocationInfo && this.treeAdapter.setNodeSourceCodeLocation(s, e.location)
    }
    _adoptNodes(e, t) {
        for (let a = this.treeAdapter.getFirstChild(e); a; a = this.treeAdapter.getFirstChild(e))
            this.treeAdapter.detachNode(a), this.treeAdapter.appendChild(t, a)
    }
    _setEndLocation(e, t) {
        if (this.treeAdapter.getNodeSourceCodeLocation(e) && t.location) {
            const a = t.location,
            n = this.treeAdapter.getTagName(e),
            i = t.type === gr.END_TAG && n === t.tagName ? {
                endTag: {
                    ...a
                },
                endLine: a.endLine,
                endCol: a.endCol,
                endOffset: a.endOffset
            }
             : {
                endLine: a.startLine,
                endCol: a.startCol,
                endOffset: a.startOffset
            };
            this.treeAdapter.updateNodeSourceCodeLocation(e, i)
        }
    }
    shouldProcessStartTagTokenInForeignContent(e) {
        if (!this.currentNotInHTML)
            return !1;
        let t,
        a;
        return 0 === this.openElements.stackTop && this.fragmentContext ? (t = this.fragmentContext, a = this.fragmentContextID) : ({
            current: t,
            currentTagId: a
        } = this.openElements),
        (e.tagID !== Ar.SVG || this.treeAdapter.getTagName(t) !== vr.ANNOTATION_XML || this.treeAdapter.getNamespaceURI(t) !== br.MATHML) && (this.tokenizer.inForeignNode || (e.tagID === Ar.MGLYPH || e.tagID === Ar.MALIGNMARK) && !this._isIntegrationPoint(a, t, br.HTML))
    }
    _processToken(e) {
        switch (e.type) {
        case gr.CHARACTER:
            this.onCharacter(e);
            break;
        case gr.NULL_CHARACTER:
            this.onNullCharacter(e);
            break;
        case gr.COMMENT:
            this.onComment(e);
            break;
        case gr.DOCTYPE:
            this.onDoctype(e);
            break;
        case gr.START_TAG:
            this._processStartTag(e);
            break;
        case gr.END_TAG:
            this.onEndTag(e);
            break;
        case gr.EOF:
            this.onEof(e);
            break;
        case gr.WHITESPACE_CHARACTER:
            this.onWhitespaceCharacter(e)
        }
    }
    _isIntegrationPoint(e, t, a) {
        return function (e, t, a, n) {
            return (!n || n === br.HTML) && function (e, t, a) {
                if (t === br.MATHML && e === Ar.ANNOTATION_XML)
                    for (let e = 0; e < a.length; e++)
                        if (a[e].name === xr.ENCODING) {
                            const t = a[e].value.toLowerCase();
                            return "text/html" === t || "application/xhtml+xml" === t
                        }
                return t === br.SVG && (e === Ar.FOREIGN_OBJECT || e === Ar.DESC || e === Ar.TITLE)
            }
            (e, t, a) || (!n || n === br.MATHML) && function (e, t) {
                return t === br.MATHML && (e === Ar.MI || e === Ar.MO || e === Ar.MN || e === Ar.MS || e === Ar.MTEXT)
            }
            (e, t)
        }
        (e, this.treeAdapter.getNamespaceURI(t), this.treeAdapter.getAttrList(t), a)
    }
    _reconstructActiveFormattingElements() {
        const e = this.activeFormattingElements.entries.length;
        if (e) {
            const t = this.activeFormattingElements.entries.findIndex((e => e.type === ec.Marker || this.openElements.contains(e.element)));
            for (let a = t < 0 ? e - 1 : t - 1; a >= 0; a--) {
                const e = this.activeFormattingElements.entries[a];
                this._insertElement(e.token, this.treeAdapter.getNamespaceURI(e.element)),
                e.element = this.openElements.current
            }
        }
    }
    _closeTableCell() {
        this.openElements.generateImpliedEndTags(),
        this.openElements.popUntilTableCellPopped(),
        this.activeFormattingElements.clearToLastMarker(),
        this.insertionMode = gc.IN_ROW
    }
    _closePElement() {
        this.openElements.generateImpliedEndTagsWithExclusion(Ar.P),
        this.openElements.popUntilTagNamePopped(Ar.P)
    }
    _resetInsertionMode() {
        for (let e = this.openElements.stackTop; e >= 0; e--)
            switch (0 === e && this.fragmentContext ? this.fragmentContextID : this.openElements.tagIDs[e]) {
            case Ar.TR:
                return void(this.insertionMode = gc.IN_ROW);
            case Ar.TBODY:
            case Ar.THEAD:
            case Ar.TFOOT:
                return void(this.insertionMode = gc.IN_TABLE_BODY);
            case Ar.CAPTION:
                return void(this.insertionMode = gc.IN_CAPTION);
            case Ar.COLGROUP:
                return void(this.insertionMode = gc.IN_COLUMN_GROUP);
            case Ar.TABLE:
                return void(this.insertionMode = gc.IN_TABLE);
            case Ar.BODY:
                return void(this.insertionMode = gc.IN_BODY);
            case Ar.FRAMESET:
                return void(this.insertionMode = gc.IN_FRAMESET);
            case Ar.SELECT:
                return void this._resetInsertionModeForSelect(e);
            case Ar.TEMPLATE:
                return void(this.insertionMode = this.tmplInsertionModeStack[0]);
            case Ar.HTML:
                return void(this.insertionMode = this.headElement ? gc.AFTER_HEAD : gc.BEFORE_HEAD);
            case Ar.TD:
            case Ar.TH:
                if (e > 0)
                    return void(this.insertionMode = gc.IN_CELL);
                break;
            case Ar.HEAD:
                if (e > 0)
                    return void(this.insertionMode = gc.IN_HEAD)
            }
        this.insertionMode = gc.IN_BODY
    }
    _resetInsertionModeForSelect(e) {
        if (e > 0)
            for (let t = e - 1; t > 0; t--) {
                const e = this.openElements.tagIDs[t];
                if (e === Ar.TEMPLATE)
                    break;
                if (e === Ar.TABLE)
                    return void(this.insertionMode = gc.IN_SELECT_IN_TABLE)
            }
        this.insertionMode = gc.IN_SELECT
    }
    _isElementCausesFosterParenting(e) {
        return xc.has(e)
    }
    _shouldFosterParentOnInsertion() {
        return this.fosterParentingEnabled && this._isElementCausesFosterParenting(this.openElements.currentTagId)
    }
    _findFosterParentingLocation() {
        for (let e = this.openElements.stackTop; e >= 0; e--) {
            const t = this.openElements.items[e];
            switch (this.openElements.tagIDs[e]) {
            case Ar.TEMPLATE:
                if (this.treeAdapter.getNamespaceURI(t) === br.HTML)
                    return {
                        parent: this.treeAdapter.getTemplateContent(t),
                        beforeElement: null
                    };
                break;
            case Ar.TABLE: {
                    const a = this.treeAdapter.getParentNode(t);
                    return a ? {
                        parent: a,
                        beforeElement: t
                    }
                     : {
                        parent: this.openElements.items[e - 1],
                        beforeElement: null
                    }
                }
            }
        }
        return {
            parent: this.openElements.items[0],
            beforeElement: null
        }
    }
    _fosterParentElement(e) {
        const t = this._findFosterParentingLocation();
        t.beforeElement ? this.treeAdapter.insertBefore(t.parent, e, t.beforeElement) : this.treeAdapter.appendChild(t.parent, e)
    }
    _isSpecialElement(e, t) {
        const a = this.treeAdapter.getNamespaceURI(e);
        return Ir[a].has(t)
    }
    onCharacter(e) {
        if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode)
            !function (e, t) {
                e._insertCharacters(t),
                e.framesetOk = !1
            }
        (this, e);
        else
            switch (this.insertionMode) {
            case gc.INITIAL:
                Oc(this, e);
                break;
            case gc.BEFORE_HTML:
                Dc(this, e);
                break;
            case gc.BEFORE_HEAD:
                Lc(this, e);
                break;
            case gc.IN_HEAD:
                Bc(this, e);
                break;
            case gc.IN_HEAD_NO_SCRIPT:
                Uc(this, e);
                break;
            case gc.AFTER_HEAD:
                Fc(this, e);
                break;
            case gc.IN_BODY:
            case gc.IN_CAPTION:
            case gc.IN_CELL:
            case gc.IN_TEMPLATE:
                zc(this, e);
                break;
            case gc.TEXT:
            case gc.IN_SELECT:
            case gc.IN_SELECT_IN_TABLE:
                this._insertCharacters(e);
                break;
            case gc.IN_TABLE:
            case gc.IN_TABLE_BODY:
            case gc.IN_ROW:
                Xc(this, e);
                break;
            case gc.IN_TABLE_TEXT:
                al(this, e);
                break;
            case gc.IN_COLUMN_GROUP:
                ol(this, e);
                break;
            case gc.AFTER_BODY:
                fl(this, e);
                break;
            case gc.AFTER_AFTER_BODY:
                _l(this, e)
            }
    }
    onNullCharacter(e) {
        if (this.skipNextNewLine = !1, this.tokenizer.inForeignNode)
            !function (e, t) {
                t.chars = "�",
                e._insertCharacters(t)
            }
        (this, e);
        else
            switch (this.insertionMode) {
            case gc.INITIAL:
                Oc(this, e);
                break;
            case gc.BEFORE_HTML:
                Dc(this, e);
                break;
            case gc.BEFORE_HEAD:
                Lc(this, e);
                break;
            case gc.IN_HEAD:
                Bc(this, e);
                break;
            case gc.IN_HEAD_NO_SCRIPT:
                Uc(this, e);
                break;
            case gc.AFTER_HEAD:
                Fc(this, e);
                break;
            case gc.TEXT:
                this._insertCharacters(e);
                break;
            case gc.IN_TABLE:
            case gc.IN_TABLE_BODY:
            case gc.IN_ROW:
                Xc(this, e);
                break;
            case gc.IN_COLUMN_GROUP:
                ol(this, e);
                break;
            case gc.AFTER_BODY:
                fl(this, e);
                break;
            case gc.AFTER_AFTER_BODY:
                _l(this, e)
            }
    }
    onComment(e) {
        if (this.skipNextNewLine = !1, this.currentNotInHTML)
            kc(this, e);
        else
            switch (this.insertionMode) {
            case gc.INITIAL:
            case gc.BEFORE_HTML:
            case gc.BEFORE_HEAD:
            case gc.IN_HEAD:
            case gc.IN_HEAD_NO_SCRIPT:
            case gc.AFTER_HEAD:
            case gc.IN_BODY:
            case gc.IN_TABLE:
            case gc.IN_CAPTION:
            case gc.IN_COLUMN_GROUP:
            case gc.IN_TABLE_BODY:
            case gc.IN_ROW:
            case gc.IN_CELL:
            case gc.IN_SELECT:
            case gc.IN_SELECT_IN_TABLE:
            case gc.IN_TEMPLATE:
            case gc.IN_FRAMESET:
            case gc.AFTER_FRAMESET:
                kc(this, e);
                break;
            case gc.IN_TABLE_TEXT:
                nl(this, e);
                break;
            case gc.AFTER_BODY:
                !function (e, t) {
                    e._appendCommentNode(t, e.openElements.items[0])
                }
                (this, e);
                break;
            case gc.AFTER_AFTER_BODY:
            case gc.AFTER_AFTER_FRAMESET:
                !function (e, t) {
                    e._appendCommentNode(t, e.document)
                }
                (this, e)
            }
    }
    onDoctype(e) {
        switch (this.skipNextNewLine = !1, this.insertionMode) {
        case gc.INITIAL:
            !function (e, t) {
                e._setDocumentType(t);
                const a = t.forceQuirks ? Tr.QUIRKS : function (e) {
                    if ("html" !== e.name)
                        return Tr.QUIRKS;
                    const {
                        systemId: t
                    } = e;
                    if (t && "http://www.ibm.com/data/dtd/v11/ibmxhtml1-transitional.dtd" === t.toLowerCase())
                        return Tr.QUIRKS;
                    let {
                        publicId: a
                    } = e;
                    if (null !== a) {
                        if (a = a.toLowerCase(), rc.has(a))
                            return Tr.QUIRKS;
                        let e = null === t ? oc : sc;
                        if (pc(a, e))
                            return Tr.QUIRKS;
                        if (e = null === t ? cc : lc, pc(a, e))
                            return Tr.LIMITED_QUIRKS
                    }
                    return Tr.NO_QUIRKS
                }
                (t);
                (function (e) {
                    return "html" === e.name && null === e.publicId && (null === e.systemId || "about:legacy-compat" === e.systemId)
                })(t) || e._err(t, Er.nonConformingDoctype),
                e.treeAdapter.setDocumentMode(e.document, a),
                e.insertionMode = gc.BEFORE_HTML
            }
            (this, e);
            break;
        case gc.BEFORE_HEAD:
        case gc.IN_HEAD:
        case gc.IN_HEAD_NO_SCRIPT:
        case gc.AFTER_HEAD:
            this._err(e, Er.misplacedDoctype);
            break;
        case gc.IN_TABLE_TEXT:
            nl(this, e)
        }
    }
    onStartTag(e) {
        this.skipNextNewLine = !1,
        this.currentToken = e,
        this._processStartTag(e),
        e.selfClosing && !e.ackSelfClosing && this._err(e, Er.nonVoidHtmlElementStartTagWithTrailingSolidus)
    }
    _processStartTag(e) {
        this.shouldProcessStartTagTokenInForeignContent(e) ? function (e, t) {
            if (function (e) {
                const t = e.tagID;
                return t === Ar.FONT && e.attrs.some((({
                            name: e
                        }) => e === xr.COLOR || e === xr.SIZE || e === xr.FACE)) || mc.has(t)
            }
                (t))
                El(e), e._startTagOutsideForeignContent(t);
            else {
                const a = e._getAdjustedCurrentElement(),
                n = e.treeAdapter.getNamespaceURI(a);
                n === br.MATHML ? fc(t) : n === br.SVG && (function (e) {
                    const t = hc.get(e.tagName);
                    null != t && (e.tagName = t, e.tagID = Nr(e.tagName))
                }
                    (t), _c(t)),
                Ec(t),
                t.selfClosing ? e._appendElement(t, n) : e._insertElement(t, n),
                t.ackSelfClosing = !0
            }
        }
        (this, e) : this._startTagOutsideForeignContent(e)
    }
    _startTagOutsideForeignContent(e) {
        switch (this.insertionMode) {
        case gc.INITIAL:
            Oc(this, e);
            break;
        case gc.BEFORE_HTML:
            !function (e, t) {
                t.tagID === Ar.HTML ? (e._insertElement(t, br.HTML), e.insertionMode = gc.BEFORE_HEAD) : Dc(e, t)
            }
            (this, e);
            break;
        case gc.BEFORE_HEAD:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.HTML:
                    Qc(e, t);
                    break;
                case Ar.HEAD:
                    e._insertElement(t, br.HTML),
                    e.headElement = e.openElements.current,
                    e.insertionMode = gc.IN_HEAD;
                    break;
                default:
                    Lc(e, t)
                }
            }
            (this, e);
            break;
        case gc.IN_HEAD:
            Mc(this, e);
            break;
        case gc.IN_HEAD_NO_SCRIPT:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.HTML:
                    Qc(e, t);
                    break;
                case Ar.BASEFONT:
                case Ar.BGSOUND:
                case Ar.HEAD:
                case Ar.LINK:
                case Ar.META:
                case Ar.NOFRAMES:
                case Ar.STYLE:
                    Mc(e, t);
                    break;
                case Ar.NOSCRIPT:
                    e._err(t, Er.nestedNoscriptInHead);
                    break;
                default:
                    Uc(e, t)
                }
            }
            (this, e);
            break;
        case gc.AFTER_HEAD:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.HTML:
                    Qc(e, t);
                    break;
                case Ar.BODY:
                    e._insertElement(t, br.HTML),
                    e.framesetOk = !1,
                    e.insertionMode = gc.IN_BODY;
                    break;
                case Ar.FRAMESET:
                    e._insertElement(t, br.HTML),
                    e.insertionMode = gc.IN_FRAMESET;
                    break;
                case Ar.BASE:
                case Ar.BASEFONT:
                case Ar.BGSOUND:
                case Ar.LINK:
                case Ar.META:
                case Ar.NOFRAMES:
                case Ar.SCRIPT:
                case Ar.STYLE:
                case Ar.TEMPLATE:
                case Ar.TITLE:
                    e._err(t, Er.abandonedHeadElementChild),
                    e.openElements.push(e.headElement, Ar.HEAD),
                    Mc(e, t),
                    e.openElements.remove(e.headElement);
                    break;
                case Ar.HEAD:
                    e._err(t, Er.misplacedStartTagForHeadElement);
                    break;
                default:
                    Fc(e, t)
                }
            }
            (this, e);
            break;
        case gc.IN_BODY:
            Qc(this, e);
            break;
        case gc.IN_TABLE:
            $c(this, e);
            break;
        case gc.IN_TABLE_TEXT:
            nl(this, e);
            break;
        case gc.IN_CAPTION:
            !function (e, t) {
                const a = t.tagID;
                il.has(a) ? e.openElements.hasInTableScope(Ar.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(Ar.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = gc.IN_TABLE, $c(e, t)) : Qc(e, t)
            }
            (this, e);
            break;
        case gc.IN_COLUMN_GROUP:
            sl(this, e);
            break;
        case gc.IN_TABLE_BODY:
            rl(this, e);
            break;
        case gc.IN_ROW:
            ll(this, e);
            break;
        case gc.IN_CELL:
            !function (e, t) {
                const a = t.tagID;
                il.has(a) ? (e.openElements.hasInTableScope(Ar.TD) || e.openElements.hasInTableScope(Ar.TH)) && (e._closeTableCell(), ll(e, t)) : Qc(e, t)
            }
            (this, e);
            break;
        case gc.IN_SELECT:
            ul(this, e);
            break;
        case gc.IN_SELECT_IN_TABLE:
            !function (e, t) {
                const a = t.tagID;
                a === Ar.CAPTION || a === Ar.TABLE || a === Ar.TBODY || a === Ar.TFOOT || a === Ar.THEAD || a === Ar.TR || a === Ar.TD || a === Ar.TH ? (e.openElements.popUntilTagNamePopped(Ar.SELECT), e._resetInsertionMode(), e._processStartTag(t)) : ul(e, t)
            }
            (this, e);
            break;
        case gc.IN_TEMPLATE:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.BASE:
                case Ar.BASEFONT:
                case Ar.BGSOUND:
                case Ar.LINK:
                case Ar.META:
                case Ar.NOFRAMES:
                case Ar.SCRIPT:
                case Ar.STYLE:
                case Ar.TEMPLATE:
                case Ar.TITLE:
                    Mc(e, t);
                    break;
                case Ar.CAPTION:
                case Ar.COLGROUP:
                case Ar.TBODY:
                case Ar.TFOOT:
                case Ar.THEAD:
                    e.tmplInsertionModeStack[0] = gc.IN_TABLE,
                    e.insertionMode = gc.IN_TABLE,
                    $c(e, t);
                    break;
                case Ar.COL:
                    e.tmplInsertionModeStack[0] = gc.IN_COLUMN_GROUP,
                    e.insertionMode = gc.IN_COLUMN_GROUP,
                    sl(e, t);
                    break;
                case Ar.TR:
                    e.tmplInsertionModeStack[0] = gc.IN_TABLE_BODY,
                    e.insertionMode = gc.IN_TABLE_BODY,
                    rl(e, t);
                    break;
                case Ar.TD:
                case Ar.TH:
                    e.tmplInsertionModeStack[0] = gc.IN_ROW,
                    e.insertionMode = gc.IN_ROW,
                    ll(e, t);
                    break;
                default:
                    e.tmplInsertionModeStack[0] = gc.IN_BODY,
                    e.insertionMode = gc.IN_BODY,
                    Qc(e, t)
                }
            }
            (this, e);
            break;
        case gc.AFTER_BODY:
            !function (e, t) {
                t.tagID === Ar.HTML ? Qc(e, t) : fl(e, t)
            }
            (this, e);
            break;
        case gc.IN_FRAMESET:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.HTML:
                    Qc(e, t);
                    break;
                case Ar.FRAMESET:
                    e._insertElement(t, br.HTML);
                    break;
                case Ar.FRAME:
                    e._appendElement(t, br.HTML),
                    t.ackSelfClosing = !0;
                    break;
                case Ar.NOFRAMES:
                    Mc(e, t)
                }
            }
            (this, e);
            break;
        case gc.AFTER_FRAMESET:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.HTML:
                    Qc(e, t);
                    break;
                case Ar.NOFRAMES:
                    Mc(e, t)
                }
            }
            (this, e);
            break;
        case gc.AFTER_AFTER_BODY:
            !function (e, t) {
                t.tagID === Ar.HTML ? Qc(e, t) : _l(e, t)
            }
            (this, e);
            break;
        case gc.AFTER_AFTER_FRAMESET:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.HTML:
                    Qc(e, t);
                    break;
                case Ar.NOFRAMES:
                    Mc(e, t)
                }
            }
            (this, e)
        }
    }
    onEndTag(e) {
        this.skipNextNewLine = !1,
        this.currentToken = e,
        this.currentNotInHTML ? function (e, t) {
            if (t.tagID === Ar.P || t.tagID === Ar.BR)
                return El(e), void e._endTagOutsideForeignContent(t);
            for (let a = e.openElements.stackTop; a > 0; a--) {
                const n = e.openElements.items[a];
                if (e.treeAdapter.getNamespaceURI(n) === br.HTML) {
                    e._endTagOutsideForeignContent(t);
                    break
                }
                const i = e.treeAdapter.getTagName(n);
                if (i.toLowerCase() === t.tagName) {
                    t.tagName = i,
                    e.openElements.shortenToLength(a);
                    break
                }
            }
        }
        (this, e) : this._endTagOutsideForeignContent(e)
    }
    _endTagOutsideForeignContent(e) {
        switch (this.insertionMode) {
        case gc.INITIAL:
            Oc(this, e);
            break;
        case gc.BEFORE_HTML:
            !function (e, t) {
                const a = t.tagID;
                a !== Ar.HTML && a !== Ar.HEAD && a !== Ar.BODY && a !== Ar.BR || Dc(e, t)
            }
            (this, e);
            break;
        case gc.BEFORE_HEAD:
            !function (e, t) {
                const a = t.tagID;
                a === Ar.HEAD || a === Ar.BODY || a === Ar.HTML || a === Ar.BR ? Lc(e, t) : e._err(t, Er.endTagWithoutMatchingOpenElement)
            }
            (this, e);
            break;
        case gc.IN_HEAD:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.HEAD:
                    e.openElements.pop(),
                    e.insertionMode = gc.AFTER_HEAD;
                    break;
                case Ar.BODY:
                case Ar.BR:
                case Ar.HTML:
                    Bc(e, t);
                    break;
                case Ar.TEMPLATE:
                    Pc(e, t);
                    break;
                default:
                    e._err(t, Er.endTagWithoutMatchingOpenElement)
                }
            }
            (this, e);
            break;
        case gc.IN_HEAD_NO_SCRIPT:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.NOSCRIPT:
                    e.openElements.pop(),
                    e.insertionMode = gc.IN_HEAD;
                    break;
                case Ar.BR:
                    Uc(e, t);
                    break;
                default:
                    e._err(t, Er.endTagWithoutMatchingOpenElement)
                }
            }
            (this, e);
            break;
        case gc.AFTER_HEAD:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.BODY:
                case Ar.HTML:
                case Ar.BR:
                    Fc(e, t);
                    break;
                case Ar.TEMPLATE:
                    Pc(e, t);
                    break;
                default:
                    e._err(t, Er.endTagWithoutMatchingOpenElement)
                }
            }
            (this, e);
            break;
        case gc.IN_BODY:
            Kc(this, e);
            break;
        case gc.TEXT:
            !function (e, t) {
                var a;
                t.tagID === Ar.SCRIPT && (null === (a = e.scriptHandler) || void 0 === a || a.call(e, e.openElements.current)),
                e.openElements.pop(),
                e.insertionMode = e.originalInsertionMode
            }
            (this, e);
            break;
        case gc.IN_TABLE:
            Jc(this, e);
            break;
        case gc.IN_TABLE_TEXT:
            nl(this, e);
            break;
        case gc.IN_CAPTION:
            !function (e, t) {
                const a = t.tagID;
                switch (a) {
                case Ar.CAPTION:
                case Ar.TABLE:
                    e.openElements.hasInTableScope(Ar.CAPTION) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(Ar.CAPTION), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = gc.IN_TABLE, a === Ar.TABLE && Jc(e, t));
                    break;
                case Ar.BODY:
                case Ar.COL:
                case Ar.COLGROUP:
                case Ar.HTML:
                case Ar.TBODY:
                case Ar.TD:
                case Ar.TFOOT:
                case Ar.TH:
                case Ar.THEAD:
                case Ar.TR:
                    break;
                default:
                    Kc(e, t)
                }
            }
            (this, e);
            break;
        case gc.IN_COLUMN_GROUP:
            !function (e, t) {
                switch (t.tagID) {
                case Ar.COLGROUP:
                    e.openElements.currentTagId === Ar.COLGROUP && (e.openElements.pop(), e.insertionMode = gc.IN_TABLE);
                    break;
                case Ar.TEMPLATE:
                    Pc(e, t);
                    break;
                case Ar.COL:
                    break;
                default:
                    ol(e, t)
                }
            }
            (this, e);
            break;
        case gc.IN_TABLE_BODY:
            cl(this, e);
            break;
        case gc.IN_ROW:
            pl(this, e);
            break;
        case gc.IN_CELL:
            !function (e, t) {
                const a = t.tagID;
                switch (a) {
                case Ar.TD:
                case Ar.TH:
                    e.openElements.hasInTableScope(a) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(a), e.activeFormattingElements.clearToLastMarker(), e.insertionMode = gc.IN_ROW);
                    break;
                case Ar.TABLE:
                case Ar.TBODY:
                case Ar.TFOOT:
                case Ar.THEAD:
                case Ar.TR:
                    e.openElements.hasInTableScope(a) && (e._closeTableCell(), pl(e, t));
                    break;
                case Ar.BODY:
                case Ar.CAPTION:
                case Ar.COL:
                case Ar.COLGROUP:
                case Ar.HTML:
                    break;
                default:
                    Kc(e, t)
                }
            }
            (this, e);
            break;
        case gc.IN_SELECT:
            dl(this, e);
            break;
        case gc.IN_SELECT_IN_TABLE:
            !function (e, t) {
                const a = t.tagID;
                a === Ar.CAPTION || a === Ar.TABLE || a === Ar.TBODY || a === Ar.TFOOT || a === Ar.THEAD || a === Ar.TR || a === Ar.TD || a === Ar.TH ? e.openElements.hasInTableScope(a) && (e.openElements.popUntilTagNamePopped(Ar.SELECT), e._resetInsertionMode(), e.onEndTag(t)) : dl(e, t)
            }
            (this, e);
            break;
        case gc.IN_TEMPLATE:
            !function (e, t) {
                t.tagID === Ar.TEMPLATE && Pc(e, t)
            }
            (this, e);
            break;
        case gc.AFTER_BODY:
            ml(this, e);
            break;
        case gc.IN_FRAMESET:
            !function (e, t) {
                t.tagID !== Ar.FRAMESET || e.openElements.isRootHtmlElementCurrent() || (e.openElements.pop(), e.fragmentContext || e.openElements.currentTagId === Ar.FRAMESET || (e.insertionMode = gc.AFTER_FRAMESET))
            }
            (this, e);
            break;
        case gc.AFTER_FRAMESET:
            !function (e, t) {
                t.tagID === Ar.HTML && (e.insertionMode = gc.AFTER_AFTER_FRAMESET)
            }
            (this, e);
            break;
        case gc.AFTER_AFTER_BODY:
            _l(this, e)
        }
    }
    onEof(e) {
        switch (this.insertionMode) {
        case gc.INITIAL:
            Oc(this, e);
            break;
        case gc.BEFORE_HTML:
            Dc(this, e);
            break;
        case gc.BEFORE_HEAD:
            Lc(this, e);
            break;
        case gc.IN_HEAD:
            Bc(this, e);
            break;
        case gc.IN_HEAD_NO_SCRIPT:
            Uc(this, e);
            break;
        case gc.AFTER_HEAD:
            Fc(this, e);
            break;
        case gc.IN_BODY:
        case gc.IN_TABLE:
        case gc.IN_CAPTION:
        case gc.IN_COLUMN_GROUP:
        case gc.IN_TABLE_BODY:
        case gc.IN_ROW:
        case gc.IN_CELL:
        case gc.IN_SELECT:
        case gc.IN_SELECT_IN_TABLE:
            Zc(this, e);
            break;
        case gc.TEXT:
            !function (e, t) {
                e._err(t, Er.eofInElementThatCanContainOnlyText),
                e.openElements.pop(),
                e.insertionMode = e.originalInsertionMode,
                e.onEof(t)
            }
            (this, e);
            break;
        case gc.IN_TABLE_TEXT:
            nl(this, e);
            break;
        case gc.IN_TEMPLATE:
            hl(this, e);
            break;
        case gc.AFTER_BODY:
        case gc.IN_FRAMESET:
        case gc.AFTER_FRAMESET:
        case gc.AFTER_AFTER_BODY:
        case gc.AFTER_AFTER_FRAMESET:
            Rc(this, e)
        }
    }
    onWhitespaceCharacter(e) {
        if (this.skipNextNewLine && (this.skipNextNewLine = !1, e.chars.charCodeAt(0) === pr.LINE_FEED)) {
            if (1 === e.chars.length)
                return;
            e.chars = e.chars.substr(1)
        }
        if (this.tokenizer.inForeignNode)
            this._insertCharacters(e);
        else
            switch (this.insertionMode) {
            case gc.IN_HEAD:
            case gc.IN_HEAD_NO_SCRIPT:
            case gc.AFTER_HEAD:
            case gc.TEXT:
            case gc.IN_COLUMN_GROUP:
            case gc.IN_SELECT:
            case gc.IN_SELECT_IN_TABLE:
            case gc.IN_FRAMESET:
            case gc.AFTER_FRAMESET:
                this._insertCharacters(e);
                break;
            case gc.IN_BODY:
            case gc.IN_CAPTION:
            case gc.IN_CELL:
            case gc.IN_TEMPLATE:
            case gc.AFTER_BODY:
            case gc.AFTER_AFTER_BODY:
            case gc.AFTER_AFTER_FRAMESET:
                jc(this, e);
                break;
            case gc.IN_TABLE:
            case gc.IN_TABLE_BODY:
            case gc.IN_ROW:
                Xc(this, e);
                break;
            case gc.IN_TABLE_TEXT:
                tl(this, e)
            }
    }
}
function Ac(e, t) {
    let a = e.activeFormattingElements.getElementEntryInScopeWithTagName(t.tagName);
    return a ? e.openElements.contains(a.element) ? e.openElements.hasInScope(t.tagID) || (a = null) : (e.activeFormattingElements.removeEntry(a), a = null) : Wc(e, t),
    a
}
function yc(e, t) {
    let a = null,
    n = e.openElements.stackTop;
    for (; n >= 0; n--) {
        const i = e.openElements.items[n];
        if (i === t.element)
            break;
        e._isSpecialElement(i, e.openElements.tagIDs[n]) && (a = i)
    }
    return a || (e.openElements.shortenToLength(n < 0 ? 0 : n), e.activeFormattingElements.removeEntry(t)),
    a
}
function wc(e, t, a) {
    let n = t,
    i = e.openElements.getCommonAncestor(t);
    for (let s = 0, o = i; o !== a; s++, o = i) {
        i = e.openElements.getCommonAncestor(o);
        const a = e.activeFormattingElements.getElementEntry(o),
        r = a && s >= 3;
        !a || r ? (r && e.activeFormattingElements.removeEntry(a), e.openElements.remove(o)) : (o = Sc(e, a), n === t && (e.activeFormattingElements.bookmark = a), e.treeAdapter.detachNode(n), e.treeAdapter.appendChild(o, n), n = o)
    }
    return n
}
function Sc(e, t) {
    const a = e.treeAdapter.getNamespaceURI(t.element),
    n = e.treeAdapter.createElement(t.token.tagName, a, t.token.attrs);
    return e.openElements.replace(t.element, n),
    t.element = n,
    n
}
function Nc(e, t, a) {
    const n = Nr(e.treeAdapter.getTagName(t));
    if (e._isElementCausesFosterParenting(n))
        e._fosterParentElement(a);
    else {
        const i = e.treeAdapter.getNamespaceURI(t);
        n === Ar.TEMPLATE && i === br.HTML && (t = e.treeAdapter.getTemplateContent(t)),
        e.treeAdapter.appendChild(t, a)
    }
}
function Cc(e, t, a) {
    const n = e.treeAdapter.getNamespaceURI(a.element), {
        token: i
    } = a,
    s = e.treeAdapter.createElement(i.tagName, n, i.attrs);
    e._adoptNodes(t, s),
    e.treeAdapter.appendChild(t, s),
    e.activeFormattingElements.insertElementAfterBookmark(s, i),
    e.activeFormattingElements.removeEntry(a),
    e.openElements.remove(a.element),
    e.openElements.insertAfter(t, s, i.tagID)
}
function Ic(e, t) {
    for (let a = 0; a < 8; a++) {
        const a = Ac(e, t);
        if (!a)
            break;
        const n = yc(e, a);
        if (!n)
            break;
        e.activeFormattingElements.bookmark = a;
        const i = wc(e, n, a.element),
        s = e.openElements.getCommonAncestor(a.element);
        e.treeAdapter.detachNode(i),
        s && Nc(e, s, i),
        Cc(e, n, a)
    }
}
function kc(e, t) {
    e._appendCommentNode(t, e.openElements.currentTmplContentOrNode)
}
function Rc(e, t) {
    if (e.stopped = !0, t.location) {
        const a = e.fragmentContext ? 0 : 2;
        for (let n = e.openElements.stackTop; n >= a; n--)
            e._setEndLocation(e.openElements.items[n], t);
        if (!e.fragmentContext && e.openElements.stackTop >= 0) {
            const a = e.openElements.items[0],
            n = e.treeAdapter.getNodeSourceCodeLocation(a);
            if (n && !n.endTag && (e._setEndLocation(a, t), e.openElements.stackTop >= 1)) {
                const a = e.openElements.items[1],
                n = e.treeAdapter.getNodeSourceCodeLocation(a);
                n && !n.endTag && e._setEndLocation(a, t)
            }
        }
    }
}
function Oc(e, t) {
    e._err(t, Er.missingDoctype, !0),
    e.treeAdapter.setDocumentMode(e.document, Tr.QUIRKS),
    e.insertionMode = gc.BEFORE_HTML,
    e._processToken(t)
}
function Dc(e, t) {
    e._insertFakeRootElement(),
    e.insertionMode = gc.BEFORE_HEAD,
    e._processToken(t)
}
function Lc(e, t) {
    e._insertFakeElement(vr.HEAD, Ar.HEAD),
    e.headElement = e.openElements.current,
    e.insertionMode = gc.IN_HEAD,
    e._processToken(t)
}
function Mc(e, t) {
    switch (t.tagID) {
    case Ar.HTML:
        Qc(e, t);
        break;
    case Ar.BASE:
    case Ar.BASEFONT:
    case Ar.BGSOUND:
    case Ar.LINK:
    case Ar.META:
        e._appendElement(t, br.HTML),
        t.ackSelfClosing = !0;
        break;
    case Ar.TITLE:
        e._switchToTextParsing(t, Lr.RCDATA);
        break;
    case Ar.NOSCRIPT:
        e.options.scriptingEnabled ? e._switchToTextParsing(t, Lr.RAWTEXT) : (e._insertElement(t, br.HTML), e.insertionMode = gc.IN_HEAD_NO_SCRIPT);
        break;
    case Ar.NOFRAMES:
    case Ar.STYLE:
        e._switchToTextParsing(t, Lr.RAWTEXT);
        break;
    case Ar.SCRIPT:
        e._switchToTextParsing(t, Lr.SCRIPT_DATA);
        break;
    case Ar.TEMPLATE:
        e._insertTemplate(t),
        e.activeFormattingElements.insertMarker(),
        e.framesetOk = !1,
        e.insertionMode = gc.IN_TEMPLATE,
        e.tmplInsertionModeStack.unshift(gc.IN_TEMPLATE);
        break;
    case Ar.HEAD:
        e._err(t, Er.misplacedStartTagForHeadElement);
        break;
    default:
        Bc(e, t)
    }
}
function Pc(e, t) {
    e.openElements.tmplCount > 0 ? (e.openElements.generateImpliedEndTagsThoroughly(), e.openElements.currentTagId !== Ar.TEMPLATE && e._err(t, Er.closingOfElementWithOpenChildElements), e.openElements.popUntilTagNamePopped(Ar.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode()) : e._err(t, Er.endTagWithoutMatchingOpenElement)
}
function Bc(e, t) {
    e.openElements.pop(),
    e.insertionMode = gc.AFTER_HEAD,
    e._processToken(t)
}
function Uc(e, t) {
    const a = t.type === gr.EOF ? Er.openElementsLeftAfterEof : Er.disallowedContentInNoscriptInHead;
    e._err(t, a),
    e.openElements.pop(),
    e.insertionMode = gc.IN_HEAD,
    e._processToken(t)
}
function Fc(e, t) {
    e._insertFakeElement(vr.BODY, Ar.BODY),
    e.insertionMode = gc.IN_BODY,
    Hc(e, t)
}
function Hc(e, t) {
    switch (t.type) {
    case gr.CHARACTER:
        zc(e, t);
        break;
    case gr.WHITESPACE_CHARACTER:
        jc(e, t);
        break;
    case gr.COMMENT:
        kc(e, t);
        break;
    case gr.START_TAG:
        Qc(e, t);
        break;
    case gr.END_TAG:
        Kc(e, t);
        break;
    case gr.EOF:
        Zc(e, t)
    }
}
function jc(e, t) {
    e._reconstructActiveFormattingElements(),
    e._insertCharacters(t)
}
function zc(e, t) {
    e._reconstructActiveFormattingElements(),
    e._insertCharacters(t),
    e.framesetOk = !1
}
function Gc(e, t) {
    e._reconstructActiveFormattingElements(),
    e._appendElement(t, br.HTML),
    e.framesetOk = !1,
    t.ackSelfClosing = !0
}
function qc(e) {
    const t = wr(e, xr.TYPE);
    return null != t && "hidden" === t.toLowerCase()
}
function Yc(e, t) {
    e._switchToTextParsing(t, Lr.RAWTEXT)
}
function Vc(e, t) {
    e._reconstructActiveFormattingElements(),
    e._insertElement(t, br.HTML)
}
function Qc(e, t) {
    switch (t.tagID) {
    case Ar.I:
    case Ar.S:
    case Ar.B:
    case Ar.U:
    case Ar.EM:
    case Ar.TT:
    case Ar.BIG:
    case Ar.CODE:
    case Ar.FONT:
    case Ar.SMALL:
    case Ar.STRIKE:
    case Ar.STRONG:
        !function (e, t) {
            e._reconstructActiveFormattingElements(),
            e._insertElement(t, br.HTML),
            e.activeFormattingElements.pushElement(e.openElements.current, t)
        }
        (e, t);
        break;
    case Ar.A:
        !function (e, t) {
            const a = e.activeFormattingElements.getElementEntryInScopeWithTagName(vr.A);
            a && (Ic(e, t), e.openElements.remove(a.element), e.activeFormattingElements.removeEntry(a)),
            e._reconstructActiveFormattingElements(),
            e._insertElement(t, br.HTML),
            e.activeFormattingElements.pushElement(e.openElements.current, t)
        }
        (e, t);
        break;
    case Ar.H1:
    case Ar.H2:
    case Ar.H3:
    case Ar.H4:
    case Ar.H5:
    case Ar.H6:
        !function (e, t) {
            e.openElements.hasInButtonScope(Ar.P) && e._closePElement(),
            kr(e.openElements.currentTagId) && e.openElements.pop(),
            e._insertElement(t, br.HTML)
        }
        (e, t);
        break;
    case Ar.P:
    case Ar.DL:
    case Ar.OL:
    case Ar.UL:
    case Ar.DIV:
    case Ar.DIR:
    case Ar.NAV:
    case Ar.MAIN:
    case Ar.MENU:
    case Ar.ASIDE:
    case Ar.CENTER:
    case Ar.FIGURE:
    case Ar.FOOTER:
    case Ar.HEADER:
    case Ar.HGROUP:
    case Ar.DIALOG:
    case Ar.DETAILS:
    case Ar.ADDRESS:
    case Ar.ARTICLE:
    case Ar.SECTION:
    case Ar.SUMMARY:
    case Ar.FIELDSET:
    case Ar.BLOCKQUOTE:
    case Ar.FIGCAPTION:
        !function (e, t) {
            e.openElements.hasInButtonScope(Ar.P) && e._closePElement(),
            e._insertElement(t, br.HTML)
        }
        (e, t);
        break;
    case Ar.LI:
    case Ar.DD:
    case Ar.DT:
        !function (e, t) {
            e.framesetOk = !1;
            const a = t.tagID;
            for (let t = e.openElements.stackTop; t >= 0; t--) {
                const n = e.openElements.tagIDs[t];
                if (a === Ar.LI && n === Ar.LI || (a === Ar.DD || a === Ar.DT) && (n === Ar.DD || n === Ar.DT)) {
                    e.openElements.generateImpliedEndTagsWithExclusion(n),
                    e.openElements.popUntilTagNamePopped(n);
                    break
                }
                if (n !== Ar.ADDRESS && n !== Ar.DIV && n !== Ar.P && e._isSpecialElement(e.openElements.items[t], n))
                    break
            }
            e.openElements.hasInButtonScope(Ar.P) && e._closePElement(),
            e._insertElement(t, br.HTML)
        }
        (e, t);
        break;
    case Ar.BR:
    case Ar.IMG:
    case Ar.WBR:
    case Ar.AREA:
    case Ar.EMBED:
    case Ar.KEYGEN:
        Gc(e, t);
        break;
    case Ar.HR:
        !function (e, t) {
            e.openElements.hasInButtonScope(Ar.P) && e._closePElement(),
            e._appendElement(t, br.HTML),
            e.framesetOk = !1,
            t.ackSelfClosing = !0
        }
        (e, t);
        break;
    case Ar.RB:
    case Ar.RTC:
        !function (e, t) {
            e.openElements.hasInScope(Ar.RUBY) && e.openElements.generateImpliedEndTags(),
            e._insertElement(t, br.HTML)
        }
        (e, t);
        break;
    case Ar.RT:
    case Ar.RP:
        !function (e, t) {
            e.openElements.hasInScope(Ar.RUBY) && e.openElements.generateImpliedEndTagsWithExclusion(Ar.RTC),
            e._insertElement(t, br.HTML)
        }
        (e, t);
        break;
    case Ar.PRE:
    case Ar.LISTING:
        !function (e, t) {
            e.openElements.hasInButtonScope(Ar.P) && e._closePElement(),
            e._insertElement(t, br.HTML),
            e.skipNextNewLine = !0,
            e.framesetOk = !1
        }
        (e, t);
        break;
    case Ar.XMP:
        !function (e, t) {
            e.openElements.hasInButtonScope(Ar.P) && e._closePElement(),
            e._reconstructActiveFormattingElements(),
            e.framesetOk = !1,
            e._switchToTextParsing(t, Lr.RAWTEXT)
        }
        (e, t);
        break;
    case Ar.SVG:
        !function (e, t) {
            e._reconstructActiveFormattingElements(),
            _c(t),
            Ec(t),
            t.selfClosing ? e._appendElement(t, br.SVG) : e._insertElement(t, br.SVG),
            t.ackSelfClosing = !0
        }
        (e, t);
        break;
    case Ar.HTML:
        !function (e, t) {
            0 === e.openElements.tmplCount && e.treeAdapter.adoptAttributes(e.openElements.items[0], t.attrs)
        }
        (e, t);
        break;
    case Ar.BASE:
    case Ar.LINK:
    case Ar.META:
    case Ar.STYLE:
    case Ar.TITLE:
    case Ar.SCRIPT:
    case Ar.BGSOUND:
    case Ar.BASEFONT:
    case Ar.TEMPLATE:
        Mc(e, t);
        break;
    case Ar.BODY:
        !function (e, t) {
            const a = e.openElements.tryPeekProperlyNestedBodyElement();
            a && 0 === e.openElements.tmplCount && (e.framesetOk = !1, e.treeAdapter.adoptAttributes(a, t.attrs))
        }
        (e, t);
        break;
    case Ar.FORM:
        !function (e, t) {
            const a = e.openElements.tmplCount > 0;
            e.formElement && !a || (e.openElements.hasInButtonScope(Ar.P) && e._closePElement(), e._insertElement(t, br.HTML), a || (e.formElement = e.openElements.current))
        }
        (e, t);
        break;
    case Ar.NOBR:
        !function (e, t) {
            e._reconstructActiveFormattingElements(),
            e.openElements.hasInScope(Ar.NOBR) && (Ic(e, t), e._reconstructActiveFormattingElements()),
            e._insertElement(t, br.HTML),
            e.activeFormattingElements.pushElement(e.openElements.current, t)
        }
        (e, t);
        break;
    case Ar.MATH:
        !function (e, t) {
            e._reconstructActiveFormattingElements(),
            fc(t),
            Ec(t),
            t.selfClosing ? e._appendElement(t, br.MATHML) : e._insertElement(t, br.MATHML),
            t.ackSelfClosing = !0
        }
        (e, t);
        break;
    case Ar.TABLE:
        !function (e, t) {
            e.treeAdapter.getDocumentMode(e.document) !== Tr.QUIRKS && e.openElements.hasInButtonScope(Ar.P) && e._closePElement(),
            e._insertElement(t, br.HTML),
            e.framesetOk = !1,
            e.insertionMode = gc.IN_TABLE
        }
        (e, t);
        break;
    case Ar.INPUT:
        !function (e, t) {
            e._reconstructActiveFormattingElements(),
            e._appendElement(t, br.HTML),
            qc(t) || (e.framesetOk = !1),
            t.ackSelfClosing = !0
        }
        (e, t);
        break;
    case Ar.PARAM:
    case Ar.TRACK:
    case Ar.SOURCE:
        !function (e, t) {
            e._appendElement(t, br.HTML),
            t.ackSelfClosing = !0
        }
        (e, t);
        break;
    case Ar.IMAGE:
        !function (e, t) {
            t.tagName = vr.IMG,
            t.tagID = Ar.IMG,
            Gc(e, t)
        }
        (e, t);
        break;
    case Ar.BUTTON:
        !function (e, t) {
            e.openElements.hasInScope(Ar.BUTTON) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(Ar.BUTTON)),
            e._reconstructActiveFormattingElements(),
            e._insertElement(t, br.HTML),
            e.framesetOk = !1
        }
        (e, t);
        break;
    case Ar.APPLET:
    case Ar.OBJECT:
    case Ar.MARQUEE:
        !function (e, t) {
            e._reconstructActiveFormattingElements(),
            e._insertElement(t, br.HTML),
            e.activeFormattingElements.insertMarker(),
            e.framesetOk = !1
        }
        (e, t);
        break;
    case Ar.IFRAME:
        !function (e, t) {
            e.framesetOk = !1,
            e._switchToTextParsing(t, Lr.RAWTEXT)
        }
        (e, t);
        break;
    case Ar.SELECT:
        !function (e, t) {
            e._reconstructActiveFormattingElements(),
            e._insertElement(t, br.HTML),
            e.framesetOk = !1,
            e.insertionMode = e.insertionMode === gc.IN_TABLE || e.insertionMode === gc.IN_CAPTION || e.insertionMode === gc.IN_TABLE_BODY || e.insertionMode === gc.IN_ROW || e.insertionMode === gc.IN_CELL ? gc.IN_SELECT_IN_TABLE : gc.IN_SELECT
        }
        (e, t);
        break;
    case Ar.OPTION:
    case Ar.OPTGROUP:
        !function (e, t) {
            e.openElements.currentTagId === Ar.OPTION && e.openElements.pop(),
            e._reconstructActiveFormattingElements(),
            e._insertElement(t, br.HTML)
        }
        (e, t);
        break;
    case Ar.NOEMBED:
        Yc(e, t);
        break;
    case Ar.FRAMESET:
        !function (e, t) {
            const a = e.openElements.tryPeekProperlyNestedBodyElement();
            e.framesetOk && a && (e.treeAdapter.detachNode(a), e.openElements.popAllUpToHtmlElement(), e._insertElement(t, br.HTML), e.insertionMode = gc.IN_FRAMESET)
        }
        (e, t);
        break;
    case Ar.TEXTAREA:
        !function (e, t) {
            e._insertElement(t, br.HTML),
            e.skipNextNewLine = !0,
            e.tokenizer.state = Lr.RCDATA,
            e.originalInsertionMode = e.insertionMode,
            e.framesetOk = !1,
            e.insertionMode = gc.TEXT
        }
        (e, t);
        break;
    case Ar.NOSCRIPT:
        e.options.scriptingEnabled ? Yc(e, t) : Vc(e, t);
        break;
    case Ar.PLAINTEXT:
        !function (e, t) {
            e.openElements.hasInButtonScope(Ar.P) && e._closePElement(),
            e._insertElement(t, br.HTML),
            e.tokenizer.state = Lr.PLAINTEXT
        }
        (e, t);
        break;
    case Ar.COL:
    case Ar.TH:
    case Ar.TD:
    case Ar.TR:
    case Ar.HEAD:
    case Ar.FRAME:
    case Ar.TBODY:
    case Ar.TFOOT:
    case Ar.THEAD:
    case Ar.CAPTION:
    case Ar.COLGROUP:
        break;
    default:
        Vc(e, t)
    }
}
function Wc(e, t) {
    const a = t.tagName,
    n = t.tagID;
    for (let t = e.openElements.stackTop; t > 0; t--) {
        const i = e.openElements.items[t],
        s = e.openElements.tagIDs[t];
        if (n === s && (n !== Ar.UNKNOWN || e.treeAdapter.getTagName(i) === a)) {
            e.openElements.generateImpliedEndTagsWithExclusion(n),
            e.openElements.stackTop >= t && e.openElements.shortenToLength(t);
            break
        }
        if (e._isSpecialElement(i, s))
            break
    }
}
function Kc(e, t) {
    switch (t.tagID) {
    case Ar.A:
    case Ar.B:
    case Ar.I:
    case Ar.S:
    case Ar.U:
    case Ar.EM:
    case Ar.TT:
    case Ar.BIG:
    case Ar.CODE:
    case Ar.FONT:
    case Ar.NOBR:
    case Ar.SMALL:
    case Ar.STRIKE:
    case Ar.STRONG:
        Ic(e, t);
        break;
    case Ar.P:
        !function (e) {
            e.openElements.hasInButtonScope(Ar.P) || e._insertFakeElement(vr.P, Ar.P),
            e._closePElement()
        }
        (e);
        break;
    case Ar.DL:
    case Ar.UL:
    case Ar.OL:
    case Ar.DIR:
    case Ar.DIV:
    case Ar.NAV:
    case Ar.PRE:
    case Ar.MAIN:
    case Ar.MENU:
    case Ar.ASIDE:
    case Ar.BUTTON:
    case Ar.CENTER:
    case Ar.FIGURE:
    case Ar.FOOTER:
    case Ar.HEADER:
    case Ar.HGROUP:
    case Ar.DIALOG:
    case Ar.ADDRESS:
    case Ar.ARTICLE:
    case Ar.DETAILS:
    case Ar.SECTION:
    case Ar.SUMMARY:
    case Ar.LISTING:
    case Ar.FIELDSET:
    case Ar.BLOCKQUOTE:
    case Ar.FIGCAPTION:
        !function (e, t) {
            const a = t.tagID;
            e.openElements.hasInScope(a) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(a))
        }
        (e, t);
        break;
    case Ar.LI:
        !function (e) {
            e.openElements.hasInListItemScope(Ar.LI) && (e.openElements.generateImpliedEndTagsWithExclusion(Ar.LI), e.openElements.popUntilTagNamePopped(Ar.LI))
        }
        (e);
        break;
    case Ar.DD:
    case Ar.DT:
        !function (e, t) {
            const a = t.tagID;
            e.openElements.hasInScope(a) && (e.openElements.generateImpliedEndTagsWithExclusion(a), e.openElements.popUntilTagNamePopped(a))
        }
        (e, t);
        break;
    case Ar.H1:
    case Ar.H2:
    case Ar.H3:
    case Ar.H4:
    case Ar.H5:
    case Ar.H6:
        !function (e) {
            e.openElements.hasNumberedHeaderInScope() && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilNumberedHeaderPopped())
        }
        (e);
        break;
    case Ar.BR:
        !function (e) {
            e._reconstructActiveFormattingElements(),
            e._insertFakeElement(vr.BR, Ar.BR),
            e.openElements.pop(),
            e.framesetOk = !1
        }
        (e);
        break;
    case Ar.BODY:
        !function (e, t) {
            if (e.openElements.hasInScope(Ar.BODY) && (e.insertionMode = gc.AFTER_BODY, e.options.sourceCodeLocationInfo)) {
                const a = e.openElements.tryPeekProperlyNestedBodyElement();
                a && e._setEndLocation(a, t)
            }
        }
        (e, t);
        break;
    case Ar.HTML:
        !function (e, t) {
            e.openElements.hasInScope(Ar.BODY) && (e.insertionMode = gc.AFTER_BODY, ml(e, t))
        }
        (e, t);
        break;
    case Ar.FORM:
        !function (e) {
            const t = e.openElements.tmplCount > 0, {
                formElement: a
            } = e;
            t || (e.formElement = null),
            (a || t) && e.openElements.hasInScope(Ar.FORM) && (e.openElements.generateImpliedEndTags(), t ? e.openElements.popUntilTagNamePopped(Ar.FORM) : a && e.openElements.remove(a))
        }
        (e);
        break;
    case Ar.APPLET:
    case Ar.OBJECT:
    case Ar.MARQUEE:
        !function (e, t) {
            const a = t.tagID;
            e.openElements.hasInScope(a) && (e.openElements.generateImpliedEndTags(), e.openElements.popUntilTagNamePopped(a), e.activeFormattingElements.clearToLastMarker())
        }
        (e, t);
        break;
    case Ar.TEMPLATE:
        Pc(e, t);
        break;
    default:
        Wc(e, t)
    }
}
function Zc(e, t) {
    e.tmplInsertionModeStack.length > 0 ? hl(e, t) : Rc(e, t)
}
function Xc(e, t) {
    if (xc.has(e.openElements.currentTagId))
        switch (e.pendingCharacterTokens.length = 0, e.hasNonWhitespacePendingCharacterToken = !1, e.originalInsertionMode = e.insertionMode, e.insertionMode = gc.IN_TABLE_TEXT, t.type) {
        case gr.CHARACTER:
            al(e, t);
            break;
        case gr.WHITESPACE_CHARACTER:
            tl(e, t)
        }
    else
        el(e, t)
}
function $c(e, t) {
    switch (t.tagID) {
    case Ar.TD:
    case Ar.TH:
    case Ar.TR:
        !function (e, t) {
            e.openElements.clearBackToTableContext(),
            e._insertFakeElement(vr.TBODY, Ar.TBODY),
            e.insertionMode = gc.IN_TABLE_BODY,
            rl(e, t)
        }
        (e, t);
        break;
    case Ar.STYLE:
    case Ar.SCRIPT:
    case Ar.TEMPLATE:
        Mc(e, t);
        break;
    case Ar.COL:
        !function (e, t) {
            e.openElements.clearBackToTableContext(),
            e._insertFakeElement(vr.COLGROUP, Ar.COLGROUP),
            e.insertionMode = gc.IN_COLUMN_GROUP,
            sl(e, t)
        }
        (e, t);
        break;
    case Ar.FORM:
        !function (e, t) {
            e.formElement || 0 !== e.openElements.tmplCount || (e._insertElement(t, br.HTML), e.formElement = e.openElements.current, e.openElements.pop())
        }
        (e, t);
        break;
    case Ar.TABLE:
        !function (e, t) {
            e.openElements.hasInTableScope(Ar.TABLE) && (e.openElements.popUntilTagNamePopped(Ar.TABLE), e._resetInsertionMode(), e._processStartTag(t))
        }
        (e, t);
        break;
    case Ar.TBODY:
    case Ar.TFOOT:
    case Ar.THEAD:
        !function (e, t) {
            e.openElements.clearBackToTableContext(),
            e._insertElement(t, br.HTML),
            e.insertionMode = gc.IN_TABLE_BODY
        }
        (e, t);
        break;
    case Ar.INPUT:
        !function (e, t) {
            qc(t) ? e._appendElement(t, br.HTML) : el(e, t),
            t.ackSelfClosing = !0
        }
        (e, t);
        break;
    case Ar.CAPTION:
        !function (e, t) {
            e.openElements.clearBackToTableContext(),
            e.activeFormattingElements.insertMarker(),
            e._insertElement(t, br.HTML),
            e.insertionMode = gc.IN_CAPTION
        }
        (e, t);
        break;
    case Ar.COLGROUP:
        !function (e, t) {
            e.openElements.clearBackToTableContext(),
            e._insertElement(t, br.HTML),
            e.insertionMode = gc.IN_COLUMN_GROUP
        }
        (e, t);
        break;
    default:
        el(e, t)
    }
}
function Jc(e, t) {
    switch (t.tagID) {
    case Ar.TABLE:
        e.openElements.hasInTableScope(Ar.TABLE) && (e.openElements.popUntilTagNamePopped(Ar.TABLE), e._resetInsertionMode());
        break;
    case Ar.TEMPLATE:
        Pc(e, t);
        break;
    case Ar.BODY:
    case Ar.CAPTION:
    case Ar.COL:
    case Ar.COLGROUP:
    case Ar.HTML:
    case Ar.TBODY:
    case Ar.TD:
    case Ar.TFOOT:
    case Ar.TH:
    case Ar.THEAD:
    case Ar.TR:
        break;
    default:
        el(e, t)
    }
}
function el(e, t) {
    const a = e.fosterParentingEnabled;
    e.fosterParentingEnabled = !0,
    Hc(e, t),
    e.fosterParentingEnabled = a
}
function tl(e, t) {
    e.pendingCharacterTokens.push(t)
}
function al(e, t) {
    e.pendingCharacterTokens.push(t),
    e.hasNonWhitespacePendingCharacterToken = !0
}
function nl(e, t) {
    let a = 0;
    if (e.hasNonWhitespacePendingCharacterToken)
        for (; a < e.pendingCharacterTokens.length; a++)
            el(e, e.pendingCharacterTokens[a]);
    else
        for (; a < e.pendingCharacterTokens.length; a++)
            e._insertCharacters(e.pendingCharacterTokens[a]);
    e.insertionMode = e.originalInsertionMode,
    e._processToken(t)
}
const il = new Set([Ar.CAPTION, Ar.COL, Ar.COLGROUP, Ar.TBODY, Ar.TD, Ar.TFOOT, Ar.TH, Ar.THEAD, Ar.TR]);
function sl(e, t) {
    switch (t.tagID) {
    case Ar.HTML:
        Qc(e, t);
        break;
    case Ar.COL:
        e._appendElement(t, br.HTML),
        t.ackSelfClosing = !0;
        break;
    case Ar.TEMPLATE:
        Mc(e, t);
        break;
    default:
        ol(e, t)
    }
}
function ol(e, t) {
    e.openElements.currentTagId === Ar.COLGROUP && (e.openElements.pop(), e.insertionMode = gc.IN_TABLE, e._processToken(t))
}
function rl(e, t) {
    switch (t.tagID) {
    case Ar.TR:
        e.openElements.clearBackToTableBodyContext(),
        e._insertElement(t, br.HTML),
        e.insertionMode = gc.IN_ROW;
        break;
    case Ar.TH:
    case Ar.TD:
        e.openElements.clearBackToTableBodyContext(),
        e._insertFakeElement(vr.TR, Ar.TR),
        e.insertionMode = gc.IN_ROW,
        ll(e, t);
        break;
    case Ar.CAPTION:
    case Ar.COL:
    case Ar.COLGROUP:
    case Ar.TBODY:
    case Ar.TFOOT:
    case Ar.THEAD:
        e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = gc.IN_TABLE, $c(e, t));
        break;
    default:
        $c(e, t)
    }
}
function cl(e, t) {
    const a = t.tagID;
    switch (t.tagID) {
    case Ar.TBODY:
    case Ar.TFOOT:
    case Ar.THEAD:
        e.openElements.hasInTableScope(a) && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = gc.IN_TABLE);
        break;
    case Ar.TABLE:
        e.openElements.hasTableBodyContextInTableScope() && (e.openElements.clearBackToTableBodyContext(), e.openElements.pop(), e.insertionMode = gc.IN_TABLE, Jc(e, t));
        break;
    case Ar.BODY:
    case Ar.CAPTION:
    case Ar.COL:
    case Ar.COLGROUP:
    case Ar.HTML:
    case Ar.TD:
    case Ar.TH:
    case Ar.TR:
        break;
    default:
        Jc(e, t)
    }
}
function ll(e, t) {
    switch (t.tagID) {
    case Ar.TH:
    case Ar.TD:
        e.openElements.clearBackToTableRowContext(),
        e._insertElement(t, br.HTML),
        e.insertionMode = gc.IN_CELL,
        e.activeFormattingElements.insertMarker();
        break;
    case Ar.CAPTION:
    case Ar.COL:
    case Ar.COLGROUP:
    case Ar.TBODY:
    case Ar.TFOOT:
    case Ar.THEAD:
    case Ar.TR:
        e.openElements.hasInTableScope(Ar.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = gc.IN_TABLE_BODY, rl(e, t));
        break;
    default:
        $c(e, t)
    }
}
function pl(e, t) {
    switch (t.tagID) {
    case Ar.TR:
        e.openElements.hasInTableScope(Ar.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = gc.IN_TABLE_BODY);
        break;
    case Ar.TABLE:
        e.openElements.hasInTableScope(Ar.TR) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = gc.IN_TABLE_BODY, cl(e, t));
        break;
    case Ar.TBODY:
    case Ar.TFOOT:
    case Ar.THEAD:
        (e.openElements.hasInTableScope(t.tagID) || e.openElements.hasInTableScope(Ar.TR)) && (e.openElements.clearBackToTableRowContext(), e.openElements.pop(), e.insertionMode = gc.IN_TABLE_BODY, cl(e, t));
        break;
    case Ar.BODY:
    case Ar.CAPTION:
    case Ar.COL:
    case Ar.COLGROUP:
    case Ar.HTML:
    case Ar.TD:
    case Ar.TH:
        break;
    default:
        Jc(e, t)
    }
}
function ul(e, t) {
    switch (t.tagID) {
    case Ar.HTML:
        Qc(e, t);
        break;
    case Ar.OPTION:
        e.openElements.currentTagId === Ar.OPTION && e.openElements.pop(),
        e._insertElement(t, br.HTML);
        break;
    case Ar.OPTGROUP:
        e.openElements.currentTagId === Ar.OPTION && e.openElements.pop(),
        e.openElements.currentTagId === Ar.OPTGROUP && e.openElements.pop(),
        e._insertElement(t, br.HTML);
        break;
    case Ar.INPUT:
    case Ar.KEYGEN:
    case Ar.TEXTAREA:
    case Ar.SELECT:
        e.openElements.hasInSelectScope(Ar.SELECT) && (e.openElements.popUntilTagNamePopped(Ar.SELECT), e._resetInsertionMode(), t.tagID !== Ar.SELECT && e._processStartTag(t));
        break;
    case Ar.SCRIPT:
    case Ar.TEMPLATE:
        Mc(e, t)
    }
}
function dl(e, t) {
    switch (t.tagID) {
    case Ar.OPTGROUP:
        e.openElements.stackTop > 0 && e.openElements.currentTagId === Ar.OPTION && e.openElements.tagIDs[e.openElements.stackTop - 1] === Ar.OPTGROUP && e.openElements.pop(),
        e.openElements.currentTagId === Ar.OPTGROUP && e.openElements.pop();
        break;
    case Ar.OPTION:
        e.openElements.currentTagId === Ar.OPTION && e.openElements.pop();
        break;
    case Ar.SELECT:
        e.openElements.hasInSelectScope(Ar.SELECT) && (e.openElements.popUntilTagNamePopped(Ar.SELECT), e._resetInsertionMode());
        break;
    case Ar.TEMPLATE:
        Pc(e, t)
    }
}
function hl(e, t) {
    e.openElements.tmplCount > 0 ? (e.openElements.popUntilTagNamePopped(Ar.TEMPLATE), e.activeFormattingElements.clearToLastMarker(), e.tmplInsertionModeStack.shift(), e._resetInsertionMode(), e.onEof(t)) : Rc(e, t)
}
function ml(e, t) {
    var a;
    if (t.tagID === Ar.HTML) {
        if (e.fragmentContext || (e.insertionMode = gc.AFTER_AFTER_BODY), e.options.sourceCodeLocationInfo && e.openElements.tagIDs[0] === Ar.HTML) {
            e._setEndLocation(e.openElements.items[0], t);
            const n = e.openElements.items[1];
            n && !(null === (a = e.treeAdapter.getNodeSourceCodeLocation(n)) || void 0 === a ? void 0 : a.endTag) && e._setEndLocation(n, t)
        }
    } else
        fl(e, t)
}
function fl(e, t) {
    e.insertionMode = gc.IN_BODY,
    Hc(e, t)
}
function _l(e, t) {
    e.insertionMode = gc.IN_BODY,
    Hc(e, t)
}
function El(e) {
    for (; e.treeAdapter.getNamespaceURI(e.openElements.current) !== br.HTML && !e._isIntegrationPoint(e.openElements.currentTagId, e.openElements.current); )
        e.openElements.pop()
}
const gl = new Set([vr.AREA, vr.BASE, vr.BASEFONT, vr.BGSOUND, vr.BR, vr.COL, vr.EMBED, vr.FRAME, vr.HR, vr.IMG, vr.INPUT, vr.KEYGEN, vr.LINK, vr.META, vr.PARAM, vr.SOURCE, vr.TRACK, vr.WBR]), bl = {
    treeAdapter: ic,
    scriptingEnabled: !0
};
function xl(e, t) {
    return Tl(e, {
        ...bl,
        ...t
    })
}
function Tl(e, t) {
    return t.treeAdapter.isElementNode(e) ? function (e, t) {
        const a = t.treeAdapter.getTagName(e);
        return `<${a}${function (e, {
            treeAdapter: t
        }) {
            let a = "";
            for (const n of t.getAttrList(e)) {
                if (a += " ", n.namespace)
                    switch (n.namespace) {
                    case br.XML:
                        a += `xml:${n.name}`;
                        break;
                    case br.XMLNS:
                        "xmlns" !== n.name && (a += "xmlns:"),
                        a += n.name;
                        break;
                    case br.XLINK:
                        a += `xlink:${n.name}`;
                        break;
                    default:
                        a += `${n.prefix}:${n.name}`
                    }
                else
                    a += n.name;
                a += `="${oi(n.value)}"`
            }
            return a
        }
        (e, t)}>${function (e, t) {
            return t.treeAdapter.isElementNode(e) && t.treeAdapter.getNamespaceURI(e) === br.HTML && gl.has(t.treeAdapter.getTagName(e))
        }
        (e, t) ? "" : `${function (e, t) {
            let a = "";
            const n = t.treeAdapter.isElementNode(e) && t.treeAdapter.getTagName(e) === vr.TEMPLATE && t.treeAdapter.getNamespaceURI(e) === br.HTML ? t.treeAdapter.getTemplateContent(e) : e,
            i = t.treeAdapter.getChildNodes(n);
            if (i)
                for (const e of i)
                    a += Tl(e, t);
            return a
        }
        (e, t)}</${a}>`}`
    }
    (e, t) : t.treeAdapter.isTextNode(e) ? function (e, t) {
        const {
            treeAdapter: a
        } = t,
        n = a.getTextNodeContent(e),
        i = a.getParentNode(e),
        s = i && a.isElementNode(i) && a.getTagName(i);
        return s && a.getNamespaceURI(i) === br.HTML && (o = s, r = t.scriptingEnabled, Rr.has(o) || r && o === vr.NOSCRIPT) ? n : ri(n);
        var o,
        r
    }
    (e, t) : t.treeAdapter.isCommentNode(e) ? function (e, {
        treeAdapter: t
    }) {
        return `\x3c!--${t.getCommentNodeContent(e)}--\x3e`
    }
    (e, t) : t.treeAdapter.isDocumentTypeNode(e) ? function (e, {
        treeAdapter: t
    }) {
        return `<!DOCTYPE ${t.getDocumentTypeNodeName(e)}>`
    }
    (e, t) : ""
}
function vl(e) {
    return new In(e)
}
function Al(e) {
    const t = e.includes('"') ? "'" : '"';
    return t + e + t
}
const yl = {
    isCommentNode: Fn,
    isElementNode: Pn,
    isTextNode: Un,
    createDocument() {
        const e = new Ln([]);
        return e["x-mode"] = Tr.NO_QUIRKS,
        e
    },
    createDocumentFragment: () => new Ln([]),
    createElement(e, t, a) {
        const n = Object.create(null),
        i = Object.create(null),
        s = Object.create(null);
        for (let e = 0; e < a.length; e++) {
            const t = a[e].name;
            n[t] = a[e].value,
            i[t] = a[e].namespace,
            s[t] = a[e].prefix
        }
        const o = new Mn(e, n, []);
        return o.namespace = t,
        o["x-attribsNamespace"] = i,
        o["x-attribsPrefix"] = s,
        o
    },
    createCommentNode: e => new kn(e),
    appendChild(e, t) {
        const a = e.children[e.children.length - 1];
        a && (a.next = t, t.prev = a),
        e.children.push(t),
        t.parent = e
    },
    insertBefore(e, t, a) {
        const n = e.children.indexOf(a), {
            prev: i
        } = a;
        i && (i.next = t, t.prev = i),
        a.prev = t,
        t.next = a,
        e.children.splice(n, 0, t),
        t.parent = e
    },
    setTemplateContent(e, t) {
        yl.appendChild(e, t)
    },
    getTemplateContent: e => e.children[0],
    setDocumentType(e, t, a, n) {
        const i = function (e, t, a) {
            let n = "!DOCTYPE ";
            return e && (n += e),
            t ? n += ` PUBLIC ${Al(t)}` : a && (n += " SYSTEM"),
            a && (n += ` ${Al(a)}`),
            n
        }
        (t, a, n);
        let s = e.children.find((e => Hn(e) && "!doctype" === e.name));
        s ? s.data = null != i ? i : null : (s = new Rn("!doctype", i), yl.appendChild(e, s)),
        s["x-name"] = null != t ? t : void 0,
        s["x-publicId"] = null != a ? a : void 0,
        s["x-systemId"] = null != n ? n : void 0
    },
    setDocumentMode(e, t) {
        e["x-mode"] = t
    },
    getDocumentMode: e => e["x-mode"],
    detachNode(e) {
        if (e.parent) {
            const t = e.parent.children.indexOf(e), {
                prev: a,
                next: n
            } = e;
            e.prev = null,
            e.next = null,
            a && (a.next = n),
            n && (n.prev = a),
            e.parent.children.splice(t, 1),
            e.parent = null
        }
    },
    insertText(e, t) {
        const a = e.children[e.children.length - 1];
        a && Un(a) ? a.data += t : yl.appendChild(e, vl(t))
    },
    insertTextBefore(e, t, a) {
        const n = e.children[e.children.indexOf(a) - 1];
        n && Un(n) ? n.data += t : yl.insertBefore(e, vl(t), a)
    },
    adoptAttributes(e, t) {
        for (let a = 0; a < t.length; a++) {
            const n = t[a].name;
            void 0 === e.attribs[n] && (e.attribs[n] = t[a].value, e["x-attribsNamespace"][n] = t[a].namespace, e["x-attribsPrefix"][n] = t[a].prefix)
        }
    },
    getFirstChild: e => e.children[0],
    getChildNodes: e => e.children,
    getParentNode: e => e.parent,
    getAttrList: e => e.attributes,
    getTagName: e => e.name,
    getNamespaceURI: e => e.namespace,
    getTextNodeContent: e => e.data,
    getCommentNodeContent: e => e.data,
    getDocumentTypeNodeName(e) {
        var t;
        return null !== (t = e["x-name"]) && void 0 !== t ? t : ""
    },
    getDocumentTypeNodePublicId(e) {
        var t;
        return null !== (t = e["x-publicId"]) && void 0 !== t ? t : ""
    },
    getDocumentTypeNodeSystemId(e) {
        var t;
        return null !== (t = e["x-systemId"]) && void 0 !== t ? t : ""
    },
    isDocumentTypeNode: e => Hn(e) && "!doctype" === e.name,
    setNodeSourceCodeLocation(e, t) {
        t && (e.startIndex = t.startOffset, e.endIndex = t.endOffset),
        e.sourceCodeLocation = t
    },
    getNodeSourceCodeLocation: e => e.sourceCodeLocation,
    updateNodeSourceCodeLocation(e, t) {
        null != t.endOffset && (e.endIndex = t.endOffset),
        e.sourceCodeLocation = {
            ...e.sourceCodeLocation,
            ...t
        }
    }
};
const wl = {
    treeAdapter: yl
};
var Sl, Nl, Cl;
function Il(e) {
    return e === Sl.Space || e === Sl.NewLine || e === Sl.Tab || e === Sl.FormFeed || e === Sl.CarriageReturn
}
function kl(e) {
    return e === Sl.Slash || e === Sl.Gt || Il(e)
}
function Rl(e) {
    return e >= Sl.Zero && e <= Sl.Nine
}
!function (e) {
    e[e.Tab = 9] = "Tab",
    e[e.NewLine = 10] = "NewLine",
    e[e.FormFeed = 12] = "FormFeed",
    e[e.CarriageReturn = 13] = "CarriageReturn",
    e[e.Space = 32] = "Space",
    e[e.ExclamationMark = 33] = "ExclamationMark",
    e[e.Num = 35] = "Num",
    e[e.Amp = 38] = "Amp",
    e[e.SingleQuote = 39] = "SingleQuote",
    e[e.DoubleQuote = 34] = "DoubleQuote",
    e[e.Dash = 45] = "Dash",
    e[e.Slash = 47] = "Slash",
    e[e.Zero = 48] = "Zero",
    e[e.Nine = 57] = "Nine",
    e[e.Semi = 59] = "Semi",
    e[e.Lt = 60] = "Lt",
    e[e.Eq = 61] = "Eq",
    e[e.Gt = 62] = "Gt",
    e[e.Questionmark = 63] = "Questionmark",
    e[e.UpperA = 65] = "UpperA",
    e[e.LowerA = 97] = "LowerA",
    e[e.UpperF = 70] = "UpperF",
    e[e.LowerF = 102] = "LowerF",
    e[e.UpperZ = 90] = "UpperZ",
    e[e.LowerZ = 122] = "LowerZ",
    e[e.LowerX = 120] = "LowerX",
    e[e.OpeningSquareBracket = 91] = "OpeningSquareBracket"
}
(Sl || (Sl = {})), function (e) {
    e[e.Text = 1] = "Text",
    e[e.BeforeTagName = 2] = "BeforeTagName",
    e[e.InTagName = 3] = "InTagName",
    e[e.InSelfClosingTag = 4] = "InSelfClosingTag",
    e[e.BeforeClosingTagName = 5] = "BeforeClosingTagName",
    e[e.InClosingTagName = 6] = "InClosingTagName",
    e[e.AfterClosingTagName = 7] = "AfterClosingTagName",
    e[e.BeforeAttributeName = 8] = "BeforeAttributeName",
    e[e.InAttributeName = 9] = "InAttributeName",
    e[e.AfterAttributeName = 10] = "AfterAttributeName",
    e[e.BeforeAttributeValue = 11] = "BeforeAttributeValue",
    e[e.InAttributeValueDq = 12] = "InAttributeValueDq",
    e[e.InAttributeValueSq = 13] = "InAttributeValueSq",
    e[e.InAttributeValueNq = 14] = "InAttributeValueNq",
    e[e.BeforeDeclaration = 15] = "BeforeDeclaration",
    e[e.InDeclaration = 16] = "InDeclaration",
    e[e.InProcessingInstruction = 17] = "InProcessingInstruction",
    e[e.BeforeComment = 18] = "BeforeComment",
    e[e.CDATASequence = 19] = "CDATASequence",
    e[e.InSpecialComment = 20] = "InSpecialComment",
    e[e.InCommentLike = 21] = "InCommentLike",
    e[e.BeforeSpecialS = 22] = "BeforeSpecialS",
    e[e.SpecialStartSequence = 23] = "SpecialStartSequence",
    e[e.InSpecialTag = 24] = "InSpecialTag",
    e[e.BeforeEntity = 25] = "BeforeEntity",
    e[e.BeforeNumericEntity = 26] = "BeforeNumericEntity",
    e[e.InNamedEntity = 27] = "InNamedEntity",
    e[e.InNumericEntity = 28] = "InNumericEntity",
    e[e.InHexEntity = 29] = "InHexEntity"
}
(Nl || (Nl = {})), function (e) {
    e[e.NoValue = 0] = "NoValue",
    e[e.Unquoted = 1] = "Unquoted",
    e[e.Single = 2] = "Single",
    e[e.Double = 3] = "Double"
}
(Cl || (Cl = {}));
const Ol = {
    Cdata: new Uint8Array([67, 68, 65, 84, 65, 91]),
    CdataEnd: new Uint8Array([93, 93, 62]),
    CommentEnd: new Uint8Array([45, 45, 62]),
    ScriptEnd: new Uint8Array([60, 47, 115, 99, 114, 105, 112, 116]),
    StyleEnd: new Uint8Array([60, 47, 115, 116, 121, 108, 101]),
    TitleEnd: new Uint8Array([60, 47, 116, 105, 116, 108, 101])
};
class Dl {
    constructor({
        xmlMode: e = !1,
        decodeEntities: t = !0
    }, a) {
        this.cbs = a,
        this.state = Nl.Text,
        this.buffer = "",
        this.sectionStart = 0,
        this.index = 0,
        this.baseState = Nl.Text,
        this.isSpecial = !1,
        this.running = !0,
        this.offset = 0,
        this.sequenceIndex = 0,
        this.trieIndex = 0,
        this.trieCurrent = 0,
        this.entityResult = 0,
        this.entityExcess = 0,
        this.xmlMode = e,
        this.decodeEntities = t,
        this.entityTrie = e ? Kn : Wn
    }
    reset() {
        this.state = Nl.Text,
        this.buffer = "",
        this.sectionStart = 0,
        this.index = 0,
        this.baseState = Nl.Text,
        this.currentSequence = void 0,
        this.running = !0,
        this.offset = 0
    }
    write(e) {
        this.offset += this.buffer.length,
        this.buffer = e,
        this.parse()
    }
    end() {
        this.running && this.finish()
    }
    pause() {
        this.running = !1
    }
    resume() {
        this.running = !0,
        this.index < this.buffer.length + this.offset && this.parse()
    }
    getIndex() {
        return this.index
    }
    getSectionStart() {
        return this.sectionStart
    }
    stateText(e) {
        e === Sl.Lt || !this.decodeEntities && this.fastForwardTo(Sl.Lt) ? (this.index > this.sectionStart && this.cbs.ontext(this.sectionStart, this.index), this.state = Nl.BeforeTagName, this.sectionStart = this.index) : this.decodeEntities && e === Sl.Amp && (this.state = Nl.BeforeEntity)
    }
    stateSpecialStartSequence(e) {
        const t = this.sequenceIndex === this.currentSequence.length;
        if (t ? kl(e) : (32 | e) === this.currentSequence[this.sequenceIndex]) {
            if (!t)
                return void this.sequenceIndex++
        } else
            this.isSpecial = !1;
        this.sequenceIndex = 0,
        this.state = Nl.InTagName,
        this.stateInTagName(e)
    }
    stateInSpecialTag(e) {
        if (this.sequenceIndex === this.currentSequence.length) {
            if (e === Sl.Gt || Il(e)) {
                const t = this.index - this.currentSequence.length;
                if (this.sectionStart < t) {
                    const e = this.index;
                    this.index = t,
                    this.cbs.ontext(this.sectionStart, t),
                    this.index = e
                }
                return this.isSpecial = !1,
                this.sectionStart = t + 2,
                void this.stateInClosingTagName(e)
            }
            this.sequenceIndex = 0
        }
        (32 | e) === this.currentSequence[this.sequenceIndex] ? this.sequenceIndex += 1 : 0 === this.sequenceIndex ? this.currentSequence === Ol.TitleEnd ? this.decodeEntities && e === Sl.Amp && (this.state = Nl.BeforeEntity) : this.fastForwardTo(Sl.Lt) && (this.sequenceIndex = 1) : this.sequenceIndex = Number(e === Sl.Lt)
    }
    stateCDATASequence(e) {
        e === Ol.Cdata[this.sequenceIndex] ? ++this.sequenceIndex === Ol.Cdata.length && (this.state = Nl.InCommentLike, this.currentSequence = Ol.CdataEnd, this.sequenceIndex = 0, this.sectionStart = this.index + 1) : (this.sequenceIndex = 0, this.state = Nl.InDeclaration, this.stateInDeclaration(e))
    }
    fastForwardTo(e) {
        for (; ++this.index < this.buffer.length + this.offset; )
            if (this.buffer.charCodeAt(this.index - this.offset) === e)
                return !0;
        return this.index = this.buffer.length + this.offset - 1,
        !1
    }
    stateInCommentLike(e) {
        e === this.currentSequence[this.sequenceIndex] ? ++this.sequenceIndex === this.currentSequence.length && (this.currentSequence === Ol.CdataEnd ? this.cbs.oncdata(this.sectionStart, this.index, 2) : this.cbs.oncomment(this.sectionStart, this.index, 2), this.sequenceIndex = 0, this.sectionStart = this.index + 1, this.state = Nl.Text) : 0 === this.sequenceIndex ? this.fastForwardTo(this.currentSequence[0]) && (this.sequenceIndex = 1) : e !== this.currentSequence[this.sequenceIndex - 1] && (this.sequenceIndex = 0)
    }
    isTagStartChar(e) {
        return this.xmlMode ? !kl(e) : function (e) {
            return e >= Sl.LowerA && e <= Sl.LowerZ || e >= Sl.UpperA && e <= Sl.UpperZ
        }
        (e)
    }
    startSpecial(e, t) {
        this.isSpecial = !0,
        this.currentSequence = e,
        this.sequenceIndex = t,
        this.state = Nl.SpecialStartSequence
    }
    stateBeforeTagName(e) {
        if (e === Sl.ExclamationMark)
            this.state = Nl.BeforeDeclaration, this.sectionStart = this.index + 1;
        else if (e === Sl.Questionmark)
            this.state = Nl.InProcessingInstruction, this.sectionStart = this.index + 1;
        else if (this.isTagStartChar(e)) {
            const t = 32 | e;
            this.sectionStart = this.index,
            this.xmlMode || t !== Ol.TitleEnd[2] ? this.state = this.xmlMode || t !== Ol.ScriptEnd[2] ? Nl.InTagName : Nl.BeforeSpecialS : this.startSpecial(Ol.TitleEnd, 3)
        } else
            e === Sl.Slash ? this.state = Nl.BeforeClosingTagName : (this.state = Nl.Text, this.stateText(e))
    }
    stateInTagName(e) {
        kl(e) && (this.cbs.onopentagname(this.sectionStart, this.index), this.sectionStart = -1, this.state = Nl.BeforeAttributeName, this.stateBeforeAttributeName(e))
    }
    stateBeforeClosingTagName(e) {
        Il(e) || (e === Sl.Gt ? this.state = Nl.Text : (this.state = this.isTagStartChar(e) ? Nl.InClosingTagName : Nl.InSpecialComment, this.sectionStart = this.index))
    }
    stateInClosingTagName(e) {
        (e === Sl.Gt || Il(e)) && (this.cbs.onclosetag(this.sectionStart, this.index), this.sectionStart = -1, this.state = Nl.AfterClosingTagName, this.stateAfterClosingTagName(e))
    }
    stateAfterClosingTagName(e) {
        (e === Sl.Gt || this.fastForwardTo(Sl.Gt)) && (this.state = Nl.Text, this.sectionStart = this.index + 1)
    }
    stateBeforeAttributeName(e) {
        e === Sl.Gt ? (this.cbs.onopentagend(this.index), this.isSpecial ? (this.state = Nl.InSpecialTag, this.sequenceIndex = 0) : this.state = Nl.Text, this.baseState = this.state, this.sectionStart = this.index + 1) : e === Sl.Slash ? this.state = Nl.InSelfClosingTag : Il(e) || (this.state = Nl.InAttributeName, this.sectionStart = this.index)
    }
    stateInSelfClosingTag(e) {
        e === Sl.Gt ? (this.cbs.onselfclosingtag(this.index), this.state = Nl.Text, this.baseState = Nl.Text, this.sectionStart = this.index + 1, this.isSpecial = !1) : Il(e) || (this.state = Nl.BeforeAttributeName, this.stateBeforeAttributeName(e))
    }
    stateInAttributeName(e) {
        (e === Sl.Eq || kl(e)) && (this.cbs.onattribname(this.sectionStart, this.index), this.sectionStart = -1, this.state = Nl.AfterAttributeName, this.stateAfterAttributeName(e))
    }
    stateAfterAttributeName(e) {
        e === Sl.Eq ? this.state = Nl.BeforeAttributeValue : e === Sl.Slash || e === Sl.Gt ? (this.cbs.onattribend(Cl.NoValue, this.index), this.state = Nl.BeforeAttributeName, this.stateBeforeAttributeName(e)) : Il(e) || (this.cbs.onattribend(Cl.NoValue, this.index), this.state = Nl.InAttributeName, this.sectionStart = this.index)
    }
    stateBeforeAttributeValue(e) {
        e === Sl.DoubleQuote ? (this.state = Nl.InAttributeValueDq, this.sectionStart = this.index + 1) : e === Sl.SingleQuote ? (this.state = Nl.InAttributeValueSq, this.sectionStart = this.index + 1) : Il(e) || (this.sectionStart = this.index, this.state = Nl.InAttributeValueNq, this.stateInAttributeValueNoQuotes(e))
    }
    handleInAttributeValue(e, t) {
        e === t || !this.decodeEntities && this.fastForwardTo(t) ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(t === Sl.DoubleQuote ? Cl.Double : Cl.Single, this.index), this.state = Nl.BeforeAttributeName) : this.decodeEntities && e === Sl.Amp && (this.baseState = this.state, this.state = Nl.BeforeEntity)
    }
    stateInAttributeValueDoubleQuotes(e) {
        this.handleInAttributeValue(e, Sl.DoubleQuote)
    }
    stateInAttributeValueSingleQuotes(e) {
        this.handleInAttributeValue(e, Sl.SingleQuote)
    }
    stateInAttributeValueNoQuotes(e) {
        Il(e) || e === Sl.Gt ? (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = -1, this.cbs.onattribend(Cl.Unquoted, this.index), this.state = Nl.BeforeAttributeName, this.stateBeforeAttributeName(e)) : this.decodeEntities && e === Sl.Amp && (this.baseState = this.state, this.state = Nl.BeforeEntity)
    }
    stateBeforeDeclaration(e) {
        e === Sl.OpeningSquareBracket ? (this.state = Nl.CDATASequence, this.sequenceIndex = 0) : this.state = e === Sl.Dash ? Nl.BeforeComment : Nl.InDeclaration
    }
    stateInDeclaration(e) {
        (e === Sl.Gt || this.fastForwardTo(Sl.Gt)) && (this.cbs.ondeclaration(this.sectionStart, this.index), this.state = Nl.Text, this.sectionStart = this.index + 1)
    }
    stateInProcessingInstruction(e) {
        (e === Sl.Gt || this.fastForwardTo(Sl.Gt)) && (this.cbs.onprocessinginstruction(this.sectionStart, this.index), this.state = Nl.Text, this.sectionStart = this.index + 1)
    }
    stateBeforeComment(e) {
        e === Sl.Dash ? (this.state = Nl.InCommentLike, this.currentSequence = Ol.CommentEnd, this.sequenceIndex = 2, this.sectionStart = this.index + 1) : this.state = Nl.InDeclaration
    }
    stateInSpecialComment(e) {
        (e === Sl.Gt || this.fastForwardTo(Sl.Gt)) && (this.cbs.oncomment(this.sectionStart, this.index, 0), this.state = Nl.Text, this.sectionStart = this.index + 1)
    }
    stateBeforeSpecialS(e) {
        const t = 32 | e;
        t === Ol.ScriptEnd[3] ? this.startSpecial(Ol.ScriptEnd, 4) : t === Ol.StyleEnd[3] ? this.startSpecial(Ol.StyleEnd, 4) : (this.state = Nl.InTagName, this.stateInTagName(e))
    }
    stateBeforeEntity(e) {
        this.entityExcess = 1,
        this.entityResult = 0,
        e === Sl.Num ? this.state = Nl.BeforeNumericEntity : e === Sl.Amp || (this.trieIndex = 0, this.trieCurrent = this.entityTrie[0], this.state = Nl.InNamedEntity, this.stateInNamedEntity(e))
    }
    stateInNamedEntity(e) {
        if (this.entityExcess += 1, this.trieIndex = ei(this.entityTrie, this.trieCurrent, this.trieIndex + 1, e), this.trieIndex < 0)
            return this.emitNamedEntity(), void this.index--;
        this.trieCurrent = this.entityTrie[this.trieIndex];
        const t = this.trieCurrent & Jn.VALUE_LENGTH;
        if (t) {
            const a = (t >> 14) - 1;
            if (this.allowLegacyEntity() || e === Sl.Semi) {
                const e = this.index - this.entityExcess + 1;
                e > this.sectionStart && this.emitPartial(this.sectionStart, e),
                this.entityResult = this.trieIndex,
                this.trieIndex += a,
                this.entityExcess = 0,
                this.sectionStart = this.index + 1,
                0 === a && this.emitNamedEntity()
            } else
                this.trieIndex += a
        }
    }
    emitNamedEntity() {
        if (this.state = this.baseState, 0 !== this.entityResult)
            switch ((this.entityTrie[this.entityResult] & Jn.VALUE_LENGTH) >> 14) {
            case 1:
                this.emitCodePoint(this.entityTrie[this.entityResult] & ~Jn.VALUE_LENGTH);
                break;
            case 2:
                this.emitCodePoint(this.entityTrie[this.entityResult + 1]);
                break;
            case 3:
                this.emitCodePoint(this.entityTrie[this.entityResult + 1]),
                this.emitCodePoint(this.entityTrie[this.entityResult + 2])
            }
    }
    stateBeforeNumericEntity(e) {
        (32 | e) === Sl.LowerX ? (this.entityExcess++, this.state = Nl.InHexEntity) : (this.state = Nl.InNumericEntity, this.stateInNumericEntity(e))
    }
    emitNumericEntity(e) {
        const t = this.index - this.entityExcess - 1;
        t + 2 + Number(this.state === Nl.InHexEntity) !== this.index && (t > this.sectionStart && this.emitPartial(this.sectionStart, t), this.sectionStart = this.index + Number(e), this.emitCodePoint(function (e) {
                var t;
                return e >= 55296 && e <= 57343 || e > 1114111 ? 65533 : null !== (t = Zn.get(e)) && void 0 !== t ? t : e
            }
                (this.entityResult))),
        this.state = this.baseState
    }
    stateInNumericEntity(e) {
        e === Sl.Semi ? this.emitNumericEntity(!0) : Rl(e) ? (this.entityResult = 10 * this.entityResult + (e - Sl.Zero), this.entityExcess++) : (this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state = this.baseState, this.index--)
    }
    stateInHexEntity(e) {
        e === Sl.Semi ? this.emitNumericEntity(!0) : Rl(e) ? (this.entityResult = 16 * this.entityResult + (e - Sl.Zero), this.entityExcess++) : function (e) {
            return e >= Sl.UpperA && e <= Sl.UpperF || e >= Sl.LowerA && e <= Sl.LowerF
        }
        (e) ? (this.entityResult = 16 * this.entityResult + ((32 | e) - Sl.LowerA + 10), this.entityExcess++) : (this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state = this.baseState, this.index--)
    }
    allowLegacyEntity() {
        return !this.xmlMode && (this.baseState === Nl.Text || this.baseState === Nl.InSpecialTag)
    }
    cleanup() {
        this.running && this.sectionStart !== this.index && (this.state === Nl.Text || this.state === Nl.InSpecialTag && 0 === this.sequenceIndex ? (this.cbs.ontext(this.sectionStart, this.index), this.sectionStart = this.index) : this.state !== Nl.InAttributeValueDq && this.state !== Nl.InAttributeValueSq && this.state !== Nl.InAttributeValueNq || (this.cbs.onattribdata(this.sectionStart, this.index), this.sectionStart = this.index))
    }
    shouldContinue() {
        return this.index < this.buffer.length + this.offset && this.running
    }
    parse() {
        for (; this.shouldContinue(); ) {
            const e = this.buffer.charCodeAt(this.index - this.offset);
            this.state === Nl.Text ? this.stateText(e) : this.state === Nl.SpecialStartSequence ? this.stateSpecialStartSequence(e) : this.state === Nl.InSpecialTag ? this.stateInSpecialTag(e) : this.state === Nl.CDATASequence ? this.stateCDATASequence(e) : this.state === Nl.InAttributeValueDq ? this.stateInAttributeValueDoubleQuotes(e) : this.state === Nl.InAttributeName ? this.stateInAttributeName(e) : this.state === Nl.InCommentLike ? this.stateInCommentLike(e) : this.state === Nl.InSpecialComment ? this.stateInSpecialComment(e) : this.state === Nl.BeforeAttributeName ? this.stateBeforeAttributeName(e) : this.state === Nl.InTagName ? this.stateInTagName(e) : this.state === Nl.InClosingTagName ? this.stateInClosingTagName(e) : this.state === Nl.BeforeTagName ? this.stateBeforeTagName(e) : this.state === Nl.AfterAttributeName ? this.stateAfterAttributeName(e) : this.state === Nl.InAttributeValueSq ? this.stateInAttributeValueSingleQuotes(e) : this.state === Nl.BeforeAttributeValue ? this.stateBeforeAttributeValue(e) : this.state === Nl.BeforeClosingTagName ? this.stateBeforeClosingTagName(e) : this.state === Nl.AfterClosingTagName ? this.stateAfterClosingTagName(e) : this.state === Nl.BeforeSpecialS ? this.stateBeforeSpecialS(e) : this.state === Nl.InAttributeValueNq ? this.stateInAttributeValueNoQuotes(e) : this.state === Nl.InSelfClosingTag ? this.stateInSelfClosingTag(e) : this.state === Nl.InDeclaration ? this.stateInDeclaration(e) : this.state === Nl.BeforeDeclaration ? this.stateBeforeDeclaration(e) : this.state === Nl.BeforeComment ? this.stateBeforeComment(e) : this.state === Nl.InProcessingInstruction ? this.stateInProcessingInstruction(e) : this.state === Nl.InNamedEntity ? this.stateInNamedEntity(e) : this.state === Nl.BeforeEntity ? this.stateBeforeEntity(e) : this.state === Nl.InHexEntity ? this.stateInHexEntity(e) : this.state === Nl.InNumericEntity ? this.stateInNumericEntity(e) : this.stateBeforeNumericEntity(e),
            this.index++
        }
        this.cleanup()
    }
    finish() {
        this.state === Nl.InNamedEntity && this.emitNamedEntity(),
        this.sectionStart < this.index && this.handleTrailingData(),
        this.cbs.onend()
    }
    handleTrailingData() {
        const e = this.buffer.length + this.offset;
        this.state === Nl.InCommentLike ? this.currentSequence === Ol.CdataEnd ? this.cbs.oncdata(this.sectionStart, e, 0) : this.cbs.oncomment(this.sectionStart, e, 0) : this.state === Nl.InNumericEntity && this.allowLegacyEntity() || this.state === Nl.InHexEntity && this.allowLegacyEntity() ? this.emitNumericEntity(!1) : this.state === Nl.InTagName || this.state === Nl.BeforeAttributeName || this.state === Nl.BeforeAttributeValue || this.state === Nl.AfterAttributeName || this.state === Nl.InAttributeName || this.state === Nl.InAttributeValueSq || this.state === Nl.InAttributeValueDq || this.state === Nl.InAttributeValueNq || this.state === Nl.InClosingTagName || this.cbs.ontext(this.sectionStart, e)
    }
    emitPartial(e, t) {
        this.baseState !== Nl.Text && this.baseState !== Nl.InSpecialTag ? this.cbs.onattribdata(e, t) : this.cbs.ontext(e, t)
    }
    emitCodePoint(e) {
        this.baseState !== Nl.Text && this.baseState !== Nl.InSpecialTag ? this.cbs.onattribentity(e) : this.cbs.ontextentity(e)
    }
}
const Ll = new Set(["input", "option", "optgroup", "select", "button", "datalist", "textarea"]), Ml = new Set(["p"]), Pl = new Set(["thead", "tbody"]), Bl = new Set(["dd", "dt"]), Ul = new Set(["rt", "rp"]), Fl = new Map([["tr", new Set(["tr", "th", "td"])], ["th", new Set(["th"])], ["td", new Set(["thead", "th", "td"])], ["body", new Set(["head", "link", "script"])], ["li", new Set(["li"])], ["p", Ml], ["h1", Ml], ["h2", Ml], ["h3", Ml], ["h4", Ml], ["h5", Ml], ["h6", Ml], ["select", Ll], ["input", Ll], ["output", Ll], ["button", Ll], ["datalist", Ll], ["textarea", Ll], ["option", new Set(["option"])], ["optgroup", new Set(["optgroup", "option"])], ["dd", Bl], ["dt", Bl], ["address", Ml], ["article", Ml], ["aside", Ml], ["blockquote", Ml], ["details", Ml], ["div", Ml], ["dl", Ml], ["fieldset", Ml], ["figcaption", Ml], ["figure", Ml], ["footer", Ml], ["form", Ml], ["header", Ml], ["hr", Ml], ["main", Ml], ["nav", Ml], ["ol", Ml], ["pre", Ml], ["section", Ml], ["table", Ml], ["ul", Ml], ["rt", Ul], ["rp", Ul], ["tbody", Pl], ["tfoot", Pl]]), Hl = new Set(["area", "base", "basefont", "br", "col", "command", "embed", "frame", "hr", "img", "input", "isindex", "keygen", "link", "meta", "param", "source", "track", "wbr"]), jl = new Set(["math", "svg"]), zl = new Set(["mi", "mo", "mn", "ms", "mtext", "annotation-xml", "foreignobject", "desc", "title"]), Gl = /\s|\//;
class ql {
    constructor(e, t = {}) {
        var a,
        n,
        i,
        s,
        o;
        this.options = t,
        this.startIndex = 0,
        this.endIndex = 0,
        this.openTagStart = 0,
        this.tagname = "",
        this.attribname = "",
        this.attribvalue = "",
        this.attribs = null,
        this.stack = [],
        this.foreignContext = [],
        this.buffers = [],
        this.bufferOffset = 0,
        this.writeIndex = 0,
        this.ended = !1,
        this.cbs = null != e ? e : {},
        this.lowerCaseTagNames = null !== (a = t.lowerCaseTags) && void 0 !== a ? a : !t.xmlMode,
        this.lowerCaseAttributeNames = null !== (n = t.lowerCaseAttributeNames) && void 0 !== n ? n : !t.xmlMode,
        this.tokenizer = new(null !== (i = t.Tokenizer) && void 0 !== i ? i : Dl)(this.options, this),
        null === (o = (s = this.cbs).onparserinit) || void 0 === o || o.call(s, this)
    }
    ontext(e, t) {
        var a,
        n;
        const i = this.getSlice(e, t);
        this.endIndex = t - 1,
        null === (n = (a = this.cbs).ontext) || void 0 === n || n.call(a, i),
        this.startIndex = t
    }
    ontextentity(e) {
        var t,
        a;
        const n = this.tokenizer.getSectionStart();
        this.endIndex = n - 1,
        null === (a = (t = this.cbs).ontext) || void 0 === a || a.call(t, Xn(e)),
        this.startIndex = n
    }
    isVoidElement(e) {
        return !this.options.xmlMode && Hl.has(e)
    }
    onopentagname(e, t) {
        this.endIndex = t;
        let a = this.getSlice(e, t);
        this.lowerCaseTagNames && (a = a.toLowerCase()),
        this.emitOpenTag(a)
    }
    emitOpenTag(e) {
        var t,
        a,
        n,
        i;
        this.openTagStart = this.startIndex,
        this.tagname = e;
        const s = !this.options.xmlMode && Fl.get(e);
        if (s)
            for (; this.stack.length > 0 && s.has(this.stack[this.stack.length - 1]); ) {
                const e = this.stack.pop();
                null === (a = (t = this.cbs).onclosetag) || void 0 === a || a.call(t, e, !0)
            }
        this.isVoidElement(e) || (this.stack.push(e), jl.has(e) ? this.foreignContext.push(!0) : zl.has(e) && this.foreignContext.push(!1)),
        null === (i = (n = this.cbs).onopentagname) || void 0 === i || i.call(n, e),
        this.cbs.onopentag && (this.attribs = {})
    }
    endOpenTag(e) {
        var t,
        a;
        this.startIndex = this.openTagStart,
        this.attribs && (null === (a = (t = this.cbs).onopentag) || void 0 === a || a.call(t, this.tagname, this.attribs, e), this.attribs = null),
        this.cbs.onclosetag && this.isVoidElement(this.tagname) && this.cbs.onclosetag(this.tagname, !0),
        this.tagname = ""
    }
    onopentagend(e) {
        this.endIndex = e,
        this.endOpenTag(!1),
        this.startIndex = e + 1
    }
    onclosetag(e, t) {
        var a,
        n,
        i,
        s,
        o,
        r;
        this.endIndex = t;
        let c = this.getSlice(e, t);
        if (this.lowerCaseTagNames && (c = c.toLowerCase()), (jl.has(c) || zl.has(c)) && this.foreignContext.pop(), this.isVoidElement(c))
            this.options.xmlMode || "br" !== c || (null === (n = (a = this.cbs).onopentagname) || void 0 === n || n.call(a, "br"), null === (s = (i = this.cbs).onopentag) || void 0 === s || s.call(i, "br", {}, !0), null === (r = (o = this.cbs).onclosetag) || void 0 === r || r.call(o, "br", !1));
        else {
            const e = this.stack.lastIndexOf(c);
            if (-1 !== e)
                if (this.cbs.onclosetag) {
                    let t = this.stack.length - e;
                    for (; t--; )
                        this.cbs.onclosetag(this.stack.pop(), 0 !== t)
                } else
                    this.stack.length = e;
            else
                this.options.xmlMode || "p" !== c || (this.emitOpenTag("p"), this.closeCurrentTag(!0))
        }
        this.startIndex = t + 1
    }
    onselfclosingtag(e) {
        this.endIndex = e,
        this.options.xmlMode || this.options.recognizeSelfClosing || this.foreignContext[this.foreignContext.length - 1] ? (this.closeCurrentTag(!1), this.startIndex = e + 1) : this.onopentagend(e)
    }
    closeCurrentTag(e) {
        var t,
        a;
        const n = this.tagname;
        this.endOpenTag(e),
        this.stack[this.stack.length - 1] === n && (null === (a = (t = this.cbs).onclosetag) || void 0 === a || a.call(t, n, !e), this.stack.pop())
    }
    onattribname(e, t) {
        this.startIndex = e;
        const a = this.getSlice(e, t);
        this.attribname = this.lowerCaseAttributeNames ? a.toLowerCase() : a
    }
    onattribdata(e, t) {
        this.attribvalue += this.getSlice(e, t)
    }
    onattribentity(e) {
        this.attribvalue += Xn(e)
    }
    onattribend(e, t) {
        var a,
        n;
        this.endIndex = t,
        null === (n = (a = this.cbs).onattribute) || void 0 === n || n.call(a, this.attribname, this.attribvalue, e === Cl.Double ? '"' : e === Cl.Single ? "'" : e === Cl.NoValue ? void 0 : null),
        this.attribs && !Object.prototype.hasOwnProperty.call(this.attribs, this.attribname) && (this.attribs[this.attribname] = this.attribvalue),
        this.attribvalue = ""
    }
    getInstructionName(e) {
        const t = e.search(Gl);
        let a = t < 0 ? e : e.substr(0, t);
        return this.lowerCaseTagNames && (a = a.toLowerCase()),
        a
    }
    ondeclaration(e, t) {
        this.endIndex = t;
        const a = this.getSlice(e, t);
        if (this.cbs.onprocessinginstruction) {
            const e = this.getInstructionName(a);
            this.cbs.onprocessinginstruction(`!${e}`, `!${a}`)
        }
        this.startIndex = t + 1
    }
    onprocessinginstruction(e, t) {
        this.endIndex = t;
        const a = this.getSlice(e, t);
        if (this.cbs.onprocessinginstruction) {
            const e = this.getInstructionName(a);
            this.cbs.onprocessinginstruction(`?${e}`, `?${a}`)
        }
        this.startIndex = t + 1
    }
    oncomment(e, t, a) {
        var n,
        i,
        s,
        o;
        this.endIndex = t,
        null === (i = (n = this.cbs).oncomment) || void 0 === i || i.call(n, this.getSlice(e, t - a)),
        null === (o = (s = this.cbs).oncommentend) || void 0 === o || o.call(s),
        this.startIndex = t + 1
    }
    oncdata(e, t, a) {
        var n,
        i,
        s,
        o,
        r,
        c,
        l,
        p,
        u,
        d;
        this.endIndex = t;
        const h = this.getSlice(e, t - a);
        this.options.xmlMode || this.options.recognizeCDATA ? (null === (i = (n = this.cbs).oncdatastart) || void 0 === i || i.call(n), null === (o = (s = this.cbs).ontext) || void 0 === o || o.call(s, h), null === (c = (r = this.cbs).oncdataend) || void 0 === c || c.call(r)) : (null === (p = (l = this.cbs).oncomment) || void 0 === p || p.call(l, `[CDATA[${h}]]`), null === (d = (u = this.cbs).oncommentend) || void 0 === d || d.call(u)),
        this.startIndex = t + 1
    }
    onend() {
        var e,
        t;
        if (this.cbs.onclosetag) {
            this.endIndex = this.startIndex;
            for (let e = this.stack.length; e > 0; this.cbs.onclosetag(this.stack[--e], !0));
        }
        null === (t = (e = this.cbs).onend) || void 0 === t || t.call(e)
    }
    reset() {
        var e,
        t,
        a,
        n;
        null === (t = (e = this.cbs).onreset) || void 0 === t || t.call(e),
        this.tokenizer.reset(),
        this.tagname = "",
        this.attribname = "",
        this.attribs = null,
        this.stack.length = 0,
        this.startIndex = 0,
        this.endIndex = 0,
        null === (n = (a = this.cbs).onparserinit) || void 0 === n || n.call(a, this),
        this.buffers.length = 0,
        this.bufferOffset = 0,
        this.writeIndex = 0,
        this.ended = !1
    }
    parseComplete(e) {
        this.reset(),
        this.end(e)
    }
    getSlice(e, t) {
        for (; e - this.bufferOffset >= this.buffers[0].length; )
            this.shiftBuffer();
        let a = this.buffers[0].slice(e - this.bufferOffset, t - this.bufferOffset);
        for (; t - this.bufferOffset > this.buffers[0].length; )
            this.shiftBuffer(), a += this.buffers[0].slice(0, t - this.bufferOffset);
        return a
    }
    shiftBuffer() {
        this.bufferOffset += this.buffers[0].length,
        this.writeIndex--,
        this.buffers.shift()
    }
    write(e) {
        var t,
        a;
        this.ended ? null === (a = (t = this.cbs).onerror) || void 0 === a || a.call(t, new Error(".write() after done!")) : (this.buffers.push(e), this.tokenizer.running && (this.tokenizer.write(e), this.writeIndex++))
    }
    end(e) {
        var t,
        a;
        this.ended ? null === (a = (t = this.cbs).onerror) || void 0 === a || a.call(t, Error(".end() after done!")) : (e && this.write(e), this.ended = !0, this.tokenizer.end())
    }
    pause() {
        this.tokenizer.pause()
    }
    resume() {
        for (this.tokenizer.resume(); this.tokenizer.running && this.writeIndex < this.buffers.length; )
            this.tokenizer.write(this.buffers[this.writeIndex++]);
        this.ended && this.tokenizer.end()
    }
    parseChunk(e) {
        this.write(e)
    }
    done(e) {
        this.end(e)
    }
}
const Yl = (Vl = (e, t, a, n) => t.xmlMode || t._useHtmlParser2 ? function (e, t) {
    const a = new Vn(void 0, t);
    return new ql(a, t).end(e),
    a.root
}
    (e, t) : function (e, t, a, n) {
    const i = {
        scriptingEnabled: "boolean" != typeof t.scriptingEnabled || t.scriptingEnabled,
        treeAdapter: yl,
        sourceCodeLocationInfo: t.sourceCodeLocationInfo
    };
    return a ? function (e, t) {
        return vc.parse(e, t)
    }
    (e, i) : function (e, t, a) {
        "string" == typeof e && (a = t, t = e, e = null);
        const n = vc.getFragmentParser(e, a);
        return n.tokenizer.write(t, !0),
        n.getFragment()
    }
    (n, e, i)
}
    (e, t, a, n), function (e, t, a, n) {
    if ("undefined" != typeof Buffer && Buffer.isBuffer(e) && (e = e.toString()), "string" == typeof e)
        return Vl(e, t, a, n);
    const i = e;
    if (!Array.isArray(i) && jn(i))
        return i;
    const s = new Ln([]);
    return Qo(i, s),
    s
});
var Vl;
const Ql = function (e, t) {
    return function t(a, n, i = !0) {
        if (null == a)
            throw new Error("cheerio.load() expects a string");
        const s = {
            ...mn,
            ..._n(n)
        },
        o = e(a, s, i, null);
        class r extends cr {
            _make(e, t) {
                const a = c(e, t);
                return a.prevObject = this,
                a
            }
            _parse(t, a, n, i) {
                return e(t, a, n, i)
            }
            _render(e) {
                return ((e, t) => t.xmlMode || t._useHtmlParser2 ? hi(e, t) : function (e) {
                    const t = "length" in e ? e : [e];
                    for (let e = 0; e < t.length; e += 1) {
                        const a = t[e];
                        jn(a) && Array.prototype.splice.call(t, e, 1, ...a.children)
                    }
                    let a = "";
                    for (let e = 0; e < t.length; e += 1)
                        a += xl(t[e], wl);
                    return a
                }
                    (e))(e, this.options)
            }
        }
        function c(t, a, n = o, i) {
            if (t && Xi(t))
                return t;
            const c = {
                ...s,
                ..._n(i)
            },
            l = "string" == typeof n ? [e(n, c, !1, null)] : "length" in n ? n : [n],
            p = Xi(l) ? l : new r(l, null, c);
            if (p._root = p, !t)
                return new r(void 0, p, c);
            const u = "string" == typeof t && es(t) ? e(t, c, !1, null).children : (d = t).name || "root" === d.type || "text" === d.type || "comment" === d.type ? [t] : Array.isArray(t) ? t : void 0;
            var d;
            const h = new r(u, p, c);
            if (u)
                return h;
            if ("string" != typeof t)
                throw new Error("Unexpected type of selector");
            let m = t;
            const f = a ? "string" == typeof a ? es(a) ? new r([e(a, c, !1, null)], p, c) : (m = `${a} ${m}`, p) : Xi(a) ? a : new r(Array.isArray(a) ? a : [a], p, c) : p;
            return f ? f.find(m) : h
        }
        return Object.assign(c, Zi, {
            load: t,
            _root: o,
            _options: s,
            fn: r.prototype,
            prototype: r.prototype
        }),
        c
    }
}
(Yl);
Ql([]);
const Wl = {
    init: '"use strict";window.__adapter_init=function(){function base64toArrayBuffer(e){var o=window.atob(e.substring(e.indexOf(",")+1));let r=o.length;for(var t=new Uint8Array(r);r--;)t[r]=o.charCodeAt(r);return t.buffer}function base64ToBlob(e,o){e=e.split(",");let r=o;2===e.length&&(n=e.shift(),t=new RegExp(":(.*?);"),n=n.match(t),r=(n&&1<n.length?n[1]:o)||o);var t=e.shift(),a=window.atob(t),n=new ArrayBuffer(a.length),d=new Uint8Array(n);for(let e=0;e<a.length;e++)d[e]=a.charCodeAt(e);return new Blob([n],{type:r})}function convertBase64(e){var o=new RegExp("-","g");return e=(e=e.replace(o,"+")).replace(o,"/")}function __adapter_get_res_path(e,o){if(o[e])return e;for(var r in o){var t=e.indexOf(r);if(-1!==t&&t+r.length===e.length)return r}return null}function __adapter_get_resource(e){return window.__adapter_resource__[__adapter_get_res_path(e,window.__adapter_resource__)]}function loadText(e,o,r){o.responseType="text",r(null,__adapter_get_resource(e))}function loadJson(e,o,r){r(null,JSON.parse(__adapter_get_resource(e)))}function loadArrayBuffer(e,o,r){r(null,base64toArrayBuffer(__adapter_get_resource(e)))}function loadScript(url,options,onComplete){let data=__adapter_get_resource(url);data||console.error(url+" isn\'t load"),eval(data),onComplete&&onComplete(null)}function loadImage(e,o,r){var t=__adapter_get_resource(e);t||console.error(e+" isn\'t load");let a=new Image;const n=function(){a.removeEventListener("load",n),a.removeEventListener("error",d),r&&r(null,a)},d=function(){a.removeEventListener("load",n),a.removeEventListener("error",d),r&&r(new Error(cc.debug.getError(4930,e)))};return a.addEventListener("load",n),a.addEventListener("error",d),a.src=t,a}function loadVideo(e,o,r){e=base64toArrayBuffer(convertBase64(__adapter_get_resource(e))),r&&r(null,e)}function loadDomAudio(o,r){const e=cc.sys.__audioSupport,t=document.createElement("audio");t.muted=!1;var a=base64ToBlob(__adapter_get_resource(o.split("?")[0]),"audio/mpeg");window.URL?t.src=window.URL.createObjectURL(a):t.src=a;function n(){clearTimeout(d),t.removeEventListener("canplaythrough",l,!1),t.removeEventListener("error",i,!1),e.USE_LOADER_EVENT&&t.removeEventListener(e.USE_LOADER_EVENT,l,!1)}const d=setTimeout(function(){(0===t.readyState?i:l)()},8e3),l=function(){n(),r&&r(null,t)},i=function(){n();var e="load audio failure - "+o;cc.log(e),r&&r(new Error(e))};t.addEventListener("canplaythrough",l,!1),t.addEventListener("error",i,!1),e.USE_LOADER_EVENT&&t.addEventListener(e.USE_LOADER_EVENT,l,!1),t}function loadWebAudio(e,o){var r=cc.sys.__audioSupport.context,t=(r||callback(new Error("Audio Downloader: no web audio context.")),base64toArrayBuffer(__adapter_get_resource(e)));t?r.decodeAudioData(t,function(e){o(null,e)},function(){o("decode error - "+e,null)}):o("request error - "+e,null)}function loadAudio(e,o,r){var t=cc.sys.__audioSupport;if(0===t.format.length)return new Error("Audio Downloader: audio not supported on this browser!");(t.WEB_AUDIO?loadWebAudio:loadDomAudio)(e,r)}function loadFont(e,o,r){const t=e.replace(/[.\\/ "\'\\\\]*/g,"");var e=__adapter_get_resource(e);null==e?r():(e=new FontFace(t,"url("+e+")"),document.fonts.add(e),e.load(),e.loaded.then(function(){r(null,t)},function(){cc.warnID(4933,t),r(null,t)}))}function loadBundle(r,e,t){var o=new RegExp("^(?:w+://|.+/).+"),a=cc.path.basename(r),o=(o.test(r)||(r="assets/"+a),e.version||cc.assetManager.downloader.bundleVers[a]);let n=0,d=null,l=null;loadJson(r+`/config.${o?o+".":""}json`,e,function(e,o){e&&(l=e),(d=o)&&(d.base=r+"/"),2===++n&&t&&t(l,d)}),loadScript(r+`/index.${o?o+".":""}js`,e,function(e){e&&(l=e),2===++n&&t&&t(l,d)})}const downloaderList={".png":loadImage,".jpg":loadImage,".bmp":loadImage,".jpeg":loadImage,".gif":loadImage,".ico":loadImage,".tiff":loadImage,".webp":loadImage,".image":loadImage,".mp3":loadAudio,".ogg":loadAudio,".wav":loadAudio,".m4a":loadAudio,".txt":loadText,".xml":loadText,".vsh":loadText,".fsh":loadText,".atlas":loadText,".tmx":loadText,".tsx":loadText,".plist":loadText,".fnt":loadText,".json":loadJson,".ExportJson":loadJson,".mp4":loadVideo,".avi":loadVideo,".mov":loadVideo,".mpg":loadVideo,".mpeg":loadVideo,".rm":loadVideo,".rmvb":loadVideo,".binary":loadArrayBuffer,".bin":loadArrayBuffer,".dbbin":loadArrayBuffer,".skel":loadArrayBuffer,".pvr":loadArrayBuffer,".pkm":loadArrayBuffer,".ttf":loadFont,".font":loadFont,".eot":loadFont,".woff":loadFont,".svg":loadFont,".ttc":loadFont,".js":loadScript,bundle:loadBundle,default:loadText};if(cc.assetManager.downloader.loadScript=loadScript,Object.keys(downloaderList).forEach(e=>{cc.assetManager.downloader.register(e,downloaderList[e])}),cc.VideoPlayer){const setURL=cc.VideoPlayer.Impl.prototype.setURL;cc.VideoPlayer.Impl.prototype.setURL=function(e,o){var r=__adapter_get_resource(e);return r?(r=base64ToBlob(r),r=URL.createObjectURL(r),setURL.call(this,r,o)):setURL.call(this,e,o)}}window.boot&&window.boot()};',
    main: '!function(){function base64toArrayBuffer(_){var e=window.atob(_.substring(_.indexOf(",")+1));let a=e.length;for(var n=new Uint8Array(a);a--;)n[a]=e.charCodeAt(a);return n.buffer}function __adapter_eval(_){_&&eval.call(window,_)}function __adapter_unzip(){console.time("load resource");try{var _=base64toArrayBuffer(window.__adapter_zip__),e=pako.inflate(_,{to:"string"});window.__adapter_resource__=JSON.parse(e),__adapter_exec_js()}catch(_){throw console.error(_),_}console.timeEnd("load resource")}function __adapter_init_plugins(){window.__adapter_plugins__&&0!==window.__adapter_plugins__.length&&window.__adapter_plugins__.forEach(_=>{_="src/"+_;window.__adapter_js__[_]?(__adapter_eval(window.__adapter_js__[_]),delete window.__adapter_js__[_]):console.warn("window.__adapter_js__ is not found ",_)})}function __adapter_exec_js(){window.__adapter_js__={};for(const a in window.__adapter_resource__){var _=a.split(".");"js"===_[_.length-1]&&(window.__adapter_js__[a]=window.__adapter_resource__[a])}var e=["src/settings.js","cocos2d-js.js","cocos2d-js-min.js","physics.js","physics-min.js","main.js"];for(let _=0;_<e.length;_++)try{window.__adapter_js__[e[_]]?(__adapter_eval(window.__adapter_js__[e[_]]),delete window.__adapter_js__[e[_]]):console.warn(e[_]+" is not existed")}catch(_){console.error(_)}__adapter_init_plugins(),__adapter_success()}function __adapter_console(){window.__adapter_js__["vconsole.min.js"]&&(eval(window.__adapter_js__["vconsole.min.js"]),delete window.__adapter_js__["vconsole.min.js"],window.VConsole)&&(window.vConsole=new VConsole)}function __adapter_success(){try{__adapter_console();const a=cc.game.run;cc.game.run=function(_,e){_.jsList=[],a.call(cc.game,_,e)},window.__adapter_init&&window.__adapter_init()}catch(_){console.error(_)}}window.pako?__adapter_unzip():__adapter_exec_js()}();'
}, Kl = {
    init: '"use strict";window.__adapter_init=function(){function base64ToBlob(e,t){e=e.split(",");let r=t;2===e.length&&(n=e.shift(),a=new RegExp(":(.*?);"),n=n.match(a),r=(n&&1<n.length?n[1]:t)||t);var a=e.shift(),o=window.atob(a),n=new ArrayBuffer(o.length),_=new Uint8Array(n);for(let e=0;e<o.length;e++)_[e]=o.charCodeAt(e);return new Blob([n],{type:r})}function base64toArrayBuffer(e){var t=window.atob(e.substring(e.indexOf(",")+1));let r=t.length;for(var a=new Uint8Array(r);r--;)a[r]=t.charCodeAt(r);return a.buffer}class AdapterFetch{constructor(){this.response=null,this.status=200,this.responseType="",this.onload=function(){console.log("onload")}}open(e,t){var r=__adapter_get_resource(t);r?this.response=r:console.log("res",r,t)}send(){switch(this.responseType){case"json":this.response=JSON.parse(this.response);break;case"text":this.response=this.response;break;case"arraybuffer":this.response=base64toArrayBuffer(this.response);break;default:this.response=this.response}this.onload()}}function __adapter_eval(name){window.__adapter_js__[name]?(eval(window.__adapter_js__[name]),delete window.__adapter_js__[name]):console.warn("window.__adapter_js__ is not found ",name)}function __adapter_get_base_url(){var e="undefined"!=typeof document;let t;return(t=e&&(e=document.querySelector("base[href]"))?e.href:t)||"undefined"==typeof location||-1!==(e=(t=location.href.split("#")[0].split("?")[0]).lastIndexOf("/"))&&(t=t.slice(0,e+1)),t||""}function __adapter_get_res_path(e,t){if(t[e])return e;for(var r in t){var a=e.indexOf(r);if(-1!==a&&a+r.length===e.length)return r}return null}function __adapter_get_resource(e){return window.__adapter_resource__[__adapter_get_res_path(e,window.__adapter_resource__)]}function __adapter_get_imports(){return JSON.parse(__adapter_get_resource("src/import-map.json")).imports}function __adapter_get_script(e){if(-1!==e.indexOf("bullet.wasm"))for(var t in window.__adapter_js__)if(-1!==t.indexOf("bullet.cocos")){e=t;break}var r=__adapter_get_res_path(e,window.__adapter_js__),a=window.__adapter_js__[r];return a&&delete window.__adapter_js__[r],a}function __adapter_init_http(){window.adapterFetch=AdapterFetch;const a=window.fetch;window.fetch=function(t,e){const r=__adapter_get_resource(t);if(r){let e={ok:!0,status:200,statusText:"OK",headers:{get:function(e){if("content-type"===e){if(-1!==t.indexOf(".json"))return"application/json";if(-1!==t.indexOf(".css"))return"text/css";if(-1!==t.indexOf(".wasm"))return"application/wasm"}return"application/javascript"}},url:t,clone:function(){return e},text:function(){return Promise.resolve(r)},json:function(){return Promise.resolve(JSON.parse(r))},arrayBuffer:function(){return Promise.resolve(base64toArrayBuffer(r))}};return Promise.resolve(e)}return a(t,e)}}function __adapter_init_js(){const r=System.__proto__.createScript;System.__proto__.createScript=function(e){var t=__adapter_get_script(e.replace(__adapter_get_base_url(),""));return t?(t=new Blob([t],{type:"text/javascript"}),r.call(this,URL.createObjectURL(t))):(console.error(e+" 找不到资源"),r.call(this,e))}}function __adapter_init_cc(){if(!window.__adapter_cc_initialized__){if(window.__adapter_cc_initialized__=!0,cc.internal.VideoPlayerImplManager){const getImpl=cc.internal.VideoPlayerImplManager.getImpl;cc.internal.VideoPlayerImplManager.getImpl=function(e){e=getImpl.call(this,e);const r=e.createVideoPlayer;return e.createVideoPlayer=function(e){var t=__adapter_get_resource(e);return t?(t=base64ToBlob(t),t=URL.createObjectURL(t),r.call(this,t)):r.call(this,e)},e}}const downloaderList={".js":loadScript,".font":loadFont,".eot":loadFont,".ttf":loadFont,".woff":loadFont,".svg":loadFont,".ttc":loadFont,".png":loadImage,".jpg":loadImage,".bmp":loadImage,".jpeg":loadImage,".gif":loadImage,".ico":loadImage,".tiff":loadImage,".webp":loadImage,".image":loadImage,".mp4":loadVideo,".avi":loadVideo,".mov":loadVideo,".mpg":loadVideo,".mpeg":loadVideo,".rm":loadVideo,".rmvb":loadVideo,".txt":loadText,".xml":loadText,".vsh":loadText,".fsh":loadText,".atlas":loadText,".tmx":loadText,".tsx":loadText,".plist":loadText,".fnt":loadText,".pvr":loadArrayBuffer,".pkm":loadArrayBuffer,".astc":loadArrayBuffer,".binary":loadArrayBuffer,".bin":loadArrayBuffer,".dbbin":loadArrayBuffer,".skel":loadArrayBuffer,bundle:loadBundle,default:loadText};function loadScript(url,options,onComplete){let scriptStr=__adapter_get_resource(url);scriptStr||console.error(url+" isn\'t load"),eval(scriptStr),onComplete&&onComplete(null)}function loadJson(e,t,r){r(null,JSON.parse(__adapter_get_resource(e)))}function loadBundle(r,e,a){var t=new RegExp("^(?:w+://|.+/).+"),o=cc.path.basename(r),t=(t.test(r)||(r="assets/"+o),e.version||cc.assetManager.downloader.bundleVers[o]);let n=0,_=null,s=null;loadJson(r+`/config.${t?t+".":""}json`,e,function(e,t){e&&(s=e),(_=t)&&(_.base=r+"/"),2===++n&&a&&a(s,_)}),loadScript(r+`/index.${t?t+".":""}js`,e,function(e){e&&(s=e),2===++n&&a&&a(s,_)})}function loadFont(e,t,r){const a=e.split("/").pop().split(".")[0];var o=__adapter_get_resource(e);null==o?r():(o=new FontFace(a,"url("+o+")"),document.fonts.add(o),o.load(),o.loaded.then(function(){r(null,a)},function(){console.error("url("+e+") load fail"),r(null,a)}))}function loadImage(e,t,r){var a=__adapter_get_resource(e);a||console.error(e+" isn\'t load");let o=new Image;const n=function(){o.removeEventListener("load",n),o.removeEventListener("error",_),r&&r(null,o)},_=function(){o.removeEventListener("load",n),o.removeEventListener("error",_),r&&r(new Error(cc.debug.getError(4930,e)))};return o.addEventListener("load",n),o.addEventListener("error",_),o.src=a,o}function loadVideo(e,t,r){var a=document.createElement("video"),o=document.createElement("source"),n=(a.appendChild(o),__adapter_get_resource(e));n?(n=base64ToBlob(n),n=URL.createObjectURL(n),o.src=n,r(null,a)):r(new Error(e+"(no response)"))}function loadText(e,t,r){t.responseType="text",r(null,__adapter_get_resource(e))}function loadArrayBuffer(e,t,r){r(null,base64toArrayBuffer(__adapter_get_resource(e)))}cc.assetManager.downloader.downloadScript=loadScript,Object.keys(downloaderList).forEach(e=>{cc.assetManager.downloader.register(e,downloaderList[e])})}}function __adapter_init_plugins(){window.__adapter_plugins__&&0!==window.__adapter_plugins__.length&&window.__adapter_plugins__.forEach(e=>{__adapter_eval("src/"+e)})}function __adapter_get_path(e){for(var t in window.__adapter_resource__)if(0==t.indexOf(e))return t;throw Error("no find "+e)}__adapter_init_http(),__adapter_eval(__adapter_get_path("src/polyfills.bundle")),__adapter_eval(__adapter_get_path("src/system.bundle")),__adapter_init_js();let prepareLoad=Promise.resolve();const importsKeys=Object.keys(__adapter_get_imports());for(let index=importsKeys.length-1;0<=index;index--){const key=importsKeys[index];prepareLoad=prepareLoad.then(()=>System.import(key))}prepareLoad.then(()=>{__adapter_init_cc(),__adapter_init_plugins(),System.import("./"+__adapter_get_path("index")).catch(e=>{console.error(e)})})};',
    main: '!function(){function base64toArrayBuffer(_){var e=window.atob(_.substring(_.indexOf(",")+1));let o=e.length;for(var a=new Uint8Array(o);o--;)a[o]=e.charCodeAt(o);return a.buffer}function __adapter_unzip(){console.time("load resource");try{var _=base64toArrayBuffer(window.__adapter_zip__),e=pako.inflate(_,{to:"string"});window.__adapter_resource__=JSON.parse(e),__adapter_exec_js()}catch(_){throw console.error(_),_}console.timeEnd("load resource")}function __adapter_exec_js(){window.__adapter_js__={};for(const e in window.__adapter_resource__){var _=e.split(".");"js"===_[_.length-1]&&(window.__adapter_js__[e]=window.__adapter_resource__[e])}__adapter_success()}function __adapter_console(){window.__adapter_js__["vconsole.min.js"]&&(eval(window.__adapter_js__["vconsole.min.js"]),delete window.__adapter_js__["vconsole.min.js"],window.VConsole)&&(window.vConsole=new VConsole)}function __adapter_success(){__adapter_console(),window.__adapter_init&&window.__adapter_init()}window.pako?__adapter_unzip():__adapter_exec_js()}();'
}, Zl = '!function(t,e){"object"==typeof exports&&"undefined"!=typeof module?e(exports):"function"==typeof define&&define.amd?define(["exports"],e):e((t="undefined"!=typeof globalThis?globalThis:t||self).pako={})}(this,function(t){"use strict";function e(t){let e=t.length;for(;0<=--e;)t[e]=0}const S=256,b=15,D=new Uint8Array([0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0]),T=new Uint8Array([0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13]),C=new Uint8Array([0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7]),M=new Uint8Array([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]),h=new Array(576),_=(e(h),new Array(60)),n=(e(_),new Array(512)),l=(e(n),new Array(256)),H=(e(l),new Array(29)),j=(e(H),new Array(30));function K(t,e,a,r,i){this.static_tree=t,this.extra_bits=e,this.extra_base=a,this.elems=r,this.max_length=i,this.has_stree=t&&t.length}let P,Y,X;function G(t,e){this.dyn_tree=t,this.max_code=0,this.stat_desc=e}e(j);const W=t=>t<256?n[t]:n[256+(t>>>7)],i=(t,e)=>{t.pending_buf[t.pending++]=255&e,t.pending_buf[t.pending++]=e>>>8&255},d=(t,e,a)=>{t.bi_valid>16-a?(t.bi_buf|=e<<t.bi_valid&65535,i(t,t.bi_buf),t.bi_buf=e>>16-t.bi_valid,t.bi_valid+=a-16):(t.bi_buf|=e<<t.bi_valid&65535,t.bi_valid+=a)},f=(t,e,a)=>{d(t,a[2*e],a[2*e+1])},q=(t,e)=>{let a=0;for(;a|=1&t,t>>>=1,a<<=1,0<--e;);return a>>>1},J=(t,e,a)=>{var r=new Array(16);let i,s,n=0;for(i=1;i<=b;i++)n=n+a[i-1]<<1,r[i]=n;for(s=0;s<=e;s++){var o=t[2*s+1];0!==o&&(t[2*s]=q(r[o]++,o))}},Q=t=>{let e;for(e=0;e<286;e++)t.dyn_ltree[2*e]=0;for(e=0;e<30;e++)t.dyn_dtree[2*e]=0;for(e=0;e<19;e++)t.bl_tree[2*e]=0;t.dyn_ltree[512]=1,t.opt_len=t.static_len=0,t.sym_next=t.matches=0},V=t=>{8<t.bi_valid?i(t,t.bi_buf):0<t.bi_valid&&(t.pending_buf[t.pending++]=t.bi_buf),t.bi_buf=0,t.bi_valid=0},$=(t,e,a,r)=>{var i=2*e,s=2*a;return t[i]<t[s]||t[i]===t[s]&&r[e]<=r[a]},tt=(t,e,a)=>{var r=t.heap[a];let i=a<<1;for(;i<=t.heap_len&&(i<t.heap_len&&$(e,t.heap[i+1],t.heap[i],t.depth)&&i++,!$(e,r,t.heap[i],t.depth));)t.heap[a]=t.heap[i],a=i,i<<=1;t.heap[a]=r},et=(t,e,a)=>{let r,i,s,n,o=0;if(0!==t.sym_next)for(;r=255&t.pending_buf[t.sym_buf+o++],r+=(255&t.pending_buf[t.sym_buf+o++])<<8,i=t.pending_buf[t.sym_buf+o++],0==r?f(t,i,e):(s=l[i],f(t,s+S+1,e),0!==(n=D[s])&&(i-=H[s],d(t,i,n)),r--,s=W(r),f(t,s,a),0!==(n=T[s])&&(r-=j[s],d(t,r,n))),o<t.sym_next;);f(t,256,e)},at=(o,l)=>{var t=l.dyn_tree,e=l.stat_desc.static_tree,a=l.stat_desc.has_stree,r=l.stat_desc.elems;let i,s,n,h=-1;for(o.heap_len=0,o.heap_max=573,i=0;i<r;i++)0!==t[2*i]?(o.heap[++o.heap_len]=h=i,o.depth[i]=0):t[2*i+1]=0;for(;o.heap_len<2;)t[2*(n=o.heap[++o.heap_len]=h<2?++h:0)]=1,o.depth[n]=0,o.opt_len--,a&&(o.static_len-=e[2*n+1]);for(l.max_code=h,i=o.heap_len>>1;1<=i;i--)tt(o,t,i);for(n=r;i=o.heap[1],o.heap[1]=o.heap[o.heap_len--],tt(o,t,1),s=o.heap[1],o.heap[--o.heap_max]=i,o.heap[--o.heap_max]=s,t[2*n]=t[2*i]+t[2*s],o.depth[n]=(o.depth[i]>=o.depth[s]?o.depth[i]:o.depth[s])+1,t[2*i+1]=t[2*s+1]=n,o.heap[1]=n++,tt(o,t,1),2<=o.heap_len;);o.heap[--o.heap_max]=o.heap[1];{var _=o,d=l.dyn_tree,f=l.max_code,u=l.stat_desc.static_tree,c=l.stat_desc.has_stree,w=l.stat_desc.extra_bits,m=l.stat_desc.extra_base,g=l.stat_desc.max_length;let t,e,a,r,i,s,n=0;for(r=0;r<=b;r++)_.bl_count[r]=0;for(d[2*_.heap[_.heap_max]+1]=0,t=_.heap_max+1;t<573;t++)e=_.heap[t],(r=d[2*d[2*e+1]+1]+1)>g&&(r=g,n++),d[2*e+1]=r,e>f||(_.bl_count[r]++,i=0,e>=m&&(i=w[e-m]),s=d[2*e],_.opt_len+=s*(r+i),c&&(_.static_len+=s*(u[2*e+1]+i)));if(0!==n){do{for(r=g-1;0===_.bl_count[r];)r--}while(_.bl_count[r]--,_.bl_count[r+1]+=2,_.bl_count[g]--,0<(n-=2));for(r=g;0!==r;r--)for(e=_.bl_count[r];0!==e;)f<(a=_.heap[--t])||(d[2*a+1]!==r&&(_.opt_len+=(r-d[2*a+1])*d[2*a],d[2*a+1]=r),e--)}}J(t,h,o.bl_count)},rt=(t,e,a)=>{let r,i,s=-1,n=e[1],o=0,l=7,h=4;for(0===n&&(l=138,h=3),e[2*(a+1)+1]=65535,r=0;r<=a;r++)i=n,n=e[2*(r+1)+1],++o<l&&i===n||(o<h?t.bl_tree[2*i]+=o:0!==i?(i!==s&&t.bl_tree[2*i]++,t.bl_tree[32]++):o<=10?t.bl_tree[34]++:t.bl_tree[36]++,o=0,s=i,h=0===n?(l=138,3):i===n?(l=6,3):(l=7,4))},it=(t,e,a)=>{let r,i,s=-1,n=e[1],o=0,l=7,h=4;for(0===n&&(l=138,h=3),r=0;r<=a;r++)if(i=n,n=e[2*(r+1)+1],!(++o<l&&i===n)){if(o<h)for(;f(t,i,t.bl_tree),0!=--o;);else 0!==i?(i!==s&&(f(t,i,t.bl_tree),o--),f(t,16,t.bl_tree),d(t,o-3,2)):o<=10?(f(t,17,t.bl_tree),d(t,o-3,3)):(f(t,18,t.bl_tree),d(t,o-11,7));o=0,s=i,h=0===n?(l=138,3):i===n?(l=6,3):(l=7,4)}};let st=!1;const nt=(t,e,a,r)=>{d(t,0+(r?1:0),3),V(t),i(t,a),i(t,~a),a&&t.pending_buf.set(t.window.subarray(e,e+a),t.pending),t.pending+=a};var ot={_tr_init:t=>{if(!st){{let t,e,a,r,i;var s=new Array(16);for(a=0,r=0;r<28;r++)for(H[r]=a,t=0;t<1<<D[r];t++)l[a++]=r;for(l[a-1]=r,i=0,r=0;r<16;r++)for(j[r]=i,t=0;t<1<<T[r];t++)n[i++]=r;for(i>>=7;r<30;r++)for(j[r]=i<<7,t=0;t<1<<T[r]-7;t++)n[256+i++]=r;for(e=0;e<=b;e++)s[e]=0;for(t=0;t<=143;)h[2*t+1]=8,t++,s[8]++;for(;t<=255;)h[2*t+1]=9,t++,s[9]++;for(;t<=279;)h[2*t+1]=7,t++,s[7]++;for(;t<=287;)h[2*t+1]=8,t++,s[8]++;for(J(h,287,s),t=0;t<30;t++)_[2*t+1]=5,_[2*t]=q(t,5);P=new K(h,D,257,286,b),Y=new K(_,T,0,30,b),X=new K(new Array(0),C,0,19,7)}st=!0}t.l_desc=new G(t.dyn_ltree,P),t.d_desc=new G(t.dyn_dtree,Y),t.bl_desc=new G(t.bl_tree,X),t.bi_buf=0,t.bi_valid=0,Q(t)},_tr_stored_block:nt,_tr_flush_block:(e,a,r,t)=>{let i,s,n=0;if(0<e.level?(2===e.strm.data_type&&(e.strm.data_type=(t=>{let e,a=4093624447;for(e=0;e<=31;e++,a>>>=1)if(1&a&&0!==t.dyn_ltree[2*e])return 0;if(0!==t.dyn_ltree[18]||0!==t.dyn_ltree[20]||0!==t.dyn_ltree[26])return 1;for(e=32;e<S;e++)if(0!==t.dyn_ltree[2*e])return 1;return 0})(e)),at(e,e.l_desc),at(e,e.d_desc),n=(t=>{let e;for(rt(t,t.dyn_ltree,t.l_desc.max_code),rt(t,t.dyn_dtree,t.d_desc.max_code),at(t,t.bl_desc),e=18;3<=e&&0===t.bl_tree[2*M[e]+1];e--);return t.opt_len+=3*(e+1)+5+5+4,e})(e),i=e.opt_len+3+7>>>3,(s=e.static_len+3+7>>>3)<=i&&(i=s)):i=s=r+5,r+4<=i&&-1!==a)nt(e,a,r,t);else if(4===e.strategy||s===i)d(e,2+(t?1:0),3),et(e,h,_);else{d(e,4+(t?1:0),3);{var o=e,l=(a=e.l_desc.max_code+1,r=e.d_desc.max_code+1,n+1);let t;for(d(o,a-257,5),d(o,r-1,5),d(o,l-4,4),t=0;t<l;t++)d(o,o.bl_tree[2*M[t]+1],3);it(o,o.dyn_ltree,a-1),it(o,o.dyn_dtree,r-1)}et(e,e.dyn_ltree,e.dyn_dtree)}Q(e),t&&V(e)},_tr_tally:(t,e,a)=>(t.pending_buf[t.sym_buf+t.sym_next++]=e,t.pending_buf[t.sym_buf+t.sym_next++]=e>>8,t.pending_buf[t.sym_buf+t.sym_next++]=a,0===e?t.dyn_ltree[2*a]++:(t.matches++,e--,t.dyn_ltree[2*(l[a]+S+1)]++,t.dyn_dtree[2*W(e)]++),t.sym_next===t.sym_end),_tr_align:t=>{d(t,2,3),f(t,256,h),16===(t=t).bi_valid?(i(t,t.bi_buf),t.bi_buf=0,t.bi_valid=0):8<=t.bi_valid&&(t.pending_buf[t.pending++]=255&t.bi_buf,t.bi_buf>>=8,t.bi_valid-=8)}},lt=(t,e,a,r)=>{let i=65535&t|0,s=t>>>16&65535|0,n=0;for(;0!==a;){for(a-=n=2e3<a?2e3:a;i=i+e[r++]|0,s=s+i|0,--n;);i%=65521,s%=65521}return i|s<<16|0};const ht=new Uint32Array((()=>{let t,e=[];for(var a=0;a<256;a++){t=a;for(var r=0;r<8;r++)t=1&t?3988292384^t>>>1:t>>>1;e[a]=t}return e})());var O=(e,a,t,r)=>{var i=ht,s=r+t;e^=-1;for(let t=r;t<s;t++)e=e>>>8^i[255&(e^a[t])];return-1^e},r={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"},a={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_MEM_ERROR:-4,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8};const{_tr_init:_t,_tr_stored_block:dt,_tr_flush_block:ft,_tr_tally:o,_tr_align:ut}=ot,{Z_NO_FLUSH:u,Z_PARTIAL_FLUSH:ct,Z_FULL_FLUSH:wt,Z_FINISH:c,Z_BLOCK:mt,Z_OK:w,Z_STREAM_END:gt,Z_STREAM_ERROR:m,Z_DATA_ERROR:bt,Z_BUF_ERROR:pt,Z_DEFAULT_COMPRESSION:vt,Z_FILTERED:kt,Z_HUFFMAN_ONLY:yt,Z_RLE:xt,Z_FIXED:zt,Z_UNKNOWN:At,Z_DEFLATED:Et}=a,g=258,p=262,v=42,k=113,Rt=666,y=(t,e)=>(t.msg=r[e],e),Zt=t=>2*t-(4<t?9:0),x=t=>{let e=t.length;for(;0<=--e;)t[e]=0},Ut=t=>{let e,a,r,i=t.w_size;for(e=t.hash_size,r=e;a=t.head[--r],t.head[r]=a>=i?a-i:0,--e;);for(e=i,r=e;a=t.prev[--r],t.prev[r]=a>=i?a-i:0,--e;);};let z=(t,e,a)=>(e<<t.hash_shift^a)&t.hash_mask;const A=t=>{var e=t.state;let a=e.pending;0!==(a=a>t.avail_out?t.avail_out:a)&&(t.output.set(e.pending_buf.subarray(e.pending_out,e.pending_out+a),t.next_out),t.next_out+=a,e.pending_out+=a,t.total_out+=a,t.avail_out-=a,e.pending-=a,0===e.pending)&&(e.pending_out=0)},E=(t,e)=>{ft(t,0<=t.block_start?t.block_start:-1,t.strstart-t.block_start,e),t.block_start=t.strstart,A(t.strm)},R=(t,e)=>{t.pending_buf[t.pending++]=e},St=(t,e)=>{t.pending_buf[t.pending++]=e>>>8&255,t.pending_buf[t.pending++]=255&e},Dt=(t,e,a,r)=>{let i=t.avail_in;return 0===(i=i>r?r:i)?0:(t.avail_in-=i,e.set(t.input.subarray(t.next_in,t.next_in+i),a),1===t.state.wrap?t.adler=lt(t.adler,e,i,a):2===t.state.wrap&&(t.adler=O(t.adler,e,i,a)),t.next_in+=i,t.total_in+=i,i)},Tt=(t,e)=>{let a,r,i=t.max_chain_length,s=t.strstart,n=t.prev_length,o=t.nice_match;var l=t.strstart>t.w_size-p?t.strstart-(t.w_size-p):0,h=t.window,_=t.w_mask,d=t.prev,f=t.strstart+g;let u=h[s+n-1],c=h[s+n];t.prev_length>=t.good_match&&(i>>=2),o>t.lookahead&&(o=t.lookahead);do{if(h[(a=e)+n]===c&&h[a+n-1]===u&&h[a]===h[s]&&h[++a]===h[s+1]){for(s+=2,a++;h[++s]===h[++a]&&h[++s]===h[++a]&&h[++s]===h[++a]&&h[++s]===h[++a]&&h[++s]===h[++a]&&h[++s]===h[++a]&&h[++s]===h[++a]&&h[++s]===h[++a]&&s<f;);if(r=g-(f-s),s=f-g,r>n){if(t.match_start=e,(n=r)>=o)break;u=h[s+n-1],c=h[s+n]}}}while((e=d[e&_])>l&&0!=--i);return n<=t.lookahead?n:t.lookahead},Z=t=>{var e=t.w_size;let a,r,i;do{if(r=t.window_size-t.lookahead-t.strstart,t.strstart>=e+(e-p)&&(t.window.set(t.window.subarray(e,e+e-r),0),t.match_start-=e,t.strstart-=e,t.block_start-=e,t.insert>t.strstart&&(t.insert=t.strstart),Ut(t),r+=e),0===t.strm.avail_in)break;if(a=Dt(t.strm,t.window,t.strstart+t.lookahead,r),t.lookahead+=a,3<=t.lookahead+t.insert)for(i=t.strstart-t.insert,t.ins_h=t.window[i],t.ins_h=z(t,t.ins_h,t.window[i+1]);t.insert&&(t.ins_h=z(t,t.ins_h,t.window[i+3-1]),t.prev[i&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=i,i++,t.insert--,!(t.lookahead+t.insert<3)););}while(t.lookahead<p&&0!==t.strm.avail_in)},Ot=(t,e)=>{let a,r,i,s=t.pending_buf_size-5>t.w_size?t.w_size:t.pending_buf_size-5,n=0,o=t.strm.avail_in;for(;a=65535,i=t.bi_valid+42>>3,!(t.strm.avail_out<i||(i=t.strm.avail_out-i,r=t.strstart-t.block_start,(a=(a=a>r+t.strm.avail_in?r+t.strm.avail_in:a)>i?i:a)<s&&(0===a&&e!==c||e===u||a!==r+t.strm.avail_in))||(n=e===c&&a===r+t.strm.avail_in?1:0,dt(t,0,0,n),t.pending_buf[t.pending-4]=a,t.pending_buf[t.pending-3]=a>>8,t.pending_buf[t.pending-2]=~a,t.pending_buf[t.pending-1]=~a>>8,A(t.strm),r&&(r>a&&(r=a),t.strm.output.set(t.window.subarray(t.block_start,t.block_start+r),t.strm.next_out),t.strm.next_out+=r,t.strm.avail_out-=r,t.strm.total_out+=r,t.block_start+=r,a-=r),a&&(Dt(t.strm,t.strm.output,t.strm.next_out,a),t.strm.next_out+=a,t.strm.avail_out-=a,t.strm.total_out+=a),0!==n)););return(o-=t.strm.avail_in)&&(o>=t.w_size?(t.matches=2,t.window.set(t.strm.input.subarray(t.strm.next_in-t.w_size,t.strm.next_in),0),t.strstart=t.w_size,t.insert=t.strstart):(t.window_size-t.strstart<=o&&(t.strstart-=t.w_size,t.window.set(t.window.subarray(t.w_size,t.w_size+t.strstart),0),t.matches<2&&t.matches++,t.insert>t.strstart)&&(t.insert=t.strstart),t.window.set(t.strm.input.subarray(t.strm.next_in-o,t.strm.next_in),t.strstart),t.strstart+=o,t.insert+=o>t.w_size-t.insert?t.w_size-t.insert:o),t.block_start=t.strstart),t.high_water<t.strstart&&(t.high_water=t.strstart),n?4:e!==u&&e!==c&&0===t.strm.avail_in&&t.strstart===t.block_start?2:(i=t.window_size-t.strstart,t.strm.avail_in>i&&t.block_start>=t.w_size&&(t.block_start-=t.w_size,t.strstart-=t.w_size,t.window.set(t.window.subarray(t.w_size,t.w_size+t.strstart),0),t.matches<2&&t.matches++,i+=t.w_size,t.insert>t.strstart)&&(t.insert=t.strstart),(i=i>t.strm.avail_in?t.strm.avail_in:i)&&(Dt(t.strm,t.window,t.strstart,i),t.strstart+=i,t.insert+=i>t.w_size-t.insert?t.w_size-t.insert:i),t.high_water<t.strstart&&(t.high_water=t.strstart),i=t.bi_valid+42>>3,i=65535<t.pending_buf_size-i?65535:t.pending_buf_size-i,s=i>t.w_size?t.w_size:i,((r=t.strstart-t.block_start)>=s||(r||e===c)&&e!==u&&0===t.strm.avail_in&&r<=i)&&(a=r>i?i:r,n=e===c&&0===t.strm.avail_in&&a===r?1:0,dt(t,t.block_start,a,n),t.block_start+=a,A(t.strm)),n?3:1)},Ft=(t,e)=>{let a,r;for(;;){if(t.lookahead<p){if(Z(t),t.lookahead<p&&e===u)return 1;if(0===t.lookahead)break}if(a=0,3<=t.lookahead&&(t.ins_h=z(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart),0!==a&&t.strstart-a<=t.w_size-p&&(t.match_length=Tt(t,a)),3<=t.match_length)if(r=o(t,t.strstart-t.match_start,t.match_length-3),t.lookahead-=t.match_length,t.match_length<=t.max_lazy_match&&3<=t.lookahead){for(t.match_length--;t.strstart++,t.ins_h=z(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart,0!=--t.match_length;);t.strstart++}else t.strstart+=t.match_length,t.match_length=0,t.ins_h=t.window[t.strstart],t.ins_h=z(t,t.ins_h,t.window[t.strstart+1]);else r=o(t,0,t.window[t.strstart]),t.lookahead--,t.strstart++;if(r&&(E(t,!1),0===t.strm.avail_out))return 1}return t.insert=t.strstart<2?t.strstart:2,e===c?(E(t,!0),0===t.strm.avail_out?3:4):t.sym_next&&(E(t,!1),0===t.strm.avail_out)?1:2},s=(t,e)=>{let a,r,i;for(;;){if(t.lookahead<p){if(Z(t),t.lookahead<p&&e===u)return 1;if(0===t.lookahead)break}if(a=0,3<=t.lookahead&&(t.ins_h=z(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart),t.prev_length=t.match_length,t.prev_match=t.match_start,t.match_length=2,0!==a&&t.prev_length<t.max_lazy_match&&t.strstart-a<=t.w_size-p&&(t.match_length=Tt(t,a),t.match_length<=5)&&(t.strategy===kt||3===t.match_length&&4096<t.strstart-t.match_start)&&(t.match_length=2),3<=t.prev_length&&t.match_length<=t.prev_length){for(i=t.strstart+t.lookahead-3,r=o(t,t.strstart-1-t.prev_match,t.prev_length-3),t.lookahead-=t.prev_length-1,t.prev_length-=2;++t.strstart<=i&&(t.ins_h=z(t,t.ins_h,t.window[t.strstart+3-1]),a=t.prev[t.strstart&t.w_mask]=t.head[t.ins_h],t.head[t.ins_h]=t.strstart),0!=--t.prev_length;);if(t.match_available=0,t.match_length=2,t.strstart++,r&&(E(t,!1),0===t.strm.avail_out))return 1}else if(t.match_available){if((r=o(t,0,t.window[t.strstart-1]))&&E(t,!1),t.strstart++,t.lookahead--,0===t.strm.avail_out)return 1}else t.match_available=1,t.strstart++,t.lookahead--}return t.match_available&&(r=o(t,0,t.window[t.strstart-1]),t.match_available=0),t.insert=t.strstart<2?t.strstart:2,e===c?(E(t,!0),0===t.strm.avail_out?3:4):t.sym_next&&(E(t,!1),0===t.strm.avail_out)?1:2};function U(t,e,a,r,i){this.good_length=t,this.max_lazy=e,this.nice_length=a,this.max_chain=r,this.func=i}const Lt=[new U(0,0,0,0,Ot),new U(4,4,8,4,Ft),new U(4,5,16,8,Ft),new U(4,6,32,32,Ft),new U(4,4,16,16,s),new U(8,16,32,32,s),new U(8,16,128,128,s),new U(8,32,128,256,s),new U(32,128,258,1024,s),new U(32,258,258,4096,s)];function Bt(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=Et,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new Uint16Array(1146),this.dyn_dtree=new Uint16Array(122),this.bl_tree=new Uint16Array(78),x(this.dyn_ltree),x(this.dyn_dtree),x(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new Uint16Array(16),this.heap=new Uint16Array(573),x(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new Uint16Array(573),x(this.depth),this.sym_buf=0,this.lit_bufsize=0,this.sym_next=0,this.sym_end=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}const Nt=t=>{var e;return!t||!(e=t.state)||e.strm!==t||e.status!==v&&57!==e.status&&69!==e.status&&73!==e.status&&91!==e.status&&103!==e.status&&e.status!==k&&e.status!==Rt?1:0},It=t=>{if(Nt(t))return y(t,m);t.total_in=t.total_out=0,t.data_type=At;var e=t.state;return e.pending=0,e.pending_out=0,e.wrap<0&&(e.wrap=-e.wrap),e.status=2===e.wrap?57:e.wrap?v:k,t.adler=2===e.wrap?0:1,e.last_flush=-2,_t(e),w},Ct=t=>{var e=It(t);return e===w&&((t=t.state).window_size=2*t.w_size,x(t.head),t.max_lazy_match=Lt[t.level].max_lazy,t.good_match=Lt[t.level].good_length,t.nice_match=Lt[t.level].nice_length,t.max_chain_length=Lt[t.level].max_chain,t.strstart=0,t.block_start=0,t.lookahead=0,t.insert=0,t.match_length=t.prev_length=2,t.match_available=0,t.ins_h=0),e},Mt=(t,e,a,r,i,s)=>{if(!t)return m;let n=1;if(e===vt&&(e=6),r<0?(n=0,r=-r):15<r&&(n=2,r-=16),i<1||9<i||a!==Et||r<8||15<r||e<0||9<e||s<0||s>zt||8===r&&1!==n)return y(t,m);8===r&&(r=9);var o=new Bt;return(t.state=o).strm=t,o.status=v,o.wrap=n,o.gzhead=null,o.w_bits=r,o.w_size=1<<o.w_bits,o.w_mask=o.w_size-1,o.hash_bits=i+7,o.hash_size=1<<o.hash_bits,o.hash_mask=o.hash_size-1,o.hash_shift=~~((o.hash_bits+3-1)/3),o.window=new Uint8Array(2*o.w_size),o.head=new Uint16Array(o.hash_size),o.prev=new Uint16Array(o.w_size),o.lit_bufsize=1<<i+6,o.pending_buf_size=4*o.lit_bufsize,o.pending_buf=new Uint8Array(o.pending_buf_size),o.sym_buf=o.lit_bufsize,o.sym_end=3*(o.lit_bufsize-1),o.level=e,o.strategy=s,o.method=a,Ct(t)};var Ht=Mt,jt=(Ct,It,(t,e)=>Nt(t)||2!==t.state.wrap?m:(t.state.gzhead=e,w)),Kt=(a,t)=>{if(Nt(a)||t>mt||t<0)return a?y(a,m):m;var r=a.state;if(!a.output||0!==a.avail_in&&!a.input||r.status===Rt&&t!==c)return y(a,0===a.avail_out?pt:m);var i=r.last_flush;if(r.last_flush=t,0!==r.pending){if(A(a),0===a.avail_out)return r.last_flush=-1,w}else if(0===a.avail_in&&Zt(t)<=Zt(i)&&t!==c)return y(a,pt);if(r.status===Rt&&0!==a.avail_in)return y(a,pt);if(r.status===v&&0===r.wrap&&(r.status=k),r.status===v){let t=Et+(r.w_bits-8<<4)<<8,e;if(e=r.strategy>=yt||r.level<2?0:r.level<6?1:6===r.level?2:3,t|=e<<6,0!==r.strstart&&(t|=32),t+=31-t%31,St(r,t),0!==r.strstart&&(St(r,a.adler>>>16),St(r,65535&a.adler)),a.adler=1,r.status=k,A(a),0!==r.pending)return r.last_flush=-1,w}if(57===r.status)if(a.adler=0,R(r,31),R(r,139),R(r,8),r.gzhead)R(r,(r.gzhead.text?1:0)+(r.gzhead.hcrc?2:0)+(r.gzhead.extra?4:0)+(r.gzhead.name?8:0)+(r.gzhead.comment?16:0)),R(r,255&r.gzhead.time),R(r,r.gzhead.time>>8&255),R(r,r.gzhead.time>>16&255),R(r,r.gzhead.time>>24&255),R(r,9===r.level?2:r.strategy>=yt||r.level<2?4:0),R(r,255&r.gzhead.os),r.gzhead.extra&&r.gzhead.extra.length&&(R(r,255&r.gzhead.extra.length),R(r,r.gzhead.extra.length>>8&255)),r.gzhead.hcrc&&(a.adler=O(a.adler,r.pending_buf,r.pending,0)),r.gzindex=0,r.status=69;else if(R(r,0),R(r,0),R(r,0),R(r,0),R(r,0),R(r,9===r.level?2:r.strategy>=yt||r.level<2?4:0),R(r,3),r.status=k,A(a),0!==r.pending)return r.last_flush=-1,w;if(69===r.status){if(r.gzhead.extra){let t=r.pending,e=(65535&r.gzhead.extra.length)-r.gzindex;for(;r.pending+e>r.pending_buf_size;){var s=r.pending_buf_size-r.pending;if(r.pending_buf.set(r.gzhead.extra.subarray(r.gzindex,r.gzindex+s),r.pending),r.pending=r.pending_buf_size,r.gzhead.hcrc&&r.pending>t&&(a.adler=O(a.adler,r.pending_buf,r.pending-t,t)),r.gzindex+=s,A(a),0!==r.pending)return r.last_flush=-1,w;t=0,e-=s}i=new Uint8Array(r.gzhead.extra);r.pending_buf.set(i.subarray(r.gzindex,r.gzindex+e),r.pending),r.pending+=e,r.gzhead.hcrc&&r.pending>t&&(a.adler=O(a.adler,r.pending_buf,r.pending-t,t)),r.gzindex=0}r.status=73}if(73===r.status){if(r.gzhead.name){let t,e=r.pending;do{if(r.pending===r.pending_buf_size){if(r.gzhead.hcrc&&r.pending>e&&(a.adler=O(a.adler,r.pending_buf,r.pending-e,e)),A(a),0!==r.pending)return r.last_flush=-1,w;e=0}}while(t=r.gzindex<r.gzhead.name.length?255&r.gzhead.name.charCodeAt(r.gzindex++):0,R(r,t),0!=t);r.gzhead.hcrc&&r.pending>e&&(a.adler=O(a.adler,r.pending_buf,r.pending-e,e)),r.gzindex=0}r.status=91}if(91===r.status){if(r.gzhead.comment){let t,e=r.pending;do{if(r.pending===r.pending_buf_size){if(r.gzhead.hcrc&&r.pending>e&&(a.adler=O(a.adler,r.pending_buf,r.pending-e,e)),A(a),0!==r.pending)return r.last_flush=-1,w;e=0}}while(t=r.gzindex<r.gzhead.comment.length?255&r.gzhead.comment.charCodeAt(r.gzindex++):0,R(r,t),0!=t);r.gzhead.hcrc&&r.pending>e&&(a.adler=O(a.adler,r.pending_buf,r.pending-e,e))}r.status=103}if(103===r.status){if(r.gzhead.hcrc){if(r.pending+2>r.pending_buf_size&&(A(a),0!==r.pending))return r.last_flush=-1,w;R(r,255&a.adler),R(r,a.adler>>8&255),a.adler=0}if(r.status=k,A(a),0!==r.pending)return r.last_flush=-1,w}if(0!==a.avail_in||0!==r.lookahead||t!==u&&r.status!==Rt){i=0===r.level?Ot(r,t):r.strategy===yt?((t,e)=>{for(var a;;){if(0===t.lookahead&&(Z(t),0===t.lookahead)){if(e===u)return 1;break}if(t.match_length=0,a=o(t,0,t.window[t.strstart]),t.lookahead--,t.strstart++,a&&(E(t,!1),0===t.strm.avail_out))return 1}return t.insert=0,e===c?(E(t,!0),0===t.strm.avail_out?3:4):t.sym_next&&(E(t,!1),0===t.strm.avail_out)?1:2})(r,t):r.strategy===xt?((t,e)=>{let a,r,i,s;for(var n=t.window;;){if(t.lookahead<=g){if(Z(t),t.lookahead<=g&&e===u)return 1;if(0===t.lookahead)break}if(t.match_length=0,3<=t.lookahead&&0<t.strstart&&(i=t.strstart-1,(r=n[i])===n[++i])&&r===n[++i]&&r===n[++i]){for(s=t.strstart+g;r===n[++i]&&r===n[++i]&&r===n[++i]&&r===n[++i]&&r===n[++i]&&r===n[++i]&&r===n[++i]&&r===n[++i]&&i<s;);t.match_length=g-(s-i),t.match_length>t.lookahead&&(t.match_length=t.lookahead)}if(3<=t.match_length?(a=o(t,1,t.match_length-3),t.lookahead-=t.match_length,t.strstart+=t.match_length,t.match_length=0):(a=o(t,0,t.window[t.strstart]),t.lookahead--,t.strstart++),a&&(E(t,!1),0===t.strm.avail_out))return 1}return t.insert=0,e===c?(E(t,!0),0===t.strm.avail_out?3:4):t.sym_next&&(E(t,!1),0===t.strm.avail_out)?1:2})(r,t):Lt[r.level].func(r,t);if(3!==i&&4!==i||(r.status=Rt),1===i||3===i)return 0===a.avail_out&&(r.last_flush=-1),w;if(2===i&&(t===ct?ut(r):t!==mt&&(dt(r,0,0,!1),t===wt)&&(x(r.head),0===r.lookahead)&&(r.strstart=0,r.block_start=0,r.insert=0),A(a),0===a.avail_out))return r.last_flush=-1,w}return t!==c||!(r.wrap<=0)&&(2===r.wrap?(R(r,255&a.adler),R(r,a.adler>>8&255),R(r,a.adler>>16&255),R(r,a.adler>>24&255),R(r,255&a.total_in),R(r,a.total_in>>8&255),R(r,a.total_in>>16&255),R(r,a.total_in>>24&255)):(St(r,a.adler>>>16),St(r,65535&a.adler)),A(a),0<r.wrap&&(r.wrap=-r.wrap),0!==r.pending)?w:gt},Pt=t=>{var e;return Nt(t)?m:(e=t.state.status,t.state=null,e===k?y(t,bt):w)},Yt=(t,e)=>{let a=e.length;if(Nt(t))return m;var r=t.state,i=r.wrap;if(2===i||1===i&&r.status!==v||r.lookahead)return m;1===i&&(t.adler=lt(t.adler,e,a,0)),r.wrap=0,a>=r.w_size&&(0===i&&(x(r.head),r.strstart=0,r.block_start=0,r.insert=0),(s=new Uint8Array(r.w_size)).set(e.subarray(a-r.w_size,a),0),e=s,a=r.w_size);var s=t.avail_in,n=t.next_in,o=t.input;for(t.avail_in=a,t.next_in=0,t.input=e,Z(r);3<=r.lookahead;){let t=r.strstart,e=r.lookahead-2;for(;r.ins_h=z(r,r.ins_h,r.window[t+3-1]),r.prev[t&r.w_mask]=r.head[r.ins_h],r.head[r.ins_h]=t,t++,--e;);r.strstart=t,r.lookahead=2,Z(r)}return r.strstart+=r.lookahead,r.block_start=r.strstart,r.insert=r.lookahead,r.lookahead=0,r.match_length=r.prev_length=2,r.match_available=0,t.next_in=n,t.input=o,t.avail_in=s,r.wrap=i,w};const Xt=(t,e)=>Object.prototype.hasOwnProperty.call(t,e);function Gt(t){const e=Array.prototype.slice.call(arguments,1);for(;e.length;){var a=e.shift();if(a){if("object"!=typeof a)throw new TypeError(a+"must be non-object");for(const e in a)Xt(a,e)&&(t[e]=a[e])}}return t}var Wt=r=>{let a=0;for(let t=0,e=r.length;t<e;t++)a+=r[t].length;var i=new Uint8Array(a);for(let t=0,e=0,a=r.length;t<a;t++){var s=r[t];i.set(s,e),e+=s.length}return i};let qt=!0;try{String.fromCharCode.apply(null,new Uint8Array(1))}catch(t){qt=!1}const Jt=new Uint8Array(256);for(let t=0;t<256;t++)Jt[t]=252<=t?6:248<=t?5:240<=t?4:224<=t?3:192<=t?2:1;Jt[254]=Jt[254]=1;function Qt(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}var Vt=t=>{if("function"==typeof TextEncoder&&TextEncoder.prototype.encode)return(new TextEncoder).encode(t);let e,a,r,i,s,n=t.length,o=0;for(i=0;i<n;i++)55296==(64512&(a=t.charCodeAt(i)))&&i+1<n&&56320==(64512&(r=t.charCodeAt(i+1)))&&(a=65536+(a-55296<<10)+(r-56320),i++),o+=a<128?1:a<2048?2:a<65536?3:4;for(e=new Uint8Array(o),s=0,i=0;s<o;i++)55296==(64512&(a=t.charCodeAt(i)))&&i+1<n&&56320==(64512&(r=t.charCodeAt(i+1)))&&(a=65536+(a-55296<<10)+(r-56320),i++),a<128?e[s++]=a:(a<2048?e[s++]=192|a>>>6:(a<65536?e[s++]=224|a>>>12:(e[s++]=240|a>>>18,e[s++]=128|a>>>12&63),e[s++]=128|a>>>6&63),e[s++]=128|63&a);return e};const $t=Object.prototype.toString,{Z_NO_FLUSH:te,Z_SYNC_FLUSH:ee,Z_FULL_FLUSH:ae,Z_FINISH:re,Z_OK:ie,Z_STREAM_END:se,Z_DEFAULT_COMPRESSION:ne,Z_DEFAULT_STRATEGY:oe,Z_DEFLATED:le}=a;function he(t){this.options=Gt({level:ne,method:le,chunkSize:16384,windowBits:15,memLevel:8,strategy:oe},t||{});t=this.options;if(t.raw&&0<t.windowBits?t.windowBits=-t.windowBits:t.gzip&&0<t.windowBits&&t.windowBits<16&&(t.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new Qt,this.strm.avail_out=0,(e=Ht(this.strm,t.level,t.method,t.windowBits,t.memLevel,t.strategy))!==ie)throw new Error(r[e]);if(t.header&&jt(this.strm,t.header),t.dictionary){var e,t="string"==typeof t.dictionary?Vt(t.dictionary):"[object ArrayBuffer]"===$t.call(t.dictionary)?new Uint8Array(t.dictionary):t.dictionary;if((e=Yt(this.strm,t))!==ie)throw new Error(r[e]);this._dict_set=!0}}function _e(t,e){e=new he(e);if(e.push(t,!0),e.err)throw e.msg||r[e.err];return e.result}he.prototype.push=function(t,e){var a,r,i=this.strm,s=this.options.chunkSize;if(this.ended)return!1;for(r=e===~~e?e:!0===e?re:te,"string"==typeof t?i.input=Vt(t):"[object ArrayBuffer]"===$t.call(t)?i.input=new Uint8Array(t):i.input=t,i.next_in=0,i.avail_in=i.input.length;;)if(0===i.avail_out&&(i.output=new Uint8Array(s),i.next_out=0,i.avail_out=s),(r===ee||r===ae)&&i.avail_out<=6)this.onData(i.output.subarray(0,i.next_out)),i.avail_out=0;else{if(Kt(i,r)===se)return 0<i.next_out&&this.onData(i.output.subarray(0,i.next_out)),a=Pt(this.strm),this.onEnd(a),this.ended=!0,a===ie;if(0!==i.avail_out){if(0<r&&0<i.next_out)this.onData(i.output.subarray(0,i.next_out)),i.avail_out=0;else if(0===i.avail_in)break}else this.onData(i.output)}return!0},he.prototype.onData=function(t){this.chunks.push(t)},he.prototype.onEnd=function(t){t===ie&&(this.result=Wt(this.chunks)),this.chunks=[],this.err=t,this.msg=this.strm.msg};ot={Deflate:he,deflate:_e,deflateRaw:function(t,e){return(e=e||{}).raw=!0,_e(t,e)},gzip:function(t,e){return(e=e||{}).gzip=!0,_e(t,e)},constants:a};const de=16209;const fe=15,ue=new Uint16Array([3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0]),ce=new Uint8Array([16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78]),we=new Uint16Array([1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0]),me=new Uint8Array([16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64]);var ge=(t,e,a,r,i,s,n,o)=>{var l=o.bits;let h,_,d,f,u,c,w=0,m=0,g=0,b=0,p=0,v=0,k=0,y=0,x=0,z=0,A=null;var E=new Uint16Array(16),R=new Uint16Array(16);let Z,U,S,D=null;for(w=0;w<=fe;w++)E[w]=0;for(m=0;m<r;m++)E[e[a+m]]++;for(p=l,b=fe;1<=b&&0===E[b];b--);if(p>b&&(p=b),0===b)i[s++]=20971520,i[s++]=20971520,o.bits=1;else{for(g=1;g<b&&0===E[g];g++);for(p<g&&(p=g),y=1,w=1;w<=fe;w++)if((y=(y<<=1)-E[w])<0)return-1;if(0<y&&(0===t||1!==b))return-1;for(R[1]=0,w=1;w<fe;w++)R[w+1]=R[w]+E[w];for(m=0;m<r;m++)0!==e[a+m]&&(n[R[e[a+m]]++]=m);if(c=0===t?(A=D=n,20):1===t?(A=ue,D=ce,257):(A=we,D=me,0),z=0,m=0,w=g,u=s,v=p,k=0,d=-1,f=(x=1<<p)-1,1===t&&852<x||2===t&&592<x)return 1;for(;;){for(Z=w-k,S=n[m]+1<c?(U=0,n[m]):n[m]>=c?(U=D[n[m]-c],A[n[m]-c]):(U=96,0),h=1<<w-k,_=1<<v,g=_;_-=h,i[u+(z>>k)+_]=Z<<24|U<<16|S|0,0!==_;);for(h=1<<w-1;z&h;)h>>=1;if(0!==h?z=(z&=h-1)+h:z=0,m++,0==--E[w]){if(w===b)break;w=e[a+n[m]]}if(w>p&&(z&f)!==d){for(0===k&&(k=p),u+=g,v=w-k,y=1<<v;v+k<b&&!((y-=E[v+k])<=0);)v++,y<<=1;if(x+=1<<v,1===t&&852<x||2===t&&592<x)return 1;i[d=z&f]=p<<24|v<<16|u-s|0}}0!==z&&(i[u+z]=w-k<<24|64<<16|0),o.bits=p}return 0};const{Z_FINISH:be,Z_BLOCK:pe,Z_TREES:ve,Z_OK:F,Z_STREAM_END:ke,Z_NEED_DICT:ye,Z_STREAM_ERROR:L,Z_DATA_ERROR:xe,Z_MEM_ERROR:ze,Z_BUF_ERROR:Ae,Z_DEFLATED:Ee}=a,Re=16180,Ze=16190,B=16191,Ue=16199,Se=16200,N=16209,De=t=>(t>>>24&255)+(t>>>8&65280)+((65280&t)<<8)+((255&t)<<24);function Te(){this.strm=null,this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new Uint16Array(320),this.work=new Uint16Array(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}const I=t=>{var e;return!t||!(e=t.state)||e.strm!==t||e.mode<Re||16211<e.mode?1:0},Oe=t=>{var e;return I(t)?L:(e=t.state,t.total_in=t.total_out=e.total=0,t.msg="",e.wrap&&(t.adler=1&e.wrap),e.mode=Re,e.last=0,e.havedict=0,e.flags=-1,e.dmax=32768,e.head=null,e.hold=0,e.bits=0,e.lencode=e.lendyn=new Int32Array(852),e.distcode=e.distdyn=new Int32Array(592),e.sane=1,e.back=-1,F)},Fe=t=>{var e;return I(t)?L:((e=t.state).wsize=0,e.whave=0,e.wnext=0,Oe(t))},Le=(t,e)=>{let a;var r;return I(t)||(r=t.state,e<0?(a=0,e=-e):(a=5+(e>>4),e<48&&(e&=15)),e&&(e<8||15<e))?L:(null!==r.window&&r.wbits!==e&&(r.window=null),r.wrap=a,r.wbits=e,Fe(t))},Be=(t,e)=>{var a;return t?(a=new Te,(t.state=a).strm=t,a.window=null,a.mode=Re,(a=Le(t,e))!==F&&(t.state=null),a):L};let Ne,Ie,Ce=!0;const Me=(t,e,a,r)=>{let i;t=t.state;return null===t.window&&(t.wsize=1<<t.wbits,t.wnext=0,t.whave=0,t.window=new Uint8Array(t.wsize)),r>=t.wsize?(t.window.set(e.subarray(a-t.wsize,a),0),t.wnext=0,t.whave=t.wsize):((i=t.wsize-t.wnext)>r&&(i=r),t.window.set(e.subarray(a-r,a-r+i),t.wnext),(r-=i)?(t.window.set(e.subarray(a-r,a),0),t.wnext=r,t.whave=t.wsize):(t.wnext+=i,t.wnext===t.wsize&&(t.wnext=0),t.whave<t.wsize&&(t.whave+=i))),0};function He(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}var je=Fe,Ke=(Le,Oe,Be),Pe=(z,t)=>{let e,a,r,i,s,n,o,l,h,_,A,d,f,u,c,w,m,g,b,p,v,k,y=0;var x=new Uint8Array(4);let E,R;var Z=new Uint8Array([16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15]);if(I(z)||!z.output||!z.input&&0!==z.avail_in)return L;(e=z.state).mode===B&&(e.mode=16192),s=z.next_out,r=z.output,o=z.avail_out,i=z.next_in,a=z.input,n=z.avail_in,l=e.hold,h=e.bits,_=n,A=o,k=F;t:for(;;)switch(e.mode){case Re:if(0===e.wrap)e.mode=16192;else{for(;h<16;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}2&e.wrap&&35615===l?(0===e.wbits&&(e.wbits=15),x[e.check=0]=255&l,x[1]=l>>>8&255,e.check=O(e.check,x,2,0),l=0,h=0,e.mode=16181):(e.head&&(e.head.done=!1),!(1&e.wrap)||(((255&l)<<8)+(l>>8))%31?(z.msg="incorrect header check",e.mode=N):(15&l)!==Ee?(z.msg="unknown compression method",e.mode=N):(l>>>=4,h-=4,v=8+(15&l),0===e.wbits&&(e.wbits=v),15<v||v>e.wbits?(z.msg="invalid window size",e.mode=N):(e.dmax=1<<e.wbits,e.flags=0,z.adler=e.check=1,e.mode=512&l?16189:B,l=0,h=0)))}break;case 16181:for(;h<16;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}if(e.flags=l,(255&e.flags)!==Ee){z.msg="unknown compression method",e.mode=N;break}if(57344&e.flags){z.msg="unknown header flags set",e.mode=N;break}e.head&&(e.head.text=l>>8&1),512&e.flags&&4&e.wrap&&(x[0]=255&l,x[1]=l>>>8&255,e.check=O(e.check,x,2,0)),l=0,h=0,e.mode=16182;case 16182:for(;h<32;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}e.head&&(e.head.time=l),512&e.flags&&4&e.wrap&&(x[0]=255&l,x[1]=l>>>8&255,x[2]=l>>>16&255,x[3]=l>>>24&255,e.check=O(e.check,x,4,0)),l=0,h=0,e.mode=16183;case 16183:for(;h<16;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}e.head&&(e.head.xflags=255&l,e.head.os=l>>8),512&e.flags&&4&e.wrap&&(x[0]=255&l,x[1]=l>>>8&255,e.check=O(e.check,x,2,0)),l=0,h=0,e.mode=16184;case 16184:if(1024&e.flags){for(;h<16;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}e.length=l,e.head&&(e.head.extra_len=l),512&e.flags&&4&e.wrap&&(x[0]=255&l,x[1]=l>>>8&255,e.check=O(e.check,x,2,0)),l=0,h=0}else e.head&&(e.head.extra=null);e.mode=16185;case 16185:if(1024&e.flags&&((d=(d=e.length)>n?n:d)&&(e.head&&(v=e.head.extra_len-e.length,e.head.extra||(e.head.extra=new Uint8Array(e.head.extra_len)),e.head.extra.set(a.subarray(i,i+d),v)),512&e.flags&&4&e.wrap&&(e.check=O(e.check,a,d,i)),n-=d,i+=d,e.length-=d),e.length))break t;e.length=0,e.mode=16186;case 16186:if(2048&e.flags){if(0===n)break t;for(d=0;v=a[i+d++],e.head&&v&&e.length<65536&&(e.head.name+=String.fromCharCode(v)),v&&d<n;);if(512&e.flags&&4&e.wrap&&(e.check=O(e.check,a,d,i)),n-=d,i+=d,v)break t}else e.head&&(e.head.name=null);e.length=0,e.mode=16187;case 16187:if(4096&e.flags){if(0===n)break t;for(d=0;v=a[i+d++],e.head&&v&&e.length<65536&&(e.head.comment+=String.fromCharCode(v)),v&&d<n;);if(512&e.flags&&4&e.wrap&&(e.check=O(e.check,a,d,i)),n-=d,i+=d,v)break t}else e.head&&(e.head.comment=null);e.mode=16188;case 16188:if(512&e.flags){for(;h<16;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}if(4&e.wrap&&l!==(65535&e.check)){z.msg="header crc mismatch",e.mode=N;break}l=0,h=0}e.head&&(e.head.hcrc=e.flags>>9&1,e.head.done=!0),z.adler=e.check=0,e.mode=B;break;case 16189:for(;h<32;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}z.adler=e.check=De(l),l=0,h=0,e.mode=Ze;case Ze:if(0===e.havedict)return z.next_out=s,z.avail_out=o,z.next_in=i,z.avail_in=n,e.hold=l,e.bits=h,ye;z.adler=e.check=1,e.mode=B;case B:if(t===pe||t===ve)break t;case 16192:if(e.last)l>>>=7&h,h-=7&h,e.mode=16206;else{for(;h<3;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}switch(e.last=1&l,l>>>=1,--h,3&l){case 0:e.mode=16193;break;case 1:var U=e;if(Ce){Ne=new Int32Array(512),Ie=new Int32Array(32);let t=0;for(;t<144;)U.lens[t++]=8;for(;t<256;)U.lens[t++]=9;for(;t<280;)U.lens[t++]=7;for(;t<288;)U.lens[t++]=8;for(ge(1,U.lens,0,288,Ne,0,U.work,{bits:9}),t=0;t<32;)U.lens[t++]=5;ge(2,U.lens,0,32,Ie,0,U.work,{bits:5}),Ce=!1}if(U.lencode=Ne,U.lenbits=9,U.distcode=Ie,U.distbits=5,e.mode=Ue,t!==ve)break;l>>>=2,h-=2;break t;case 2:e.mode=16196;break;case 3:z.msg="invalid block type",e.mode=N}l>>>=2,h-=2}break;case 16193:for(l>>>=7&h,h-=7&h;h<32;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}if((65535&l)!=(l>>>16^65535)){z.msg="invalid stored block lengths",e.mode=N;break}if(e.length=65535&l,l=0,h=0,e.mode=16194,t===ve)break t;case 16194:e.mode=16195;case 16195:if(d=e.length){if(0===(d=(d=d>n?n:d)>o?o:d))break t;r.set(a.subarray(i,i+d),s),n-=d,i+=d,o-=d,s+=d,e.length-=d}else e.mode=B;break;case 16196:for(;h<14;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}if(e.nlen=257+(31&l),l>>>=5,h-=5,e.ndist=1+(31&l),l>>>=5,h-=5,e.ncode=4+(15&l),l>>>=4,h-=4,286<e.nlen||30<e.ndist){z.msg="too many length or distance symbols",e.mode=N;break}e.have=0,e.mode=16197;case 16197:for(;e.have<e.ncode;){for(;h<3;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}e.lens[Z[e.have++]]=7&l,l>>>=3,h-=3}for(;e.have<19;)e.lens[Z[e.have++]]=0;if(e.lencode=e.lendyn,e.lenbits=7,E={bits:e.lenbits},k=ge(0,e.lens,0,19,e.lencode,0,e.work,E),e.lenbits=E.bits,k){z.msg="invalid code lengths set",e.mode=N;break}e.have=0,e.mode=16198;case 16198:for(;e.have<e.nlen+e.ndist;){for(;y=e.lencode[l&(1<<e.lenbits)-1],c=y>>>24,w=y>>>16&255,m=65535&y,!(c<=h);){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}if(m<16)l>>>=c,h-=c,e.lens[e.have++]=m;else{if(16===m){for(R=c+2;h<R;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}if(l>>>=c,h-=c,0===e.have){z.msg="invalid bit length repeat",e.mode=N;break}v=e.lens[e.have-1],d=3+(3&l),l>>>=2,h-=2}else if(17===m){for(R=c+3;h<R;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}l>>>=c,h-=c,v=0,d=3+(7&l),l>>>=3,h-=3}else{for(R=c+7;h<R;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}l>>>=c,h-=c,v=0,d=11+(127&l),l>>>=7,h-=7}if(e.have+d>e.nlen+e.ndist){z.msg="invalid bit length repeat",e.mode=N;break}for(;d--;)e.lens[e.have++]=v}}if(e.mode===N)break;if(0===e.lens[256]){z.msg="invalid code -- missing end-of-block",e.mode=N;break}if(e.lenbits=9,E={bits:e.lenbits},k=ge(1,e.lens,0,e.nlen,e.lencode,0,e.work,E),e.lenbits=E.bits,k){z.msg="invalid literal/lengths set",e.mode=N;break}if(e.distbits=6,e.distcode=e.distdyn,E={bits:e.distbits},k=ge(2,e.lens,e.nlen,e.ndist,e.distcode,0,e.work,E),e.distbits=E.bits,k){z.msg="invalid distances set",e.mode=N;break}if(e.mode=Ue,t===ve)break t;case Ue:e.mode=Se;case Se:if(6<=n&&258<=o){z.next_out=s,z.avail_out=o,z.next_in=i,z.avail_in=n,e.hold=l,e.bits=h;{T=void 0;var S=z;var D=A;let t,e,a,r,i,s,n,o,l,h,_,d,f,u,c,w,m,g,b,p,v,k,y,x;var T=S.state;t=S.next_in,y=S.input,e=t+(S.avail_in-5),a=S.next_out,x=S.output,r=a-(D-S.avail_out),i=a+(S.avail_out-257),s=T.dmax,n=T.wsize,o=T.whave,l=T.wnext,h=T.window,_=T.hold,d=T.bits,f=T.lencode,u=T.distcode,c=(1<<T.lenbits)-1,w=(1<<T.distbits)-1;e:do{for(d<15&&(_+=y[t++]<<d,d+=8,_+=y[t++]<<d,d+=8),m=f[_&c];;){if(g=m>>>24,_>>>=g,d-=g,0===(g=m>>>16&255))x[a++]=65535&m;else{if(!(16&g)){if(0==(64&g)){m=f[(65535&m)+(_&(1<<g)-1)];continue}if(32&g){T.mode=16191;break e}S.msg="invalid literal/length code",T.mode=de;break e}for(b=65535&m,(g&=15)&&(d<g&&(_+=y[t++]<<d,d+=8),b+=_&(1<<g)-1,_>>>=g,d-=g),d<15&&(_+=y[t++]<<d,d+=8,_+=y[t++]<<d,d+=8),m=u[_&w];;){if(g=m>>>24,_>>>=g,d-=g,!(16&(g=m>>>16&255))){if(0==(64&g)){m=u[(65535&m)+(_&(1<<g)-1)];continue}S.msg="invalid distance code",T.mode=de;break e}if(p=65535&m,g&=15,d<g&&(_+=y[t++]<<d,(d+=8)<g)&&(_+=y[t++]<<d,d+=8),s<(p+=_&(1<<g)-1)){S.msg="invalid distance too far back",T.mode=de;break e}if(_>>>=g,d-=g,p>(g=a-r)){if((g=p-g)>o&&T.sane){S.msg="invalid distance too far back",T.mode=de;break e}if(v=0,k=h,0===l){if(v+=n-g,g<b){for(b-=g;x[a++]=h[v++],--g;);v=a-p,k=x}}else if(l<g){if(v+=n+l-g,(g-=l)<b){for(b-=g;x[a++]=h[v++],--g;);if(v=0,l<b){for(g=l,b-=g;x[a++]=h[v++],--g;);v=a-p,k=x}}}else if(v+=l-g,g<b){for(b-=g;x[a++]=h[v++],--g;);v=a-p,k=x}for(;2<b;)x[a++]=k[v++],x[a++]=k[v++],x[a++]=k[v++],b-=3;b&&(x[a++]=k[v++],1<b)&&(x[a++]=k[v++])}else{for(v=a-p;x[a++]=x[v++],x[a++]=x[v++],x[a++]=x[v++],2<(b-=3););b&&(x[a++]=x[v++],1<b)&&(x[a++]=x[v++])}break}}break}}while(t<e&&a<i);b=d>>3,t-=b,d-=b<<3,_&=(1<<d)-1,S.next_in=t,S.next_out=a,S.avail_in=t<e?e-t+5:5-(t-e),S.avail_out=a<i?i-a+257:257-(a-i),T.hold=_,T.bits=d}s=z.next_out,r=z.output,o=z.avail_out,i=z.next_in,a=z.input,n=z.avail_in,l=e.hold,h=e.bits,e.mode===B&&(e.back=-1);break}for(e.back=0;y=e.lencode[l&(1<<e.lenbits)-1],c=y>>>24,w=y>>>16&255,m=65535&y,!(c<=h);){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}if(w&&0==(240&w)){for(g=c,b=w,p=m;y=e.lencode[p+((l&(1<<g+b)-1)>>g)],c=y>>>24,w=y>>>16&255,m=65535&y,!(g+c<=h);){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}l>>>=g,h-=g,e.back+=g}if(l>>>=c,h-=c,e.back+=c,e.length=m,0===w){e.mode=16205;break}if(32&w){e.back=-1,e.mode=B;break}if(64&w){z.msg="invalid literal/length code",e.mode=N;break}e.extra=15&w,e.mode=16201;case 16201:if(e.extra){for(R=e.extra;h<R;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}e.length+=l&(1<<e.extra)-1,l>>>=e.extra,h-=e.extra,e.back+=e.extra}e.was=e.length,e.mode=16202;case 16202:for(;y=e.distcode[l&(1<<e.distbits)-1],c=y>>>24,w=y>>>16&255,m=65535&y,!(c<=h);){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}if(0==(240&w)){for(g=c,b=w,p=m;y=e.distcode[p+((l&(1<<g+b)-1)>>g)],c=y>>>24,w=y>>>16&255,m=65535&y,!(g+c<=h);){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}l>>>=g,h-=g,e.back+=g}if(l>>>=c,h-=c,e.back+=c,64&w){z.msg="invalid distance code",e.mode=N;break}e.offset=m,e.extra=15&w,e.mode=16203;case 16203:if(e.extra){for(R=e.extra;h<R;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}e.offset+=l&(1<<e.extra)-1,l>>>=e.extra,h-=e.extra,e.back+=e.extra}if(e.offset>e.dmax){z.msg="invalid distance too far back",e.mode=N;break}e.mode=16204;case 16204:if(0===o)break t;if(d=A-o,e.offset>d){if((d=e.offset-d)>e.whave&&e.sane){z.msg="invalid distance too far back",e.mode=N;break}f=d>e.wnext?(d-=e.wnext,e.wsize-d):e.wnext-d,d>e.length&&(d=e.length),u=e.window}else u=r,f=s-e.offset,d=e.length;for(d>o&&(d=o),o-=d,e.length-=d;r[s++]=u[f++],--d;);0===e.length&&(e.mode=Se);break;case 16205:if(0===o)break t;r[s++]=e.length,o--,e.mode=Se;break;case 16206:if(e.wrap){for(;h<32;){if(0===n)break t;n--,l|=a[i++]<<h,h+=8}if(A-=o,z.total_out+=A,e.total+=A,4&e.wrap&&A&&(z.adler=e.check=(e.flags?O:lt)(e.check,r,A,s-A)),A=o,4&e.wrap&&(e.flags?l:De(l))!==e.check){z.msg="incorrect data check",e.mode=N;break}l=0,h=0}e.mode=16207;case 16207:if(e.wrap&&e.flags){for(;h<32;){if(0===n)break t;n--,l+=a[i++]<<h,h+=8}if(4&e.wrap&&l!==(4294967295&e.total)){z.msg="incorrect length check",e.mode=N;break}l=0,h=0}e.mode=16208;case 16208:k=ke;break t;case N:k=xe;break t;case 16210:return ze;default:return L}return z.next_out=s,z.avail_out=o,z.next_in=i,z.avail_in=n,e.hold=l,e.bits=h,(e.wsize||A!==z.avail_out&&e.mode<N&&(e.mode<16206||t!==be))&&Me(z,z.output,z.next_out,A-z.avail_out),_-=z.avail_in,A-=z.avail_out,z.total_in+=_,z.total_out+=A,e.total+=A,4&e.wrap&&A&&(z.adler=e.check=(e.flags?O:lt)(e.check,r,A,z.next_out-A)),z.data_type=e.bits+(e.last?64:0)+(e.mode===B?128:0)+(e.mode===Ue||16194===e.mode?256:0),k=(0==_&&0===A||t===be)&&k===F?Ae:k},Ye=t=>{var e;return I(t)?L:((e=t.state).window&&(e.window=null),t.state=null,F)},Xe=(t,e)=>{return I(t)||0==(2&(t=t.state).wrap)?L:((t.head=e).done=!1,F)},Ge=(t,e)=>{var a,r=e.length;return I(t)||0!==(a=t.state).wrap&&a.mode!==Ze?L:a.mode===Ze&&lt(1,e,r,0)!==a.check?xe:Me(t,e,r,r)?(a.mode=16210,ze):(a.havedict=1,F)};const We=Object.prototype.toString,{Z_NO_FLUSH:qe,Z_FINISH:Je,Z_OK:Qe,Z_STREAM_END:Ve,Z_NEED_DICT:$e,Z_STREAM_ERROR:ta,Z_DATA_ERROR:ea,Z_MEM_ERROR:aa}=a;function ra(t){this.options=Gt({chunkSize:65536,windowBits:15,to:""},t||{});var e=this.options;e.raw&&0<=e.windowBits&&e.windowBits<16&&(e.windowBits=-e.windowBits,0===e.windowBits)&&(e.windowBits=-15),!(0<=e.windowBits&&e.windowBits<16)||t&&t.windowBits||(e.windowBits+=32),15<e.windowBits&&e.windowBits<48&&0==(15&e.windowBits)&&(e.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new Qt,this.strm.avail_out=0;let a=Ke(this.strm,e.windowBits);if(a!==Qe)throw new Error(r[a]);if(this.header=new He,Xe(this.strm,this.header),e.dictionary&&("string"==typeof e.dictionary?e.dictionary=Vt(e.dictionary):"[object ArrayBuffer]"===We.call(e.dictionary)&&(e.dictionary=new Uint8Array(e.dictionary)),e.raw)&&(a=Ge(this.strm,e.dictionary))!==Qe)throw new Error(r[a])}function ia(t,e){e=new ra(e);if(e.push(t),e.err)throw e.msg||r[e.err];return e.result}ra.prototype.push=function(t,e){var a,r,i,s=this.strm,n=this.options.chunkSize,o=this.options.dictionary;let l,h,_;if(this.ended)return!1;for(h=e===~~e?e:!0===e?Je:qe,"[object ArrayBuffer]"===We.call(t)?s.input=new Uint8Array(t):s.input=t,s.next_in=0,s.avail_in=s.input.length;;){for(0===s.avail_out&&(s.output=new Uint8Array(n),s.next_out=0,s.avail_out=n),(l=Pe(s,h))===$e&&o&&((l=Ge(s,o))===Qe?l=Pe(s,h):l===ea&&(l=$e));0<s.avail_in&&l===Ve&&0<s.state.wrap&&0!==t[s.next_in];)je(s),l=Pe(s,h);switch(l){case ta:case ea:case $e:case aa:return this.onEnd(l),!(this.ended=!0)}if(_=s.avail_out,!s.next_out||0!==s.avail_out&&l!==Ve||("string"===this.options.to?(a=((t,e)=>{let a=(e=(e=e||t.length)>t.length?t.length:e)-1;for(;0<=a&&128==(192&t[a]);)a--;return!(a<0||0===a)&&a+Jt[t[a]]>e?a:e})(s.output,s.next_out),r=s.next_out-a,i=((a,t)=>{var r=t||a.length;if("function"==typeof TextDecoder&&TextDecoder.prototype.decode)return(new TextDecoder).decode(a.subarray(0,t));let i,s;var n=new Array(2*r);for(s=0,i=0;i<r;){let e=a[i++];if(e<128)n[s++]=e;else{let t=Jt[e];if(4<t)n[s++]=65533,i+=t-1;else{for(e&=2===t?31:3===t?15:7;1<t&&i<r;)e=e<<6|63&a[i++],t--;1<t?n[s++]=65533:e<65536?n[s++]=e:(e-=65536,n[s++]=55296|e>>10&1023,n[s++]=56320|1023&e)}}}{var o=n,l=s;if(l<65534&&o.subarray&&qt)return String.fromCharCode.apply(null,o.length===l?o:o.subarray(0,l));let e="";for(let t=0;t<l;t++)e+=String.fromCharCode(o[t]);return e}})(s.output,a),s.next_out=r,s.avail_out=n-r,r&&s.output.set(s.output.subarray(a,a+r),0),this.onData(i)):this.onData(s.output.length===s.next_out?s.output:s.output.subarray(0,s.next_out))),l!==Qe||0!==_){if(l===Ve)return l=Ye(this.strm),this.onEnd(l),this.ended=!0;if(0===s.avail_in)break}}return!0},ra.prototype.onData=function(t){this.chunks.push(t)},ra.prototype.onEnd=function(t){t===Qe&&("string"===this.options.to?this.result=this.chunks.join(""):this.result=Wt(this.chunks)),this.chunks=[],this.err=t,this.msg=this.strm.msg};var{Deflate:ot,deflate:sa,deflateRaw:na,gzip:oa}=ot,{Inflate:la,inflate:ha,inflateRaw:_a,ungzip:da}={Inflate:ra,inflate:ia,inflateRaw:function(t,e){return(e=e||{}).raw=!0,ia(t,e)},ungzip:ia},fa={Deflate:ot,deflate:sa,deflateRaw:na,gzip:oa,Inflate:la,inflate:ha,inflateRaw:_a,ungzip:da,constants:a};t.Deflate=ot,t.Inflate=la,t.constants=a,t.default=fa,t.deflate=sa,t.deflateRaw=na,t.gzip=oa,t.inflate=ha,t.inflateRaw=_a,t.ungzip=da,Object.defineProperty(t,"__esModule",{value:!0})});';
function Xl(e) {
    let t = e.length;
    for (; --t >= 0; )
        e[t] = 0
}
const $l = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0]), Jl = new Uint8Array([0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13]), ep = new Uint8Array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 7]), tp = new Uint8Array([16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15]), ap = new Array(576);
Xl(ap);
const np = new Array(60);
Xl(np);
const ip = new Array(512);
Xl(ip);
const sp = new Array(256);
Xl(sp);
const op = new Array(29);
Xl(op);
const rp = new Array(30);
function cp(e, t, a, n, i) {
    this.static_tree = e,
    this.extra_bits = t,
    this.extra_base = a,
    this.elems = n,
    this.max_length = i,
    this.has_stree = e && e.length
}
let lp, pp, up;
function dp(e, t) {
    this.dyn_tree = e,
    this.max_code = 0,
    this.stat_desc = t
}
Xl(rp);
const hp = e => e < 256 ? ip[e] : ip[256 + (e >>> 7)], mp = (e, t) => {
    e.pending_buf[e.pending++] = 255 & t,
    e.pending_buf[e.pending++] = t >>> 8 & 255
}, fp = (e, t, a) => {
    e.bi_valid > 16 - a ? (e.bi_buf |= t << e.bi_valid & 65535, mp(e, e.bi_buf), e.bi_buf = t >> 16 - e.bi_valid, e.bi_valid += a - 16) : (e.bi_buf |= t << e.bi_valid & 65535, e.bi_valid += a)
}, _p = (e, t, a) => {
    fp(e, a[2 * t], a[2 * t + 1])
}, Ep = (e, t) => {
    let a = 0;
    do {
        a |= 1 & e,
        e >>>= 1,
        a <<= 1
    } while (--t > 0);
    return a >>> 1
}, gp = (e, t, a) => {
    const n = new Array(16);
    let i,
    s,
    o = 0;
    for (i = 1; i <= 15; i++)
        o = o + a[i - 1] << 1, n[i] = o;
    for (s = 0; s <= t; s++) {
        let t = e[2 * s + 1];
        0 !== t && (e[2 * s] = Ep(n[t]++, t))
    }
}, bp = e => {
    let t;
    for (t = 0; t < 286; t++)
        e.dyn_ltree[2 * t] = 0;
    for (t = 0; t < 30; t++)
        e.dyn_dtree[2 * t] = 0;
    for (t = 0; t < 19; t++)
        e.bl_tree[2 * t] = 0;
    e.dyn_ltree[512] = 1,
    e.opt_len = e.static_len = 0,
    e.sym_next = e.matches = 0
}, xp = e => {
    e.bi_valid > 8 ? mp(e, e.bi_buf) : e.bi_valid > 0 && (e.pending_buf[e.pending++] = e.bi_buf),
    e.bi_buf = 0,
    e.bi_valid = 0
}, Tp = (e, t, a, n) => {
    const i = 2 * t,
    s = 2 * a;
    return e[i] < e[s] || e[i] === e[s] && n[t] <= n[a]
}, vp = (e, t, a) => {
    const n = e.heap[a];
    let i = a << 1;
    for (; i <= e.heap_len && (i < e.heap_len && Tp(t, e.heap[i + 1], e.heap[i], e.depth) && i++, !Tp(t, n, e.heap[i], e.depth)); )
        e.heap[a] = e.heap[i], a = i, i <<= 1;
    e.heap[a] = n
}, Ap = (e, t, a) => {
    let n,
    i,
    s,
    o,
    r = 0;
    if (0 !== e.sym_next)
        do {
            n = 255 & e.pending_buf[e.sym_buf + r++],
            n += (255 & e.pending_buf[e.sym_buf + r++]) << 8,
            i = e.pending_buf[e.sym_buf + r++],
            0 === n ? _p(e, i, t) : (s = sp[i], _p(e, s + 256 + 1, t), o = $l[s], 0 !== o && (i -= op[s], fp(e, i, o)), n--, s = hp(n), _p(e, s, a), o = Jl[s], 0 !== o && (n -= rp[s], fp(e, n, o)))
        } while (r < e.sym_next);
    _p(e, 256, t)
}, yp = (e, t) => {
    const a = t.dyn_tree,
    n = t.stat_desc.static_tree,
    i = t.stat_desc.has_stree,
    s = t.stat_desc.elems;
    let o,
    r,
    c,
    l = -1;
    for (e.heap_len = 0, e.heap_max = 573, o = 0; o < s; o++)
        0 !== a[2 * o] ? (e.heap[++e.heap_len] = l = o, e.depth[o] = 0) : a[2 * o + 1] = 0;
    for (; e.heap_len < 2; )
        c = e.heap[++e.heap_len] = l < 2 ? ++l : 0, a[2 * c] = 1, e.depth[c] = 0, e.opt_len--, i && (e.static_len -= n[2 * c + 1]);
    for (t.max_code = l, o = e.heap_len >> 1; o >= 1; o--)
        vp(e, a, o);
    c = s;
    do {
        o = e.heap[1],
        e.heap[1] = e.heap[e.heap_len--],
        vp(e, a, 1),
        r = e.heap[1],
        e.heap[--e.heap_max] = o,
        e.heap[--e.heap_max] = r,
        a[2 * c] = a[2 * o] + a[2 * r],
        e.depth[c] = (e.depth[o] >= e.depth[r] ? e.depth[o] : e.depth[r]) + 1,
        a[2 * o + 1] = a[2 * r + 1] = c,
        e.heap[1] = c++,
        vp(e, a, 1)
    } while (e.heap_len >= 2);
    e.heap[--e.heap_max] = e.heap[1],
    ((e, t) => {
        const a = t.dyn_tree,
        n = t.max_code,
        i = t.stat_desc.static_tree,
        s = t.stat_desc.has_stree,
        o = t.stat_desc.extra_bits,
        r = t.stat_desc.extra_base,
        c = t.stat_desc.max_length;
        let l,
        p,
        u,
        d,
        h,
        m,
        f = 0;
        for (d = 0; d <= 15; d++)
            e.bl_count[d] = 0;
        for (a[2 * e.heap[e.heap_max] + 1] = 0, l = e.heap_max + 1; l < 573; l++)
            p = e.heap[l], d = a[2 * a[2 * p + 1] + 1] + 1, d > c && (d = c, f++), a[2 * p + 1] = d, p > n || (e.bl_count[d]++, h = 0, p >= r && (h = o[p - r]), m = a[2 * p], e.opt_len += m * (d + h), s && (e.static_len += m * (i[2 * p + 1] + h)));
        if (0 !== f) {
            do {
                for (d = c - 1; 0 === e.bl_count[d]; )
                    d--;
                e.bl_count[d]--,
                e.bl_count[d + 1] += 2,
                e.bl_count[c]--,
                f -= 2
            } while (f > 0);
            for (d = c; 0 !== d; d--)
                for (p = e.bl_count[d]; 0 !== p; )
                    u = e.heap[--l], u > n || (a[2 * u + 1] !== d && (e.opt_len += (d - a[2 * u + 1]) * a[2 * u], a[2 * u + 1] = d), p--)
        }
    })(e, t),
    gp(a, l, e.bl_count)
}, wp = (e, t, a) => {
    let n,
    i,
    s = -1,
    o = t[1],
    r = 0,
    c = 7,
    l = 4;
    for (0 === o && (c = 138, l = 3), t[2 * (a + 1) + 1] = 65535, n = 0; n <= a; n++)
        i = o, o = t[2 * (n + 1) + 1], ++r < c && i === o || (r < l ? e.bl_tree[2 * i] += r : 0 !== i ? (i !== s && e.bl_tree[2 * i]++, e.bl_tree[32]++) : r <= 10 ? e.bl_tree[34]++ : e.bl_tree[36]++, r = 0, s = i, 0 === o ? (c = 138, l = 3) : i === o ? (c = 6, l = 3) : (c = 7, l = 4))
}, Sp = (e, t, a) => {
    let n,
    i,
    s = -1,
    o = t[1],
    r = 0,
    c = 7,
    l = 4;
    for (0 === o && (c = 138, l = 3), n = 0; n <= a; n++)
        if (i = o, o = t[2 * (n + 1) + 1], !(++r < c && i === o)) {
            if (r < l)
                do {
                    _p(e, i, e.bl_tree)
                } while (0 != --r);
            else
                0 !== i ? (i !== s && (_p(e, i, e.bl_tree), r--), _p(e, 16, e.bl_tree), fp(e, r - 3, 2)) : r <= 10 ? (_p(e, 17, e.bl_tree), fp(e, r - 3, 3)) : (_p(e, 18, e.bl_tree), fp(e, r - 11, 7));
            r = 0,
            s = i,
            0 === o ? (c = 138, l = 3) : i === o ? (c = 6, l = 3) : (c = 7, l = 4)
        }
};
let Np = !1;
const Cp = (e, t, a, n) => {
    fp(e, 0 + (n ? 1 : 0), 3),
    xp(e),
    mp(e, a),
    mp(e, ~a),
    a && e.pending_buf.set(e.window.subarray(t, t + a), e.pending),
    e.pending += a
};
var Ip = {
    _tr_init: e => {
        Np || ((() => {
                let e,
                t,
                a,
                n,
                i;
                const s = new Array(16);
                for (a = 0, n = 0; n < 28; n++)
                    for (op[n] = a, e = 0; e < 1 << $l[n]; e++)
                        sp[a++] = n;
                for (sp[a - 1] = n, i = 0, n = 0; n < 16; n++)
                    for (rp[n] = i, e = 0; e < 1 << Jl[n]; e++)
                        ip[i++] = n;
                for (i >>= 7; n < 30; n++)
                    for (rp[n] = i << 7, e = 0; e < 1 << Jl[n] - 7; e++)
                        ip[256 + i++] = n;
                for (t = 0; t <= 15; t++)
                    s[t] = 0;
                for (e = 0; e <= 143; )
                    ap[2 * e + 1] = 8, e++, s[8]++;
                for (; e <= 255; )
                    ap[2 * e + 1] = 9, e++, s[9]++;
                for (; e <= 279; )
                    ap[2 * e + 1] = 7, e++, s[7]++;
                for (; e <= 287; )
                    ap[2 * e + 1] = 8, e++, s[8]++;
                for (gp(ap, 287, s), e = 0; e < 30; e++)
                    np[2 * e + 1] = 5, np[2 * e] = Ep(e, 5);
                lp = new cp(ap, $l, 257, 286, 15),
                pp = new cp(np, Jl, 0, 30, 15),
                up = new cp(new Array(0), ep, 0, 19, 7)
            })(), Np = !0),
        e.l_desc = new dp(e.dyn_ltree, lp),
        e.d_desc = new dp(e.dyn_dtree, pp),
        e.bl_desc = new dp(e.bl_tree, up),
        e.bi_buf = 0,
        e.bi_valid = 0,
        bp(e)
    },
    _tr_stored_block: Cp,
    _tr_flush_block: (e, t, a, n) => {
        let i,
        s,
        o = 0;
        e.level > 0 ? (2 === e.strm.data_type && (e.strm.data_type = (e => {
                    let t,
                    a = 4093624447;
                    for (t = 0; t <= 31; t++, a >>>= 1)
                        if (1 & a && 0 !== e.dyn_ltree[2 * t])
                            return 0;
                    if (0 !== e.dyn_ltree[18] || 0 !== e.dyn_ltree[20] || 0 !== e.dyn_ltree[26])
                        return 1;
                    for (t = 32; t < 256; t++)
                        if (0 !== e.dyn_ltree[2 * t])
                            return 1;
                    return 0
                })(e)), yp(e, e.l_desc), yp(e, e.d_desc), o = (e => {
                let t;
                for (wp(e, e.dyn_ltree, e.l_desc.max_code), wp(e, e.dyn_dtree, e.d_desc.max_code), yp(e, e.bl_desc), t = 18; t >= 3 && 0 === e.bl_tree[2 * tp[t] + 1]; t--);
                return e.opt_len += 3 * (t + 1) + 5 + 5 + 4,
                t
            })(e), i = e.opt_len + 3 + 7 >>> 3, s = e.static_len + 3 + 7 >>> 3, s <= i && (i = s)) : i = s = a + 5,
        a + 4 <= i && -1 !== t ? Cp(e, t, a, n) : 4 === e.strategy || s === i ? (fp(e, 2 + (n ? 1 : 0), 3), Ap(e, ap, np)) : (fp(e, 4 + (n ? 1 : 0), 3), ((e, t, a, n) => {
                let i;
                for (fp(e, t - 257, 5), fp(e, a - 1, 5), fp(e, n - 4, 4), i = 0; i < n; i++)
                    fp(e, e.bl_tree[2 * tp[i] + 1], 3);
                Sp(e, e.dyn_ltree, t - 1),
                Sp(e, e.dyn_dtree, a - 1)
            })(e, e.l_desc.max_code + 1, e.d_desc.max_code + 1, o + 1), Ap(e, e.dyn_ltree, e.dyn_dtree)),
        bp(e),
        n && xp(e)
    },
    _tr_tally: (e, t, a) => (e.pending_buf[e.sym_buf + e.sym_next++] = t, e.pending_buf[e.sym_buf + e.sym_next++] = t >> 8, e.pending_buf[e.sym_buf + e.sym_next++] = a, 0 === t ? e.dyn_ltree[2 * a]++ : (e.matches++, t--, e.dyn_ltree[2 * (sp[a] + 256 + 1)]++, e.dyn_dtree[2 * hp(t)]++), e.sym_next === e.sym_end),
    _tr_align: e => {
        fp(e, 2, 3),
        _p(e, 256, ap),
        (e => {
            16 === e.bi_valid ? (mp(e, e.bi_buf), e.bi_buf = 0, e.bi_valid = 0) : e.bi_valid >= 8 && (e.pending_buf[e.pending++] = 255 & e.bi_buf, e.bi_buf >>= 8, e.bi_valid -= 8)
        })(e)
    }
}, kp = (e, t, a, n) => {
    let i = 65535 & e | 0,
    s = e >>> 16 & 65535 | 0,
    o = 0;
    for (; 0 !== a; ) {
        o = a > 2e3 ? 2e3 : a,
        a -= o;
        do {
            i = i + t[n++] | 0,
            s = s + i | 0
        } while (--o);
        i %= 65521,
        s %= 65521
    }
    return i | s << 16 | 0
};
const Rp = new Uint32Array((() => {
            let e,
            t = [];
            for (var a = 0; a < 256; a++) {
                e = a;
                for (var n = 0; n < 8; n++)
                    e = 1 & e ? 3988292384 ^ e >>> 1 : e >>> 1;
                t[a] = e
            }
            return t
        })());
var Op = (e, t, a, n) => {
    const i = Rp,
    s = n + a;
    e ^= -1;
    for (let a = n; a < s; a++)
        e = e >>> 8 ^ i[255 & (e ^ t[a])];
    return -1 ^ e
}, Dp = {
    2: "need dictionary",
    1: "stream end",
    0: "",
    "-1": "file error",
    "-2": "stream error",
    "-3": "data error",
    "-4": "insufficient memory",
    "-5": "buffer error",
    "-6": "incompatible version"
}, Lp = {
    Z_NO_FLUSH: 0,
    Z_PARTIAL_FLUSH: 1,
    Z_SYNC_FLUSH: 2,
    Z_FULL_FLUSH: 3,
    Z_FINISH: 4,
    Z_BLOCK: 5,
    Z_TREES: 6,
    Z_OK: 0,
    Z_STREAM_END: 1,
    Z_NEED_DICT: 2,
    Z_ERRNO: -1,
    Z_STREAM_ERROR: -2,
    Z_DATA_ERROR: -3,
    Z_MEM_ERROR: -4,
    Z_BUF_ERROR: -5,
    Z_NO_COMPRESSION: 0,
    Z_BEST_SPEED: 1,
    Z_BEST_COMPRESSION: 9,
    Z_DEFAULT_COMPRESSION: -1,
    Z_FILTERED: 1,
    Z_HUFFMAN_ONLY: 2,
    Z_RLE: 3,
    Z_FIXED: 4,
    Z_DEFAULT_STRATEGY: 0,
    Z_BINARY: 0,
    Z_TEXT: 1,
    Z_UNKNOWN: 2,
    Z_DEFLATED: 8
};
const {
    _tr_init: Mp,
    _tr_stored_block: Pp,
    _tr_flush_block: Bp,
    _tr_tally: Up,
    _tr_align: Fp
} = Ip, {
    Z_NO_FLUSH: Hp,
    Z_PARTIAL_FLUSH: jp,
    Z_FULL_FLUSH: zp,
    Z_FINISH: Gp,
    Z_BLOCK: qp,
    Z_OK: Yp,
    Z_STREAM_END: Vp,
    Z_STREAM_ERROR: Qp,
    Z_DATA_ERROR: Wp,
    Z_BUF_ERROR: Kp,
    Z_DEFAULT_COMPRESSION: Zp,
    Z_FILTERED: Xp,
    Z_HUFFMAN_ONLY: $p,
    Z_RLE: Jp,
    Z_FIXED: eu,
    Z_DEFAULT_STRATEGY: tu,
    Z_UNKNOWN: au,
    Z_DEFLATED: nu
} = Lp, iu = (e, t) => (e.msg = Dp[t], t), su = e => 2 * e - (e > 4 ? 9 : 0), ou = e => {
    let t = e.length;
    for (; --t >= 0; )
        e[t] = 0
}, ru = e => {
    let t,
    a,
    n,
    i = e.w_size;
    t = e.hash_size,
    n = t;
    do {
        a = e.head[--n],
        e.head[n] = a >= i ? a - i : 0
    } while (--t);
    t = i,
    n = t;
    do {
        a = e.prev[--n],
        e.prev[n] = a >= i ? a - i : 0
    } while (--t)
};
let cu = (e, t, a) => (t << e.hash_shift ^ a) & e.hash_mask;
const lu = e => {
    const t = e.state;
    let a = t.pending;
    a > e.avail_out && (a = e.avail_out),
    0 !== a && (e.output.set(t.pending_buf.subarray(t.pending_out, t.pending_out + a), e.next_out), e.next_out += a, t.pending_out += a, e.total_out += a, e.avail_out -= a, t.pending -= a, 0 === t.pending && (t.pending_out = 0))
}, pu = (e, t) => {
    Bp(e, e.block_start >= 0 ? e.block_start : -1, e.strstart - e.block_start, t),
    e.block_start = e.strstart,
    lu(e.strm)
}, uu = (e, t) => {
    e.pending_buf[e.pending++] = t
}, du = (e, t) => {
    e.pending_buf[e.pending++] = t >>> 8 & 255,
    e.pending_buf[e.pending++] = 255 & t
}, hu = (e, t, a, n) => {
    let i = e.avail_in;
    return i > n && (i = n),
    0 === i ? 0 : (e.avail_in -= i, t.set(e.input.subarray(e.next_in, e.next_in + i), a), 1 === e.state.wrap ? e.adler = kp(e.adler, t, i, a) : 2 === e.state.wrap && (e.adler = Op(e.adler, t, i, a)), e.next_in += i, e.total_in += i, i)
}, mu = (e, t) => {
    let a,
    n,
    i = e.max_chain_length,
    s = e.strstart,
    o = e.prev_length,
    r = e.nice_match;
    const c = e.strstart > e.w_size - 262 ? e.strstart - (e.w_size - 262) : 0,
    l = e.window,
    p = e.w_mask,
    u = e.prev,
    d = e.strstart + 258;
    let h = l[s + o - 1],
    m = l[s + o];
    e.prev_length >= e.good_match && (i >>= 2),
    r > e.lookahead && (r = e.lookahead);
    do {
        if (a = t, l[a + o] === m && l[a + o - 1] === h && l[a] === l[s] && l[++a] === l[s + 1]) {
            s += 2,
            a++;
            do {}
            while (l[++s] === l[++a] && l[++s] === l[++a] && l[++s] === l[++a] && l[++s] === l[++a] && l[++s] === l[++a] && l[++s] === l[++a] && l[++s] === l[++a] && l[++s] === l[++a] && s < d);
            if (n = 258 - (d - s), s = d - 258, n > o) {
                if (e.match_start = t, o = n, n >= r)
                    break;
                h = l[s + o - 1],
                m = l[s + o]
            }
        }
    } while ((t = u[t & p]) > c && 0 != --i);
    return o <= e.lookahead ? o : e.lookahead
}, fu = e => {
    const t = e.w_size;
    let a,
    n,
    i;
    do {
        if (n = e.window_size - e.lookahead - e.strstart, e.strstart >= t + (t - 262) && (e.window.set(e.window.subarray(t, t + t - n), 0), e.match_start -= t, e.strstart -= t, e.block_start -= t, e.insert > e.strstart && (e.insert = e.strstart), ru(e), n += t), 0 === e.strm.avail_in)
            break;
        if (a = hu(e.strm, e.window, e.strstart + e.lookahead, n), e.lookahead += a, e.lookahead + e.insert >= 3)
            for (i = e.strstart - e.insert, e.ins_h = e.window[i], e.ins_h = cu(e, e.ins_h, e.window[i + 1]); e.insert && (e.ins_h = cu(e, e.ins_h, e.window[i + 3 - 1]), e.prev[i & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = i, i++, e.insert--, !(e.lookahead + e.insert < 3)); );
    } while (e.lookahead < 262 && 0 !== e.strm.avail_in)
}, _u = (e, t) => {
    let a,
    n,
    i,
    s = e.pending_buf_size - 5 > e.w_size ? e.w_size : e.pending_buf_size - 5,
    o = 0,
    r = e.strm.avail_in;
    do {
        if (a = 65535, i = e.bi_valid + 42 >> 3, e.strm.avail_out < i)
            break;
        if (i = e.strm.avail_out - i, n = e.strstart - e.block_start, a > n + e.strm.avail_in && (a = n + e.strm.avail_in), a > i && (a = i), a < s && (0 === a && t !== Gp || t === Hp || a !== n + e.strm.avail_in))
            break;
        o = t === Gp && a === n + e.strm.avail_in ? 1 : 0,
        Pp(e, 0, 0, o),
        e.pending_buf[e.pending - 4] = a,
        e.pending_buf[e.pending - 3] = a >> 8,
        e.pending_buf[e.pending - 2] = ~a,
        e.pending_buf[e.pending - 1] = ~a >> 8,
        lu(e.strm),
        n && (n > a && (n = a), e.strm.output.set(e.window.subarray(e.block_start, e.block_start + n), e.strm.next_out), e.strm.next_out += n, e.strm.avail_out -= n, e.strm.total_out += n, e.block_start += n, a -= n),
        a && (hu(e.strm, e.strm.output, e.strm.next_out, a), e.strm.next_out += a, e.strm.avail_out -= a, e.strm.total_out += a)
    } while (0 === o);
    return r -= e.strm.avail_in,
    r && (r >= e.w_size ? (e.matches = 2, e.window.set(e.strm.input.subarray(e.strm.next_in - e.w_size, e.strm.next_in), 0), e.strstart = e.w_size, e.insert = e.strstart) : (e.window_size - e.strstart <= r && (e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, e.insert > e.strstart && (e.insert = e.strstart)), e.window.set(e.strm.input.subarray(e.strm.next_in - r, e.strm.next_in), e.strstart), e.strstart += r, e.insert += r > e.w_size - e.insert ? e.w_size - e.insert : r), e.block_start = e.strstart),
    e.high_water < e.strstart && (e.high_water = e.strstart),
    o ? 4 : t !== Hp && t !== Gp && 0 === e.strm.avail_in && e.strstart === e.block_start ? 2 : (i = e.window_size - e.strstart, e.strm.avail_in > i && e.block_start >= e.w_size && (e.block_start -= e.w_size, e.strstart -= e.w_size, e.window.set(e.window.subarray(e.w_size, e.w_size + e.strstart), 0), e.matches < 2 && e.matches++, i += e.w_size, e.insert > e.strstart && (e.insert = e.strstart)), i > e.strm.avail_in && (i = e.strm.avail_in), i && (hu(e.strm, e.window, e.strstart, i), e.strstart += i, e.insert += i > e.w_size - e.insert ? e.w_size - e.insert : i), e.high_water < e.strstart && (e.high_water = e.strstart), i = e.bi_valid + 42 >> 3, i = e.pending_buf_size - i > 65535 ? 65535 : e.pending_buf_size - i, s = i > e.w_size ? e.w_size : i, n = e.strstart - e.block_start, (n >= s || (n || t === Gp) && t !== Hp && 0 === e.strm.avail_in && n <= i) && (a = n > i ? i : n, o = t === Gp && 0 === e.strm.avail_in && a === n ? 1 : 0, Pp(e, e.block_start, a, o), e.block_start += a, lu(e.strm)), o ? 3 : 1)
}, Eu = (e, t) => {
    let a,
    n;
    for (; ; ) {
        if (e.lookahead < 262) {
            if (fu(e), e.lookahead < 262 && t === Hp)
                return 1;
            if (0 === e.lookahead)
                break
        }
        if (a = 0, e.lookahead >= 3 && (e.ins_h = cu(e, e.ins_h, e.window[e.strstart + 3 - 1]), a = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), 0 !== a && e.strstart - a <= e.w_size - 262 && (e.match_length = mu(e, a)), e.match_length >= 3)
            if (n = Up(e, e.strstart - e.match_start, e.match_length - 3), e.lookahead -= e.match_length, e.match_length <= e.max_lazy_match && e.lookahead >= 3) {
                e.match_length--;
                do {
                    e.strstart++,
                    e.ins_h = cu(e, e.ins_h, e.window[e.strstart + 3 - 1]),
                    a = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h],
                    e.head[e.ins_h] = e.strstart
                } while (0 != --e.match_length);
                e.strstart++
            } else
                e.strstart += e.match_length, e.match_length = 0, e.ins_h = e.window[e.strstart], e.ins_h = cu(e, e.ins_h, e.window[e.strstart + 1]);
        else
            n = Up(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++;
        if (n && (pu(e, !1), 0 === e.strm.avail_out))
            return 1
    }
    return e.insert = e.strstart < 2 ? e.strstart : 2,
    t === Gp ? (pu(e, !0), 0 === e.strm.avail_out ? 3 : 4) : e.sym_next && (pu(e, !1), 0 === e.strm.avail_out) ? 1 : 2
}, gu = (e, t) => {
    let a,
    n,
    i;
    for (; ; ) {
        if (e.lookahead < 262) {
            if (fu(e), e.lookahead < 262 && t === Hp)
                return 1;
            if (0 === e.lookahead)
                break
        }
        if (a = 0, e.lookahead >= 3 && (e.ins_h = cu(e, e.ins_h, e.window[e.strstart + 3 - 1]), a = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart), e.prev_length = e.match_length, e.prev_match = e.match_start, e.match_length = 2, 0 !== a && e.prev_length < e.max_lazy_match && e.strstart - a <= e.w_size - 262 && (e.match_length = mu(e, a), e.match_length <= 5 && (e.strategy === Xp || 3 === e.match_length && e.strstart - e.match_start > 4096) && (e.match_length = 2)), e.prev_length >= 3 && e.match_length <= e.prev_length) {
            i = e.strstart + e.lookahead - 3,
            n = Up(e, e.strstart - 1 - e.prev_match, e.prev_length - 3),
            e.lookahead -= e.prev_length - 1,
            e.prev_length -= 2;
            do {
                ++e.strstart <= i && (e.ins_h = cu(e, e.ins_h, e.window[e.strstart + 3 - 1]), a = e.prev[e.strstart & e.w_mask] = e.head[e.ins_h], e.head[e.ins_h] = e.strstart)
            } while (0 != --e.prev_length);
            if (e.match_available = 0, e.match_length = 2, e.strstart++, n && (pu(e, !1), 0 === e.strm.avail_out))
                return 1
        } else if (e.match_available) {
            if (n = Up(e, 0, e.window[e.strstart - 1]), n && pu(e, !1), e.strstart++, e.lookahead--, 0 === e.strm.avail_out)
                return 1
        } else
            e.match_available = 1, e.strstart++, e.lookahead--
    }
    return e.match_available && (n = Up(e, 0, e.window[e.strstart - 1]), e.match_available = 0),
    e.insert = e.strstart < 2 ? e.strstart : 2,
    t === Gp ? (pu(e, !0), 0 === e.strm.avail_out ? 3 : 4) : e.sym_next && (pu(e, !1), 0 === e.strm.avail_out) ? 1 : 2
};
function bu(e, t, a, n, i) {
    this.good_length = e,
    this.max_lazy = t,
    this.nice_length = a,
    this.max_chain = n,
    this.func = i
}
const xu = [new bu(0, 0, 0, 0, _u), new bu(4, 4, 8, 4, Eu), new bu(4, 5, 16, 8, Eu), new bu(4, 6, 32, 32, Eu), new bu(4, 4, 16, 16, gu), new bu(8, 16, 32, 32, gu), new bu(8, 16, 128, 128, gu), new bu(8, 32, 128, 256, gu), new bu(32, 128, 258, 1024, gu), new bu(32, 258, 258, 4096, gu)];
function Tu() {
    this.strm = null,
    this.status = 0,
    this.pending_buf = null,
    this.pending_buf_size = 0,
    this.pending_out = 0,
    this.pending = 0,
    this.wrap = 0,
    this.gzhead = null,
    this.gzindex = 0,
    this.method = nu,
    this.last_flush = -1,
    this.w_size = 0,
    this.w_bits = 0,
    this.w_mask = 0,
    this.window = null,
    this.window_size = 0,
    this.prev = null,
    this.head = null,
    this.ins_h = 0,
    this.hash_size = 0,
    this.hash_bits = 0,
    this.hash_mask = 0,
    this.hash_shift = 0,
    this.block_start = 0,
    this.match_length = 0,
    this.prev_match = 0,
    this.match_available = 0,
    this.strstart = 0,
    this.match_start = 0,
    this.lookahead = 0,
    this.prev_length = 0,
    this.max_chain_length = 0,
    this.max_lazy_match = 0,
    this.level = 0,
    this.strategy = 0,
    this.good_match = 0,
    this.nice_match = 0,
    this.dyn_ltree = new Uint16Array(1146),
    this.dyn_dtree = new Uint16Array(122),
    this.bl_tree = new Uint16Array(78),
    ou(this.dyn_ltree),
    ou(this.dyn_dtree),
    ou(this.bl_tree),
    this.l_desc = null,
    this.d_desc = null,
    this.bl_desc = null,
    this.bl_count = new Uint16Array(16),
    this.heap = new Uint16Array(573),
    ou(this.heap),
    this.heap_len = 0,
    this.heap_max = 0,
    this.depth = new Uint16Array(573),
    ou(this.depth),
    this.sym_buf = 0,
    this.lit_bufsize = 0,
    this.sym_next = 0,
    this.sym_end = 0,
    this.opt_len = 0,
    this.static_len = 0,
    this.matches = 0,
    this.insert = 0,
    this.bi_buf = 0,
    this.bi_valid = 0
}
const vu = e => {
    if (!e)
        return 1;
    const t = e.state;
    return !t || t.strm !== e || 42 !== t.status && 57 !== t.status && 69 !== t.status && 73 !== t.status && 91 !== t.status && 103 !== t.status && 113 !== t.status && 666 !== t.status ? 1 : 0
}, Au = e => {
    if (vu(e))
        return iu(e, Qp);
    e.total_in = e.total_out = 0,
    e.data_type = au;
    const t = e.state;
    return t.pending = 0,
    t.pending_out = 0,
    t.wrap < 0 && (t.wrap = -t.wrap),
    t.status = 2 === t.wrap ? 57 : t.wrap ? 42 : 113,
    e.adler = 2 === t.wrap ? 0 : 1,
    t.last_flush = -2,
    Mp(t),
    Yp
}, yu = e => {
    const t = Au(e);
    var a;
    return t === Yp && ((a = e.state).window_size = 2 * a.w_size, ou(a.head), a.max_lazy_match = xu[a.level].max_lazy, a.good_match = xu[a.level].good_length, a.nice_match = xu[a.level].nice_length, a.max_chain_length = xu[a.level].max_chain, a.strstart = 0, a.block_start = 0, a.lookahead = 0, a.insert = 0, a.match_length = a.prev_length = 2, a.match_available = 0, a.ins_h = 0),
    t
}, wu = (e, t, a, n, i, s) => {
    if (!e)
        return Qp;
    let o = 1;
    if (t === Zp && (t = 6), n < 0 ? (o = 0, n = -n) : n > 15 && (o = 2, n -= 16), i < 1 || i > 9 || a !== nu || n < 8 || n > 15 || t < 0 || t > 9 || s < 0 || s > eu || 8 === n && 1 !== o)
        return iu(e, Qp);
    8 === n && (n = 9);
    const r = new Tu;
    return e.state = r,
    r.strm = e,
    r.status = 42,
    r.wrap = o,
    r.gzhead = null,
    r.w_bits = n,
    r.w_size = 1 << r.w_bits,
    r.w_mask = r.w_size - 1,
    r.hash_bits = i + 7,
    r.hash_size = 1 << r.hash_bits,
    r.hash_mask = r.hash_size - 1,
    r.hash_shift = ~~((r.hash_bits + 3 - 1) / 3),
    r.window = new Uint8Array(2 * r.w_size),
    r.head = new Uint16Array(r.hash_size),
    r.prev = new Uint16Array(r.w_size),
    r.lit_bufsize = 1 << i + 6,
    r.pending_buf_size = 4 * r.lit_bufsize,
    r.pending_buf = new Uint8Array(r.pending_buf_size),
    r.sym_buf = r.lit_bufsize,
    r.sym_end = 3 * (r.lit_bufsize - 1),
    r.level = t,
    r.strategy = s,
    r.method = a,
    yu(e)
};
var Su = wu, Nu = (e, t) => vu(e) || 2 !== e.state.wrap ? Qp : (e.state.gzhead = t, Yp), Cu = (e, t) => {
    if (vu(e) || t > qp || t < 0)
        return e ? iu(e, Qp) : Qp;
    const a = e.state;
    if (!e.output || 0 !== e.avail_in && !e.input || 666 === a.status && t !== Gp)
        return iu(e, 0 === e.avail_out ? Kp : Qp);
    const n = a.last_flush;
    if (a.last_flush = t, 0 !== a.pending) {
        if (lu(e), 0 === e.avail_out)
            return a.last_flush = -1, Yp
    } else if (0 === e.avail_in && su(t) <= su(n) && t !== Gp)
        return iu(e, Kp);
    if (666 === a.status && 0 !== e.avail_in)
        return iu(e, Kp);
    if (42 === a.status && 0 === a.wrap && (a.status = 113), 42 === a.status) {
        let t = nu + (a.w_bits - 8 << 4) << 8,
        n = -1;
        if (n = a.strategy >= $p || a.level < 2 ? 0 : a.level < 6 ? 1 : 6 === a.level ? 2 : 3, t |= n << 6, 0 !== a.strstart && (t |= 32), t += 31 - t % 31, du(a, t), 0 !== a.strstart && (du(a, e.adler >>> 16), du(a, 65535 & e.adler)), e.adler = 1, a.status = 113, lu(e), 0 !== a.pending)
            return a.last_flush = -1, Yp
    }
    if (57 === a.status)
        if (e.adler = 0, uu(a, 31), uu(a, 139), uu(a, 8), a.gzhead)
            uu(a, (a.gzhead.text ? 1 : 0) + (a.gzhead.hcrc ? 2 : 0) + (a.gzhead.extra ? 4 : 0) + (a.gzhead.name ? 8 : 0) + (a.gzhead.comment ? 16 : 0)), uu(a, 255 & a.gzhead.time), uu(a, a.gzhead.time >> 8 & 255), uu(a, a.gzhead.time >> 16 & 255), uu(a, a.gzhead.time >> 24 & 255), uu(a, 9 === a.level ? 2 : a.strategy >= $p || a.level < 2 ? 4 : 0), uu(a, 255 & a.gzhead.os), a.gzhead.extra && a.gzhead.extra.length && (uu(a, 255 & a.gzhead.extra.length), uu(a, a.gzhead.extra.length >> 8 & 255)), a.gzhead.hcrc && (e.adler = Op(e.adler, a.pending_buf, a.pending, 0)), a.gzindex = 0, a.status = 69;
        else if (uu(a, 0), uu(a, 0), uu(a, 0), uu(a, 0), uu(a, 0), uu(a, 9 === a.level ? 2 : a.strategy >= $p || a.level < 2 ? 4 : 0), uu(a, 3), a.status = 113, lu(e), 0 !== a.pending)
            return a.last_flush = -1, Yp;
    if (69 === a.status) {
        if (a.gzhead.extra) {
            let t = a.pending,
            n = (65535 & a.gzhead.extra.length) - a.gzindex;
            for (; a.pending + n > a.pending_buf_size; ) {
                let i = a.pending_buf_size - a.pending;
                if (a.pending_buf.set(a.gzhead.extra.subarray(a.gzindex, a.gzindex + i), a.pending), a.pending = a.pending_buf_size, a.gzhead.hcrc && a.pending > t && (e.adler = Op(e.adler, a.pending_buf, a.pending - t, t)), a.gzindex += i, lu(e), 0 !== a.pending)
                    return a.last_flush = -1, Yp;
                t = 0,
                n -= i
            }
            let i = new Uint8Array(a.gzhead.extra);
            a.pending_buf.set(i.subarray(a.gzindex, a.gzindex + n), a.pending),
            a.pending += n,
            a.gzhead.hcrc && a.pending > t && (e.adler = Op(e.adler, a.pending_buf, a.pending - t, t)),
            a.gzindex = 0
        }
        a.status = 73
    }
    if (73 === a.status) {
        if (a.gzhead.name) {
            let t,
            n = a.pending;
            do {
                if (a.pending === a.pending_buf_size) {
                    if (a.gzhead.hcrc && a.pending > n && (e.adler = Op(e.adler, a.pending_buf, a.pending - n, n)), lu(e), 0 !== a.pending)
                        return a.last_flush = -1, Yp;
                    n = 0
                }
                t = a.gzindex < a.gzhead.name.length ? 255 & a.gzhead.name.charCodeAt(a.gzindex++) : 0,
                uu(a, t)
            } while (0 !== t);
            a.gzhead.hcrc && a.pending > n && (e.adler = Op(e.adler, a.pending_buf, a.pending - n, n)),
            a.gzindex = 0
        }
        a.status = 91
    }
    if (91 === a.status) {
        if (a.gzhead.comment) {
            let t,
            n = a.pending;
            do {
                if (a.pending === a.pending_buf_size) {
                    if (a.gzhead.hcrc && a.pending > n && (e.adler = Op(e.adler, a.pending_buf, a.pending - n, n)), lu(e), 0 !== a.pending)
                        return a.last_flush = -1, Yp;
                    n = 0
                }
                t = a.gzindex < a.gzhead.comment.length ? 255 & a.gzhead.comment.charCodeAt(a.gzindex++) : 0,
                uu(a, t)
            } while (0 !== t);
            a.gzhead.hcrc && a.pending > n && (e.adler = Op(e.adler, a.pending_buf, a.pending - n, n))
        }
        a.status = 103
    }
    if (103 === a.status) {
        if (a.gzhead.hcrc) {
            if (a.pending + 2 > a.pending_buf_size && (lu(e), 0 !== a.pending))
                return a.last_flush = -1, Yp;
            uu(a, 255 & e.adler),
            uu(a, e.adler >> 8 & 255),
            e.adler = 0
        }
        if (a.status = 113, lu(e), 0 !== a.pending)
            return a.last_flush = -1, Yp
    }
    if (0 !== e.avail_in || 0 !== a.lookahead || t !== Hp && 666 !== a.status) {
        let n = 0 === a.level ? _u(a, t) : a.strategy === $p ? ((e, t) => {
            let a;
            for (; ; ) {
                if (0 === e.lookahead && (fu(e), 0 === e.lookahead)) {
                    if (t === Hp)
                        return 1;
                    break
                }
                if (e.match_length = 0, a = Up(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++, a && (pu(e, !1), 0 === e.strm.avail_out))
                    return 1
            }
            return e.insert = 0,
            t === Gp ? (pu(e, !0), 0 === e.strm.avail_out ? 3 : 4) : e.sym_next && (pu(e, !1), 0 === e.strm.avail_out) ? 1 : 2
        })(a, t) : a.strategy === Jp ? ((e, t) => {
            let a,
            n,
            i,
            s;
            const o = e.window;
            for (; ; ) {
                if (e.lookahead <= 258) {
                    if (fu(e), e.lookahead <= 258 && t === Hp)
                        return 1;
                    if (0 === e.lookahead)
                        break
                }
                if (e.match_length = 0, e.lookahead >= 3 && e.strstart > 0 && (i = e.strstart - 1, n = o[i], n === o[++i] && n === o[++i] && n === o[++i])) {
                    s = e.strstart + 258;
                    do {}
                    while (n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && n === o[++i] && i < s);
                    e.match_length = 258 - (s - i),
                    e.match_length > e.lookahead && (e.match_length = e.lookahead)
                }
                if (e.match_length >= 3 ? (a = Up(e, 1, e.match_length - 3), e.lookahead -= e.match_length, e.strstart += e.match_length, e.match_length = 0) : (a = Up(e, 0, e.window[e.strstart]), e.lookahead--, e.strstart++), a && (pu(e, !1), 0 === e.strm.avail_out))
                    return 1
            }
            return e.insert = 0,
            t === Gp ? (pu(e, !0), 0 === e.strm.avail_out ? 3 : 4) : e.sym_next && (pu(e, !1), 0 === e.strm.avail_out) ? 1 : 2
        })(a, t) : xu[a.level].func(a, t);
        if (3 !== n && 4 !== n || (a.status = 666), 1 === n || 3 === n)
            return 0 === e.avail_out && (a.last_flush = -1), Yp;
        if (2 === n && (t === jp ? Fp(a) : t !== qp && (Pp(a, 0, 0, !1), t === zp && (ou(a.head), 0 === a.lookahead && (a.strstart = 0, a.block_start = 0, a.insert = 0))), lu(e), 0 === e.avail_out))
            return a.last_flush = -1, Yp
    }
    return t !== Gp ? Yp : a.wrap <= 0 ? Vp : (2 === a.wrap ? (uu(a, 255 & e.adler), uu(a, e.adler >> 8 & 255), uu(a, e.adler >> 16 & 255), uu(a, e.adler >> 24 & 255), uu(a, 255 & e.total_in), uu(a, e.total_in >> 8 & 255), uu(a, e.total_in >> 16 & 255), uu(a, e.total_in >> 24 & 255)) : (du(a, e.adler >>> 16), du(a, 65535 & e.adler)), lu(e), a.wrap > 0 && (a.wrap = -a.wrap), 0 !== a.pending ? Yp : Vp)
}, Iu = e => {
    if (vu(e))
        return Qp;
    const t = e.state.status;
    return e.state = null,
    113 === t ? iu(e, Wp) : Yp
}, ku = (e, t) => {
    let a = t.length;
    if (vu(e))
        return Qp;
    const n = e.state,
    i = n.wrap;
    if (2 === i || 1 === i && 42 !== n.status || n.lookahead)
        return Qp;
    if (1 === i && (e.adler = kp(e.adler, t, a, 0)), n.wrap = 0, a >= n.w_size) {
        0 === i && (ou(n.head), n.strstart = 0, n.block_start = 0, n.insert = 0);
        let e = new Uint8Array(n.w_size);
        e.set(t.subarray(a - n.w_size, a), 0),
        t = e,
        a = n.w_size
    }
    const s = e.avail_in,
    o = e.next_in,
    r = e.input;
    for (e.avail_in = a, e.next_in = 0, e.input = t, fu(n); n.lookahead >= 3; ) {
        let e = n.strstart,
        t = n.lookahead - 2;
        do {
            n.ins_h = cu(n, n.ins_h, n.window[e + 3 - 1]),
            n.prev[e & n.w_mask] = n.head[n.ins_h],
            n.head[n.ins_h] = e,
            e++
        } while (--t);
        n.strstart = e,
        n.lookahead = 2,
        fu(n)
    }
    return n.strstart += n.lookahead,
    n.block_start = n.strstart,
    n.insert = n.lookahead,
    n.lookahead = 0,
    n.match_length = n.prev_length = 2,
    n.match_available = 0,
    e.next_in = o,
    e.input = r,
    e.avail_in = s,
    n.wrap = i,
    Yp
};
const Ru = (e, t) => Object.prototype.hasOwnProperty.call(e, t);
try {
    String.fromCharCode.apply(null, new Uint8Array(1))
} catch (A) {}
const Ou = new Uint8Array(256);
for (let e = 0; e < 256; e++)
    Ou[e] = e >= 252 ? 6 : e >= 248 ? 5 : e >= 240 ? 4 : e >= 224 ? 3 : e >= 192 ? 2 : 1;
Ou[254] = Ou[254] = 1;
var Du = e => {
    if ("function" == typeof TextEncoder && TextEncoder.prototype.encode)
        return (new TextEncoder).encode(e);
    let t,
    a,
    n,
    i,
    s,
    o = e.length,
    r = 0;
    for (i = 0; i < o; i++)
        a = e.charCodeAt(i), 55296 == (64512 & a) && i + 1 < o && (n = e.charCodeAt(i + 1), 56320 == (64512 & n) && (a = 65536 + (a - 55296 << 10) + (n - 56320), i++)), r += a < 128 ? 1 : a < 2048 ? 2 : a < 65536 ? 3 : 4;
    for (t = new Uint8Array(r), s = 0, i = 0; s < r; i++)
        a = e.charCodeAt(i), 55296 == (64512 & a) && i + 1 < o && (n = e.charCodeAt(i + 1), 56320 == (64512 & n) && (a = 65536 + (a - 55296 << 10) + (n - 56320), i++)), a < 128 ? t[s++] = a : a < 2048 ? (t[s++] = 192 | a >>> 6, t[s++] = 128 | 63 & a) : a < 65536 ? (t[s++] = 224 | a >>> 12, t[s++] = 128 | a >>> 6 & 63, t[s++] = 128 | 63 & a) : (t[s++] = 240 | a >>> 18, t[s++] = 128 | a >>> 12 & 63, t[s++] = 128 | a >>> 6 & 63, t[s++] = 128 | 63 & a);
    return t
}, Lu = function () {
    this.input = null,
    this.next_in = 0,
    this.avail_in = 0,
    this.total_in = 0,
    this.output = null,
    this.next_out = 0,
    this.avail_out = 0,
    this.total_out = 0,
    this.msg = "",
    this.state = null,
    this.data_type = 2,
    this.adler = 0
};
const Mu = Object.prototype.toString, {
    Z_NO_FLUSH: Pu,
    Z_SYNC_FLUSH: Bu,
    Z_FULL_FLUSH: Uu,
    Z_FINISH: Fu,
    Z_OK: Hu,
    Z_STREAM_END: ju,
    Z_DEFAULT_COMPRESSION: zu,
    Z_DEFAULT_STRATEGY: Gu,
    Z_DEFLATED: qu
} = Lp;
function Yu(e) {
    this.options = function (e) {
        const t = Array.prototype.slice.call(arguments, 1);
        for (; t.length; ) {
            const a = t.shift();
            if (a) {
                if ("object" != typeof a)
                    throw new TypeError(a + "must be non-object");
                for (const t in a)
                    Ru(a, t) && (e[t] = a[t])
            }
        }
        return e
    }
    ({
        level: zu,
        method: qu,
        chunkSize: 16384,
        windowBits: 15,
        memLevel: 8,
        strategy: Gu
    }, e || {});
    let t = this.options;
    t.raw && t.windowBits > 0 ? t.windowBits = -t.windowBits : t.gzip && t.windowBits > 0 && t.windowBits < 16 && (t.windowBits += 16),
    this.err = 0,
    this.msg = "",
    this.ended = !1,
    this.chunks = [],
    this.strm = new Lu,
    this.strm.avail_out = 0;
    let a = Su(this.strm, t.level, t.method, t.windowBits, t.memLevel, t.strategy);
    if (a !== Hu)
        throw new Error(Dp[a]);
    if (t.header && Nu(this.strm, t.header), t.dictionary) {
        let e;
        if (e = "string" == typeof t.dictionary ? Du(t.dictionary) : "[object ArrayBuffer]" === Mu.call(t.dictionary) ? new Uint8Array(t.dictionary) : t.dictionary, a = ku(this.strm, e), a !== Hu)
            throw new Error(Dp[a]);
        this._dict_set = !0
    }
}
function Vu(e, t) {
    const a = new Yu(t);
    if (a.push(e, !0), a.err)
        throw a.msg || Dp[a.err];
    return a.result
}
Yu.prototype.push = function (e, t) {
    const a = this.strm,
    n = this.options.chunkSize;
    let i,
    s;
    if (this.ended)
        return !1;
    for (s = t === ~~t ? t : !0 === t ? Fu : Pu, "string" == typeof e ? a.input = Du(e) : "[object ArrayBuffer]" === Mu.call(e) ? a.input = new Uint8Array(e) : a.input = e, a.next_in = 0, a.avail_in = a.input.length; ; )
        if (0 === a.avail_out && (a.output = new Uint8Array(n), a.next_out = 0, a.avail_out = n), (s === Bu || s === Uu) && a.avail_out <= 6)
            this.onData(a.output.subarray(0, a.next_out)), a.avail_out = 0;
        else {
            if (i = Cu(a, s), i === ju)
                return a.next_out > 0 && this.onData(a.output.subarray(0, a.next_out)), i = Iu(this.strm), this.onEnd(i), this.ended = !0, i === Hu;
            if (0 !== a.avail_out) {
                if (s > 0 && a.next_out > 0)
                    this.onData(a.output.subarray(0, a.next_out)), a.avail_out = 0;
                else if (0 === a.avail_in)
                    break
            } else
                this.onData(a.output)
        }
    return !0
}, Yu.prototype.onData = function (e) {
    this.chunks.push(e)
}, Yu.prototype.onEnd = function (e) {
    e === Hu && (this.result = (e => {
            let t = 0;
            for (let a = 0, n = e.length; a < n; a++)
                t += e[a].length;
            const a = new Uint8Array(t);
            for (let t = 0, n = 0, i = e.length; t < i; t++) {
                let i = e[t];
                a.set(i, n),
                n += i.length
            }
            return a
        })(this.chunks)),
    this.chunks = [],
    this.err = e,
    this.msg = this.strm.msg
};
var Qu = {
    Deflate: Yu,
    deflate: Vu,
    deflateRaw: function (e, t) {
        return (t = t || {}).raw = !0,
        Vu(e, t)
    },
    gzip: function (e, t) {
        return (t = t || {}).gzip = !0,
        Vu(e, t)
    },
    constants: Lp
};
const {
    Deflate: Wu,
    deflate: Ku,
    deflateRaw: Zu,
    gzip: Xu
} = Qu;
var $u = Ku;
const Ju = async e => {
    const {
        singleFilePath: t,
        injectsCode: a
    } = e,
    n = ln(),
    i = w.join(n, "/index.html"),
    s = Ya(i, "utf-8"),
    o = Ql(s);
    (e => {
        const {
            enableSplash: t = !0
        } = cn() || {},
        a = ln();
        e('link[type="text/css"]').toArray().forEach((t => {
                const n = e(t).attr("href");
                if (!n)
                    return;
                const i = Ya(w.join(a, n), "utf-8");
                e(`<style>${i}</style>`).appendTo("head")
            })),
        t || e("<style>#splash .progress-bar{opacity:0;visibility:hidden}</style>").appendTo("head"),
        e('link[type="text/css"]').remove(),
        e("head").find("style").each(((n, i) => {
                const s = /url\("?'?.*"?'?\)/g;
                let o = e(i).html() || "";
                const r = o.match(s);
                r && (r.forEach((e => {
                            const n = e.replace(/"|'|url|\(|\)/g, ""),
                            i = t ? en(w.join(a, n)) : "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7";
                            o = o.replace(s, `url(${i})`)
                        })), e(i).html(o).html())
            }))
    })(o),
    (e => {
        const t = ln();
        let a = "";
        e('script[type="systemjs-importmap"]').toArray().forEach((n => {
                const i = e(n).attr("src");
                if (!i)
                    return;
                let s = Ya(w.join(t, i), "utf-8");
                a += `<script type="systemjs-importmap">${s}<\/script>`
            })),
        e("head link").remove(),
        e("body script").remove(),
        e(a).appendTo("body")
    })(o);
    const {
        resMapper: r,
        compDiff: c
    } = await(async e => {
        const {
            isZip: t = !0,
            enableSplash: a = !0
        } = cn() || {}, {
            injectsCode: n,
            $: i
        } = e,
        s = ln();
        let o = [];
        const {
            resMapper: r
        } = await(async e => {
            const {
                dirPath: t,
                rmHttp: a = !1,
                unmountCbFn: n,
                mountCbFn: i,
                skipFiles: s = []
            } = e;
            let o = {};
            const r = za(t);
            for (let e = 0; e < r.length; e++) {
                const c = r[e],
                l = w.extname(c);
                if (Za.includes(l))
                    continue;
                if (s.length > 0 && s.includes(c))
                    continue;
                const p = $a(`${t}/`),
                u = $a(c).replace(p, "");
                let d = tn(c);
                i && (d = i(u, d)),
                a && ".js" === l && (d = d.replace(/XMLHttpRequest/g, "adapterFetch")),
                o[u] = d,
                n && n(u, d)
            }
            return {
                resMapper: o
            }
        })({
            dirPath: s,
            rmHttp: !0,
            mountCbFn: (e, t) => {
                if (-1 !== e.indexOf("src/settings.json")) {
                    const {
                        jsList: e,
                        settingsData: n
                    } = (e => {
                        let t = JSON.parse(e);
                        t.plugins = {
                            jsList: [],
                            ...t.plugins
                        };
                        const a = [...t.plugins.jsList];
                        return t.plugins.jsList = [], {
                            jsList: a,
                            settingsData: t
                        }
                    })(t);
                    return o = e,
                    !a && n?.splashScreen?.totalTime && (n.splashScreen.totalTime = 0),
                    JSON.stringify(n)
                }
                if (-1 !== e.indexOf("src/settings.js")) {
                    const {
                        jsList: e,
                        settingsData: a
                    } = (e => {
                        const t = {
                            jsList: [],
                            settingsData: e
                        };
                        let a = e.split("jsList:");
                        if (a.length < 2)
                            return t;
                        const n = a.pop() || "",
                        i = /\[[^\]]*\]/.exec(n);
                        if (!i)
                            return t;
                        const s = i[0];
                        return {
                            jsList: JSON.parse(s),
                            settingsData: e.replace(s, "[]")
                        }
                    })(t);
                    return o = e,
                    a
                }
                return t
            }
        });
        let c = JSON.stringify(r),
        l = 0;
        if (t) {
            const e = $u(c),
            t = Buffer.from(e).toString("base64");
            console.log("【Origin Pkg Size】", c.length, "【Compressed Pkg Size】", t.length),
            t.length < c.length ? (l = c.length - t.length, console.log("【Compressed】", l), c = t) : console.log("【Compressed】", "Compression is not recommended, the compressed file is too large")
        }
        return l > 0 ? (i(`<script data-id="jszip">${Zl}<\/script>`).appendTo("body"), i(`<script data-id="adapter-zip-0">window.__adapter_zip__="${c}";<\/script>`).appendTo("body")) : i(`<script data-id="adapter-resource-0">window.__adapter_resource__=${c}<\/script>`).appendTo("body"),
        i(`<script data-id="adapter-plugins">window.__adapter_plugins__=${JSON.stringify(o)}<\/script>`).appendTo("body"),
        i(`<script data-id="adapter-init">${n.init}<\/script>`).appendTo("body"),
        i(`<script data-id="adapter-main">${n.main}<\/script>`).appendTo("body"), {
            resMapper: r,
            compDiff: l
        }
    })({
        injectsCode: a,
        $: o
    });
    var l;
    return Va(t, o.html()),
    console.info(`【Single file template successfully generated】 File size: ${l = t, I.statSync(l).size / 1024}kb`), {
        resMapper: r,
        compDiff: c
    }
}, ed = (e, t, a) => new Promise((async(n, i) => {
        "serial" === a ? (async e => {
            const {
                channelExports: t,
                options: a,
                resolve: n,
                reject: i
            } = e;
            try {
                const {
                    exportChannels: e = []
                } = cn() || {};
                let i = 0 === e.length ? Object.keys(t) : e;
                for (let e = 0; e < i.length; e++) {
                    const n = i[e];
                    await t[n](a)
                }
                n()
            } catch (e) {
                i(e)
            }
        })({
            channelExports: e,
            options: t,
            resolve: n,
            reject: i
        }) : (e => {
            const {
                channelExports: t,
                options: a,
                resolve: n,
                reject: i
            } = e, {
                exportChannels: s = []
            } = cn() || {};
            let o = 0 === s.length ? Object.keys(t) : s,
            r = [];
            o.forEach((e => {
                    (0 === s.length || s.includes(e)) && r.push(t[e](a))
                })),
            Promise.all(r).then((() => {
                    n()
                })).catch((e => {
                    console.error(e),
                    i(e)
                }))
        })({
            channelExports: e,
            options: t,
            resolve: n,
            reject: i
        })
    })), td = async(e, t) => {
    const a = cn();
    if (!a || !a.injectOptions || !a.injectOptions[t])
        return;
    const {
        head: n,
        body: i
    } = a.injectOptions[t];
    n && e(n).appendTo("head"),
    i && e("body script").first().before(i)
}, ad = 1677721.6, nd = (e, t) => {
    let {
        channel: a,
        resMapper: n,
        compDiff: i
    } = t;
    n = (e => {
        const {
            channel: t,
            resMapper: a
        } = e;
        if (!a)
            return {};
        for (const [e, n] of Object.entries(a))
            a[e] = n.replaceAll(Wa, t);
        return a
    })({
        channel: a,
        resMapper: n ? {
            ...n
        }
         : {},
        $: e
    }),
    (i ?? 0) > 0 ? ((e, t) => {
        const {
            resMapper: a
        } = t,
        n = $u(JSON.stringify(a));
        let i = Buffer.from(n).toString("base64"),
        s = Number(ad.toFixed(0)),
        o = Math.ceil(i.length / s);
        for (let t = 0; t < o; t++) {
            const a = i.slice(t * s, (t + 1) * s);
            0 === t ? e('script[data-id="adapter-zip-0"]').html(`window.__adapter_zip__="${a}";`) : e(`script[data-id="adapter-zip-${t - 1}"]`).after(`<script data-id="adapter-zip-${t}">window.__adapter_zip__+="${a}";<\/script>`)
        }
        e(`<script data-id="jszip">${Zl}<\/script>`).appendTo("body")
    })(e, {
        resMapper: n
    }) : ((e, t) => {
        const a = (t, a) => {
            const n = JSON.stringify(t),
            i = `<script data-id="adapter-resource-${a}">Object.assign(window.__adapter_resource__, ${n});<\/script>`;
            0 !== a ? e(`script[data-id="adapter-resource-${a - 1}"]`).after(i) : e('script[data-id="adapter-resource-0"]').html(`window.__adapter_resource__=${n};`)
        }, {
            resMapper: n
        } = t;
        if (!n)
            return;
        const i = Number(ad.toFixed(0));
        let s = 0,
        o = 0,
        r = {};
        for (const [e, t] of Object.entries(n)) {
            const n = t.length;
            n >= i ? (a({
                    [e]: t
                }, o), o++) : (s + n >= i && (a(r, o), r = {}, s = 0, o++), r[e] = t, s += n)
        }
        s > 0 && a(r, o)
    })(e, {
        resMapper: n
    })
}, id = async(e, t) => {
    const {
        channel: a,
        transformHTML: n,
        transform: i
    } = t;
    console.info(`【${a}】adaptation started`);
    const s = Ya(e, "utf-8"),
    o = w.join(sn(), `${a}.html`);
    let r = Ql(s);
    nd(r, t),
    await td(r, a),
    Va(o, r.html()),
    n && (await n(r), Va(o, r.html())),
    i && await i(o),
    console.info(`【${a}】adaptation completed`)
}, sd = async e => {
    const {
        channel: t,
        transformHTML: a,
        transform: n
    } = e;
    console.info(`【${t}】adaptation started`);
    const i = ln(),
    s = sn(),
    o = w.join(s, t);
    qa(i, o),
    Ja(o, t);
    const r = w.join(o, "/index.html"),
    c = Ya(r, "utf-8"),
    l = Ql(c);
    await td(l, t),
    a && await a(l),
    Va(r, l.html()),
    n && await n(o),
    console.info(`【${t}】adaptation completed`)
}, od = async(e, t) => {
    const {
        channel: a,
        transformHTML: n,
        transform: i,
        transformScript: s,
        resMapper: o,
        compDiff: r
    } = t;
    console.info(`【${a}】adaptation started`);
    const c = e,
    l = sn(),
    p = w.join(l, a);
    Ga(p);
    const u = w.join(p, "/index.html"),
    d = w.join(p, "/js");
    I.mkdirSync(d, {
        recursive: !0
    });
    let h = Ql(Ya(c, "utf-8"));
    nd(h, t),
    await td(h, a);
    const m = h('body script[type!="systemjs-importmap"]');
    for (let e = 0; e < m.length; e++) {
        const t = h(m[e]);
        s && await s(t);
        let a = t.text();
        const n = `index${e}.js`,
        i = w.join(d, n);
        t.replaceWith(`<script src="./js/${n}"><\/script>`),
        Va(i, a)
    }
    if (Va(u, h.html()), n) {
        await n(h);
        const e = w.join(p, "/index.html");
        Va(e, h.html())
    }
    i && await i(p),
    console.info(`【${a}】adaptation completed`)
}, rd = async e => {
    await id(on(), e)
}, cd = async e => {
    await sd(e)
}, ld = async e => {
    await od(on(), e)
}, pd = async e => {
    await id(rn(), e)
}, ud = async e => {
    await sd(e)
}, dd = async e => {
    await od(rn(), e)
}, hd = '<meta name="ad.orientation" content="landscape"><meta name="ad.size" content="width=480,height=320">', 
md = '<meta name="ad.orientation" content="portrait"><meta name="ad.size" content="width=320,height=480">', 
fd = '<script type="text/javascript" src="https://tpc.googlesyndication.com/pagead/gadgets/html5/api/exitapi.js"><\/script>', 
_d = '<script>function getScript(e,i){var n=document.createElement("script");n.type="text/javascript",n.async=!0,i&&(n.onload=i),n.src=e,document.head.appendChild(n)}function parseMessage(e){var i=e.data,n=i.indexOf(DOLLAR_PREFIX+RECEIVE_MSG_PREFIX);if(-1!==n){var t=i.slice(n+2);return getMessageParams(t)}return{}}function getMessageParams(e){var i,n=[],t=e.split("/"),a=t.length;if(-1===e.indexOf(RECEIVE_MSG_PREFIX)){if(a>=2&&a%2===0)for(i=0;a>i;i+=2)n[t[i]]=t.length<i+1?null:decodeURIComponent(t[i+1])}else{var o=e.split(RECEIVE_MSG_PREFIX);void 0!==o[1]&&(n=JSON&&JSON.parse(o[1]))}return n}function getDapi(e){var i=parseMessage(e);if(!i||i.name===GET_DAPI_URL_MSG_NAME){var n=i.data;getScript(n,onDapiReceived)}}function invokeDapiListeners(){for(var e in dapiEventsPool)dapiEventsPool.hasOwnProperty(e)&&dapi.addEventListener(e,dapiEventsPool[e])}function onDapiReceived(){dapi=window.dapi,window.removeEventListener("message",getDapi),invokeDapiListeners()}function init(){window.dapi.isDemoDapi&&(window.parent.postMessage(DOLLAR_PREFIX+SEND_MSG_PREFIX+JSON.stringify({state:"getDapiUrl"}),"*"),window.addEventListener("message",getDapi,!1))}var DOLLAR_PREFIX="$$",RECEIVE_MSG_PREFIX="DAPI_SERVICE:",SEND_MSG_PREFIX="DAPI_AD:",GET_DAPI_URL_MSG_NAME="connection.getDapiUrl",dapiEventsPool={},dapi=window.dapi||{isReady:function(){return!1},addEventListener:function(e,i){dapiEventsPool[e]=i},removeEventListener:function(e){delete dapiEventsPool[e]},isDemoDapi:!0};init();<\/script>', 
Ed = '<script src="https://sf-tb-sg.ibytedtos.com/obj/ttfe-malisg/playable/sdk/index.b5662ec443f458c8a87e.js"><\/script>', 
gd = '<script src="cordova.js"><\/script><script>function onLoad(){document.addEventListener("deviceready",()=>{navigator.splashscreen.hide()},false)}<\/script>', 
bd = '<script src="https://sf3-ttcdn-tos.pstatp.com/obj/union-fe-nc/playable/sdk/playable-sdk.js" data-tomark-pass><\/script>', 
xd = '<script src="https://sf16-muse-va.ibytedtos.com/obj/union-fe-nc-i18n/playable/sdk/playable-sdk.js"><\/script>', 
Td = {
    AppLovin: async e => {
        const t = "AppLovin";
        await rd({
            ...e,
            channel: t,
            transformHTML: async e => {
                e(un(t) || '<script src="mraid.js"><\/script>').appendTo("head")
            }
        })
    },
    Facebook: async e => {
        await ld({
            ...e,
            channel: "Facebook"
        })
    },
    Google: async e => {
        const {
            orientation: t
        } = e,
        a = "Google";
        await rd({
            ...e,
            channel: a,
            transformHTML: async e => {
                e("landscape" === t ? hd : md).appendTo("head"),
                e(un(a) || fd).appendTo("head")
            }
        })
    },
    IronSource: async e => {
        const t = "IronSource";
        await rd({
            ...e,
            channel: t,
            transformHTML: async e => {
                e(un(t) || _d).appendTo("head")
            }
        })
    },
    Liftoff: async e => {
        const t = "Liftoff";
        await rd({
            ...e,
            channel: t,
            transformHTML: async e => {
                e(un(t) || '<script src="mraid.js"><\/script>').appendTo("head")
            }
        })
    },
    Mintegral: async e => {
        await ld({
            ...e,
            channel: "Mintegral"
        })
    },
    Moloco: async e => {
        await rd({
            ...e,
            channel: "Moloco"
        })
    },
    Pangle: async e => {
        const {
            orientation: t
        } = e,
        a = "Pangle";
        await cd({
            ...e,
            channel: a,
            transformHTML: async e => {
                e(un(a) || Ed).appendTo("head")
            },
            transform: async e => {
                await Xa({
                    destPath: e,
                    orientation: t
                })
            }
        })
    },
    Rubeex: async e => {
        const {
            orientation: t
        } = e,
        a = "Rubeex";
        await cd({
            ...e,
            channel: a,
            transformHTML: async e => {
                e(gd).appendTo("head"),
                e("body").attr("onload", "onLoad()");
                const t = un(a) || bd;
                e("body script").first().before(t)
            },
            transform: async e => {
                await Xa({
                    destPath: e,
                    orientation: t
                })
            }
        })
    },
    Tiktok: async e => {
        const {
            orientation: t
        } = e,
        a = "Tiktok";
        await cd({
            ...e,
            channel: a,
            transformHTML: async e => {
                e(un(a) || xd).appendTo("head")
            },
            transform: async e => {
                await Xa({
                    destPath: e,
                    orientation: t
                })
            }
        })
    },
    Unity: async e => {
        const t = "Unity";
        await rd({
            ...e,
            channel: t,
            transformHTML: async e => {
                const a = un(t) || '<script src="mraid.js"><\/script>';
                e("body script").first().before(a)
            }
        })
    }
}, vd = {
    AppLovin: async e => {
        const t = "AppLovin";
        await pd({
            ...e,
            channel: t,
            transformHTML: async e => {
                e(un(t) || '<script src="mraid.js"><\/script>').appendTo("head")
            }
        })
    },
    Facebook: async e => {
        await dd({
            ...e,
            channel: "Facebook"
        })
    },
    Google: async e => {
        const {
            orientation: t
        } = e,
        a = "Google";
        await pd({
            ...e,
            channel: a,
            transformHTML: async e => {
                e("landscape" === t ? hd : md).appendTo("head"),
                e(un(a) || fd).appendTo("head")
            }
        })
    },
    IronSource: async e => {
        const t = "IronSource";
        await pd({
            ...e,
            channel: t,
            transformHTML: async e => {
                e(un(t) || _d).appendTo("head")
            }
        })
    },
    Liftoff: async e => {
        const t = "Liftoff";
        await pd({
            ...e,
            channel: t,
            transformHTML: async e => {
                e(un(t) || '<script src="mraid.js"><\/script>').appendTo("head")
            }
        })
    },
    Mintegral: async e => {
        await dd({
            ...e,
            channel: "Mintegral"
        })
    },
    Moloco: async e => {
        await pd({
            ...e,
            channel: "Moloco"
        })
    },
    Pangle: async e => {
        const {
            orientation: t
        } = e,
        a = "Pangle";
        await ud({
            ...e,
            channel: a,
            transformHTML: async e => {
                e(un(a) || Ed).appendTo("head")
            },
            transform: async e => {
                await Xa({
                    destPath: e,
                    orientation: t
                })
            }
        })
    },
    Rubeex: async e => {
        const {
            orientation: t
        } = e,
        a = "Rubeex";
        await ud({
            ...e,
            channel: a,
            transformHTML: async e => {
                e(gd).appendTo("head"),
                e("body").attr("onload", "onLoad()");
                const t = un(a) || bd;
                e("body script").first().before(t)
            },
            transform: async e => {
                await Xa({
                    destPath: e,
                    orientation: t
                })
            }
        })
    },
    Tiktok: async e => {
        const {
            orientation: t
        } = e,
        a = "Tiktok";
        await ud({
            ...e,
            channel: a,
            transformHTML: async e => {
                e(un(a) || xd).appendTo("head")
            },
            transform: async e => {
                await Xa({
                    destPath: e,
                    orientation: t
                })
            }
        })
    },
    Unity: async e => {
        const t = "Unity";
        await pd({
            ...e,
            channel: t,
            transformHTML: async e => {
                const a = un(t) || '<script src="mraid.js"><\/script>';
                e("body script").first().before(a)
            }
        })
    }
};
v.exec2xAdapter = async(e, t) => {
    an(e);
    try {
        const {
            success: e,
            msg: t
        } = await hn();
        e || console.warn(`${t}，aborting the image compression process`)
    } catch (e) {
        console.error(e)
    }
    const {
        resMapper: a,
        compDiff: n
    } = await(async() => await Ju({
                injectsCode: Wl,
                singleFilePath: on()
            }))(), {
        orientation: i = "auto"
    } = cn() || {}, {
        mode: s = "parallel"
    } = t ?? {
        mode: "parallel"
    };
    await((e, t) => ed(Td, e, t ?? "parallel"))({
        orientation: i,
        resMapper: a,
        compDiff: n
    }, s),
    nn()
}, exports.exec3xAdapter = v.exec3xAdapter = async(e, t) => {
    an(e);
    try {
        const {
            success: e,
            msg: t
        } = await hn();
        e || console.warn(`${t}，aborting the image compression process`)
    } catch (e) {
        console.error(e)
    }
    const {
        resMapper: a,
        compDiff: n
    } = await(async() => await Ju({
                injectsCode: Kl,
                singleFilePath: rn()
            }))(), {
        orientation: i = "auto"
    } = cn() || {}, {
        mode: s = "parallel"
    } = t ?? {
        mode: "parallel"
    };
    await((e, t) => ed(vd, e, t ?? "parallel"))({
        orientation: i,
        resMapper: a,
        compDiff: n
    }, s),
    nn()
};
